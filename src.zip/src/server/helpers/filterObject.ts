/**
 * filterObject
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
type Entry<T> = {
    [K in keyof T]: [K, T[K]];
}[keyof T];

export function filterObject<T extends object>(obj: T, fn: (entry: Entry<T>, i: number, arr: Entry<T>[]) => boolean) {
    return Object.fromEntries((Object.entries(obj) as Entry<T>[]).filter(fn)) as Partial<T>;
}
