/**
 * pgQuery interface
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */

export interface IpgQuery {
    // postgresSql query simple Interface
    select: string;
    from: string[];
    count?: string;
    where?: string;
    orderBy?: string;
    join?: string;
    groupBy?: string;
    skip?: number;
    limit?: number;
    keys: string[];
}
