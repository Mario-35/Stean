/**
 * Model Maker
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */

import { config } from "../configuration";
import { _STREAM } from "../db/constants";
import { queries } from "../db/queries";
import { EColumnType, EConstant, EDataType, EErrors, EExtensions, EInfos, ERelations } from "../enums";
import { doubleQuotes, deepClone, isTest, formatPgTableColumn, isString, hidePassword } from "../helpers";
import { Iservice, Ientities, Ientity, IstreamInfos, koaContext, IentityRelation, getColumnType, IentityColumn, Id } from "../types";
import {
    LORASTREAMS,
    DECODER,
    LORA,
    USER,
    PAYLOAD,
    CREATEOBSERVATION,
    DATASTREAM,
    FEATUREOFINTEREST,
    HISTORICALLOCATION,
    LOCATION,
    LOCATIONHISTORICALLOCATION,
    LOG,
    MULTIDATASTREAM,
    OBSERVATION,
    OBSERVEDPROPERTY,
    SENSOR,
    SERVICE,
    THING,
    THINGLOCATION,
    MULTIDATASTREAMOBSERVEDPROPERTY
} from "./entities";
import { Geometry, Jsonb, Numeric, Text, Texts } from "./types";
import { logging } from "../log";
import { executeSql, executeSqlValues } from "../db/helpers";

export class Models {
    static models: {
        [key: string]: Ientities;
    } = {};

    public async infos(ctx: koaContext) {
        const temp = ctx._.toString();
        let model = "https://app.diagrams.net?lightbox=1&edit=_blank#Uhttps%3A%2F%2Fraw.githubusercontent.com%2FMario-35%2FStean%2Frefs%2Fheads%2Fmain%2Fdrawio%2FSTA%2520V1.1.drawio";
        if (ctx._.service._lora) model = "https://viewer.diagrams.net/?tags=%7B%7D&lightbox=1&highlight=0000ff&edit=_blank&layers=1&nav=1&title=STA%20V1.1.Lora.drawio&dark=auto#Uhttps%3A%2F%2Fraw.githubusercontent.com%2FMario-35%2FStean%2Fmain%2Fdrawio%2FSTA%2520V1.1.Lora.drawio";
        
        const result: Record<string, any> = {
            ...hidePassword(temp),
            model: model,
            ready: config.connection(ctx._.service.name) ? true : false,
            Postgres: {},
            users: {}
        };

        const extensions: Record<string, any> = {};
        switch (ctx._.service.apiVersion) {
            case "20":
                result["Ogc link"] = "https://hylkevds.github.io/23-019/23-019.html";
                break;
            case "11":
                result["Ogc link"] = "https://docs.ogc.org/is/18-088/18-088.html";
                break;
            default:
                result["Ogc link"] = "https://docs.ogc.org/is/15-078r6/15-078r6.html";
                break;
        }
        if (ctx._.inExtension(EExtensions.tasking)) extensions["tasking"] = "https://docs.ogc.org/is/17-079r1/17-079r1.html";

        await executeSqlValues(
            ctx._.service,
            ` select version(), (SELECT ARRAY(SELECT extname||'-'||extversion AS extension FROM pg_extension) AS extension), (SELECT c.relname||'.'||a.attname FROM pg_attribute a JOIN pg_class c ON (a.attrelid=c.relfilenode) WHERE a.atttypid = 114) ;`
        ).then((res) => {
            result["Postgres"]["version"] = res[0 as keyof object];
            result["Postgres"]["extensions"] = res[1 as keyof object];
        });
        if(ctx._.inExtension(EExtensions.users))
        await executeSql(ctx._.service, `select username, "canPost", "canDelete", "canCreateUser", "canCreateDb", "admin", "superAdmin" FROM public.user ORDER By username;`).then((res) => {
            Object.keys(res).forEach((e) => {
                result["users"][res[+e as keyof object]["username"]] = {
                    "canPost": res[+e as keyof object]["canPost"],
                    "canDelete": res[+e as keyof object]["canDelete"],
                    "canCreateUser": res[+e as keyof object]["canCreateUser"],
                    "canCreateDb": res[+e as keyof object]["canCreateDb"],
                    "admin": res[+e as keyof object]["admin"],
                    "superAdmin": res[+e as keyof object]["superAdmin"]
                };
            });
        });
        await executeSqlValues(
            ctx._.service,
            `SELECT array_agg(table_name) FROM information_schema.tables WHERE table_schema LIKE 'public' AND table_type LIKE 'BASE TABLE' AND position('_' in table_name) = 0`
        ).then(async (res: Record<string, any>) => {
            await executeSql(
                ctx._.service,
                ` SELECT JSON_AGG(t) AS results FROM ( SELECT ${res[0 as keyof object].map((e: string) => `(SELECT COUNT(*) FROM "${e}") AS "${e}"${EConstant.return}`).join()}) AS t`
            ).then((res) => {
                result["tables"] = res[0 as keyof object]["results"][0 as keyof object];
            });
        });
        if (ctx._.service._partitioned === true)
            await executeSql(ctx._.service, queries.countAll()).then((res) => {
                result["partitioned"] = {};
                Object.values(res[0 as keyof object]["results"]).forEach((e: any) => (result["partitioned"][e["table_name"]] = e["count"]));
            });

        return result;
    }

    // Get multiDatastream or Datastreams infos
    public async streamInfos(ctx: koaContext, input: Record<string, any>): Promise<IstreamInfos | undefined> {
        console.log(logging.whereIam(new Error().stack));
        const stream: _STREAM = input["Datastream"] ? "Datastream" : input["MultiDatastream"] ? "MultiDatastream" : undefined;
        if (!stream) return undefined;
        const streamEntity = models.entityName(ctx._.model(), stream);
        if (!streamEntity) return undefined;
        const foiId: Id = input["FeaturesOfInterest"] ? input["FeaturesOfInterest"] : undefined;
        const searchKey = input[models.getModel(ctx._.service)[streamEntity].name] || input[models.getModel(ctx._.service)[streamEntity].singular];
        const streamId: Id = isNaN(searchKey) ? searchKey[EConstant.id] : searchKey;
        if (streamId) {
            return executeSqlValues(
                ctx._.service,
                queries.asJson({
                    query: `SELECT "id", "observationType", "_default_featureofinterest" FROM ${doubleQuotes(models.getModel(ctx._.service)[streamEntity].table)} WHERE "id" = ${BigInt(
                        streamId
                    )} LIMIT 1`,
                    singular: true,
                    strip: false,
                    count: false
                })
            )
                .then((res: object) => {
                    return res
                        ? {
                              type: stream,
                              id: res[0 as keyof object]["id"],
                              observationType: res[0 as keyof object]["observationType"],
                              FoId: foiId ? foiId : res[0 as keyof object]["_default_featureofinterest"]
                          }
                        : undefined;
                })
                .catch((error) => {
                    logging.error(error, EInfos.createUser);
                    return undefined;
                });
        }
    }

    // Internal create version
    /**
     *
     * @param entities list of entities to create
     * @param extensions extensions services
     * @returns Ientities
     */
    private makeModel(entities: Ientity[], service?: Iservice) {
        const base: Ientities = {};
        entities.forEach((e) => {
            base[e.name] = e;
        });
        if ((service && service._lora === true) || !service) {
            base["LoraStreams"] = LORASTREAMS;
            const streamObject = {
                type: ERelations.hasMany,
                entityRelation: LORASTREAMS.name
            };
            base["Decoders"] = DECODER;
            base["Loras"] = LORA;
            base["Datastreams"].relations["Loras"] = streamObject;
            base["MultiDatastreams"].relations["Loras"] = streamObject;
            base["Payload"] = PAYLOAD;
        }
        if (service && service.extensions && service.extensions.includes(EExtensions.users)) 
            base["Users"] = USER;
        
        return base;
    }

    private version1_0(service: Iservice): Ientities {
        return this.makeModel(
            [
                THING,
                FEATUREOFINTEREST,
                LOCATION,
                THINGLOCATION,
                HISTORICALLOCATION,
                LOCATIONHISTORICALLOCATION,
                OBSERVEDPROPERTY,
                SENSOR,
                DATASTREAM,
                MULTIDATASTREAM,
                OBSERVATION,
                SERVICE,
                LOG,
                CREATEOBSERVATION,
                MULTIDATASTREAMOBSERVEDPROPERTY
            ],
            service
        );
    }

    private version1_1(entities: Ientities): Ientities {
        // add properties to entities
        ["Locations", "FeaturesOfInterest", "ObservedProperties", "Sensors", "Datastreams", "MultiDatastreams"].forEach((entityName: string) => {
            if (entities[entityName]) entities[entityName].columns["properties"] = new Jsonb().column();
        });
        // add geom to Location
        entities.Locations.columns["geom"] = new Geometry().column();
        return entities;
    }

    private createVersion(verStr: string, service: Iservice): Ientities {
        console.log(logging.whereIam(new Error().stack));
        switch (verStr) {
            case "v1.0":
                return this.version1_0(service);
            case "v1.1":
                return this.version1_1(deepClone(this.version1_0(service)));
            case "v2.0":
                return this.version2_0(this.version1_1(deepClone(this.version1_0(service))));
            default:
                return {};
        }
    }

    version2_0(entities: Ientities): Ientities {
        // add properties to entities
        ["Things", "Locations", "Sensors", "ObservedProperties", "Sensors", "Datastreams", "MultiDatastreams"].forEach((entityName: string) => {
            if (entities[entityName]) entities[entityName].columns["description"] = new Texts().column();
        });
        // add geom to Location
        entities.Locations.columns["geom"] = new Geometry().column();
        return entities;
    }

    public listVersion() {
        // MUST BE SORTED
        return ["v1.0", "v1.1","v2.0"];
    }

    public getService(service: Iservice | string): Iservice {
        if (typeof service === "string") {
            const nameConfig = config.getConfigNameFromName(service);
            if (!nameConfig) throw new Error(EErrors.configName);
            return config.getService(nameConfig);
        }
        return service;
    }

    public listTables(entities: Ientities): string[] {
        console.log(logging.whereIam(new Error().stack));
        return Object.values(entities)
            .map((e) => e.table)
            .filter((e) => e.trim() !== "");
    }

    public addTriggersOnTables(entities: Ientities, triggerName: string): string[] {
        return this.listTables(entities).map((table) => queries.createTrigger(table, triggerName));
    }

    public removeTriggersOnTables(entities: Ientities, triggerName: string): string[] {
        return this.listTables(entities).map((table) => queries.dropTrigger(table, triggerName));
    }

    public isEntitySingular(entities: Ientities, tableName: string): boolean {
        if (config && tableName) {
            const entityName = this.entityName(entities, tableName);
            return entityName ? entities[entityName].singular == tableName : false;
        }
        return false;
    }

    public entityName(entities: Ientities, search: string): string | undefined {
        const testString: string | undefined = search
            .trim()
            .match(/[a-zA-Z_]/g)
            ?.join("");
        return testString
            ? entities.hasOwnProperty(testString)
                ? testString
                : Object.keys(entities).filter((elem: string) => entities[elem].table == testString.toLowerCase() || entities[elem].singular == testString)[0]
            : undefined;
    }

    public entityStrict = (entities: Ientities, entity: Ientity | string): Ientity | undefined => {
        return typeof entity === "string" ? entities[entity] : entities[entity.name];
    };

    public entity = (entities: Ientities, entity: Ientity | string): Ientity | undefined => {
        return entities[this.entityName(entities, isString(entity) ? entity.trim() : entity.name) || ""];
    };

    public entityColumn = (entities: Ientities, entity: Ientity | string, columnName: string): IentityColumn | undefined => {
        return entities[this.entity(entities, entity)?.name || ""].columns[columnName];
    };

    public entityColumnType = (entities: Ientities, entity: Ientity | string, columnName: string): EDataType => {
        return entities[this.entity(entities, entity)?.name || ""].columns[columnName].dataType;
    };

    public entityRelationName = (entity: Ientity, searchs: string[]): string | undefined => {
        let res: string | undefined = undefined;
        searchs.forEach((e) => {
            if (entity.relations[e]) {
                res = e;
                return;
            }
        });
        return res;
    };

    public entityRelation = (entities: Ientities, entity: Ientity, relation: Ientity | string): IentityRelation | undefined => {
        const entityRelation = this.entity(entities, relation);
        return entityRelation ? entity.relations[entityRelation.name] || entity.relations[entityRelation.singular] : undefined;
    };

    public entityRelationColumnTable = (entities: Ientities, entity: Ientity | string, test: string): EColumnType | undefined => {
        const tempEntity = this.entity(entities, entity);
        if (tempEntity) return tempEntity.relations.hasOwnProperty(test) ? EColumnType.Relation : tempEntity.columns.hasOwnProperty(test) ? EColumnType.Column : undefined;
    };

    public entityColumnListForSelect(entities: Ientities, entity: Ientity | string, complete: boolean, exclus?: string[]) {
        const tempEntity = this.entity(entities, entity);
        return tempEntity
            ? Object.keys(tempEntity.columns)
                  .filter((word) => !word.includes("_") && !(exclus || [""]).includes(word))
                  .map((e: string) => (complete ? formatPgTableColumn(tempEntity.table, e) : doubleQuotes(e)))
            : [];
    }

    public isEntityColumnType(entities: Ientities, entity: Ientity | string, column: string, test: string): boolean {
        if (config && entity) {
            const tempEntity = this.entity(entities, entity);
            return tempEntity && tempEntity.columns[column] ? getColumnType(tempEntity.columns[column]) === test.toLowerCase() : false;
        }
        return false;
    }

    public root(ctx: koaContext) {
        console.log(logging.whereIam(new Error().stack));
        let expectedResponse: object[] = [];
        Object.keys(ctx._.model())
            .filter((elem: string) => ctx._.model()[elem].order > 0)
            .sort((a, b) => (ctx._.model()[a].order > ctx._.model()[b].order ? 1 : -1))
            .forEach((value: string) => {
                expectedResponse.push({
                    name: ctx._.model()[value].name,
                    url: `${ctx._.base()}/${ctx._.service.apiVersion}/${value}`
                });
            });

        switch (ctx._.service.apiVersion) {
            case "v1.0":
                return {
                    value: expectedResponse.filter((elem) => Object.keys(elem).length)
                };
            case "v1.1":
                expectedResponse = expectedResponse.filter((elem) => Object.keys(elem).length);
                // base
                const list: string[] = [
                    "https://docs.ogc.org/is/18-088/18-088.html",
                    // list.push("https://docs.ogc.org/is/18-088/18-088.html#req-batch-request-batch-request");
                    "https://docs.ogc.org/is/18-088/18-088.html#uri-components",
                    "https://docs.ogc.org/is/18-088/18-088.html#resource-path",
                    "https://docs.ogc.org/is/18-088/18-088.html#req-resource-path-resource-path-to-entities",
                    "https://docs.ogc.org/is/18-088/18-088.html#requesting-data",
                    "https://docs.ogc.org/is/18-088/18-088.html#create-update-delete",
                    "https://docs.ogc.org/is/18-088/18-088.html#req-data-array-data-array",
                    "https://docs.ogc.org/is/18-088/18-088.html#req-resource-path-resource-path-to-entities",
                    "http://docs.oasis-open.org/odata/odata-json-format/v4.01/odata-json-format-v4.01.html",
                    "http://www.rfc.fr/rfc/en/rfc4180.pdf"
                ];
                // "http://www.opengis.net/spec/iot_sensing/1.1/req/receive-updates-via-mqtt/receive-updates",
                // "https://fraunhoferiosb.github.io/FROST-Server/extensions/DeepSelect.html",
                // "https://fraunhoferiosb.github.io/FROST-Server/extensions/GeoJSON-ResultFormat.html",
                // "https://fraunhoferiosb.github.io/FROST-Server/extensions/JsonBatchRequest.html",
                // "https://fraunhoferiosb.github.io/FROST-Server/extensions/OpenAPI.html",
                // "https://fraunhoferiosb.github.io/FROST-Server/extensions/ResponseMetadata.html",
                // "https://fraunhoferiosb.github.io/FROST-Server/extensions/SelectDistinct.html",
                // "https://github.com/INSIDE-information-systems/SensorThingsAPI/blob/master/CSV-ResultFormat/CSV-ResultFormat.md",
                // "https://github.com/INSIDE-information-systems/SensorThingsAPI/blob/master/EntityLinking/Linking.md#Expand",
                // "https://github.com/INSIDE-information-systems/SensorThingsAPI/blob/master/EntityLinking/Linking.md#Filter",
                // "https://github.com/INSIDE-information-systems/SensorThingsAPI/blob/master/EntityLinking/Linking.md#NavigationLinks"],
                if (ctx._.service._lora === true) list.push(`${ctx._.origin}/documentation?Loras`);
                list.push("https://docs.ogc.org/is/18-088/18-088.html#multidatastream-extension");
                if (ctx._.inExtension(EExtensions.mqtt))
                    list.push("https://docs.ogc.org/is/18-088/18-088.html#req-create-observations-via-mqtt-observations-creation", "https://docs.ogc.org/is/18-088/18-088.html#mqtt-extension");
                const temp: Record<string, any> = {
                    "value": expectedResponse.filter((elem) => Object.keys(elem).length),
                    "serverSettings": {
                        "conformance": list
                    }
                };
                list.push(`${ctx._.origin}/documentation?Services`);
                list.push(`${ctx._.origin}/documentation?Token`);
                list.push(`${ctx._.origin}/documentation?Import`);
                list.push(`${ctx._.origin}/documentation?Format`);
                temp[`${ctx._.base()}/${ctx._.service.apiVersion}/req/receive-updates-via-mqtt/receive-updates`] = {
                    "endpoints": [`mqtt://server.example.com:${config.getService(EConstant.admin).ports?.ws}`, "ws://server.example.com/sensorThings"]
                };
                return temp;
            default:
                break;
        }
    }

    /**
     * initialize model class
     */
    public initialisation() {
        if (isTest()) this.getModel(EConstant.test);
    }

    public getModel(service: Iservice | string): Ientities {
        service = this.getService(service);
        if (!Models.models[service.name]) Models.models[service.name] = this.create(service.apiVersion, service);
        return Models.models[service.name];
    }

    private create(version: string, service: Iservice): Ientities {
        console.log(logging.whereIam(new Error().stack));        
        let model = this.createVersion(version, service);
        const name = service._unique === true ? new Text().notNull().default(EInfos.noName).unique().column() : new Text().notNull().column();
        const description = service._unique === true ? new Text().notNull().default(EInfos.noName).unique().column() : new Text().notNull().column();
        // const result = service._numeric === true ? new Numeric().column() : new Any().column();
       if (service._numeric ) model[OBSERVATION.name].columns["result"] = new Numeric().column();
        Object.keys(model).forEach((k: string) => {
            if (model[k].columns["name"]) model[k].columns.name = name;
            if (model[k].columns["description"]) model[k].columns.name = description;
        });
        return model;
    }
}

export const models = new Models();
