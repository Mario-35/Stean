/**
 * streamCsvFile
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */

import { IcsvFile, IcsvImport, Iservice } from "../../types";
import { createReadStream } from "fs";
import { addAbortSignal } from "stream";
import { config } from "../../configuration";
import { logging } from "../../log";
import { executeSql } from "./executeSql";
import { executeSqlValues } from "./executeSqlValues";

export async function streamCsvFile(service: Iservice, paramsFile: IcsvFile, sqlRequest: IcsvImport): Promise<number> {
    console.log(logging.whereIam(new Error().stack));
    const cols: string[] = Array(sqlRequest.columns.length)
        .fill("")
        .map((_, i) => `value${i}`);
    const controller = new AbortController();
    const readable = createReadStream(paramsFile.filename);
    await executeSql(
        service,
        `CREATE TABLE "${paramsFile.tempTable}" ( id serial4 NOT NULL, ${cols.map((e) => `"${e}" varchar(255) NULL`)}, CONSTRAINT ${paramsFile.tempTable}_pkey PRIMARY KEY (id));`
    ).catch((error: any) => {
        console.log(error);
    });
    const writable = config
        .connection(service.name)
        .unsafe(`COPY "${paramsFile.tempTable}" (${cols.join(",")}) FROM STDIN WITH(FORMAT csv, DELIMITER ';', NULL ' ' ${paramsFile.header})`)
        .writable();
    return new Promise(async function (resolve, reject) {
        readable
            .pipe(addAbortSignal(controller.signal, await writable))
            .on("finish", async (e: any) => {
                await executeSqlValues(service, `SELECT count(id) FROM "${paramsFile.tempTable}"`)
                    .then((e) => {
                        resolve(+e[0 as keyof object]);
                    })
                    .catch((error) => {
                        console.log(error);
                        resolve(-1);
                    });
            })
            .on("error", (error) => {
                console.log(error);
                resolve(-1);
            });
    });
}
