
// DON'T REMOVE !!!!
// @start@
// @request@

// create json default configuration
function updateDataService()  {
	const opt = multiSelects["optionsOption"].getData();
	const ext = multiSelects["extensionsOption"].getData();
	var obj = {
		name: optName.value,
		pg: {
            "host": "localhost",
            "port": 5432,
            "user": optName.value,
            "password": optPassword.value,
            "database": optName.value,
            "retry": 2
        },
		"version": optVersion.value || "v1.1",
		"date_format": dateOption.value || "DD/MM/YYYY hh:mi:ss",
        "nb_page": pageOption.value || 200,
        "nb_graph": graphOption.value || 1000000,
		"extensions": ext.length > 0 ? ext : ["base", "multiDatastream", "partitioned", "unique"],
        "options": opt.length > 0 ? opt : ["canDrop"],
        "csvDelimiter": csvOption.value || ";"
	}
	setJSON(JSON.stringify(obj, null, 4));
};

// update datas after paste
jsonDatas.onpaste = function() {
	{
		setTimeout(() => {
			setJSON();
		}, 100);
	}
};


// catch click on service block
btnBlank.onclick = async (e) => {	
	e.preventDefault();
	const newName = window.prompt("Name of the service", name);
	if (newName !== null && newName !== "") {
		optVersion.value = "v1.1";
		dateOption.value = "DD/MM/YYYY hh:mi:ss";
		pageOption.value = 200;
		graphOption.value = 1000000;
		csvOption.value =";";
		optName.value = newName || "";
		optPassword.value = newName || "";
		optRepeat.value = newName ||"";
		populateMultiSelect("optionsOption", _PARAMS.options, ["canDrop"]);
		populateMultiSelect("extensionsOption", _PARAMS.extensions, ["base", "multiDatastream", "partitioned", "unique"]);
		updateDataService();
	}	
}

btnService.onclick = async (e) => {	
	e.preventDefault();
	updateDataService();
	if (optName.value === "") {
		notifyError("Error", "name can't be empty");
		return;
	} 
	if (optPassword.value === "") {
		notifyError("Error", "Password can't be empty");
		return;
	} 
	if (optRepeat.value === "")  {
		notifyError("Error", "Repeat can't be empty");
		return;
	} 
	if (optPassword.value !== optRepeat.value)  {
		notifyError("Error", "Password and repeat not the same");
		return;
	} 
	try {
		jsonDatas.innerText = jsonDatas.innerText.replace(/[^\x00-\x7F]/g, '');
		getElement("actionForm").action = `${_PARAMS.addUrl.split("service")[0]}admin`;
		getElement("_action").value = "addService";
		document.getElementById("actionForm").requestSubmit();
	} catch (error) {
		console.error(error);
		wait(false);
	}
};

// fill form service from another
function fillService(name, newName) {
	const serv = _PARAMS.services[name]["service"];
	csvOption.value = serv.csvDelimiter;
	pageOption.value = serv.nb_page;
	graphOption.value = serv.nb_graph;
	dateOption.value = serv.date_format;
	populateSelect(optVersion, _PARAMS.versions, serv.apiVersion);
	populateMultiSelect("optionsOption", _PARAMS.options, serv.options);
	populateMultiSelect("extensionsOption", _PARAMS.extensions, serv.extensions);
	optName.value = newName || name;
	optPassword.value = newName || "";
	optRepeat.value = newName ||"";
	Labelchck1.innerText = "Service " + optName.value;
	optDistHost.value = _PARAMS.services[name].base + "/" + serv.apiVersion + "/" ;
}

// load Log file from log select
getDatas = async (url) => {
	try {
		const response = await fetch(encodeURI(url), {
			method: "GET",
			headers: {
				"Content-Type": "application/json",
			},
		});
		return await response.json();
	} catch (err) {
		notifyError("Error", err);
	}
}

// fill form for create service from another
async function selectCard(name) {
	fillService(name);
}

// fill form for create service from another
async function delService(name) {
	const newName = window.prompt("Name of the service", name);
	if (newName !== null && newName !== "") {
		let response = await fetch(`${_PARAMS.services[newName].base}/${_PARAMS.services[newName]["service"].apiVersion}/Services(${newName})`, {
			method: "DELETE",
			headers: {
				"Content-Type": "application/json",
			},
		});
	}
}

// change nb Page
function editPage(name ,elem) {
	const temp = window.prompt("Number of page for " + name, elem.textContent);
	if (temp !== null && temp !== "" && +temp > 0) {
		elem.textContent = temp; 		
		fetch(`${_PARAMS.services[name].base}/${_PARAMS.services[name]["service"]["service"].apiVersion}/nb_page`, {
			method: "PUT",
			headers: {
				"Content-Type": "application/json",
			},
			body: `{"nb_page": ${temp}}`
		});
	}
}
// change nb Graph
function editGraph(name ,elem) {
	const temp = window.prompt("Number of point for graph", elem.textContent);
	if (temp !== null && temp !== "" && +temp > 0) {
		elem.textContent = temp; 		
		fetch(`${_PARAMS.services[name].base}/${_PARAMS.services[name]["service"].apiVersion}/nb_graph`, {
			method: "PUT",
			headers: {
				"Content-Type": "application/json",
			},
			body: `{"nb_graph": ${temp}}`
		});
	}
}

// edit synonyms
async function editList(name ,elem) {
	show(getElement("editList"+ name));
	hide(getElement("options"+ name));
	const lines = Object.values(_PARAMS.services[name]["service"].synonyms[elem]);
	const temp = window.prompt("Synonyms for " + elem, _PARAMS.services[name]["service"].synonyms[elem]);
	if (temp !== null && temp !== "" && temp != lines) {
		_PARAMS.services[name]["service"].synonyms[elem] = temp.split(',');
		await fetch(`${_PARAMS.services[name].base}/${_PARAMS.services[name]["service"].apiVersion}/synonyms`, {
			method: "PUT",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify(_PARAMS.services[name]["service"].synonyms)
		});
	}


}

// change csv delimiter
async function editCsv(name ,elem) {
	const temp = window.prompt("Csv delimiter for " + name, elem.textContent);
	if (temp === "," || temp === ";") elem.textContent = temp; 
	if (temp === "," || temp === ";") {
		await fetch(`${_PARAMS.services[name].base}/${_PARAMS.services[name]["service"].apiVersion}/csvDelimiter`, {
			method: "PUT",
			headers: {
				"Content-Type": "application/json",
			},
			body: `{"csvDelimiter": "${temp}"}`
		});
	}
}

// change card selector
async function selectChange(name ,elem) {
	switch (elem.value) {
		case "Users":				
			getElement("infos"+ name).innerHTML = _PARAMS.services[name].stats["Users"].map(e => `<option value="${e["username"]}" onclick="showUserInfos('${name}', '${e["username"]}')">${e["username"]}</option>`).join("\n");
			break;
		case "Loras":
			const url = `${_PARAMS.services[name].base}/${_PARAMS.services[name]["service"].apiVersion}/Decoders?$select=id,name`;		
			const datas = await getDatas(url);
			getElement("infos"+ name).innerHTML =  Object.values(datas.value).map(e => `<option value="${e.name}" onclick="showDecoderInfos('${name}','${e["@iot.id"]}')">${e.name}</option>`).join("\n");
			break;
		case "Synonyms": 
			if (_PARAMS.services[name].service)
				getElement("infos"+ name).innerHTML = Object.keys(_PARAMS.services[name]["service"].synonyms).map(e => `<option value="${e["username"]}" onclick="editList('${name}','${e}')">${e}</option>`).join("\n");
			break;	
		case 0:
			if (_PARAMS.options.includes(elem.textContent)) {
				if (_PARAMS.services[name]["service"].options.includes(elem.textContent)) {
					var index = _PARAMS.services[name]["service"].options.indexOf(elem.textContent);
					_PARAMS.services[name]["service"].options.splice(index, 1);
				} else _PARAMS.services[name]["service"].options.push(elem.textContent);
				try {					
					await fetch(`${_PARAMS.services[name].base}/${_PARAMS.services[name]["service"].apiVersion}/options`, {
						method: "PUT",
						headers: {
							"Content-Type": "application/json",
						},
						body: JSON.stringify(_PARAMS.services[name]["service"].options)
					});
				} catch (error) {
					console.log(error);
					await fetch(`${_PARAMS.services[name].base.replace('https', 'http')}/${_PARAMS.services[name]["service"].apiVersion}/options`, {
						method: "PUT",
						headers: {
							"Content-Type": "application/json",
						},
						body: JSON.stringify(_PARAMS.services[name]["service"].options)
					});
				}
			}
			showInfos(name);
			break;						
		default:
			getElement("infos"+ name).innerHTML = _PARAMS.services[name]["service"].extensions.map(e => `<option value="${e}">${e}</option>`).join("\n");
			showInfos(name);
	}
}

// load Log file from log select
optLogs.onclick = async () => {
	try {
		const url = `${_PARAMS.addUrl.split("service")[0]}${optLogs.value}`;
		const response = await fetch(encodeURI(url), {
			method: "GET",
			headers: {
				"Content-Type": "application/json",
			},
		});
		wrapper.classList.add("scrollable-div");
		wrapper.innerHTML = await response.text();
	} catch (err) {
		notifyError("Error", err);
	}
}

// change view for user infos
function showUserInfos(service, element) {
	var obj = Object(_PARAMS.services[service].stats["Users"]).filter(e => e.username === element)[0];
	var elem = (name) => `<li class="card-list-item icon-${obj[name] === true ? "yes" : "no"}">${name}</li>`;
	getElement("options"+ service).innerHTML = `<legend>${element}</legend> <ul class="card-list"> ${[ elem("canPost"), elem("canDelete"), elem("canCreateDb"), elem("canCreateUser"), elem("admin"), elem("superAdmin") ].join("")} </ul>`;
}

// change view for standard default infos
async function showDecoderInfos(name, decoder) {
	const datas = await getDatas(`${_PARAMS.services[name].base}/${_PARAMS.services[name]["service"].apiVersion}/Decoders(${decoder})`);
	decoderWindow(datas, name);
}

// Change view for standard default infos
function showInfos(service) {
	const li = (operation) => `<li class="card-list-item canPoint icon-${_PARAMS.services[service]["service"].options.includes(operation) ? "yes" : "no" }"  onclick="selectChange('${service}', this)">${operation}</li>`;
	const ul = ['<legend>Options</legend>','<ul class="card-list">'];
	["canDrop","forceHttps","stripNull","unique","locked"].forEach( e => ul.push(li(e)));
	ul.push("</ul>");	
	getElement("options"+ service).innerHTML = ul.join("");
}

// Launch test decoder
function testDecoder() {
	const payload = getElement("optPayload").value || window.prompt("payload", "");
	if (payload !== null && payload !== "") {
		getElement("optPayload").value = payload;
		decodingPayload(payload) ;
	}
}

// Delete decoder
async function deleteDecoder() {
	const serviceName = getElement("optDecoderId").name;
	const id = getElement("optDecoderId").value;	
	if (Number(id) > 0) {
		let response = await fetch(`${_PARAMS.services[serviceName].base}/${_PARAMS.services[serviceName]["service"].apiVersion}/Decoders(${id})`, {
			method: "DELETE",
			headers: {
				"Content-Type": "application/json",
			},
		});

		if (response.status == 204)
			notifyAlert("Delete", `delete Ok`);
		else 
			notifyError("Error", `delete Error`);
	}	
}

// Save decoder as PUT http verb
async function saveDecoder() {
	const serviceName = getElement("optDecoderId").name;	
	await fetch(`${_PARAMS.services[serviceName].base}/${_PARAMS.services[serviceName]["service"].apiVersion}/Decoders`, {
		method: "PUT",
		headers: {
			"Content-Type": "application/json",
		},
		body: JSON.stringify({
			"name": getElement("optDecoderName").value,
			"code": String(getElement("jsonDecoderCode").innerText.split("\n").join("")),
			"nomenclature": String(getElement("jsonDecoderNomenclature").innerText.split("\n").join(""))
		})
	});
}

// Decode payload test
function decodingPayload(payload) {
	try {
		const F = new Function("input", "nomenclature", `${getElement("jsonDecoderCode").innerText}; return decode(input, nomenclature);`);
		let nomenclature = JSON.parse(getElement("jsonDecoderNomenclature").innerText);
		const result = F(payload, nomenclature);		
		beautifyDatas(getElement("jsonDecoderResult"), result.datas, "json");		
	}
	catch (error) {
		notifyError("Error", error);
	}
};

// Save configs as PUT http verb
async function saveDecoder() {
	const serviceName = getElement("optDecoderId").name;	
	await fetch(`${_PARAMS.services[serviceName].base}/${_PARAMS.services[serviceName]["service"].apiVersion}/Synonims`, {
		method: "PUT",
		headers: {
			"Content-Type": "application/json",
		},
		body: JSON.stringify({
			"name": getElement("optDecoderName").value,
			"code": String(getElement("jsonDecoderCode").innerText.split("\n").join("")),
			"nomenclature": String(getElement("jsonDecoderNomenclature").innerText.split("\n").join(""))
		})
	});
}

// Start
(function init() {
	wait(false);
	message(_PARAMS);	
	new SplitterBar(container, first, two);
	populateSelect(optVersion, _PARAMS.versions, "v1.1");
	populateSelect(optLogs, _PARAMS.logsFiles);
	populateMultiSelect("optionsOption", _PARAMS.options);
	populateMultiSelect("extensionsOption", _PARAMS.extensions);
	csvOption.value = ';';
	pageOption.value = '200';
	dateOption.value = "DD/MM/YYYY hh:mi:ss";
	jsonViewer = new JSONViewer();
	if (_PARAMS.message) notifyConfirm("Confirmation", _PARAMS.message);
}
)();
