/**
 * createQueryParams
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */

import { getAuthenticatedUser } from "../../authentication";
import { config } from "../../configuration";
import { EConstant } from "../../enums";
import { logging } from "../../log";
import { Ientities, IqueryOptions, koaContext } from "../../types";

export async function createQueryParams(ctx: koaContext): Promise<IqueryOptions | undefined> {
    console.log(logging.whereIam(new Error().stack));
    let user = await getAuthenticatedUser(ctx);
    user = user ? user : ctx._.blankUser();
    const listEntities =
        user.superAdmin === true
            ? Object.keys(ctx._.model())
            : user.admin === true
            ? Object.keys(ctx._.model()).filter((elem: string) => ctx._.model()[elem].order > 0 || ctx._.model()[elem].createOrder === 99 || ctx._.model()[elem].createOrder === -1)
            : user.canPost === true
            ? Object.keys(ctx._.model()).filter((elem: string) => ctx._.model()[elem].order > 0 || ctx._.model()[elem].createOrder === 99 || ctx._.model()[elem].createOrder === -1)
            : Object.keys(ctx._.model()).filter((elem: string) => ctx._.model()[elem].order > 0);
    listEntities.push("Services", "Logs");
    return {
        methods: ["GET"],
        _: ctx._,
        entity: "",
        options: ctx.querystring ? ctx.querystring : "",
        user: user,
        graph: ctx.url.includes("$resultFormat=graph"),
        admin: ctx._.service.name === EConstant.admin,
        services: config.getInfosForAll(ctx),
        _DATAS: Object.fromEntries(Object.entries(ctx._.model()).filter(([k, v]) => listEntities.includes(k) && v.order >= 0)) as Ientities
    };
}
