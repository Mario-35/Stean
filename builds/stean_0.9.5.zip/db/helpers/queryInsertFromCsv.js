Object.defineProperty(exports,"__esModule",{value:!0}),exports.queryInsertFromCsv=queryInsertFromCsv;let _1=require("."),log_1=require("../../log");async function queryInsertFromCsv(a,s){let u=await(0,_1.columnsNameFromHydrasCsv)(s);if(u){var e=await(0,_1.streamCsvFile)(a,s,u);if(0<e){let r=s.filename.split("/").reverse()[0],l=(new Date).toLocaleString(),o=[],t=(Object.keys(s.columns).forEach((e,t)=>{e=s.columns[e];o.push(`INSERT INTO "${a.model.Observations.table}" 
          ("${e.stream.type?.toLowerCase()}_id", "featureofinterest_id", "phenomenonTime", "resultTime", "result", "resultQuality")
            SELECT 
            ${e.stream.id}, 
            ${e.stream.FoId},  
            ${u.dateSql}, 
            ${u.dateSql},
            json_build_object('value', 
            CASE "${s.tempTable}".value${e.column}
              WHEN '---' THEN NULL 
              WHEN '#REF!' THEN NULL 
              ELSE CAST(REPLACE(value${e.column},',','.') AS float) 
            END),
            '{"import": "${r}","date": "${l}"}'  
           FROM "${s.tempTable}" ON CONFLICT DO NOTHING returning 1`)}),[]);return Object.keys(s.columns).forEach(e=>{e=s.columns[e];t.push(`CASE "${s.tempTable}".value${e.column}
              WHEN '---' THEN NULL 
              WHEN '#REF!' THEN NULL 
              ELSE CAST(REPLACE(value${e.column},',','.') AS float) 
            END`)}),{count:e,query:o}}}}