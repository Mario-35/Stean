Object.defineProperty(exports,"__esModule",{value:!0}),exports.MultiDatastream=void 0;let entity_1=require("../entity"),enums_1=require("../../enums"),messages_1=require("../../messages"),types_1=require("../types");exports.MultiDatastream=new entity_1.Entity("MultiDatastreams",{createOrder:8,type:enums_1.ETable.table,order:2,orderBy:'"id"',columns:{id:(new types_1.Bigint).generated("id").type(),name:(new types_1.Text).notNull().default(messages_1.info.noName).unique().type(),description:(new types_1.Text).notNull().default(messages_1.info.noDescription).type(),unitOfMeasurements:(new types_1.Jsonb).notNull().type(),observationType:(new types_1.Text).notNull().default("http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement").verify(Object.keys(enums_1.EObservationType)).type(),multiObservationDataTypes:(new types_1.Texts).type(),observedArea:(new types_1.Geometry).type(),phenomenonTime:(new types_1.Timestamp).alias("phenomenonTime").type(),resultTime:(new types_1.Timestamp).alias("resultTime").type(),_phenomenonTimeStart:(new types_1.Timestamp).tz().type(),_phenomenonTimeEnd:(new types_1.Timestamp).tz().type(),_resultTimeStart:(new types_1.Timestamp).tz().type(),_resultTimeEnd:(new types_1.Timestamp).tz().type(),thing_id:(new types_1.Relation).relation("Things").type(),sensor_id:(new types_1.Relation).relation("Sensors").type(),_default_featureofinterest:(new types_1.Relation).relation("FeaturesOfInterest").default(1).type()},relations:{Thing:{type:enums_1.ERelations.belongsTo},Sensor:{type:enums_1.ERelations.belongsTo},Observations:{type:enums_1.ERelations.hasMany},ObservedProperties:{type:enums_1.ERelations.hasMany,entityRelation:"MultiDatastreamObservedProperties"},Lora:{type:enums_1.ERelations.belongsTo},FeatureOfInterest:{type:enums_1.ERelations.defaultUnique}},clean:[`WITH multidatastreams AS (
                SELECT DISTINCT "multidatastream_id" AS id FROM observation
            ),
            datas AS (SELECT 
                    "multidatastream_id" AS id,
                    MIN("phenomenonTime") AS pmin,
                    MAX("phenomenonTime") AS pmax,
                    MIN("resultTime") AS rmin,
                    MAX("resultTime") AS rmax
                FROM observation, multidatastreams WHERE "multidatastream_id" = multidatastreams.id GROUP BY "multidatastream_id"
            )
            UPDATE "multidatastream" SET 
                "_phenomenonTimeStart" =  datas.pmin,
                "_phenomenonTimeEnd" = datas.pmax,
                "_resultTimeStart" = datas.rmin,
                "_resultTimeEnd" = datas.rmax
            FROM datas WHERE "multidatastream".id = datas.id`]});