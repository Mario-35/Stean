Object.defineProperty(exports,"__esModule",{value:!0}),exports.Datastream=void 0;let enums_1=require("../../enums"),messages_1=require("../../messages"),entity_1=require("../entity"),types_1=require("../types");exports.Datastream=new entity_1.Entity("Datastreams",{createOrder:7,type:enums_1.ETable.table,order:1,orderBy:'"id"',columns:{id:(new types_1.Bigint).generated("id").type(),name:(new types_1.Text).notNull().default(messages_1.info.noName).unique().type(),description:(new types_1.Text).notNull().default(messages_1.info.noDescription).type(),observationType:(new types_1.Text).notNull().default("http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement").verify(Object.keys(enums_1.EObservationType)).type(),unitOfMeasurement:(new types_1.Jsonb).notNull().type(),observedArea:(new types_1.Geometry).type(),phenomenonTime:(new types_1.Timestamp).alias("phenomenonTime").type(),resultTime:(new types_1.Timestamp).alias("resultTime").type(),_phenomenonTimeStart:(new types_1.Timestamp).tz().type(),_phenomenonTimeEnd:(new types_1.Timestamp).tz().type(),_resultTimeStart:(new types_1.Timestamp).tz().type(),_resultTimeEnd:(new types_1.Timestamp).tz().type(),thing_id:(new types_1.Relation).relation("Things").type(),observedproperty_id:(new types_1.Relation).relation("ObservedProperties").type(),sensor_id:(new types_1.Relation).relation("Sensors").type(),_default_featureofinterest:(new types_1.Relation).relation("FeaturesOfInterest").default(1).type()},relations:{Thing:{type:enums_1.ERelations.belongsTo},Sensor:{type:enums_1.ERelations.belongsTo},ObservedProperty:{type:enums_1.ERelations.belongsTo},Observations:{type:enums_1.ERelations.hasMany},Lora:{type:enums_1.ERelations.belongsTo},FeatureOfInterest:{type:enums_1.ERelations.defaultUnique}},clean:[`WITH datastreams AS (
      SELECT DISTINCT "datastream_id" AS id FROM observation
      ),
      datas AS (SELECT 
        "datastream_id" AS id,
        MIN("phenomenonTime") AS pmin ,
        MAX("phenomenonTime") AS pmax,
        MIN("resultTime") AS rmin,
        MAX("resultTime") AS rmax
        FROM observation, datastreams where "datastream_id" = datastreams.id group by "datastream_id"
      )
      UPDATE "datastream" SET 
        "_phenomenonTimeStart" =  datas.pmin ,
        "_phenomenonTimeEnd" = datas.pmax,
        "_resultTimeStart" = datas.rmin,
        "_resultTimeEnd" = datas.rmax
      FROM datas WHERE "datastream".id = datas.id`]});