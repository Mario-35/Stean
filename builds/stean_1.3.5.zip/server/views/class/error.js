Object.defineProperty(exports,"__esModule",{value:!0}),exports.HtmlError=void 0;let log_1=require("../../log"),core_1=require("./core");class HtmlError extends core_1.CoreHtmlView{constructor(r,t){super(r,t),this.error(t.message,t.url)}error(r,t){this._HTMLResult=[`<!DOCTYPE html>
            <html>
                ${this.head("Error")}
                <body>
                    <div class="login-error">
                        <div class="login-html">
                            ${this.title("Error","titleError")}
                            <h3>${r||""}</h3>
                            ${this.hr()}
                            <div id="outer">
                                <div class="inner">
                                    <a href="${t.includes("admin")?this.ctx._.root()+"/admin":this.ctx._.root()+"/Login"}" class="button-submit">${t.includes("admin")?"Admin login":"Login"}</a>
                                </div>
                                <div class="inner">
                                    <a  href="${this.ctx._.root()}/help" class="button">Documentation</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </body>
            </html>`]}}exports.HtmlError=HtmlError;