Object.defineProperty(exports,"__esModule",{value:!0}),exports.createTable=void 0;let configuration_1=require("../../configuration"),log_1=require("../../log"),helpers_1=require("../../helpers"),helpers_2=require("../../models/helpers"),constants_1=require("../constants"),createTable=async(o,r,e)=>{async function t(t,e){log_1.logging.debug().query(t,e).to().log().file(),l[t]=await configuration_1.config.connection(o).unsafe(e).then(()=>(log_1.logging.debug().status(!0,t).to().log().file(),"✔️️")).catch(e=>(log_1.logging.error(t,e).to().log().file(),e.message))}if(log_1.logging.debug().head(`CreateTable [${r.table||"pseudo "+r.name}] for `+o).to().log(),!r||""===r.table.trim())return{};var n=()=>" ".repeat(5);let a=[],i=[],l={};var s;if(!configuration_1.config.connection(o))return log_1.logging.error("connection Error","connection Error"),{error:"connection Error"};Object.keys(r.columns).forEach(e=>{""!=r.columns[e].create.trim()&&a.push((0,helpers_1.doubleQuotes)(e)+" "+r.columns[e].create)}),s=a.join(", "),Object.keys(r.constraints).forEach(e=>{i.push(`ALTER TABLE ${(0,helpers_1.doubleQuotes)(r.table)} ADD CONSTRAINT ${(0,helpers_1.doubleQuotes)(e)} `+r.constraints[e])});let E=`CREATE TABLE ${(0,helpers_1.doubleQuotes)(r.table)} (${s})${r.partition?`PARTITION BY LIST(${r.partition.column})`:""};`,c=(""!=r.table.trim()&&await t(String("Create table "+(0,helpers_1.doubleQuotes)(r.table)),E),r.indexes),u=[];return c&&Object.keys(c).forEach(e=>{u.push(`CREATE INDEX "${e}" `+c[e])}),0<u.length&&await t(n()+"Create indexes for "+r.name,u.join(";")),r.partition&&(r.partition.entityRelation&&(E=r.partition.entityRelation.map((e,t)=>`CREATE OR REPLACE FUNCTION public.${e.toLowerCase()}_on_action()
      RETURNS trigger
      LANGUAGE plpgsql
      AS $function$ 
      DECLARE id BIGINT;
      BEGIN 
        IF (NEW."id" is not null) THEN 
            EXECUTE '${(0,constants_1.partitionTable)(r.table,t)}' using NEW;
            EXECUTE '${(0,constants_1.partitionTable)(r.table,t+1)}' using NEW;
        END IF;
        RETURN NEW; 
      END;
      $function$;
    CREATE OR REPLACE TRIGGER ${e.toLowerCase()}_on_insert BEFORE INSERT ON public."${(0,helpers_2.singular)(e).toLowerCase()}" FOR EACH STATEMENT EXECUTE FUNCTION ${e.toLowerCase()}_on_action();
    `).join(";"),E+=`CREATE TABLE IF NOT EXISTS "observationdefault" PARTITION OF "${r.table}" DEFAULT;`),await t(String("CREATE PARTITION TRIGGER "+(0,helpers_1.doubleQuotes)(r.table)),E)),0<i.length&&await t(n()+"Create constraints for "+r.table,i.join(";")),r.after&&await t(n()+"Something to do after for "+r.table,r.after),e&&await t(n()+" doAfter "+r.table,e),l};exports.createTable=createTable;