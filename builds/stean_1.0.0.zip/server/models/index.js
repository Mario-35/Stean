"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.models = exports.Models = void 0;
const configuration_1 = require("../configuration");
const log_1 = require("../log");
const queries_1 = require("../db/queries");
const enums_1 = require("../enums");
const helpers_1 = require("../helpers");
const messages_1 = require("../messages");
const types_1 = require("../types");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const entities_1 = require("./entities");
const types_2 = require("./types");
class Models {
    static models = {};
    testVersion(verStr) {
        return Models.models.hasOwnProperty(verStr);
    }
    getDrawIo(service) {
        const deleteId = (id) => {
            const start = `<mxCell id="${id}"`;
            const end = "</mxCell>";
            fileContent = fileContent.replace(`${start}${fileContent.split(start)[1].split(end)[0]}${end}`, "");
        };
        const entities = Models.models[service.apiVersion];
        let fileContent = fs_1.default.readFileSync(path_1.default.join(__dirname, "/", "model.drawio"), "utf8");
        fileContent = fileContent.replace("&gt;Version&lt;", `&gt;version : ${service.apiVersion}&lt;`);
        if (!service.extensions.includes(enums_1.EExtensions.multiDatastream)) {
            ["114", "115", "117", "118", "119", "116", "120", "121"].forEach((e) => deleteId(e));
            fileContent = fileContent.replace(`&lt;hr&gt;COLUMNS.${entities.MultiDatastreams.name}`, "");
            fileContent = fileContent.replace(`&lt;hr&gt;COLUMNS.${entities.MultiDatastreams.name}`, "");
            fileContent = fileContent.replace(`&lt;strong&gt;${entities.MultiDatastreams.singular}&lt;/strong&gt;`, "");
        }
        Object.keys(entities).forEach((strEntity) => {
            fileContent = fileContent.replace(`COLUMNS.${entities[strEntity].name}`, Object.keys(entities[strEntity].columns)
                .filter((word) => !word.includes("_") && !word.includes("id"))
                .map((colName) => `&lt;p style=&quot;margin: 0px; margin-left: 8px;&quot;&gt;${colName}: ${(0, types_1.getColumnType)(entities[strEntity].columns[colName]).toUpperCase()}&lt;/p&gt;`)
                .join(""));
        });
        return fileContent;
    }
    async getInfos(ctx) {
        const temp = configuration_1.config.getInfos(ctx, ctx.service.name);
        const result = {
            ...temp,
            ready: ctx.service._connection ? true : false,
            Postgres: {},
            users: {}
        };
        const extensions = {};
        switch (ctx.service.apiVersion) {
            case "11":
                result["Ogc link"] = "https://docs.ogc.org/is/18-088/18-088.html";
                break;
            default:
                result["Ogc link"] = "https://docs.ogc.org/is/15-078r6/15-078r6.html";
                break;
        }
        if (ctx.service.extensions.includes(enums_1.EExtensions.tasking))
            extensions["tasking"] = "https://docs.ogc.org/is/17-079r1/17-079r1.html";
        result["extensions"] = extensions;
        result["options"] = ctx.service.options;
        await configuration_1.config.executeSqlValues(ctx.service, ` select version(), (SELECT ARRAY(SELECT extname||'-'||extversion AS extension FROM pg_extension) AS extension), (SELECT c.relname||'.'||a.attname FROM pg_attribute a JOIN pg_class c ON (a.attrelid=c.relfilenode) WHERE a.atttypid = 114) ;`).then((res) => {
            result["Postgres"]["version"] = res[0];
            result["Postgres"]["extensions"] = res[1];
        });
        await configuration_1.config.executeSql(ctx.service, `select username, "canPost", "canDelete", "canCreateUser", "canCreateDb", "admin", "superAdmin" FROM public.user ORDER By username;`).then((res) => {
            Object.keys(res).forEach((e) => {
                result["users"][res[+e]["username"]] = {
                    "canPost": res[+e]["canPost"],
                    "canDelete": res[+e]["canDelete"],
                    "canCreateUser": res[+e]["canCreateUser"],
                    "canCreateDb": res[+e]["canCreateDb"],
                    "admin": res[+e]["admin"],
                    "superAdmin": res[+e]["superAdmin"]
                };
            });
        });
        return result;
    }
    // Get multiDatastream or Datastreams infos
    async getStreamInfos(service, input) {
        console.log(log_1.log.whereIam());
        const stream = input["Datastream"] ? "Datastream" : input["MultiDatastream"] ? "MultiDatastream" : undefined;
        if (!stream)
            return undefined;
        const streamEntity = exports.models.getEntityName(service, stream);
        if (!streamEntity)
            return undefined;
        const foiId = input["FeaturesOfInterest"] ? input["FeaturesOfInterest"] : undefined;
        const searchKey = input[exports.models.DBFull(service)[streamEntity].name] || input[exports.models.DBFull(service)[streamEntity].singular];
        const streamId = isNaN(searchKey) ? searchKey[enums_1.EConstant.id] : searchKey;
        if (streamId) {
            const query = `SELECT "id", "observationType", "_default_featureofinterest" FROM ${(0, helpers_1.doubleQuotesString)(exports.models.DBFull(service)[streamEntity].table)} WHERE "id" = ${BigInt(streamId)} LIMIT 1`;
            return configuration_1.config
                .executeSqlValues(service, (0, queries_1.asJson)({ query: query, singular: true, strip: false, count: false }))
                .then((res) => {
                return res
                    ? {
                        type: stream,
                        id: res[0]["id"],
                        observationType: res[0]["observationType"],
                        FoId: foiId ? foiId : res[0]["_default_featureofinterest"]
                    }
                    : undefined;
            })
                .catch((error) => {
                console.log(error);
                return undefined;
            });
        }
    }
    version0_9() {
        return {
            Files: entities_1.FILE,
            Lines: entities_1.LINE,
            CreateFile: entities_1.CREATEFILE
        };
    }
    version1_0() {
        return {
            Things: entities_1.THING,
            FeaturesOfInterest: entities_1.FEATUREOFINTEREST,
            Locations: entities_1.LOCATION,
            ThingsLocations: entities_1.THINGLOCATION,
            HistoricalLocations: entities_1.HISTORICALLOCATION,
            LocationsHistoricalLocations: entities_1.LOCATIONHISTORICALLOCATION,
            ObservedProperties: entities_1.OBSERVEDPROPERTY,
            Sensors: entities_1.SENSOR,
            Datastreams: entities_1.DATASTREAM,
            MultiDatastreams: entities_1.MULTIDATASTREAM,
            MultiDatastreamObservedProperties: entities_1.MULTIDATASTREAMOBSERVEDPROPERTY,
            Observations: entities_1.OBSERVATION,
            Decoders: entities_1.DECODER,
            Loras: entities_1.LORA,
            Users: entities_1.USER,
            Services: entities_1.SERVICE,
            Logs: entities_1.LOG,
            CreateObservations: entities_1.CREATEOBSERVATION
        };
    }
    version1_1(input) {
        // add properties to entities
        ["Locations", "FeaturesOfInterest", "ObservedProperties", "Sensors", "Datastreams", "MultiDatastreams"].forEach((entityName) => {
            input[entityName].columns["properties"] = new types_2.Jsonb().type();
        });
        // add geom to Location
        input.Locations.columns["geom"] = new types_2.Geometry().type();
        return input;
    }
    createVersion(verStr) {
        console.log(log_1.log.whereIam(verStr));
        switch (verStr) {
            case "v0.9":
                Models.models["v0.9"] = this.version0_9();
            case "v1.1":
                this.createVersion("v1.0");
                Models.models["v1.1"] = this.version1_1((0, helpers_1.deepClone)(Models.models["v1.0"]));
            default:
                Models.models["v1.0"] = this.version1_0();
        }
        return this.testVersion(verStr);
    }
    listVersion() {
        return ["v0.9", "v1.0", "v1.1"];
    }
    filtering(service) {
        return Object.fromEntries(Object.entries(Models.models[service.apiVersion]).filter(([, v]) => Object.keys((0, enums_1.filterEntities)(service.extensions)).includes(v.name)));
    }
    filtered(service) {
        if (this.testVersion(service.apiVersion) === false)
            this.createVersion(service.apiVersion);
        return service.name === enums_1.EConstant.admin ? this.DBAdmin(service) : this.filtering(service);
    }
    get(service) {
        if (typeof service === "string") {
            const nameConfig = configuration_1.config.getConfigNameFromName(service);
            if (!nameConfig)
                throw new Error(messages_1.errors.configName);
            if (this.testVersion(configuration_1.config.getService(nameConfig).apiVersion) === false)
                this.createVersion(configuration_1.config.getService(nameConfig).apiVersion);
            return configuration_1.config.getService(nameConfig);
        }
        return service;
    }
    getStats(service) {
        service = this.get(service);
        const a = this.filtered(service);
        const b = Object.keys(a)
            .filter((e) => a[e].type === enums_1.ETable.table)
            .map((e) => (a[e].name === "Users" ? `(SELECT JSON_AGG(u) AS mario FROM ( select username, "canPost", "canDelete", "canCreateUser", "canCreateDb", "admin", "superAdmin" FROM public.user WHERE username <> 'postgres' ORDER By username ) as u) AS "Users"` : `(SELECT COUNT('${a[e].orderBy.split(" ")[0]}') FROM "${a[e].table}") AS "${a[e].name}"${enums_1.EConstant.return}`));
        return ` SELECT JSON_AGG(t) AS results FROM ( SELECT ${b.join()}) AS t`;
    }
    DBFullCreate(service) {
        service = this.get(service);
        const name = service.options.includes(enums_1.EOptions.unique) ? new types_2.Text().notNull().default(messages_1.info.noName).unique().type() : new types_2.Text().notNull().type();
        const description = service.options.includes(enums_1.EOptions.unique) ? new types_2.Text().notNull().default(messages_1.info.noName).unique().type() : new types_2.Text().notNull().type();
        const s = Models.models[service.apiVersion];
        Object.keys(s).forEach((k) => {
            if (s[k].columns["name"])
                s[k].columns.name = name;
            if (s[k].columns["description"])
                s[k].columns.name = description;
        });
        return Models.models[service.apiVersion];
    }
    DBFull(service) {
        return Models.models[this.get(service).apiVersion];
    }
    DBAdmin(service) {
        const entities = Models.models["v1.0"];
        return Object.fromEntries(Object.entries(entities));
    }
    isSingular(service, input) {
        if (configuration_1.config && input) {
            const entityName = this.getEntityName(service, input);
            return entityName ? Models.models[service.apiVersion][entityName].singular == input : false;
        }
        return false;
    }
    getEntityName(service, search) {
        if (configuration_1.config && search) {
            const tempModel = Models.models[service.apiVersion];
            const testString = search
                .trim()
                .match(/[a-zA-Z_]/g)
                ?.join("");
            return tempModel && testString ? (tempModel.hasOwnProperty(testString) ? testString : Object.keys(tempModel).filter((elem) => tempModel[elem].table == testString.toLowerCase() || tempModel[elem].singular == testString)[0]) : undefined;
        }
    }
    getEntityStrict = (service, entity) => {
        return typeof entity === "string" ? Models.models[service.apiVersion][entity] : Models.models[service.apiVersion][entity.name];
    };
    getEntity = (service, entity) => {
        if (configuration_1.config && entity) {
            if ((0, helpers_1.isString)(entity)) {
                const entityName = this.getEntityName(service, entity.trim());
                if (!entityName)
                    return;
                entity = entityName;
            }
            return (0, helpers_1.isString)(entity) ? Models.models[service.apiVersion][entity] : Models.models[service.apiVersion][entity.name];
        }
    };
    getRelationName = (entity, searchs) => {
        let res = undefined;
        searchs.forEach((e) => {
            if (entity.relations[e]) {
                res = e;
                return;
            }
        });
        return res;
    };
    getRelation = (service, entity, relation) => {
        const entityRelation = this.getEntity(service, relation);
        return entityRelation ? entity.relations[entityRelation.name] || entity.relations[entityRelation.singular] : undefined;
    };
    getRelationColumnTable = (service, entity, test) => {
        if (configuration_1.config && entity) {
            const tempEntity = this.getEntity(service, entity);
            if (tempEntity)
                return tempEntity.relations.hasOwnProperty(test) ? enums_1.EColumnType.Relation : tempEntity.columns.hasOwnProperty(test) ? enums_1.EColumnType.Column : undefined;
        }
    };
    getSelectColumnList(service, entity, complete, exclus) {
        const tempEntity = this.getEntity(service, entity);
        exclus = exclus || [""];
        return tempEntity
            ? Object.keys(tempEntity.columns)
                .filter((word) => !word.includes("_") && !exclus.includes(word))
                .map((e) => (complete ? (0, helpers_1.formatPgTableColumn)(tempEntity.table, e) : (0, helpers_1.doubleQuotesString)(e)))
            : [];
    }
    isColumnType(service, entity, column, test) {
        if (configuration_1.config && entity) {
            const tempEntity = this.getEntity(service, entity);
            return tempEntity && tempEntity.columns[column] ? (0, types_1.getColumnType)(tempEntity.columns[column]) === test.toLowerCase() : false;
        }
        return false;
    }
    getRoot(ctx) {
        console.log(log_1.log.whereIam());
        let expectedResponse = [];
        Object.keys(ctx.model)
            .filter((elem) => ctx.model[elem].order > 0)
            .sort((a, b) => (ctx.model[a].order > ctx.model[b].order ? 1 : -1))
            .forEach((value) => {
            expectedResponse.push({
                name: ctx.model[value].name,
                url: `${ctx.decodedUrl.linkbase}/${ctx.service.apiVersion}/${value}`
            });
        });
        switch (ctx.service.apiVersion) {
            case "v0.9":
            case "v1.0":
                return {
                    value: expectedResponse.filter((elem) => Object.keys(elem).length)
                };
            case "v1.1":
                expectedResponse = expectedResponse.filter((elem) => Object.keys(elem).length);
                // base
                const list = [
                    "https://docs.ogc.org/is/18-088/18-088.html",
                    // list.push("https://docs.ogc.org/is/18-088/18-088.html#req-batch-request-batch-request");
                    "https://docs.ogc.org/is/18-088/18-088.html#uri-components",
                    "https://docs.ogc.org/is/18-088/18-088.html#resource-path",
                    "https://docs.ogc.org/is/18-088/18-088.html#req-resource-path-resource-path-to-entities",
                    "https://docs.ogc.org/is/18-088/18-088.html#requesting-data",
                    "https://docs.ogc.org/is/18-088/18-088.html#create-update-delete",
                    "https://docs.ogc.org/is/18-088/18-088.html#req-data-array-data-array",
                    "https://docs.ogc.org/is/18-088/18-088.html#req-resource-path-resource-path-to-entities",
                    "http://docs.oasis-open.org/odata/odata-json-format/v4.01/odata-json-format-v4.01.html",
                    "https://datatracker.ietf.org/doc/html/rfc4180"
                ];
                // "http://www.opengis.net/spec/iot_sensing/1.1/req/receive-updates-via-mqtt/receive-updates",
                // "https://fraunhoferiosb.github.io/FROST-Server/extensions/DeepSelect.html",
                // "https://fraunhoferiosb.github.io/FROST-Server/extensions/GeoJSON-ResultFormat.html",
                // "https://fraunhoferiosb.github.io/FROST-Server/extensions/JsonBatchRequest.html",
                // "https://fraunhoferiosb.github.io/FROST-Server/extensions/OpenAPI.html",
                // "https://fraunhoferiosb.github.io/FROST-Server/extensions/ResponseMetadata.html",
                // "https://fraunhoferiosb.github.io/FROST-Server/extensions/SelectDistinct.html",
                // "https://github.com/INSIDE-information-systems/SensorThingsAPI/blob/master/CSV-ResultFormat/CSV-ResultFormat.md",
                // "https://github.com/INSIDE-information-systems/SensorThingsAPI/blob/master/EntityLinking/Linking.md#Expand",
                // "https://github.com/INSIDE-information-systems/SensorThingsAPI/blob/master/EntityLinking/Linking.md#Filter",
                // "https://github.com/INSIDE-information-systems/SensorThingsAPI/blob/master/EntityLinking/Linking.md#NavigationLinks"],
                if (ctx.service.extensions.includes(enums_1.EExtensions.lora))
                    list.push(`${ctx.decodedUrl.origin}/#api-Loras`);
                if (ctx.service.extensions.includes(enums_1.EExtensions.multiDatastream))
                    list.push("https://docs.ogc.org/is/18-088/18-088.html#multidatastream-extension");
                if (ctx.service.extensions.includes(enums_1.EExtensions.mqtt))
                    list.push("https://docs.ogc.org/is/18-088/18-088.html#req-create-observations-via-mqtt-observations-creation", "https://docs.ogc.org/is/18-088/18-088.html#mqtt-extension");
                const temp = {
                    "value": expectedResponse.filter((elem) => Object.keys(elem).length),
                    "serverSettings": {
                        "conformance": list
                    }
                };
                list.push(`${ctx.decodedUrl.origin}/#api-Services`);
                list.push(`${ctx.decodedUrl.origin}/#api-Token`);
                list.push(`${ctx.decodedUrl.origin}/#api-Import`);
                list.push(`${ctx.decodedUrl.origin}/#api-Format`);
                temp[`${ctx.decodedUrl.linkbase}/${ctx.service.apiVersion}/req/receive-updates-via-mqtt/receive-updates`] = {
                    "endpoints": [`mqtt://server.example.com:${configuration_1.config.getService(enums_1.EConstant.admin).ports?.ws}`, "ws://server.example.com/sensorThings"]
                };
                return temp;
            default:
                break;
        }
    }
    /**
     * initialize model class
     */
    initialisation() {
        if ((0, helpers_1.isTest)())
            this.createVersion("v1.1");
    }
}
exports.Models = Models;
exports.models = new Models();
