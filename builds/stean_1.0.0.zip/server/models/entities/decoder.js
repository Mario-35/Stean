"use strict";
/**
 * entity Decoder.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DECODER = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.DECODER = new entity_1.Entity("Decoders", {
    createOrder: 10,
    type: enums_1.ETable.table,
    order: 12,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        name: new types_1.Text().notNull().type(),
        hash: new types_1.Text().type(),
        code: new types_1.Text().notNull().default("const decoded = null; return decoded;").type(),
        nomenclature: new types_1.Text().notNull().default("{}").type(),
        synonym: new types_1.Text().type()
    },
    relations: {
        Loras: {
            type: enums_1.ERelations.hasMany
        }
    }
});
