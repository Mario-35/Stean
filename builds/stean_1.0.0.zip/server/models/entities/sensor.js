"use strict";
/**
 * entity Sensor
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SENSOR = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.SENSOR = new entity_1.Entity("Sensors", {
    createOrder: 6,
    type: enums_1.ETable.table,
    order: 9,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        name: new types_1.Text().notNull().type(),
        description: new types_1.Text().notNull().type(),
        encodingType: new types_1.Text().default("application/pdf").type(),
        metadata: new types_1.Text().default("none.pdf").type()
    },
    relations: {
        Datastreams: {
            type: enums_1.ERelations.hasMany
        },
        MultiDatastreams: {
            type: enums_1.ERelations.hasMany
        }
    }
});
