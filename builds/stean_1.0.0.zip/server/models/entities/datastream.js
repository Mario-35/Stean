"use strict";
/**
 * entity Datastream
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DATASTREAM = void 0;
const enums_1 = require("../../enums");
const messages_1 = require("../../messages");
const entity_1 = require("../entity");
const types_1 = require("../types");
exports.DATASTREAM = new entity_1.Entity("Datastreams", {
    createOrder: 7,
    type: enums_1.ETable.table,
    order: 1,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        name: new types_1.Text().notNull().type(),
        description: new types_1.Text().notNull().default(messages_1.info.noDescription).type(),
        observationType: new types_1.Text().notNull().default("http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement").verify(Object.keys(enums_1.EObservationType)).type(),
        unitOfMeasurement: new types_1.Jsonb().notNull().type(),
        observedArea: new types_1.Geometry().type(),
        phenomenonTime: new types_1.Tmperiod("timestamp").source("Observations").coalesce("resultTime").type(),
        resultTime: new types_1.Tmperiod("timestamp").source("Observations").type(),
        thing_id: new types_1.Relation().relation("Things").type(),
        observedproperty_id: new types_1.Relation().relation("ObservedProperties").type(),
        sensor_id: new types_1.Relation().relation("Sensors").type(),
        _default_featureofinterest: new types_1.Relation().relation("FeaturesOfInterest").default(1).type()
    },
    relations: {
        Thing: {
            type: enums_1.ERelations.belongsTo
        },
        Sensor: {
            type: enums_1.ERelations.belongsTo
        },
        ObservedProperty: {
            type: enums_1.ERelations.belongsTo
        },
        Observations: {
            type: enums_1.ERelations.hasMany
        },
        Lora: {
            type: enums_1.ERelations.belongsTo
        },
        FeatureOfInterest: {
            type: enums_1.ERelations.defaultUnique
        }
    }
});
