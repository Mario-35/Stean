"use strict";
/**
 * entity FeatureOfInterest
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.FEATUREOFINTEREST = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.FEATUREOFINTEREST = new entity_1.Entity("FeaturesOfInterest", {
    createOrder: 4,
    type: enums_1.ETable.table,
    order: 4,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        name: new types_1.Text().notNull().type(),
        description: new types_1.Text().notNull().type(),
        encodingType: new types_1.Text().type(),
        feature: new types_1.Jsonb().notNull().type()
    },
    relations: {
        Observations: {
            type: enums_1.ERelations.hasMany
        },
        Datastreams: {
            type: enums_1.ERelations.hasMany
        },
        MultiDatastreams: {
            type: enums_1.ERelations.hasMany
        }
    },
    after: "INSERT INTO featureofinterest (name, description, \"encodingType\", feature) VALUES ('Default Feature of Interest', 'Default Feature of Interest', 'application/vnd.geo+json', '{}');"
});
