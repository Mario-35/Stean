"use strict";
/**
 * entity Thing
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.THING = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.THING = new entity_1.Entity("Things", {
    createOrder: 1,
    type: enums_1.ETable.table,
    order: 10,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        name: new types_1.Text().notNull().type(),
        description: new types_1.Text().notNull().type(),
        properties: new types_1.Jsonb().type()
    },
    relations: {
        Locations: {
            type: enums_1.ERelations.belongsToMany,
            entityRelation: "ThingsLocations"
        },
        HistoricalLocations: {
            type: enums_1.ERelations.hasMany
        },
        Datastreams: {
            type: enums_1.ERelations.hasMany
        },
        MultiDatastreams: {
            type: enums_1.ERelations.hasMany
        }
    }
});
