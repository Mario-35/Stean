"use strict";
/**
 * file File
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.FILE = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const messages_1 = require("../../messages");
const types_1 = require("../types");
exports.FILE = new entity_1.Entity("Files", {
    createOrder: 1,
    type: enums_1.ETable.table,
    order: 1,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        name: new types_1.Text().notNull().default(messages_1.info.noName).unique().type(),
        description: new types_1.Text().notNull().default(messages_1.info.noDescription).type(),
        properties: new types_1.Jsonb().type(),
    },
    relations: {
        Lines: {
            type: enums_1.ERelations.hasMany
        }
    }
});
