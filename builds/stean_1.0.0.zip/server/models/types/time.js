"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Time = void 0;
const enums_1 = require("../../enums");
const core_1 = require("./core");
class Time extends core_1.Core {
    constructor(tz) {
        super(tz ? enums_1.EDataType.timetz : enums_1.EDataType.time, tz ? "TIMETZ" : "TIME");
    }
    defaultCurrent() {
        this._create = this._create.replace("@DEFAULT@", " DEFAULT CURRENT_TIME");
        return this;
    }
    alias(alias) {
        const tmpType = this._dataType === enums_1.EDataType.timetz ? enums_1.EDatesType.timeTz : enums_1.EDatesType.time;
        this._override = {
            create: "",
            alias(service, test) {
                return `CONCAT(to_char("_${alias}Start",'${tmpType}'),'/',to_char("_${alias}End",'${tmpType}')) AS "${alias}"`;
            },
            dataType: enums_1.EDataType.text
        };
        return this;
    }
}
exports.Time = Time;
