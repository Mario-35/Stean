"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Timestamp = void 0;
const enums_1 = require("../../enums");
const core_1 = require("./core");
class Timestamp extends core_1.Core {
    constructor(tz) {
        super(tz ? enums_1.EDataType.timestamptz : enums_1.EDataType.timestamp, tz ? "TIMESTAMPTZ" : "TIMESTAMP");
    }
    defaultCurrent() {
        this._create = this._create.replace("@DEFAULT@", " DEFAULT CURRENT_TIMESTAMP");
        return this;
    }
    alias(alias) {
        const tmpType = this._dataType === enums_1.EDataType.timestamptz ? enums_1.EDatesType.dateTz : enums_1.EDatesType.date;
        this._override = {
            create: "",
            alias(service, test) {
                return `CONCAT(to_char("_${alias}Start",'${tmpType}'),'/',to_char("_${alias}End",'${tmpType}')) AS "${alias}"`;
            },
            dataType: enums_1.EDataType.text
        };
        return this;
    }
}
exports.Timestamp = Timestamp;
