"use strict";
/**
 * Trace class
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Trace = void 0;
const helpers_1 = require("../helpers");
const _1 = require(".");
const paths_1 = require("../paths");
const enums_1 = require("../enums");
const constants_1 = require("../db/constants");
/**
 * Class to trace requests
 */
class Trace {
    static adminConnection;
    constructor(adminConnection) {
        Trace.adminConnection = adminConnection;
    }
    query(ctx, error) {
        return ctx.traceId && error ? `UPDATE public.log SET error = ${(0, constants_1.FORMAT_JSONB)(error)} WHERE id = ${ctx.traceId}` : `INSERT INTO public.log (method, url${(0, helpers_1.notNull)(ctx.body) ? ", datas" : ""}${(0, helpers_1.notNull)(error) ? ", error" : ""}) VALUES('${ctx.method}', '${ctx.request.url}'${(0, helpers_1.notNull)(ctx.body) ? `,${(0, constants_1.FORMAT_JSONB)(ctx.body)}` : ""}${(0, helpers_1.notNull)(error) ? `,${(0, constants_1.FORMAT_JSONB)(error)}` : ""}) RETURNING id;`;
    }
    /**
     * Add to trace
     *
     * @param ctx koa context
     */
    async write(ctx) {
        if (ctx.method !== "GET") {
            const datas = this.query(ctx);
            await Trace.adminConnection
                .unsafe(datas)
                .then((res) => {
                ctx.traceId = BigInt(res[0].id);
            })
                .catch(async (error) => {
                console.log(error);
                if (error.code === "42P01") {
                    await Trace.adminConnection.unsafe(`CREATE TABLE public.log ( id int8 GENERATED ALWAYS AS IDENTITY( INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1 NO CYCLE ) NOT NULL, "date" timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL, "method" text NULL, url text NULL, datas jsonb NULL, CONSTRAINT log_pkey PRIMARY KEY (id) ); CREATE INDEX log_id ON public.log USING btree (id); `).catch((err) => process.stdout.write(err + enums_1.EConstant.return));
                    Trace.adminConnection.unsafe(datas);
                }
                else
                    process.stdout.write(error + enums_1.EConstant.return);
            });
        }
    }
    /**
     * Trace error
     *
     * @param ctx koa context
     */
    async error(ctx, error) {
        try {
            await Trace.adminConnection.unsafe(this.query(ctx, error));
        }
        catch (err) {
            console.log("---- [Error]-------------");
            console.log(err);
            console.log(this.query(ctx, error));
        }
    }
    async get(query) {
        return new Promise(async function (resolve, reject) {
            await Trace.adminConnection
                .unsafe(query)
                .values()
                .then((res) => {
                resolve(res[0]);
            })
                .catch((err) => {
                if (!(0, helpers_1.isTest)() && +err["code"] === 23505) {
                    const input = _1.log.queryError(query, err);
                    process.stdout.write(input + enums_1.EConstant.return);
                    paths_1.paths.logFile.writeStream((0, helpers_1.logToHtml)(input));
                }
                reject(err);
            });
        });
    }
}
exports.Trace = Trace;
