"use strict";
/**
 * blankRootPgVisitor
 *
 * @copyright 2022-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.blankRootPgVisitor = void 0;
const __1 = require("..");
const parser_1 = require("../../parser/parser");
const blankRootPgVisitor = (ctx, entity) => {
    const astRessources = (0, parser_1.resourcePath)(entity.name);
    const astQuery = (0, parser_1.query)(decodeURIComponent(`$top=${ctx.service.nb_page ? ctx.service.nb_page : 200}`));
    try {
        return new __1.RootPgVisitor(ctx, {
            onlyValue: false,
            onlyRef: false,
            valueskeys: false
        }, astRessources).start(astQuery);
    }
    catch (error) {
        console.log(error);
        return undefined;
    }
};
exports.blankRootPgVisitor = blankRootPgVisitor;
