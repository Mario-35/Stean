"use strict";
/**
 * pgVisitor index.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createOdata = void 0;
const parser_1 = require("./parser/parser");
const helpers_1 = require("../helpers");
const visitor_1 = require("./visitor");
const messages_1 = require("../messages");
const enums_1 = require("../enums");
const helper_1 = require("./visitor/helper");
const createOdata = async (ctx) => {
    // init Ressource wich have to be tested first
    const options = {
        onlyValue: false,
        onlyRef: false,
        valueskeys: false
    };
    // normalize href
    let urlSrc = `${ctx.decodedUrl.path}${ctx.decodedUrl.search}`;
    if (urlSrc && urlSrc.trim() != "")
        urlSrc = (0, helper_1.escapesOdata)(urlSrc);
    // replace element
    const replaceElement = (replaceThis, by) => (urlSrc = urlSrc.split(replaceThis).join(by ? by : ""));
    // function to remove element in url
    const removeElement = (input) => {
        replaceElement(`&${input}`);
        replaceElement(input);
    };
    replaceElement("geography%27", "%27");
    replaceElement("@iot.");
    // clean id in url
    urlSrc = (0, helpers_1.cleanUrl)(replaceElement(enums_1.EConstant.id, "id"));
    // if nothing to do return
    if (urlSrc === "/")
        return;
    // If params after ? in loras post delete them to not be catch by odata
    if (ctx.request.method === "POST" && ctx.originalUrl.includes(`/Loras`))
        urlSrc = urlSrc.split("?")[0];
    // Remove actions that are not odata
    if (urlSrc.includes("$"))
        urlSrc.split("$").forEach((element) => {
            switch (element) {
                case "value?":
                case "value":
                    options.onlyValue = true;
                    removeElement(`/$${element}`);
                    break;
                case "ref":
                    options.onlyRef = true;
                    removeElement(`/$${element}`);
                    break;
                case "valuesKeys=true":
                    options.valueskeys = true;
                    removeElement(`$${element}`);
                    break;
            }
        });
    const urlSrcSplit = (0, helpers_1.cleanUrl)(urlSrc).split("?");
    if (!urlSrcSplit[1])
        urlSrcSplit.push(`$top=${ctx.service.nb_page || 200}`);
    if (urlSrcSplit[0].split("(").length != urlSrcSplit[0].split(")").length)
        urlSrcSplit[0] += ")";
    // INIT ressource
    let astRessources;
    const src = urlSrcSplit[0].split("/");
    try {
        astRessources = src.length > 1 ? (0, parser_1.resourcePath)([src.shift(), src.shift()].filter((e) => e !== "").join("/")) : (0, parser_1.resourcePath)(urlSrcSplit[0]);
    }
    catch (error) {
        console.log(error);
        ctx.throw(404 /* EHttpCode.notFound */, { code: 400 /* EHttpCode.badRequest */, detail: messages_1.errors.notValid });
    }
    // INIT query
    const astQuery = (0, parser_1.query)(decodeURIComponent(urlSrcSplit[1]));
    const temp = new visitor_1.RootPgVisitor(ctx, options, astRessources, src).start(astQuery);
    await (0, helper_1.doSomeWorkAfterCreateAst)(temp, ctx);
    return temp;
};
exports.createOdata = createOdata;
