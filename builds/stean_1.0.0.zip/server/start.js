Object.defineProperty(exports,"__esModule",{value:!0});let fs=require("fs"),_1=require(".");function message(e,s){process.stdout.write(`[36m${e} [32m:[37m ${s}[0m 
`)}fs.existsSync("./newVersion")&&(process.stdout.write(`[34m${"▬".repeat(24)} [32m New Versin detected [34m${"▬".repeat(24)}[0m 
`),fs.rename("./server","./bak",e=>{message("update","Backup server"),e&&process.exit(112),message("new","folder server"),fs.rename("./newVersion","./server",e=>{e&&process.exit(112)})})),process.stdout.write(`[34m${"▬".repeat(24)}[32m Run index.js [34m${"▬".repeat(24)}[0m 
`),_1.server;