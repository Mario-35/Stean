"use strict";
/**
 * columnType Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EColumnType = void 0;
var EColumnType;
(function (EColumnType) {
    EColumnType[EColumnType["Null"] = 0] = "Null";
    EColumnType[EColumnType["Column"] = 1] = "Column";
    EColumnType[EColumnType["SelfLink"] = 2] = "SelfLink";
    EColumnType[EColumnType["Relation"] = 3] = "Relation";
    EColumnType[EColumnType["Table"] = 4] = "Table";
})(EColumnType || (exports.EColumnType = EColumnType = {}));
