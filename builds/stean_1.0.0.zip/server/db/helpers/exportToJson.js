"use strict";
/**
 * exportToJson
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.exportToJson = void 0;
const configuration_1 = require("../../configuration");
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const entities_1 = require("../../models/entities");
const exportToJson = async (ctx) => {
    // get config with hidden password
    const result = { "create": (0, helpers_1.hidePassword)(configuration_1.config.getService(ctx.service.name)) };
    // get entites list
    const entities = Object.keys(ctx.model).filter((e) => ctx.model[e].createOrder > 0);
    // add ThingsLocations
    entities.push(entities_1.THINGLOCATION.name);
    // async loop
    await (0, helpers_1.asyncForEach)(
    // Entities list
    entities, 
    // Action
    async (entity) => {
        if (Object.keys(ctx.model[entity].columns) && ctx.model[entity].table != "") {
            // Create columns list
            const columnList = Object.keys(ctx.model[entity].columns).filter((e) => e != "id" && !e.endsWith("_id") && e[0] != "_" && ctx.model[entity].columns[e].create != "");
            // Create relations list
            const rels = [""];
            Object.keys(ctx.model[entity].columns)
                .filter((e) => e.endsWith("_id"))
                .forEach((e) => {
                const table = e.split("_")[0];
                rels.push(`CASE WHEN "${e}" ISNULL THEN NULL ELSE JSON_BUILD_OBJECT('@iot.name', (SELECT REPLACE (name, '''', '''''') FROM "${table}" WHERE "${table}"."id" = ${e} LIMIT 1)) END AS "${e}"`);
            });
            const columnListWithQuotes = columnList.map((e) => (0, helpers_1.doubleQuotesString)(e)).join();
            if (columnListWithQuotes.length <= 1)
                rels.shift();
            // Execute query
            const tempResult = await configuration_1.config.connection(ctx.service.name).unsafe(`select ${columnListWithQuotes}${rels.length > 1 ? rels.join() : ""}${enums_1.EConstant.return} FROM "${ctx.model[entity].table}" LIMIT ${(0, helpers_1.getUrlKey)(ctx.request.url, "limit") || ctx.service.nb_page}`);
            // remove null and store datas result
            result[entity] = (0, helpers_1.removeEmpty)(tempResult);
        }
    });
    delete result["FeaturesOfInterest"][0];
    return result;
};
exports.exportToJson = exportToJson;
