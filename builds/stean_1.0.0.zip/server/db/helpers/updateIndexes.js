"use strict";
/**
 * updateIndexes
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateIndexes = void 0;
const configuration_1 = require("../../configuration");
const models_1 = require("../../models");
/**
 * this (re)create index without wait
 *
 * @param name
 */
const updateIndexes = (name) => {
    const mod = models_1.models.DBFull(name);
    Object.keys(mod).forEach((entity) => {
        const tmp = mod[entity].update;
        if (tmp)
            tmp.forEach((e) => configuration_1.config
                .connection(name)
                .unsafe(e)
                .catch((error) => {
                console.error(error);
                console.log(error);
                return false;
            }));
    });
};
exports.updateIndexes = updateIndexes;
