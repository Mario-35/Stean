"use strict";
/**
 * CreateObservations entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateObservations = void 0;
const common_1 = require("./common");
const helpers_1 = require("../helpers");
const helpers_2 = require("../../helpers");
const messages_1 = require("../../messages/");
const enums_1 = require("../../enums");
const util_1 = __importDefault(require("util"));
const models_1 = require("../../models");
const log_1 = require("../../log");
const entities_1 = require("../../models/entities");
const configuration_1 = require("../../configuration");
/**
 * CreateFile Class
 */
class CreateObservations extends common_1.Common {
    indexResult = -1;
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    createListColumnsValues(type, input) {
        const res = [];
        const separateur = type === "COLUMNS" ? '"' : "'";
        input.forEach((elem, index) => {
            switch (elem) {
                case "result":
                    this.indexResult = index + 1;
                    break;
                case "FeatureOfInterest/id":
                    elem = "featureofinterest_id";
                    break;
            }
            res.push(isNaN(+elem) ? (Array.isArray(elem) ? `'{"value": [${elem}]}'` : typeof elem === "string" ? (elem.endsWith("Z") ? `TO_TIMESTAMP('${(0, helpers_1.dateToDateWithTimeZone)(elem)}', '${enums_1.EDatesType.dateImport}')::TIMESTAMP` : `${separateur}${elem}${separateur}`) : `${separateur}{${elem}}${separateur}`) : index === this.indexResult && type === "VALUES" ? (this.ctx.service.extensions.includes(enums_1.EExtensions.resultNumeric) ? elem : `'{"value": ${elem}}'`) : elem);
        });
        return res;
    }
    // Override get all to return error Bad request
    async getAll() {
        console.log(log_1.log.whereIam());
        this.ctx.throw(400 /* EHttpCode.badRequest */, { code: 400 /* EHttpCode.badRequest */ });
    }
    // Override get one to return error Bad request
    async getSingle() {
        console.log(log_1.log.whereIam());
        this.ctx.throw(400 /* EHttpCode.badRequest */, { code: 400 /* EHttpCode.badRequest */ });
    }
    // Override post to posted file as createObservations
    async postForm() {
        console.log(log_1.log.whereIam());
        // verify is there FORM data
        // const datasJson = JSON.parse(this.ctx.datas["datas"]);
        const datasJson = JSON.parse(this.ctx.datas["datas"] || this.ctx.datas["json"]);
        if (!datasJson["columns"])
            this.ctx.throw(404 /* EHttpCode.notFound */, { code: 404 /* EHttpCode.notFound */, detail: messages_1.errors.noColumn });
        const myColumns = [];
        const streamInfos = [];
        // loop for mulitDatastreams inputs or one for datastream
        await (0, helpers_2.asyncForEach)(Object.keys(datasJson["columns"]), async (key) => {
            const tempStreamInfos = await models_1.models.getStreamInfos(this.ctx.service, datasJson["columns"][key]);
            if (tempStreamInfos) {
                streamInfos.push(tempStreamInfos);
                myColumns.push({
                    column: key,
                    stream: tempStreamInfos
                });
            }
            else
                this.ctx.throw(404 /* EHttpCode.notFound */, (0, messages_1.msg)(messages_1.errors.noValidStream, util_1.default.inspect(datasJson["columns"][key], { showHidden: false, depth: null, colors: false })));
        });
        // Create paramsFile
        const paramsFile = {
            tempTable: `temp${Date.now().toString()}`,
            filename: this.ctx.datas["file"],
            columns: myColumns,
            header: datasJson["header"] && datasJson["header"] == true ? ", HEADER" : "",
            stream: streamInfos
        };
        // stream file in temp table and get query to insert
        const sqlInsert = await (0, helpers_1.queryInsertFromCsv)(this.ctx.service, paramsFile);
        console.log(log_1.log.debug_infos(`Stream csv file ${paramsFile.filename} in PostgreSql`, sqlInsert ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : "\u274C" /* EChar.notOk */));
        if (sqlInsert) {
            const sqls = sqlInsert.query.map((e, index) => `${index === 0 ? "WITH " : ", "}updated${index + 1} as (${e})${enums_1.EConstant.return}`);
            // Remove logs and triggers for speed insert
            await configuration_1.config.executeSql(this.ctx.service, `SET session_replication_role = replica;`);
            const resultSql = await configuration_1.config.executeSql(this.ctx.service, `${sqls.join("")}SELECT (SELECT count(*) FROM ${paramsFile.tempTable}) AS total, (SELECT count(*) FROM updated1) AS inserted`);
            // Restore logs and triggers
            await configuration_1.config.executeSql(this.ctx.service, `SET session_replication_role = DEFAULT;`);
            return this.formatReturnResult({
                total: sqlInsert.count,
                body: [`Add ${resultSql[0]["inserted"]} on ${resultSql[0]["total"]} lines from ${paramsFile.filename.split("/").reverse()[0]}`]
            });
        }
        return undefined;
    }
    // Override post xson file as createObservations
    async postJson(dataInput) {
        console.log(log_1.log.whereIam());
        const returnValue = [];
        let total = 0;
        /// classic Create
        const dataStreamId = await models_1.models.getStreamInfos(this.ctx.service, dataInput);
        if (!dataStreamId)
            this.ctx.throw(404 /* EHttpCode.notFound */, { code: 404 /* EHttpCode.notFound */, detail: messages_1.errors.noStream });
        else {
            await (0, helpers_2.asyncForEach)(dataInput["dataArray"], async (elem) => {
                const keys = [`"${dataStreamId.type?.toLowerCase()}_id"`].concat(this.createListColumnsValues("COLUMNS", dataInput["components"]));
                const values = this.createListColumnsValues("VALUES", [String(dataStreamId.id), ...elem]);
                await configuration_1.config
                    .executeSqlValues(this.ctx.service, `INSERT INTO ${(0, helpers_2.doubleQuotesString)(entities_1.OBSERVATION.table)} (${keys}) VALUES (${values}) RETURNING id`)
                    .then((res) => {
                    returnValue.push(this.linkBase.replace("Create", "") + "(" + res[0] + ")");
                    total += 1;
                })
                    .catch(async (error) => {
                    if (error.code === "23505") {
                        returnValue.push(`Duplicate (${elem})`);
                        if (dataInput["duplicate"] && dataInput["duplicate"].toUpperCase() === "DELETE") {
                            await configuration_1.config
                                .executeSqlValues(this.ctx.service, `DELETE FROM ${(0, helpers_2.doubleQuotesString)(entities_1.OBSERVATION.table)} WHERE 1=1 ` + keys.map((e, i) => `AND ${e} = ${values[i]}`).join(" ") + ` RETURNING id`)
                                .then((res) => {
                                returnValue.push(`delete id ==> ${res[0]}`);
                                total += 1;
                            })
                                .catch((error) => {
                                console.log(error);
                            });
                        }
                    }
                    else
                        this.ctx.throw(400 /* EHttpCode.badRequest */, { code: 400 /* EHttpCode.badRequest */, detail: error });
                });
            });
            if (returnValue) {
                return this.formatReturnResult({
                    total: total,
                    body: returnValue
                });
            }
        }
    }
    // Override post caller
    async post(dataInput) {
        console.log(log_1.log.whereIam());
        return this.ctx.datas ? await this.postForm() : await this.postJson(dataInput);
    }
    // Override update to return error Bad request
    async update(dataInput) {
        console.log(log_1.log.whereIam());
        this.ctx.throw(400 /* EHttpCode.badRequest */, { code: 400 /* EHttpCode.badRequest */ });
    }
    // Override delete to return error Bad request
    async delete(idInput) {
        console.log(log_1.log.whereIam());
        this.ctx.throw(400 /* EHttpCode.badRequest */, { code: 400 /* EHttpCode.badRequest */ });
    }
}
exports.CreateObservations = CreateObservations;
