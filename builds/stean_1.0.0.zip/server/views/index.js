"use strict";
/**
 * HTML Views Index for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Documentation = exports.Query = exports.Status = exports.HtmlError = exports.Login = exports.Update = exports.Admin = void 0;
var admin_1 = require("./class/admin");
Object.defineProperty(exports, "Admin", { enumerable: true, get: function () { return admin_1.Admin; } });
var update_1 = require("./class/update");
Object.defineProperty(exports, "Update", { enumerable: true, get: function () { return update_1.Update; } });
var login_1 = require("./class/login");
Object.defineProperty(exports, "Login", { enumerable: true, get: function () { return login_1.Login; } });
var error_1 = require("./class/error");
Object.defineProperty(exports, "HtmlError", { enumerable: true, get: function () { return error_1.HtmlError; } });
var status_1 = require("./class/status");
Object.defineProperty(exports, "Status", { enumerable: true, get: function () { return status_1.Status; } });
var query_1 = require("./class/query");
Object.defineProperty(exports, "Query", { enumerable: true, get: function () { return query_1.Query; } });
var documentation_1 = require("./class/documentation");
Object.defineProperty(exports, "Documentation", { enumerable: true, get: function () { return documentation_1.Documentation; } });
