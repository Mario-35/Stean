let pretty=new pp;function methodIcon(t){return`<span class="method meth-${t}">${t}</span>`}function getMenuMain(t){for(;t&&!t.classList.contains("patrom-accordion-content");)t=t.parentElement;if((t=t.previousElementSibling).classList.contains("patrom-accordion-label"))return t.innerHTML}function getExamples(t,e){let s=['<div class="patrom-tabs">'];return Object.keys(t).forEach((t,e)=>{s.push(`<input type="radio" name="tabs" id="tab${e}" ${0==e?'checked="checked"':""}>`,`<label for="tab${e}">${t}</label>`,'<div class="patrom-tab">',`<div contenteditable="" id="datas${e}" spellcheck="false" class="shj-lang-js">`,"</div>","</div>")}),s.push("</div>"),s.join("")}function getContent(t){return`<article class="">
    <div class="pull-left">
      <h1>${t.short}</h1>
    </div>
    ${t.description?`<section><p>${t.description}</p></section>`:""}
    ${t.structure?`<section>${getStructure(t.structure)}</section>`:""}
    ${t.examples?`<section>${getExamples(t.examples,t.params)}</section>`:""}
    ${t.params?`<section><div class="datasBox"> <h2 class="title">Datas</h2> <div class="view"> <div id="jsonDatasContainer"> <div contenteditable spellcheck="false" id="jsonDatas" class='blakkAll shj-lang-json'></div> </div></div> </div></section>`:""}
    ${t.success?'<section><div class="successBox"> <h2 class="title">Success 200</h2> <div class="view"> <div id="success"></div> </div> </div></section>':""}
    ${t.error?'<section><div class="errorBox"> <h2 class="title">Error</h2> <div class="view"> <div id="error"></div> </div> </div></section>':""}
  </article>`}function getStructure(s){let a=["<table>","<thead>","<tr>",'<th style="width: 20%">Champ</th>','<th style="width: 5%">Requis</th>','<th style="width: 10%">Type</th>','<th style="width: 55%">Description</th>',"</tr>","</thead>","<tbody>"];return["columns","relations"].forEach(e=>{Object.keys(s[e]).forEach(t=>{a.push("<tr>",`<td>${t}</td>`,`<td>${1==s[e][t].requis?"✔️":"❌"}</td>`,`<td>${s[e][t].type}</td>`,`<td>${s[e][t].description}</td>`,"</tr>")})}),a.push("</tbody>","</table>"),a.join("")}function showDoc(t){var e=getMenuMain(t.srcElement);let s=doc[e][t.srcElement.id];var e=getContent(s);document.getElementById("content").innerHTML=e,document.getElementById("two").style.overflow="auto",s.params&&beautifyDatas(getElement("jsonDatas"),s.params,"json"),s.success&&(t=new JSONViewer,success.appendChild(t.getContainer()),t.showJSON(JSON.parse(s.success))),s.error&&(e=new JSONViewer,error.appendChild(e.getContainer()),e.showJSON(JSON.parse(s.error))),s.examples&&Object.keys(s.examples).forEach((t,e)=>{beautifyDatas(getElement("datas"+e),s.examples[t].replace("@DATAS@",`m${JSON.stringify(s.params,4,null)}m`),"js")})}function essai(t){search.value,Object.keys()}(()=>{let e=[`<div class="patrom-row">
                  <div class="patrom-col col-span-10">
                    <div class="field">                      
                      <input id="search" type="text" class="patrom-text-input width75">
                      <div class="patrom-button-bar__item">
                      <button class="patrom-button-bar__button" id="btnFilter" onclick="essai(event)">filter</button>
                    </div>
                    </div>
                  </div>

                <div class="patrom-col col-span-2">
                  <label class="patrom-switch">
                    <input id="theme" type="checkbox" class="patrom-switch__input" onchange="toggleTheme()">
                    <div class="patrom-switch__theme"></div>
                  </label>
                </div>
              </div>  `];Object.keys(doc).forEach((s,t)=>{e.push(`<div class="patrom-accordion">
      <input class="patrom-accordion-check" type="checkbox" id="chck${t}">
      <label class="patrom-accordion-label" for="chck${t}" id="Labelchck${t}">${s}</label>
      <div class="patrom-accordion-content">        
          ${Object.keys(doc[s]).map((t,e)=>`<div class="patrom-row">
          <div class="patrom-col col-span-12" fullWidth">
          ${methodIcon(doc[s][t].type)}
          <label class="menuItem" onclick="showDoc(event)" id="${e}">${doc[s][t].short} </label>                      
        </div>
      </div>`).join("")}  
      </div>
    </div>`)}),document.getElementById("menuTabs").innerHTML=e.join(""),wait(!1),new SplitterBar(container,first,two),jsonViewer=new JSONViewer})();