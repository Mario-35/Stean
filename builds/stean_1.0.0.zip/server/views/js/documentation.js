function methodIcon(e){return`<span class="method meth-${e}">${e}</span>`}function getMenuMain(e){for(;e&&!e.classList.contains("patrom-accordion-content");)e=e.parentElement;if((e=e.previousElementSibling).classList.contains("patrom-accordion-label"))return e.innerHTML}function getExamples(a,e){let s=['<div class="patrom-tabs">'];return Object.keys(a).forEach((e,t)=>{s.push(`<input type="radio" name="tabs" id="tab${t}" ${0==t?'checked="checked"':""}>`,`<label for="tab${t}">${e}</label>`,'<div class="patrom-tab">',`<code class='language-${e}'>`,a[e],"</code>","</div>")}),s.push("</div>"),s.join("")}function getContent(e){return`<article class="">
    <div class="pull-left">
      <h1>${e.short}</h1>
    </div>
    ${e.description?`<section><p>${e.description}</p></section>`:""}
    ${getDatasTabs(e)}    
    ${e.examples?`<section>${getExamples(e.examples,e.params)}</section>`:""}
  </article>`}function getDatasTabs(e){let a=0;function t(e,t){return`<li class="tab__item">
              <input class="tab__radio" type="radio" name="tab" id="tab_id_${a+=1}" ${1===a?'checked="checked"':""}/>
              <label class="tab__label" for="tab_id_${a}">${e}</label>
              <div class="tab__content">
                ${t}                 
              </div>
            </li>`}e=`
          <div class="tab">
            <div class="tab__body">
              <ul class="tab__list">
                ${e.params?t("Params",'<div class="view"> <div id="params"></div></div>'):""}
                ${e.success?t("Success",'<div class="view"> <div id="success"></div></div>'):""}
                ${e.error?t("Error",'<div class="view"> <div id="error"></div></div>'):""}
                ${e.structure?t("Structure",`<div class="view">${getStructure(e.structure)}</div>`):""}
              </ul>
            </div>
          </div>`;return 0===a?"":e}function getStructure(a){let s=["<table>","<thead>","<tr>",'<th style="width: 20%">Champ</th>','<th style="width: 5%">Requis</th>','<th style="width: 10%">Type</th>','<th style="width: 55%">Description</th>',"</tr>","</thead>","<tbody>"];return["columns","relations"].forEach(t=>{Object.keys(a[t]).forEach(e=>{s.push("<tr>",`<td>${e}</td>`,`<td>${1==a[t][e].requis?"✔️":"❌"}</td>`,`<td>${a[t][e].type}</td>`,`<td>${a[t][e].description}</td>`,"</tr>")})}),s.push("</tbody>","</table>"),s.join("")}function showDoc(e){var t=getMenuMain(e.srcElement),t=doc[t][e.srcElement.id],e=getContent(t);if(document.getElementById("content").innerHTML=e,document.getElementById("two").style.overflow="auto",t.params&&(e=new JSONViewer,params.appendChild(e.getContainer()),e.showJSON(JSON.parse(t.params))),t.success){e=new JSONViewer;success.appendChild(e.getContainer());try{e.showJSON(JSON.parse(t.success))}catch(e){}}t.error&&(e=new JSONViewer,error.appendChild(e.getContainer()),e.showJSON(JSON.parse(t.error)))}function filterDoc(){let s=search.value;Object.keys(doc).forEach(t=>{let a=!1;Object.keys(doc[t]).forEach(e=>{doc[t][e].description.includes(s)&&(a=!0);e=getElement(t+"-"+e);0==a?e.classList.add("hide"):e.classList.remove("hide"),0==a?e.parentElement.parentElement.classList.add("hide"):e.parentElement.parentElement.classList.remove("hide")})})}function createSideBar(){let t=[`<div class="patrom-row">
                    <div class="patrom-col col-span-12 fullWidth">
                      <input type="text" id="search" class="patrom-text-input" value="" placeholder="filter">
                      <button class="patrom-icon-button" onclick="filterDoc(event)"> 🔎 </button>
                      <label class="patrom-switch">
                        <input id="theme" type="checkbox" class="patrom-switch__input" onchange="localStorage.setItem('theme', localStorage.getItem('theme') === 'dark' ? 'light' : 'dark'); document.documentElement.className = localStorage.getItem('theme');">
                        <div class="patrom-switch__theme"></div>
                      </label>
                    </div>
                    </div>
                  </div>  `];return Object.keys(doc).forEach((a,e)=>{t.push(`<div class="patrom-accordion">
  <input class="patrom-accordion-check" type="checkbox" id="chck${e}">
  <label class="patrom-accordion-label" for="chck${e}" id="Labelchck${e}">${a}</label>
  <div class="patrom-accordion-content">        
  ${Object.keys(doc[a]).map((e,t)=>`<div class="patrom-row"  id="${a}-${t}">
  <div class="patrom-col col-span-12" fullWidth">
  ${methodIcon(doc[a][e].type)}
  <label class="menuItem" onclick="showDoc(event)" id="${t}">${doc[a][e].short} </label>                      
  </div>
  </div>`).join("")}  
  </div>
  </div>`)}),t.join("")}new SplitterBar(container,first,two),document.getElementById("menuTabs").innerHTML=createSideBar(),jsonViewer=new JSONViewer,wait(!1);