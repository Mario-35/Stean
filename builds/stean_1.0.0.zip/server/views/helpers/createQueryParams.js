"use strict";
/**
 * createQueryParams
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createQueryParams = createQueryParams;
const authentication_1 = require("../../authentication");
const configuration_1 = require("../../configuration");
const enums_1 = require("../../enums");
const log_1 = require("../../log");
const _1 = require("./");
async function createQueryParams(ctx) {
    console.log(log_1.log.whereIam());
    let user = await (0, authentication_1.getAuthenticatedUser)(ctx);
    user = user ? user : (0, _1.blankUser)(ctx.service);
    const listEntities = user.superAdmin === true ? Object.keys(ctx.model) : user.admin === true ? Object.keys(ctx.model).filter((elem) => ctx.model[elem].order > 0 || ctx.model[elem].createOrder === 99 || ctx.model[elem].createOrder === -1) : user.canPost === true ? Object.keys(ctx.model).filter((elem) => ctx.model[elem].order > 0 || ctx.model[elem].createOrder === 99 || ctx.model[elem].createOrder === -1) : Object.keys(ctx.model).filter((elem) => ctx.model[elem].order > 0);
    listEntities.push("Services", "Logs");
    return {
        methods: ["GET"],
        decodedUrl: ctx.decodedUrl,
        entity: ctx.service.extensions.includes(enums_1.EExtensions.file) ? "Files" : "",
        options: ctx.querystring ? ctx.querystring : "",
        user: user,
        graph: ctx.url.includes("$resultFormat=graph"),
        admin: ctx.service.name === enums_1.EConstant.admin,
        services: configuration_1.config.getInfosForAll(ctx),
        _DATAS: Object.fromEntries(Object.entries(ctx.model).filter(([k, v]) => listEntities.includes(k) && v.order >= 0))
    };
}
