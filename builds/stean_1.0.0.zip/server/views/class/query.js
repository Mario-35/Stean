"use strict";
/**
 * HTML Views First for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Query = void 0;
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const log_1 = require("../../log");
const css_1 = require("../css");
const js_1 = require("../js");
const core_1 = require("./core");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
/**
 * Query Class for HTML View
 */
class Query extends core_1.CoreHtmlView {
    params;
    constructor(ctx, datas) {
        super(ctx, datas);
        if (datas.queryOptions)
            this.params = datas.queryOptions;
        this.createQueryHtmlString();
    }
    createQueryHtmlString() {
        console.log(log_1.log.debug_head("commonHtml"));
        // if js or css .min
        const fileWithOutMin = (input) => input.replace(".min", "");
        // Split files for better search and replace
        this._HTMLResult = fs_1.default
            .readFileSync(path_1.default.resolve(__dirname, "../html/", "query.html"))
            .toString()
            .replace(/<link /g, `${enums_1.EConstant.newline}<link `)
            .replace(/<script /g, `${enums_1.EConstant.newline}<script `)
            .replace(/<\/script>/g, `</script>${enums_1.EConstant.newline}`)
            .replace(`/\r${enums_1.EConstant.newline}/g`, enums_1.EConstant.newline)
            .split(enums_1.EConstant.newline)
            .map((e) => e.trim())
            .filter((e) => e.trim() != "");
        // replace in result
        const replaceInReturnResult = (searhText, content) => {
            let index = this._HTMLResult.indexOf(searhText);
            if (index > 0)
                this._HTMLResult[index] = content;
            else {
                index = this._HTMLResult.indexOf((0, helpers_1.removeAllQuotes)(searhText));
                if (index > 0)
                    this._HTMLResult[index] = content;
            }
        };
        // users possibilities
        if (this.params.user.canPost) {
            this.params.methods.push("POST");
            this.params.methods.push("PATCH");
            if (this.params.user.canDelete)
                this.params.methods.push("DELETE");
        }
        // Format this.params
        if (this.params.options) {
            let tempOptions = this.params.options;
            if (this.params.options.includes("options=")) {
                const temp = this.params.options.split("options=");
                this.params.options = temp[1];
                tempOptions = temp[0];
            }
            else
                this.params.options = "";
            const splitOptions = tempOptions.split("&");
            const valid = ["method", "id", "entity", "subentity", "property", "onlyValue"];
            splitOptions.forEach((element) => {
                if (element.includes("=")) {
                    const temp = element.split("=");
                    if (temp[0] && temp[1]) {
                        // @ts-ignore
                        if (valid.includes(temp[0]))
                            this.params[temp[0]] = cleanUrl(temp[1]);
                        else if (temp[0] == "datas")
                            this.params.datas = JSON.parse(unescape(temp[1]));
                    }
                }
            });
        }
        // process all css files
        (0, css_1.listaddCssFiles)().forEach((item) => {
            replaceInReturnResult(`<link rel="stylesheet" href="${fileWithOutMin(item)}">`, `<style>${(0, css_1.addCssFile)(item)}</style>`);
        });
        // process all js files
        (0, js_1.listaddJsFiles)().forEach((item) => {
            replaceInReturnResult(`<script src="${fileWithOutMin(item)}"></script>`, `<script>${(0, js_1.addJsFile)(item)}</script>`);
        });
    }
    toString() {
        this.replacers({
            start: this.params.results ? "jsonObj = JSON.parse(`" + this.params.results + "`); jsonViewer.showJSON(jsonObj);" : "",
            action: `${this.params.decodedUrl.root}/${this.params.decodedUrl.version}/CreateObservations`
        });
        this.replacer("_PARAMS = {}", "_PARAMS=" + JSON.stringify(this.params, this.bigIntReplacer));
        return super.toString();
    }
}
exports.Query = Query;
