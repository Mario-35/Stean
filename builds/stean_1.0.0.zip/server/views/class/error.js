Object.defineProperty(exports,"__esModule",{value:!0}),exports.HtmlError=void 0;let log_1=require("../../log"),core_1=require("./core");class HtmlError extends core_1.CoreHtmlView{constructor(r,e){super(r,e),this.error(e.message,e.url)}error(r,e){this._HTMLResult=[`<!DOCTYPE html>
            <html>
                ${this.head("Error")}
                <body>
                    <div class="login-error">
                        <div class="login-html">
                            ${this.title("Error","titleError")}
                            <h3>${r}</h3>
                            ${this.hr()}
                            <div id="outer">
                                <div class="inner">
                                    <a href="${e}" class="button-submit">${e.includes("admin")?"Admin login":"Login"}</a>
                                </div>
                                <div class="inner">
                                    <a  href="/" class="button">Documentation</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </body>
            </html>`]}}exports.HtmlError=HtmlError;