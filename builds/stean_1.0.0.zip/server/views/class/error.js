"use strict";
/**
 * HTML Views Error for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.HtmlError = void 0;
const log_1 = require("../../log");
const core_1 = require("./core");
/**
 * Error Class for HTML View
 */
class HtmlError extends core_1.CoreHtmlView {
    constructor(ctx, datas) {
        console.log(log_1.log.whereIam("View"));
        super(ctx, datas);
        this.error(datas.message, datas.url);
    }
    error(message, url) {
        // const ref = this.ctx.decodedUrl && this.ctx.decodedUrl.linkbase ? `${this.ctx.decodedUrl.linkbase + `/${this.ctx.service.apiVersion}/Query`}` : "";
        this._HTMLResult = [
            `<!DOCTYPE html>
            <html>
                ${this.head("Error")}
                <body>
                    <div class="login-error">
                        <div class="login-html">
                            ${this.title("Error", "titleError")}
                            <h3>${message}</h3>
                            ${this.hr()}
                            <div id="outer">
                                <div class="inner">
                                    <a href="${url}" class="button-submit">${url.includes("admin") ? "Admin login" : "Login"}</a>
                                </div>
                                <div class="inner">
                                    <a  href="/" class="button">Documentation</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </body>
            </html>`
        ];
    }
}
exports.HtmlError = HtmlError;
