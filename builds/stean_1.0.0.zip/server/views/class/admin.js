"use strict";
/**
 * HTML Views First Install for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Admin = void 0;
const configuration_1 = require("../../configuration");
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const log_1 = require("../../log");
const models_1 = require("../../models");
const paths_1 = require("../../paths");
const css_1 = require("../css");
const js_1 = require("../js");
const core_1 = require("./core");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
/**
 * Admin Class for HTML View
 */
class Admin extends core_1.CoreHtmlView {
    constructor(ctx, datas) {
        console.log(log_1.log.whereIam("View"));
        super(ctx, datas);
        this.init();
    }
    /**
     * if admin login not correct redirect to admin login or create htmlPage.
     */
    init() {
        if (this.adminConnection === true)
            this.adminHtml();
        else
            this.adminLogin("admin");
    }
    /**
     * create admin htmlPage for all services.
     */
    adminHtml() {
        // get all infos for all services
        const services = configuration_1.config.getInfosForAll(this.ctx);
        const dest = this.ctx.header.referer?.split("/");
        if (dest)
            dest[dest.length - 1] = "service";
        // create params object
        const params = {
            addUrl: dest?.join("/"),
            services: services,
            versions: models_1.models
                .listVersion()
                .reverse()
                .map((e) => e.replace("_", ".")),
            extensions: (0, enums_1.enumKeys)(enums_1.EExtensions).filter((e) => !["file", "base"].includes(e)),
            options: (0, enums_1.enumKeys)(enums_1.EOptions),
            logsFiles: paths_1.paths.logFile.list()
        };
        // if js or css .min
        const fileWithOutMin = (input) => input.replace(".min", "");
        // Split files for better search and replace
        this._HTMLResult = fs_1.default
            .readFileSync(path_1.default.resolve(__dirname, "../html/", "admin.html"))
            .toString()
            .replace(/<link /g, `${enums_1.EConstant.return}<link `)
            .replace(/<script /g, `${enums_1.EConstant.return}<script `)
            .replace(/<\/script>/g, `</script>${enums_1.EConstant.return}`)
            .replace(/\r\n/g, enums_1.EConstant.return)
            .split(enums_1.EConstant.return)
            .map((e) => e.trim())
            .filter((e) => e.trim() != "");
        // replace in result
        const replaceInReturnResult = (searhText, content) => {
            let index = this._HTMLResult.indexOf(searhText);
            if (index > 0)
                this._HTMLResult[index] = content;
            else {
                index = this._HTMLResult.indexOf((0, helpers_1.removeAllQuotes)(searhText));
                if (index > 0)
                    this._HTMLResult[index] = content;
            }
        };
        // process all css files
        (0, css_1.listaddCssFiles)().forEach((item) => {
            replaceInReturnResult(`<link rel="stylesheet" href="${fileWithOutMin(item)}">`, `<style>${(0, css_1.addCssFile)(item)}</style>`);
        });
        // process all js files
        (0, js_1.listaddJsFiles)().forEach((item) => {
            replaceInReturnResult(`<script src="${fileWithOutMin(item)}"></script>`, `<script>${(0, js_1.addJsFile)(item)}</script>`);
        });
        // create all cards
        const cards = Object.keys(services)
            .filter((e) => e !== enums_1.EConstant.test)
            .map((e) => `<div class="card">
                <div class="title" onclick="selectCard('${e}')">${e}</div>
                <button class="copy-btn" id="copy${e}" onclick="copyService('${e}')"> COPY </button>
                <div class="product">
                    <span class="service-name">${services[e].version}&nbsp;:&nbsp;</span>
                    <span id="root" class="service-root" onclick="location.href = '${services[e].root}';">${services[e].root}</span>
                </div>
                <div class="description">
                    <div id="editList${e}"class="editList">
                        <textarea></textarea>
                    </div>
                    <fieldset id="options${e}">
                        <legend>Options</legend>
                        <ul class="card-list">
                            <li class="card-list-item canPoint icon-${services[e].service.options.includes(enums_1.EOptions.canDrop) ? "yes" : "no"}" onclick="selectChange('${e}', this)">canDrop</li>
                            <li class="card-list-item canPoint icon-${services[e].service.options.includes(enums_1.EOptions.forceHttps) ? "yes" : "no"}" onclick="selectChange('${e}', this)">forceHttps</li>
                            <li class="card-list-item canPoint icon-${services[e].service.options.includes(enums_1.EOptions.stripNull) ? "yes" : "no"}" onclick="selectChange('${e}', this)">stripNull</li>
                            <li class="card-list-item canPoint icon-${services[e].service.options.includes(enums_1.EOptions.unique) ? "yes" : "no"}" onclick="selectChange('${e}', this)">unique</li>
                        </ul>
                    </fieldset>
    
                    <select id="infos${e}" size="5">
                        ${services[e].service.extensions.map((f) => `<option value="${f}">${f}</option>`).join(enums_1.EConstant.return)}
                    </select>
    
                </div>
                <ul class="list" id="list${e}">
                ${Object.keys(services[e].stats)
            .map((k) => `<li>${k} : ${services[e].stats[k]}</li>`)
            .join("")}
                </ul>
                <div class="description">
                    <span class="page canPoint" onclick="editPage('${e}', this)">${services[e].service.nb_page}</span>
                    <span class="csv canPoint" onclick="editCsv('${e}', this)">${services[e].service.csvDelimiter}</span>
                    <select class="patrom-select tabindex="1" onchange="selectChange('${e}', this)">
                        <option selected="selected">Services</option>
                        <option>Statistiques</option>
                        ${services[e].service.extensions.includes("users") ? "<option>Users</option>" : ""} 
                        ${services[e].service.extensions.includes("lora") ? "<option>Loras</option>" : ""} 
                        ${services[e].service.extensions.includes("lora") ? "<option>Synonyms</option>" : ""} 
                    </select>
                </div>
                </div>`);
        this.replacers({ cards: cards.join("") });
        this.replacer("_PARAMS={}", "_PARAMS=" + JSON.stringify(params, this.bigIntReplacer));
    }
}
exports.Admin = Admin;
