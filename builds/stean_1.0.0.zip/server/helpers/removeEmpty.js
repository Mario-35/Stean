"use strict";
/**
 * removeEmpty
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeEmpty = removeEmpty;
function removeEmpty(obj) {
    if (Array.isArray(obj))
        return obj.map((v) => (v && typeof v === "object" ? removeEmpty(v) : v)).filter((v) => !(v == null));
    else
        return Object.entries(obj)
            .map(([k, v]) => [k, v && typeof v === "object" ? removeEmpty(v) : v])
            .reduce((a, [k, v]) => (v == null ? a : ((a[k] = v), a)), {});
}
