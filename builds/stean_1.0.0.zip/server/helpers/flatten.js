"use strict";
/**
 * flatten
 *
 * @copyright 2025-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.flatten = flatten;
function flatten(obj) {
    return Object.keys(obj).reduce((acc, current) => {
        const _key = `${current}`;
        const currentValue = obj[current];
        if (Array.isArray(currentValue) || Object(currentValue) === currentValue) {
            Object.assign(acc, flatten(currentValue));
        }
        else {
            acc[_key] = currentValue;
        }
        return acc;
    }, {});
}
