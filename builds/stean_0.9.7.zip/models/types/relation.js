"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Relation = void 0;
const enums_1 = require("../../enums");
const core_1 = require("./core");
class Relation extends core_1.Core {
    constructor() {
        super(enums_1.EDataType.link, "BIGINT");
    }
}
exports.Relation = Relation;
