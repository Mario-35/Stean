"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Bigint = void 0;
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const core_1 = require("./core");
class Bigint extends core_1.Core {
    constructor() {
        super(enums_1.EDataType.bigint, "BIGINT");
    }
    generated(name) {
        this._override = {
            create: "BIGINT GENERATED ALWAYS AS IDENTITY",
            alias(service, test) {
                return `"${name}"${test["alias"] && test["alias"] === true === true ? ` AS ${(0, helpers_1.doubleQuotesString)(`@iot.${name}`)}` : ''}`;
            },
            dataType: enums_1.EDataType.bigint
        };
        return this;
    }
}
exports.Bigint = Bigint;
