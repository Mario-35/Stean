"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Text = void 0;
const enums_1 = require("../../enums");
const core_1 = require("./core");
class Text extends core_1.Core {
    constructor() {
        super(enums_1.EDataType.text, "TEXT");
    }
    verify(input) {
        this._verify.list = input;
        return this;
    }
}
exports.Text = Text;
