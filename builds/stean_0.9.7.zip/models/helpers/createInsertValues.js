"use strict";
/**
 * createInsertValues
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createInsertValues = createInsertValues;
const _1 = require(".");
const __1 = require("..");
const constants_1 = require("../../constants");
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const log_1 = require("../../log");
/**
 *
 * @param service Service
 * @param input JSON
 * @param entityName string
 * @returns string
*/
function createInsertValues(ctx, input, entityName) {
    console.log(log_1.log.whereIam());
    if (input) {
        const keys = [];
        const values = [];
        if (ctx && entityName) {
            const entity = __1.models.getEntity(ctx.service, entityName);
            if (!entity)
                return "";
            Object.keys(input).forEach((elem) => {
                if (input[elem] && entity.columns[elem]) {
                    const temp = (0, _1.formatColumnValue)(elem, input[elem], entity.columns[elem]);
                    if (temp) {
                        keys.push((0, helpers_1.doubleQuotesString)(elem));
                        values.push(temp);
                    }
                }
                else if (input[elem] && entity.relations[elem]) {
                    const relation = (0, _1.relationInfos)(ctx, entity.name, elem);
                    if (entity.columns[relation.column]) {
                        const temp = (0, _1.formatColumnValue)(relation.column, input[elem], entity.columns[relation.column]);
                        if (temp) {
                            keys.push((0, helpers_1.doubleQuotesString)(relation.column));
                            values.push(temp);
                        }
                    }
                }
            });
        }
        else {
            Object.keys(input).forEach((elem) => {
                if (input[elem]) {
                    if (input[elem].startsWith && input[elem].startsWith('"{') && input[elem].endsWith('}"')) {
                        input[elem] = (0, helpers_1.removeFirstEndDoubleQuotes)(input[elem].replace(/\\"+/g, ""));
                    }
                    else if (input[elem].startsWith && input[elem].startsWith('{"@iot.name"')) {
                        input[elem] = `(SELECT "id" FROM "${elem.split("_")[0]}" WHERE "name" = '${JSON.parse((0, helpers_1.removeFirstEndDoubleQuotes)(input[elem]))[enums_1.EConstant.name]}')`;
                    }
                    keys.push((0, helpers_1.doubleQuotesString)(elem));
                    values.push(typeof input[elem] === "string"
                        ? input[elem].startsWith("(SELECT")
                            ? input[elem]
                            : (0, helpers_1.simpleQuotesString)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(input[elem].trim()))
                        : elem === "result" ? `'{"value": ${input[elem]}}'::jsonb` : (0, constants_1.ESCAPE_SIMPLE_QUOTE)(input[elem].trim()));
                }
            });
        }
        return `(${keys.join()}) VALUES (${values.join()})`;
    }
    return "";
}
;
