"use strict";
/**
 * Index Entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LINE = exports.FILE = exports.USER = exports.THINGLOCATION = exports.THING = exports.SENSOR = exports.OBSERVEDPROPERTY = exports.OBSERVATION = exports.MULTIDATASTREAMOBSERVEDPROPERTY = exports.MULTIDATASTREAM = exports.LORA = exports.LOG = exports.LOCATIONHISTORICALLOCATION = exports.LOCATION = exports.HISTORICALLOCATION = exports.FEATUREOFINTEREST = exports.DECODER = exports.DATASTREAM = exports.CREATEFILE = exports.CREATEOBSERVATION = exports.SERVICE = void 0;
const helpers_1 = require("../helpers");
// Entities are in uppercase to have a difference with classes entities
exports.SERVICE = (0, helpers_1.createBlankEntity)("Services");
exports.CREATEOBSERVATION = (0, helpers_1.createBlankEntity)("CreateObservations");
exports.CREATEFILE = (0, helpers_1.createBlankEntity)("CreateFile");
var datastream_1 = require("./datastream");
Object.defineProperty(exports, "DATASTREAM", { enumerable: true, get: function () { return datastream_1.DATASTREAM; } });
var decoder_1 = require("./decoder");
Object.defineProperty(exports, "DECODER", { enumerable: true, get: function () { return decoder_1.DECODER; } });
var featureOfInterest_1 = require("./featureOfInterest");
Object.defineProperty(exports, "FEATUREOFINTEREST", { enumerable: true, get: function () { return featureOfInterest_1.FEATUREOFINTEREST; } });
var historicalLocation_1 = require("./historicalLocation");
Object.defineProperty(exports, "HISTORICALLOCATION", { enumerable: true, get: function () { return historicalLocation_1.HISTORICALLOCATION; } });
var location_1 = require("./location");
Object.defineProperty(exports, "LOCATION", { enumerable: true, get: function () { return location_1.LOCATION; } });
var locationHistoricalLocation_1 = require("./locationHistoricalLocation");
Object.defineProperty(exports, "LOCATIONHISTORICALLOCATION", { enumerable: true, get: function () { return locationHistoricalLocation_1.LOCATIONHISTORICALLOCATION; } });
var log_1 = require("./log");
Object.defineProperty(exports, "LOG", { enumerable: true, get: function () { return log_1.LOG; } });
var lora_1 = require("./lora");
Object.defineProperty(exports, "LORA", { enumerable: true, get: function () { return lora_1.LORA; } });
var multiDatastream_1 = require("./multiDatastream");
Object.defineProperty(exports, "MULTIDATASTREAM", { enumerable: true, get: function () { return multiDatastream_1.MULTIDATASTREAM; } });
var multiDatastreamObservedProperty_1 = require("./multiDatastreamObservedProperty");
Object.defineProperty(exports, "MULTIDATASTREAMOBSERVEDPROPERTY", { enumerable: true, get: function () { return multiDatastreamObservedProperty_1.MULTIDATASTREAMOBSERVEDPROPERTY; } });
var observation_1 = require("./observation");
Object.defineProperty(exports, "OBSERVATION", { enumerable: true, get: function () { return observation_1.OBSERVATION; } });
var observedProperty_1 = require("./observedProperty");
Object.defineProperty(exports, "OBSERVEDPROPERTY", { enumerable: true, get: function () { return observedProperty_1.OBSERVEDPROPERTY; } });
var sensor_1 = require("./sensor");
Object.defineProperty(exports, "SENSOR", { enumerable: true, get: function () { return sensor_1.SENSOR; } });
var thing_1 = require("./thing");
Object.defineProperty(exports, "THING", { enumerable: true, get: function () { return thing_1.THING; } });
var thingLocation_1 = require("./thingLocation");
Object.defineProperty(exports, "THINGLOCATION", { enumerable: true, get: function () { return thingLocation_1.THINGLOCATION; } });
var user_1 = require("./user");
Object.defineProperty(exports, "USER", { enumerable: true, get: function () { return user_1.USER; } });
var file_1 = require("./file");
Object.defineProperty(exports, "FILE", { enumerable: true, get: function () { return file_1.FILE; } });
var line_1 = require("./line");
Object.defineProperty(exports, "LINE", { enumerable: true, get: function () { return line_1.LINE; } });
