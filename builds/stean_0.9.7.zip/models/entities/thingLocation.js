"use strict";
/**
 * entity ThingLocation
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.THINGLOCATION = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.THINGLOCATION = new entity_1.Entity("ThingsLocations", {
    createOrder: 3,
    type: enums_1.ETable.link,
    order: -1,
    columns: {
        thing_id: new types_1.Bigint().notNull().unique().type(),
        location_id: new types_1.Bigint().notNull().type(),
    },
    relations: {},
    trigger: [
        `CREATE OR REPLACE FUNCTION thing_location_update_insert() RETURNS TRIGGER LANGUAGE PLPGSQL AS $$ DECLARE t_id integer; BEGIN INSERT INTO historicallocation(time, thing_id) VALUES(current_timestamp, new.thing_id) returning id into t_id; INSERT INTO locationhistoricallocation(historicallocation_id, location_id) VALUES(t_id, new.location_id); RETURN NEW; END; $$`,
        `do $$ begin CREATE TRIGGER thing_location_update_insert AFTER INSERT OR UPDATE on "thinglocation" for each row execute procedure thing_location_update_insert(); exception when others then null; end $$;`
    ]
});
