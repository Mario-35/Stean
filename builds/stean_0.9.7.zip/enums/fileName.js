"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EFileName = void 0;
/**
 * fileName Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var EFileName;
(function (EFileName) {
    EFileName["logs"] = "logs.html";
    EFileName["trace"] = "trace.md";
    EFileName["logsBak"] = "logs.bak";
    EFileName["config"] = "configuration.json";
    EFileName["key"] = ".key";
})(EFileName || (exports.EFileName = EFileName = {}));
