"use strict";
/**
 * User dataAccess
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.userAccess = void 0;
const helpers_1 = require("../../helpers");
const configuration_1 = require("../../configuration");
const models_1 = require("../../models");
const enums_1 = require("../../enums");
const entities_1 = require("../../models/entities");
// Get all the columns of user table
const userColumns = () => Object.keys(models_1.models.DBAdmin(configuration_1.config.getService(enums_1.EConstant.admin)).Users.columns);
exports.userAccess = {
    getAll: async (configName) => {
        const conn = configuration_1.config.connection(configName);
        const query = await conn `SELECT ${conn(userColumns())} FROM ${conn(models_1.models.DBAdmin(configuration_1.config.getService(configName)).Users.table)} ORDER BY id`;
        return query[0];
    },
    getSingle: async (configName, id) => {
        const conn = configuration_1.config.connection(configName);
        id = (typeof id === "number") ? String(id) : id;
        const query = await conn `SELECT ${conn(userColumns())} FROM ${conn(models_1.models.DBAdmin(configuration_1.config.getService(configName)).Users.table)} WHERE id = ${+id} LIMIT 1`;
        if (query.length === 1)
            return query[0];
    },
    post: async (configName, data) => {
        const conn = configuration_1.config.connection(configName);
        return await conn.unsafe(`INSERT INTO "user" ("username", "email", "password", "database", "canPost", "canDelete", "canCreateUser", "canCreateDb", "superAdmin", "admin") 
       VALUES ('${data.username}', '${data.email}', '${(0, helpers_1.encrypt)(data.password)}', '${data.database || "all"}', ${data.canPost || false}, ${data.canDelete || false}, ${data.canCreateUser || false}, ${data.canCreateDb || false}, ${data.superAdmin || false}, ${data.admin || false}) 
      RETURNING *`).catch(async (err) => {
            if (err.code === "23505") {
                const id = await conn.unsafe(`SELECT id FROM "${entities_1.USER.table}" WHERE "username" = '${data.username}'`);
                if (id[0]) {
                    data.id = id[0].id;
                    return await conn.unsafe(`UPDATE "user" SET "username" = '${data.username}', "email" = '${data.email}', "database" = '${data.database}', "canPost" = ${data.canPost || false}, "canDelete" = ${data.canDelete || false}, "canCreateUser" = ${data.canCreateUser || false}, "canCreateDb" = ${data.canCreateDb || false}, "superAdmin" = ${data.superAdmin || false}, "admin" = ${data.admin || false} WHERE "id" = ${data.id} RETURNING *`);
                }
            }
        });
    },
    update: async (configName, data) => {
        const conn = configuration_1.config.connection(configName);
        return await conn.unsafe(`UPDATE "user" SET "username" = '${data.username}', "email" = '${data.email}', "database" = '${data.database}', "canPost" = ${data.canPost || false}, "canDelete" = ${data.canDelete || false}, "canCreateUser" = ${data.canCreateUser || false}, "canCreateDb" = ${data.canCreateDb || false}, "superAdmin" = ${data.superAdmin || false}, "admin" = ${data.admin || false} WHERE "id" = ${data.id} RETURNING *`);
    }
};
