Object.defineProperty(exports,"__esModule",{value:!0}),exports.testId=void 0;let testId=(e,E)=>`SELECT 
CASE WHEN EXISTS(
  SELECT 
    1 
  FROM 
    "${e}" 
  WHERE 
    "id" = ${E}
) THEN (
  SELECT 
    "id" 
  FROM 
    "${e}" 
  WHERE 
    "id" = ${E}
) END AS "id"`;exports.testId=testId;