Object.defineProperty(exports,"__esModule",{value:!0}),exports.multiDatastreamUoM=void 0;let multiDatastreamUoM=t=>`SELECT 
jsonb_agg(tmp.units -> 'name') AS keys 
FROM 
(
  SELECT 
    jsonb_array_elements("unitOfMeasurements") AS units 
  FROM 
    "multidatastream" 
  WHERE 
    id = ${t.parentId}
) AS tmp
`;exports.multiDatastreamUoM=multiDatastreamUoM;