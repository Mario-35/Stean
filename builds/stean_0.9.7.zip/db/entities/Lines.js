"use strict";
/**
 * Lines entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Lines = void 0;
const common_1 = require("./common");
const log_1 = require("../../log");
class Lines extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
}
exports.Lines = Lines;
