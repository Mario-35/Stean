"use strict";
/**
 * Users entity.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Users = void 0;
const common_1 = require("./common");
const configuration_1 = require("../../configuration");
const helpers_1 = require("../../helpers");
const messages_1 = require("../../messages/");
const enums_1 = require("../../enums");
const models_1 = require("../../models");
const log_1 = require("../../log");
const entities_1 = require("../../models/entities");
class Users extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    // Override get all to return all users only if rights are good
    async getAll() {
        console.log(log_1.log.whereIam());
        if (this.ctx.user?.PDCUAS[enums_1.EUserRights.SuperAdmin] === true || this.ctx.user?.PDCUAS[enums_1.EUserRights.Admin] === true) {
            const temp = await configuration_1.config.executeSqlValues(configuration_1.config.getService(enums_1.EConstant.admin), `SELECT ${models_1.models.getSelectColumnList(this.ctx.service, models_1.models.DBAdmin(configuration_1.config.getService(enums_1.EConstant.admin)).Users, true)} FROM "${entities_1.USER.table}" ORDER BY "id"`);
            return this.formatReturnResult({
                body: (0, helpers_1.hidePassword)(temp),
            });
        }
        else
            this.ctx.throw(401 /* EHttpCode.Unauthorized */, { code: 401 /* EHttpCode.Unauthorized */, detail: messages_1.errors[401 /* EHttpCode.Unauthorized */] });
    }
    // Override to creste a new config and load it 
    async post(dataInput) {
        console.log(log_1.log.whereIam());
        if (dataInput)
            return this.formatReturnResult({
                body: await configuration_1.config.addConfig(dataInput),
            });
    }
}
exports.Users = Users;
