"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUser = void 0;
const dataAccess_1 = require("../dataAccess");
/**
 *
 * @param service service
 * @returns return user string
 */
const createUser = async (service) => {
    return new Promise(async function (resolve, reject) {
        await dataAccess_1.userAccess.post(service.name, {
            username: service.pg.user,
            email: "TWOdefault@email.com",
            password: service.pg.password,
            database: service.pg.database,
            canPost: true,
            canDelete: true,
            canCreateUser: true,
            canCreateDb: true,
            superAdmin: false,
            admin: false
        })
            .then(() => { resolve(`${service.pg.user} ${"\u2714\uFE0F\uFE0F" /* EChar.ok */}`); })
            .catch((err) => {
            console.log(err);
            reject(err);
        });
    });
};
exports.createUser = createUser;
