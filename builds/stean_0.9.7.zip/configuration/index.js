"use strict";
/**
 * Configuration class
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
*
*/
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
const constants_1 = require("../constants");
const helpers_1 = require("../helpers");
const messages_1 = require("../messages");
const __1 = require("..");
const enums_1 = require("../enums");
const fs_1 = __importDefault(require("fs"));
const update_json_1 = __importDefault(require("./update.json"));
const postgres_1 = __importDefault(require("postgres"));
const log_1 = require("../log");
const createDb_1 = require("../db/createDb");
const dataAccess_1 = require("../db/dataAccess");
const path_1 = __importDefault(require("path"));
const helpers_2 = require("./helpers");
const mqtt_1 = require("../mqtt");
const helpers_3 = require("../db/helpers");
// class to lcreate configs environements
class Configuration {
    // store all services
    static services = {};
    static adminConnection;
    // configuration complete file path
    static filePath;
    static MqttServer;
    static queries = {};
    logFile = fs_1.default.createWriteStream(path_1.default.resolve(__dirname, "../", enums_1.EFileName.logs), { flags: 'w' });
    static listenPorts = [];
    constructor() {
        const file = __dirname + `/${enums_1.EFileName.config}`;
        // Set path of the configuration file
        Configuration.filePath = file.toString();
        // override console log for TDD important in production build will remove all console.log
        if ((0, helpers_1.isTest)()) {
            console.log = (data) => { };
            this.readConfigFile();
        }
        else
            console.log = (data) => {
                if (data)
                    this.writeLog(data);
            };
    }
    /**
     * log message of listening
     *
     * @param what messace log
     * @param port port number
     * @param db show db infos
    */
    messageListen(what, port, db) {
        if (db)
            this.writeLog(log_1.log.booting(`${(0, enums_1.color)(35 /* EColor.Magenta */)}${messages_1.info.db} => ${(0, enums_1.color)(33 /* EColor.Yellow */)}${what}${(0, enums_1.color)(39 /* EColor.Default */)} ${messages_1.info.onLine}`, port));
        else
            this.writeLog(log_1.log.booting(`${(0, enums_1.color)(33 /* EColor.Yellow */)}${what}${(0, enums_1.color)(33 /* EColor.Yellow */)} ${(0, enums_1.color)(32 /* EColor.Green */)}${messages_1.info.listenPort}`, port));
    }
    /**
     * Override console log
     *
     * @param input
    */
    writeLog(input) {
        if (input) {
            process.stdout.write(input + "\n");
            if (exports.config && exports.config.logFile)
                exports.config.logFile.write((0, helpers_1.logToHtml)(input));
        }
    }
    async writeTrace(ctx) {
        const datas = `INSERT INTO trace ("method", url, datas) VALUES('${ctx.method}', '${ctx.request.url}', ('${ctx.body ? (0, constants_1.ESCAPE_SIMPLE_QUOTE)(JSON.stringify(ctx.body)) : '{}'}')::text::jsonb) RETURNING id;`;
        await Configuration.adminConnection.unsafe(datas)
            .then(res => ctx.traceId = res[0].id)
            .catch(async (error) => {
            if (error.code === "42P01") {
                await Configuration.adminConnection.unsafe(`CREATE TABLE public.trace ( id int8 GENERATED ALWAYS AS IDENTITY( INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1 NO CYCLE) NOT NULL, "date" timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL, "method" text NULL, url text NULL, datas jsonb NULL, CONSTRAINT log_pkey PRIMARY KEY (id) ); CREATE INDEX trace_id ON public.trace USING btree (id);`)
                    .catch(err => process.stdout.write(err + "\n"));
                Configuration.adminConnection.unsafe(datas);
            }
            else
                process.stdout.write(error + "\n");
        });
    }
    /**
     * Read string (or default configuration file) as configuration file
     *
     * @param input
     * @returns true if it's done
    */
    readConfigFile(input) {
        this.writeLog(`${(0, enums_1.color)(31 /* EColor.Red */)}${"▬".repeat(24)} ${(0, enums_1.color)(36 /* EColor.Cyan */)} ${`START ${enums_1.EConstant.appName} ${messages_1.info.ver} : ${enums_1.EConstant.appVersion} [${enums_1.EConstant.nodeEnv}]`} ${(0, enums_1.color)(37 /* EColor.White */)} ${new Date().toLocaleDateString()} : ${new Date().toLocaleTimeString()} ${(0, enums_1.color)(31 /* EColor.Red */)} ${"▬".repeat(24)}${(0, enums_1.color)(0 /* EColor.Reset */)}`);
        this.writeLog(log_1.log.message((0, messages_1.infos)(["read", "config"]), input ? "content" : Configuration.filePath));
        try {
            // load File
            const fileContent = input || fs_1.default.readFileSync(Configuration.filePath, "utf8");
            if (fileContent.trim() === "") {
                this.writeLog(log_1.log.error((0, messages_1.msg)(messages_1.errors.fileEmpty, Configuration.filePath), Configuration.filePath));
                process.exit(111);
            }
            // decrypt file
            Configuration.services = JSON.parse((0, helpers_1.decrypt)(fileContent));
            if ((0, helpers_2.validJSONService)(Configuration.services)) {
                if ((0, helpers_1.isTest)()) {
                    Configuration.services[enums_1.EConstant.admin] = this.formatConfig(enums_1.EConstant.admin);
                    Configuration.services[enums_1.EConstant.test] = this.formatConfig(createDb_1.testDatas["create"]);
                }
                else {
                    Object.keys(Configuration.services).forEach((element) => {
                        Configuration.services[element] = this.formatConfig(element);
                    });
                }
            }
            else {
                this.writeLog(log_1.log.error(messages_1.errors.configFileError));
                process.exit(112);
            }
            // rewrite file (to update config modification except in test mode)
            if (!(0, helpers_1.isTest)())
                this.writeConfig();
        }
        catch (error) {
            this.writeLog(log_1.log.error(messages_1.errors.configFileError, error["message"]));
            process.exit(111);
        }
        const infosAdmin = Configuration.services[enums_1.EConstant.admin].pg;
        Configuration.adminConnection = (0, postgres_1.default)(`postgres://${infosAdmin.user}:${infosAdmin.password}@${infosAdmin.host}:${infosAdmin.port || 5432}/${enums_1.EConstant.defaultDb}`, {
            debug: constants_1._DEBUG,
            connection: {
                application_name: `${enums_1.EConstant.appName} ${enums_1.EConstant.appVersion}`
            }
        });
        return true;
    }
    /**
     *
     * @returns http port number
    */
    defaultHttp() {
        return Configuration.services[enums_1.EConstant.admin] && Configuration.services[enums_1.EConstant.admin].ports ? Configuration.services[enums_1.EConstant.admin].ports?.http || 8029 : 8029;
    }
    /** Initialivze mqtt */
    initMqtt() {
        Configuration.MqttServer = new mqtt_1.MqttServer({ wsPort: Configuration.services[enums_1.EConstant.admin].ports?.ws || 1883, tcpPort: Configuration.services[enums_1.EConstant.admin].ports?.tcp || 9000 });
    }
    /**
     *
     * @returns broker id
     */
    getBrokerId() {
        return Configuration.MqttServer.broker.id;
    }
    /**
     *
     * @returns configuration file present
    */
    configFileExist() {
        return fs_1.default.existsSync(Configuration.filePath);
    }
    /**
     * Return infos of a service
     *
     * @param ctx koa context
     * @param name service name
     * @returns infos as IserviceInfos
    */
    getInfos = (ctx, name) => {
        const protocol = ctx.request.headers["x-forwarded-proto"]
            ? ctx.request.headers["x-forwarded-proto"].toString()
            : Configuration.services[name].options.includes(enums_1.EOptions.forceHttps)
                ? "https"
                : ctx.protocol;
        // make linkbase
        let linkBase = ctx.request.headers["x-forwarded-host"]
            ? `${protocol}://${ctx.request.headers["x-forwarded-host"].toString()}`
            : ctx.request.header.host
                ? `${protocol}://${ctx.request.header.host}`
                : "";
        // make rootName
        if (!linkBase.includes(name))
            linkBase += "/" + name;
        const version = Configuration.services[name].apiVersion;
        return {
            protocol: protocol,
            linkBase: linkBase,
            version: version,
            root: process.env.NODE_ENV?.trim() === enums_1.EConstant.test ? `proxy/${version}` : `${linkBase}/${version}`,
            model: `https://app.diagrams.net/?lightbox=1&edit=_blank#U${linkBase}/${version}/draw`
        };
    };
    /**
     * Return infos for all services
     *
     * @param ctx koa context
     * @param name service name
     * @returns infos as IserviceInfos
    */
    getInfosForAll(ctx) {
        const result = {};
        this.getServicesNames().forEach((conf) => {
            result[conf] = this.getInfos(ctx, conf);
        });
        return result;
    }
    /**
     *
     * @param name service name
     * @returns service.
    */
    getService(name) {
        return Configuration.services[name];
    }
    /**
     *
     * @returns service names
    */
    getServicesNames() {
        return Object.keys(Configuration.services).filter(e => e !== enums_1.EConstant.admin);
    }
    /**
     * Write an encrypt config file in json file
     *
     * @returns true if it's done
    */
    writeConfig() {
        this.writeLog(log_1.log.message((0, messages_1.infos)(["write", "config"]), Configuration.filePath));
        const result = {};
        Object.entries(Configuration.services).forEach(([k, v]) => {
            if (k !== enums_1.EConstant.test)
                result[k] = Object.keys(v).filter(e => !e.startsWith("_")).reduce((obj, key) => { obj[key] = v[key]; return obj; }, {});
        });
        // in some case of crash config is blank so prevent to overrite it
        if (Object.keys(result).length > 0)
            fs_1.default.writeFile(
            // encrypt only in production mode
            Configuration.filePath, (0, helpers_1.isProduction)() === true
                ? (0, helpers_1.encrypt)(JSON.stringify(result, null, 4))
                : JSON.stringify(result, null, 4), (error) => {
                if (error) {
                    console.log(error);
                    return false;
                }
            });
        return true;
    }
    /**
     * Execute one query
     *
     * @param service service
     * @param query query
     * @returns result postgres.js object
     */
    async executeOneSql(service, query) {
        this.writeLog(log_1.log.query(query));
        return new Promise(async function (resolve, reject) {
            await exports.config.connection(service.name).unsafe(query).then((res) => {
                resolve(res);
            }).catch((err) => {
                if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                    exports.config.writeLog(log_1.log.queryError(query, err));
                reject(err);
            });
        });
    }
    ;
    /**
     * Execute multiple queries
     *
     * @param service service
     * @param query query
     * @returns result postgres.js object
     */
    async executeMultiSql(service, query) {
        this.writeLog(log_1.log.query(query));
        return new Promise(async function (resolve, reject) {
            await exports.config.connection(service.name).begin(sql => query.map((e) => sql.unsafe(e)))
                .then((res) => {
                resolve(res);
            }).catch((err) => {
                if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                    exports.config.writeLog(log_1.log.queryError(query, err));
                reject(err);
            });
        });
    }
    ;
    /**
     *
     * @param service service or service name
     * @param query one or multiple queries
     * @returns result postgres.js object
    */
    async executeSql(service, query) {
        service = typeof service === "string" ? Configuration.services[service] : service;
        return typeof query === "string"
            ? this.executeOneSql(service, query)
            : this.executeMultiSql(service, query);
    }
    /**
     *
     * @param query query
     * @returns result postgres.js object
     */
    async executeAdmin(query) {
        this.writeLog(log_1.log.query(query));
        return new Promise(async function (resolve, reject) {
            await exports.config.connection(enums_1.EConstant.admin).unsafe(query).then((res) => {
                resolve(res);
            }).catch((err) => {
                reject(err);
            });
        });
    }
    ;
    /**
     *
     * @param service service or service name
     * @param query one or multiple queries
     * @returns result postgres.js object values
    */
    async executeSqlValues(service, query) {
        this.writeLog(log_1.log.query(query));
        if (typeof query === "string") {
            return new Promise(async function (resolve, reject) {
                await exports.config.connection(typeof service === "string" ? service : service.name).unsafe(query).values().then((res) => {
                    resolve(res[0]);
                }).catch((err) => {
                    if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                        exports.config.writeLog(log_1.log.queryError(query, err));
                    reject(err);
                });
            });
        }
        else {
            return new Promise(async function (resolve, reject) {
                let result = {};
                await (0, helpers_1.asyncForEach)(query, async (sql) => {
                    await exports.config.connection(typeof service === "string" ? service : service.name).unsafe(sql).values().then((res) => {
                        result = { ...result, ...res[0] };
                    }).catch((err) => {
                        if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                            exports.config.writeLog(log_1.log.queryError(query, err));
                        reject(err);
                    });
                });
                resolve(result);
            });
        }
    }
    ;
    /**
     *
     * @param title of the operation
     * @returns true if it's done
      */
    async executeQueriesForAllServices(title) {
        try {
            await (0, helpers_1.asyncForEach)(Object.keys(Configuration.queries), async (connectName) => {
                await this.executeSql(connectName, Configuration.queries[connectName]);
                log_1.log.create(`${title} : [${connectName}]`, "\u2714\uFE0F\uFE0F" /* EChar.ok */);
            });
        }
        catch (error) {
            console.log(error);
        }
        return true;
    }
    /**
     *
     * @param string
     * @returns Hash code number
    */
    hashCode(s) {
        return s.split("").reduce((a, b) => {
            a = (a << 5) - a + b.charCodeAt(0);
            return a & a;
        }, 0);
    }
    /**
     *
     * @param name connection name
     * @returns postgres postgres.js
    */
    connection(name) {
        if (!Configuration.services[name]._connection)
            this.createDbConnectionFromConfigName(name);
        return Configuration.services[name]._connection || this.createDbConnection(Configuration.services[name].pg);
    }
    /**
     *
     * @returns return postgres.js connection with EConstant.admin rights
    */
    adminConnection() {
        return Configuration.adminConnection;
    }
    /**
     *
     * @param input IdbConnection
     * @returns return postgres.js connection (psql connect string)
    */
    createDbConnection(input) {
        return (0, postgres_1.default)(`postgres://${input.user}:${input.password}@${input.host}:${input.port || 5432}/${input.database}`, {
            debug: true,
            max: 2000,
            connection: {
                application_name: `${enums_1.EConstant.appName} ${enums_1.EConstant.appVersion}`
            },
        });
    }
    /**
     *
     * @param input connection string name
     * @returns return postgres.js connection (psql connect string)
    */
    createDbConnectionFromConfigName(input) {
        const temp = this.createDbConnection(Configuration.services[input].pg);
        Configuration.services[input]._connection = temp;
        return temp;
    }
    /**
     *
     * @param connectName name
     * @param query sql query
    */
    addToQueries(connectName, query) {
        if (Configuration.queries[connectName])
            Configuration.queries[connectName].push(query);
        else
            Configuration.queries[connectName] = [query];
    }
    /**
     *
     * @param connection name
     * @returns true if it's done
    */
    async reCreatePgFunctions(connection) {
        await (0, helpers_1.asyncForEach)((0, createDb_1.pgFunctions)(), async (query) => {
            const name = query.split(" */")[0].split("/*")[1].trim();
            await exports.config.connection(connection).unsafe(query).then(() => {
                log_1.log.create(`[${connection}] ${name}`, "\u2714\uFE0F\uFE0F" /* EChar.ok */);
            }).catch((error) => {
                console.log(error);
                return false;
            });
        });
        this.writeLog(log_1.log.message(messages_1.info.createFunc, connection));
        return true;
    }
    /**
     * Executes queries present in updates afterAll json file
     *
     * @returns true if it's done
     */
    async afterAll() {
        // Updates database after init
        if (update_json_1.default && update_json_1.default[enums_1.EUpdate.afterAll] && Object.entries(update_json_1.default[enums_1.EUpdate.afterAll]).length > 0) {
            Configuration.queries = {};
            Object.keys(Configuration.services)
                .filter((e) => e != enums_1.EConstant.admin)
                .forEach(async (connectName) => {
                update_json_1.default[enums_1.EUpdate.afterAll].forEach((operation) => { this.addToQueries(connectName, operation); });
            });
            await this.executeQueriesForAllServices(enums_1.EUpdate.afterAll);
        }
        // epdate decoders
        if (update_json_1.default && update_json_1.default[enums_1.EUpdate.decoders] && Object.entries(update_json_1.default[enums_1.EUpdate.decoders]).length > 0) {
            Configuration.queries = {};
            Object.keys(Configuration.services)
                .filter((e) => e != enums_1.EConstant.admin && Configuration.services[e].extensions.includes(enums_1.EExtensions.lora))
                .forEach((connectName) => {
                if (Configuration.services[connectName].extensions.includes(enums_1.EExtensions.lora)) {
                    const decs = [];
                    Object.keys(update_json_1.default[enums_1.EUpdate.decoders]).forEach(async (name) => {
                        const hash = this.hashCode(update_json_1.default[enums_1.EUpdate.decoders][name]);
                        decs.push(name);
                        const sql = `UPDATE decoder SET code='${update_json_1.default[enums_1.EUpdate.decoders][name]}', hash = '${hash}' WHERE name = '${name}' AND hash <> '${hash}' `;
                        await exports.config
                            .connection(connectName)
                            .unsafe(sql)
                            .catch((error) => {
                            console.log(error);
                            return false;
                        });
                    });
                    this.writeLog(log_1.log.booting(`UPDATE decoder ${(0, enums_1.color)(33 /* EColor.Yellow */)} [${connectName}]`, decs));
                }
            });
        }
        return true;
    }
    /**
     *
     * @param port listening port
     * @param message messagu info
     */
    addListening(port, message) {
        if (Configuration.listenPorts.includes(port))
            this.messageListen(`ADD ${message}`, String(port));
        else
            __1.app.listen(port, () => {
                Configuration.listenPorts.push(port);
                this.messageListen(message, String(port));
            });
    }
    /**
     *
     * @param input specific config file
     * @returns true if it's done
     */
    async init(input) {
        if (this.configFileExist() === true || input) {
            this.readConfigFile(input);
            console.log(log_1.log.message(messages_1.info.config, messages_1.info.loaded + " " + "\u2714\uFE0F\uFE0F" /* EChar.ok */));
            let status = true;
            await (0, helpers_1.asyncForEach)(
            // Start connection ALL entries in config file
            Object.keys(Configuration.services).filter(e => e.toUpperCase() !== enums_1.EConstant.test.toUpperCase()), async (key) => {
                try {
                    await this.addToServer(key);
                }
                catch (error) {
                    console.log(error);
                    status = false;
                }
            });
            this.writeLog(log_1.log._head("mqtt"));
            this.initMqtt();
            (0, constants_1.setReady)(status);
            // note that is executed without async to not block start processus
            if (status === true)
                this.afterAll();
            if (!(0, helpers_1.isTest)()) {
                if (await (0, helpers_2.testDbExists)(Configuration.services[enums_1.EConstant.admin].pg, enums_1.EConstant.test)) {
                    Configuration.services[enums_1.EConstant.test] = this.formatConfig(createDb_1.testDatas["create"]);
                }
                // else await createService(testDatas);
                this.messageListen(enums_1.EConstant.test, String(this.defaultHttp()), true);
            }
            this.writeLog(log_1.log._head("Ready", "\u2714\uFE0F\uFE0F" /* EChar.ok */));
            this.writeLog(log_1.log.logo(enums_1.EConstant.appVersion));
            return status;
            // no configuration file so First install    
        }
        else {
            console.log(log_1.log.message("file", Configuration.filePath + " " + "\u274C" /* EChar.notOk */));
            this.addListening(this.defaultHttp(), "First launch");
            return true;
        }
    }
    /**
     * return config name from databse name
     *
     * @param input config to search
     * @returns config name or undefined
     */
    getConfigNameFromDatabase(input) {
        if (input !== "all") {
            const aliasName = Object.keys(Configuration.services).filter((configName) => Configuration.services[configName].pg.database === input)[0];
            if (aliasName)
                return aliasName;
            throw new Error(`No configuration found for ${input} name`);
        }
    }
    /**
     * return config name from config name
     *
     * @param input config to search
     * @returns config name or undefined
     */
    getConfigNameFromName = (name) => {
        if (name) {
            if (Object.keys(Configuration.services).includes(name))
                return name;
            Object.keys(Configuration.services).forEach((configName) => {
                if (Configuration.services[configName].alias.includes(name))
                    return configName;
            });
        }
    };
    /**
     * Return Iservice Formated for Iservice object or name found in json file
     *
     * @param input config nome to search
     * @param name name of the config (if format)
     * @returns
     */
    formatConfig(input, name) {
        if (typeof input === "string") {
            name = input;
            input = Configuration.services[input];
        }
        const goodDbName = name
            ? name
            : input["pg"] && input["pg"]["database"] ? input["pg"]["database"] : `ERROR` || "ERROR";
        return (0, helpers_2.formatServiceFile)(goodDbName, input);
    }
    // Add config to configuration file
    /**
     *
     * @param addJson service JSON
     * @returns formated service
     */
    async addConfig(addJson) {
        try {
            const addedConfig = this.formatConfig(addJson);
            Configuration.services[addedConfig.name] = addedConfig;
            if (!(0, helpers_1.isTest)()) { // For TDD not create service
                await this.addToServer(addedConfig.name);
                this.writeConfig();
            }
            return addedConfig;
        }
        catch (error) {
            return undefined;
        }
    }
    // process to add an entry in server
    /**
     *
     * @param key name
     * @returns true if it's ok
     */
    async addToServer(key) {
        this.writeLog(log_1.log._head(key));
        return await this.isServiceExist(key, true)
            .then(async (res) => {
            if (res === true) {
                await dataAccess_1.userAccess.post(key, {
                    username: Configuration.services[key].pg.user,
                    email: "steandefault@email.com",
                    password: Configuration.services[key].pg.password,
                    database: Configuration.services[key].pg.database,
                    canPost: true,
                    canDelete: true,
                    canCreateUser: true,
                    canCreateDb: true,
                    superAdmin: false,
                    admin: false
                });
                if (![enums_1.EConstant.admin, enums_1.EConstant.test].includes(key))
                    (0, helpers_3.updateIndexes)(key);
                if (!Configuration.services[key].extensions.includes(enums_1.EExtensions.file) && ![enums_1.EConstant.admin, enums_1.EConstant.test].includes(key))
                    (0, helpers_3.updateIndexes)(key);
                this.messageListen(key, res ? "\uD83C\uDF0D" /* EChar.web */ : "\u274C" /* EChar.notOk */, true);
                this.addListening(this.defaultHttp(), key);
            }
            return res;
        })
            .catch((error) => {
            this.writeLog(log_1.log.error(messages_1.errors.unableFindCreate, Configuration.services[key].pg.database));
            console.log(error);
            process.exit(111);
        });
    }
    /**
   * Create dataBase
   *
   * @param serviceName service name
   * @returns true if it's done
   */
    async createDB(connectName) {
        this.writeLog(log_1.log.booting(messages_1.info.try, Configuration.services[connectName].pg.database));
        return await (0, createDb_1.createDatabase)(connectName)
            .then(async () => {
            this.writeLog(log_1.log.booting(`${messages_1.info.db} ${messages_1.info.create} [${Configuration.services[connectName].pg.database}]`, "\u2714\uFE0F\uFE0F" /* EChar.ok */));
            this.createDbConnectionFromConfigName(connectName);
            return true;
        })
            .catch((err) => {
            this.writeLog(log_1.log.error((0, messages_1.msg)(messages_1.info.create, messages_1.info.db), err.message));
            return false;
        });
    }
    /**
     *
     * @param serviceName service name
     * @param create create if not exist
     * @returns true if it's done
     */
    async isServiceExist(serviceName, create) {
        this.writeLog(log_1.log.booting(messages_1.info.dbExist, Configuration.services[serviceName].pg.database));
        return await this.connection(serviceName) `select 1+1 AS result`.then(async () => {
            const listTempTables = await this.connection(serviceName) `SELECT array_agg(table_name) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE 'temp%';`;
            const tables = listTempTables[0]["array_agg"];
            if (tables != null)
                this.writeLog(log_1.log.booting(`DELETE temp table(s) ==> \x1b[33m${serviceName}\x1b[32m`, await this.connection(serviceName).begin(sql => {
                    tables.forEach(async (table) => {
                        await sql.unsafe(`DROP TABLE ${table}`);
                    });
                }).then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
                    .catch((err) => err.message)));
            await this.reCreatePgFunctions(serviceName);
            if (update_json_1.default[enums_1.EUpdate.beforeAll] && Object.entries(update_json_1.default[enums_1.EUpdate.beforeAll]).length > 0) {
                if (update_json_1.default[enums_1.EUpdate.beforeAll] && Object.entries(update_json_1.default[enums_1.EUpdate.beforeAll]).length > 0) {
                    console.log(log_1.log._head(enums_1.EUpdate.beforeAll));
                    try {
                        Object.keys(Configuration.services)
                            .filter((e) => ![enums_1.EConstant.admin, enums_1.EConstant.test].includes(e))
                            .forEach((connectName) => {
                            update_json_1.default[enums_1.EUpdate.beforeAll].forEach((operation) => {
                                this.addToQueries(connectName, operation);
                            });
                        });
                        await this.executeQueriesForAllServices(enums_1.EUpdate.beforeAll);
                        // RelogCreate triggers for this service
                    }
                    catch (error) {
                        console.log(error);
                    }
                }
            }
            return true;
        })
            .catch(async (error) => {
            // Password authentication failed 
            if (error["code"] === "ECONNREFUSED") {
                console.log(log_1.log.error(error));
            }
            else if (error["code"] === "28P01") {
                if (!(0, helpers_1.isTest)())
                    return await this.createDB(serviceName);
                // Database does not exist
            }
            else if (error["code"] === "3D000" && create == true) {
                console.log(log_1.log._infos((0, messages_1.msg)(messages_1.info.tryCreate, messages_1.info.db), Configuration.services[serviceName].pg.database));
                if (serviceName !== enums_1.EConstant.test)
                    return await this.createDB(serviceName);
            }
            else
                console.log(error);
            return false;
        });
    }
}
exports.config = new Configuration();
