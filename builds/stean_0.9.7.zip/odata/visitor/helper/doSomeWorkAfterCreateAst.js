"use strict";
/**
 * doSomeWorkAfterCreateAst
 *
 * @copyright 2022-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.doSomeWorkAfterCreateAst = void 0;
const configuration_1 = require("../../../configuration");
const queries_1 = require("../../../db/queries");
const helpers_1 = require("../../../helpers");
const tests_1 = require("../../../helpers/tests");
const log_1 = require("../../../log");
const doSomeWorkAfterCreateAst = async (input, ctx) => {
    console.log(log_1.log.whereIam());
    if ((0, helpers_1.isObservation)(input)) {
    }
    if (input.entity && input.splitResult && input.splitResult[0].toUpperCase() == "ALL" && input.parentId && input.parentId > 0) {
        const temp = await configuration_1.config.connection(ctx.service.name).unsafe(`${(0, queries_1.multiDatastreamKeys)(input.parentId)}`);
        input.splitResult = temp[0]["keys"];
        const col = input.valueskeys === true ? "result->'valueskeys'" : "result->'value'";
        await configuration_1.config.connection(ctx.service.name).unsafe((0, queries_1.resultKeys)(col, input)).then((res) => {
            if (res.length > 0)
                input.columnSpecials["result"] = res.map(e => `${col}->'${e.k}' AS "${e.k}"`);
        });
    }
    else if (input.returnFormat === helpers_1.returnFormats.csv
        && input.entity
        && (0, helpers_1.isObservation)(input)
        && input.parentEntity?.name?.endsWith('atastreams')
        && input.parentId
        && input.parentId > 0) {
        if (input.parentEntity.name === "Datastreams")
            input.columnSpecials["result"] = [`"result"->'value' AS result`];
        if (input.parentEntity.name === "MultiDatastreams") {
            await configuration_1.config.connection(ctx.service.name).unsafe((0, queries_1.multiDatastreamUoM)(input)).then((res) => {
                if (res[0] && res[0].keys && res[0].keys.map)
                    input.columnSpecials["result"] = res[0].keys.map((e) => `("result"->>'valueskeys')::json->'${e}' AS "${e}"`);
            });
        }
    }
    else if ((0, tests_1.isFile)(input.ctx)) {
        await configuration_1.config.connection(ctx.service.name).unsafe(`SELECT jsonb_object_keys(("result"->>'valueskeys')::jsonb) As k FROM "line"  WHERE "line"."id" = (SELECT "line"."id" FROM "line" WHERE "line"."file_id" =${input.parentId} limit 1)`).then((res) => {
            if (res.length > 0)
                input.columnSpecials["result"] = res.map(e => `(result->'valueskeys')->>'${e.k}' AS "${e.k}"`);
        });
    }
};
exports.doSomeWorkAfterCreateAst = doSomeWorkAfterCreateAst;
