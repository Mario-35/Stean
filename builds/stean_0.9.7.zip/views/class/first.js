Object.defineProperty(exports,"__esModule",{value:!0}),exports.First=void 0;let log_1=require("../../log"),messages_1=require("../../messages"),core_1=require("./core");class First extends core_1.CoreHtmlView{constructor(e,s){super(e),this.first(s)}first(s){var e=e=>s.why&&s.why[e]?`<div class="alert">${s.why[e]}</div>`:"";this._HTMLResult=[`
            <!DOCTYPE html>
            <html>
              ${this.head("Login")}    
              <body>
                <div class="login-wrap">
                  <div class="login-html" color="#FF0000">
                    ${this.title("First Start")}
                    <input id="tab-1" type="radio" name="tab" class="sign-in" checked>
                    <label for="tab-1" class="tab">${messages_1.info.pg} Admin</label>
                    <input id="tab-2" type="radio" name="tab" class="sign-up">
                    <label for="tab-2" class="tab">Help</label>
                    <div class="login-form">
                      <form action="/service" method="post">
                        <div class="sign-in-htm">
                          ${this.addHidden("_src","_first")}
                          ${this.addTextInput({name:"host",label:messages_1.info.host,value:s.body&&s.body.host||"localhost",alert:e("host"),toolType:messages_1.info.least5Tool})}
                          ${this.addTextInput({name:"port",label:messages_1.info.pg+" port",value:s.body&&s.body.port||"5432",toolType:messages_1.info.portTool,alert:e("port")})}
                          ${this.addTextInput({name:"adminname",label:messages_1.info.user,value:s.body&&s.body.adminname||"postgres",alert:e("username"),toolType:messages_1.info.least5Tool})}
                          ${this.addTextInput({name:"adminpassword",label:messages_1.info.pass,password:!0,value:"",alert:e("password"),toolType:messages_1.info.passTool})}
                          ${this.addTextInput({name:"repeat",label:messages_1.info.rep,password:!0,value:"",alert:e("repeat"),toolType:messages_1.info.repTool})}
                          ${this.addSubmitButton(messages_1.info.dbPgConn)}
                          ${s.why&&s.why._error?this.AddErrorMessage(s.why._error):""}
                        </div> 
                        <div class="sign-up-htm">
                          <span>
                            You have to create configuration to start the API<br>
                            <br>
                            You have to put user admin postgresSql connection in PostgresSql Admin in tab above (This user must have right to create databases).<br>
                            <br>
                            When the connection test succed you can create your first service.
                          </span>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </body>                  
            </html>`]}}exports.First=First;