"use strict";
/**
 * HTML ViewsNew Service for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Service = void 0;
const enums_1 = require("../../enums");
const log_1 = require("../../log");
const messages_1 = require("../../messages");
const models_1 = require("../../models");
const core_1 = require("./core");
class Service extends core_1.CoreHtmlView {
    constructor(ctx, datas) {
        console.log(log_1.log.whereIam("View"));
        super(ctx);
        this.service(datas);
    }
    service(datas) {
        const alert = (name) => (datas.why && datas.why[name] ? `<div class="alert">${datas.why[name]}</div>` : "");
        this._HTMLResult = [`
          <!DOCTYPE html>
            <html>
              ${this.head("Login")}    
            <body>
                <script>
                  var expanded = false;
                  function showCheckboxes(checkboxes) {
                      update();
                      regextensions.style.display = "none";
                      regoptions.style.display = "none";
                    if (!expanded) {
                      checkboxes.style.display = "block";
                      expanded = true;
                    } else {
                      checkboxes.style.display = "none";
                      expanded = false;
                    }
                  }
                </script> 
              <div class="login-wrap">
              <div class="login-html" color="#FF0000">
                    ${this.title(`${datas.body._src === "_first" ? "First" : "New"} service`)}
                    <input  id="tab-1" type="radio" name="tab" class="sign-in" checked>
                    <label for="tab-1" class="tab">New service</label>
                    <input id="tab-2" type="radio" name="tab" class="sign-up">
                    <label for="tab-2" class="tab">New User</label>
                    <div class="login-form">
                      <form action="/service" method="post">
                        <div class="sign-in-htm">
                          ${this.addHidden("_src", datas.body._src === "_first" ? "_createService" : "_addService")}
                          ${this.addHidden("host", datas)}
                          ${this.addHidden("port", datas)}
                          ${this.addHidden("adminname", datas)}
                          ${this.addHidden("adminpassword", datas)}
                          ${this.addTextInput({ name: "name", label: "Service name", value: datas.body && datas.body.name || "", alert: alert("name"), toolType: `Name ${messages_1.info.least5Tool}`, onlyAlpha: true })}
                          ${this.addTextInput({ name: "database", label: `${messages_1.info.pg} ${messages_1.info.db} name`, value: datas.body && datas.body.database || "", alert: alert("database"), toolType: `name of ${messages_1.info.pg} ${messages_1.info.db}`, onlyAlpha: true })} </td>
                          ${this.addSelect({ name: "version", list: models_1.models.listVersion().reverse().map(e => e.replace("_", ".")), message: "Select version", value: datas.body && datas.body.version || "", alert: alert("repeat"), toolType: messages_1.info.repTool })}
                          ${this.addMultiSelect({ name: "extensions", list: (0, enums_1.enumKeys)(enums_1.EExtensions).filter(e => !["file", "base"].includes(e)), message: "Select Extensions", values: datas.body && datas.body.extensions || [""] })}                            
                          ${this.addMultiSelect({ name: "options", list: (0, enums_1.enumKeys)(enums_1.EOptions), message: "Select Options", values: datas.body && datas.body.options || [""] })}
                        </div> 
                        <div class="sign-up-htm">
                          ${this.addTextInput({ name: "username", label: messages_1.info.firstUser, value: "", alert: alert("username"), disabled: true })}
                          ${this.addTextInput({ name: "password", label: `New user ${messages_1.info.pass}`, password: true, value: datas.body && datas.body.password || "", alert: alert("password"), toolType: messages_1.info.passTool })}
                          ${this.addTextInput({ name: "repeat", label: `${messages_1.info.rep} ${messages_1.info.pass}`, password: true, value: "", alert: alert("repeat"), toolType: messages_1.info.repTool })}
                          ${this.addSubmitButton(messages_1.info.createServ)}
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </body>  
              <script>
                function clsAlphaNoOnly (e) {
                  var regex = new RegExp("^[a-zA-Z0-9]+$");
                  var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
                  if (regex.test(str)) {
                      return true;
                  }
                  e.preventDefault();
                  return false;
                }
                function update() { 
                  username.value = database.value;
                  if (version.value === 'v0.9') {
                    
                  }
                }
                username.addEventListener("change", () => {
                  update();
                });
                version.addEventListener("change", () => {
                  update();
                });
                ${this.addMultiJs()}
                MultiselectDropdown("extensions", "${datas.body.extensions}");
                MultiselectDropdown("options", "${datas.body.options}");
              </script>                 
            </html>`];
    }
    ;
}
exports.Service = Service;
