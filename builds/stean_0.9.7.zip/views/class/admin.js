Object.defineProperty(exports,"__esModule",{value:!0}),exports.Admin=void 0;let log_1=require("../../log"),messages_1=require("../../messages"),core_1=require("./core"),service_1=require("./service");class Admin extends core_1.CoreHtmlView{constructor(e,s){super(e),this.admin(e,s)}admin(e,s){if("_admin"===s.body._src)return new service_1.Service(e,{login:!1,url:e.request.url,body:s.body,why:{}});e=e=>s.why&&s.why[e]?`<div class="alert">${s.why[e]}</div>`:"";this._HTMLResult=[`
            <!DOCTYPE html>
            <html>
              ${this.head("Login")}    
              <body>
                <div class="login-wrap">
                  <div class="login-html">
                    ${this.title("Authentification")}
                    <div class="login-form">
                      <form action="/service" method="post">
                          ${this.addHidden("_src","_admin")}
                          ${this.addTextInput({name:"host",label:messages_1.info.host,value:s.body&&s.body.host||"localhost",alert:e("host")})}
                          ${this.addTextInput({name:"port",label:messages_1.info.pg+" port",value:s.body&&s.body.port||"5432",toolType:messages_1.info.portTool,alert:e("port")})}
                          ${this.addTextInput({name:"adminname",label:messages_1.info.user,value:s.body&&s.body.adminname||"postgres",alert:e("adminname")})}
                          ${this.addTextInput({name:"adminpassword",label:messages_1.info.pass,value:"",password:!0,alert:e("adminpassword")})}
                          ${this.hr()}
                          ${this.addSubmitButton(messages_1.info.conn)}
                          ${s.why&&s.why._error?this.AddErrorMessage(s.why._error):""}
                      </form>
                    </div>
                  </div>
                </div>
              </body>                  
            </html>`]}}exports.Admin=Admin;