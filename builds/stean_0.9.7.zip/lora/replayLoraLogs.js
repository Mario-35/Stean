"use strict";
/**
 * replayLoraLogs for odata
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.replayLoraLogs = void 0;
const configuration_1 = require("../configuration");
const dataAccess_1 = require("../db/dataAccess");
const entities_1 = require("../models/entities");
const helper_1 = require("../odata/visitor/helper");
/**
 *
 * @param ctx koa context
 * @param sql filter query
 */
const replayLoraLogs = async (ctx, sql) => {
    const delLog = (id) => {
        configuration_1.config.connection(ctx.service.name).unsafe(`DELETE FROM "${entities_1.LOG.table}" WHERE id = ${id}`).then((e) => {
            process.stdout.write(`replay log ----> ${id}` + "\u2714\uFE0F\uFE0F" /* EChar.ok */ + "\n");
        });
    };
    await configuration_1.config.connection(ctx.service.name).unsafe(`SELECT "@iot.id","datas" FROM (${sql})`).cursor(async (res) => {
        const temp = (0, helper_1.blankRootPgVisitor)(ctx, ctx.model.Loras);
        if (temp) {
            ctx.odata = temp;
            ctx.odata.replay = true;
            const objectAccess = new dataAccess_1.apiAccess(ctx);
            try {
                await objectAccess.post(res[0]["datas"]).then((ok) => {
                    delLog(res[0]["@iot.id"]);
                });
            }
            catch (error) {
                if (error["detail"].includes("already exist"))
                    delLog(res[0]["@iot.id"]);
                process.stdout.write(error["detail"] + "\n");
            }
        }
    });
    return true;
};
exports.replayLoraLogs = replayLoraLogs;
