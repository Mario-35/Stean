"use strict";
/**
 * Constants of API
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports._READY = exports._DEBUG = exports._TRACE = exports.TIMESTAMP = exports.ESCAPE_SIMPLE_QUOTE = exports.ESCAPE_ARRAY_JSON = void 0;
exports.setDebug = setDebug;
exports.setReady = setReady;
const ESCAPE_ARRAY_JSON = (input) => input ? input.replace("[", "{").replace("]", "}") : undefined;
exports.ESCAPE_ARRAY_JSON = ESCAPE_ARRAY_JSON;
const ESCAPE_SIMPLE_QUOTE = (input) => input.replace(/[']+/g, "''");
exports.ESCAPE_SIMPLE_QUOTE = ESCAPE_SIMPLE_QUOTE;
const TIMESTAMP = () => { const d = new Date(); return d.toLocaleTimeString(); };
exports.TIMESTAMP = TIMESTAMP;
function setDebug(input) { exports._DEBUG = input; }
function setReady(input) { exports._READY = input; }
exports._TRACE = true;
exports._DEBUG = false;
exports._READY = false;
