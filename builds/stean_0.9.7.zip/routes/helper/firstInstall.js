"use strict";
/**
 * firstInstall
 *
 * @copyright 2020-present Inrae
 * @review 31-01-2024
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.firstInstall = firstInstall;
const postgres_1 = __importDefault(require("postgres"));
const configuration_1 = require("../../configuration");
const helpers_1 = require("../../helpers");
const views_1 = require("../../views");
function formatConfig(input, admin) {
    const name = admin ? "admin" : input.name.toLowerCase();
    return {
        "name": name,
        "ports": admin ? {
            "http": 8029,
            "tcp": 9000,
            "ws": 1883
        } : 8029,
        "pg": {
            "host": input["host"],
            "port": input["port"],
            "user": admin ? input["adminname"] : name,
            "password": admin ? input["adminpassword"] : input["password"],
            "database": admin ? "postgres" : input["database"].toLowerCase(),
            "retry": 2
        },
        "apiVersion": input["version"],
        "date_format": "DD/MM/YYYY hh:mi:ss",
        "webSite": "no web site",
        "nb_page": 200,
        "alias": [""],
        "extensions": admin ? ["base"] : `base,${input["extensions"] ? String(input["extensions"]) : ''}`.split(","),
        "options": admin ? [] : input["options"] ? String(input["options"]).split(",") : []
    };
}
async function firstInstall(ctx) {
    // If Configuration file Not exist first Install
    const why = {};
    const src = JSON.parse(JSON.stringify(ctx.request.body, null, 2));
    function verifyItems(src, search) {
        let error = false;
        function verifyItem(search) {
            if (src.hasOwnProperty(search))
                return;
            why[search] = `${search} not define`;
            error = true;
        }
        search.forEach(e => {
            verifyItem(e);
        });
        return error;
    }
    function returnBody(connection) {
        const obj = { login: false, url: ctx.request.url, body: ctx.request.body, why: why };
        const bodyFirst = connection === true
            ? new views_1.Service(ctx, obj)
            : (configuration_1.config.configFileExist() === false)
                ? new views_1.First(ctx, obj)
                : new views_1.Admin(ctx, obj);
        ctx.type = helpers_1.returnFormats.html.type;
        ctx.body = bodyFirst.toString();
        return undefined;
    }
    if (src["_src"]) {
        ["host", "port", "adminname", "adminpassword", "database", "extensions", "options"].forEach(e => { if (src[e])
            why[e] = src[e]; });
        if (src["name"])
            why["name"] = src["name"].toLowerCase();
        switch (src["_src"]) {
            case "_admin":
                if (verifyItems(src, ["host", "adminname", "port", "adminpassword"]) === false) {
                    const testConnection = await (0, postgres_1.default)(`postgres://${src["adminname"]}:${src["adminpassword"]}@${src["host"]}:${src["port"]}/postgres`, {}) `select 1+1 AS result`.then(async () => true)
                        .catch((error) => {
                        ctx.throw(401 /* EHttpCode.Unauthorized */);
                    });
                    if (testConnection === true)
                        return returnBody(testConnection);
                }
                else {
                    return returnBody(false);
                }
            case "_first":
                if (verifyItems(src, ["host", "adminname", "port", "adminpassword", "repeat"]) === false) {
                    if (src["adminpassword"] === src["repeat"]) {
                        const testConnection = await (0, postgres_1.default)(`postgres://${src["adminname"]}:${src["adminpassword"]}@${src["host"]}:${src["port"]}/postgres`, {}) `select 1+1 AS result`.then(async () => true)
                            .catch((error) => {
                            why["_error"] = error.message;
                            return false;
                        });
                        if (testConnection === true)
                            return returnBody(testConnection);
                    }
                    else {
                        why["repeat"] = "repeat password HAVE TO be same as pasword";
                        return returnBody(false);
                    }
                }
                else {
                    return returnBody(false);
                }
            case "_createService":
                if (verifyItems(src, ["host", "port", "adminname", "adminpassword", "name", "database", "version", "password", "repeat"]) === false) {
                    if (src["name"].toUpperCase() === "POSTGRES") {
                        why["name"] = "name must not be postgres";
                        return returnBody(false);
                    }
                    const confJson = {
                        "admin": formatConfig(src, true)
                    };
                    confJson[src["name"].toLowerCase()] = formatConfig(src);
                    const returnUrl = `${ctx.request.origin}/${src["name"].toLowerCase()}/${src["version"]}`;
                    if (await configuration_1.config.init(JSON.stringify(confJson, null, 2)))
                        ctx.redirect(returnUrl);
                    return returnBody(true);
                }
                else {
                    return returnBody(true);
                }
            case "_addService":
                if (verifyItems(src, ["name", "database", "version", "password", "repeat"]) === false) {
                    if (src["name"].toUpperCase() === "POSTGRES") {
                        why["name"] = "name must not be postgres";
                        return returnBody(false);
                    }
                    const returnUrl = `${ctx.request.origin}/${src["name"].toLowerCase()}/${src["version"]}`;
                    if (await configuration_1.config.addConfig(formatConfig(src)))
                        ctx.redirect(returnUrl);
                    return returnBody(true);
                }
                else {
                    return returnBody(true);
                }
        }
    }
    return returnBody(false);
}
