"use strict";
/**
 * testDbExists
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.testDbExists = testDbExists;
const postgres_1 = __importDefault(require("postgres"));
const constants_1 = require("../../constants");
const enums_1 = require("../../enums");
/**
 * Test if database exist with admin connection
 *
 * @param adminConn admin connection
 * @param database DB name
 * @returns true if exist
 */
async function testDbExists(adminConn, database) {
    return await (0, postgres_1.default)(`postgres://${adminConn.user}:${adminConn.password}@${adminConn.host}:${adminConn.port || 5432}/${database}`, {
        debug: constants_1._DEBUG,
        connection: {
            application_name: `${enums_1.EConstant.appName} ${enums_1.EConstant.appVersion}`
        }
    }) `select 1+1 AS result`.then(async () => true)
        .catch((error) => {
        console.log(error);
        return false;
    });
}
