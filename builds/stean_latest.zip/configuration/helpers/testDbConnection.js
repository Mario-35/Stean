"use strict";
/**
 * testDbConnection
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.testDbConnection = testDbConnection;
const postgres_1 = __importDefault(require("postgres"));
const constants_1 = require("../../constants");
const enums_1 = require("../../enums");
/**
 * Test if database exist with admin connection
 *
 * @param host pg host name
 * @param username pg username name
 * @param password pg password name
 * @param port pg port name
 * @param database pg database name
 * @returns true if connection valid
 */
async function testDbConnection(host, username, password, port, database) {
    return await (0, postgres_1.default)(`postgres://${username}:${password}@${host}:${port || 5432}/${database || "postgres"}`, {
        debug: constants_1._DEBUG,
        connection: {
            application_name: `${enums_1.EConstant.appName} ${enums_1.EConstant.appVersion}`
        }
    }) `select 1+1 AS result`.then(async () => true)
        .catch((error) => {
        console.log(error);
        return false;
    });
}
