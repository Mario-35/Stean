"use strict";
/**
 * constant Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EConstant = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const getKey = () => {
    let res = "zLwX893Mtt9Rc0TKvlInDXuZTFj9rxDV";
    try {
        return fs_1.default.readFileSync(path_1.default.resolve(__dirname, "../configuration/", '.key'), "utf8");
    }
    catch (error) {
        fs_1.default.writeFileSync(path_1.default.resolve(__dirname, "../configuration/", '.key'), res, { encoding: "utf-8" });
    }
    return res;
};
exports.EConstant = Object.freeze({
    rights: "SUPERUSER CREATEDB NOCREATEROLE INHERIT LOGIN NOREPLICATION NOBYPASSRLS CONNECTION LIMIT -1",
    id: '@iot.id',
    name: "@iot.name",
    navLink: '@iot.navigationLink',
    selfLink: '@iot.selfLink',
    encoding: "encodingType",
    columnSeparator: '@|@',
    admin: 'admin',
    test: 'test',
    doubleQuotedComa: '",\n"',
    simpleQuotedComa: "',\n'",
    newline: '\r\n',
    uploadPath: "./upload",
    host: "localhost",
    pg: "postgres",
    port: 5432,
    voidtable: "spatial_ref_sys",
    appName: process.env.npm_package_name || "_STEAN",
    nodeEnv: process.env.NODE_ENV ? process.env.NODE_ENV : "production",
    appVersion: process.env.version || process.env.npm_package_version || "0",
    stringException: ["CONCAT", "CASE", "COALESCE"],
    key: getKey(),
    helmetConfig: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "cdnjs.cloudflare.com"],
        styleSrc: ["'self'", "'unsafe-inline'", "cdnjs.cloudflare.com", "fonts.googleapis.com",],
    }
});
