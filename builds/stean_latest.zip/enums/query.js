"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EQuery = void 0;
/**
 * EQuery Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var EQuery;
(function (EQuery) {
    EQuery["Where"] = "where";
    EQuery["Select"] = "select";
    EQuery["GroubBy"] = "groubBy";
    EQuery["Geo"] = "Geo";
    EQuery["OrderBy"] = "orderBy";
})(EQuery || (exports.EQuery = EQuery = {}));
