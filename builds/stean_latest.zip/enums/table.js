"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ETable = void 0;
/**
 * table Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var ETable;
(function (ETable) {
    ETable[ETable["blank"] = 0] = "blank";
    ETable[ETable["table"] = 1] = "table";
    ETable[ETable["link"] = 2] = "link";
})(ETable || (exports.ETable = ETable = {}));
