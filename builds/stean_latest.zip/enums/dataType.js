"use strict";
/**
 * DataType Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EDataType = void 0;
var EDataType;
(function (EDataType) {
    EDataType[EDataType["none"] = 0] = "none";
    EDataType[EDataType["bigint"] = 1] = "bigint";
    EDataType[EDataType["bigserial"] = 2] = "bigserial";
    EDataType[EDataType["bit"] = 3] = "bit";
    EDataType[EDataType["boolean"] = 4] = "boolean";
    EDataType[EDataType["box"] = 5] = "box";
    EDataType[EDataType["bytea"] = 6] = "bytea";
    EDataType[EDataType["character"] = 7] = "character";
    EDataType[EDataType["cidr"] = 8] = "cidr";
    EDataType[EDataType["circle"] = 9] = "circle";
    EDataType[EDataType["date"] = 10] = "date";
    EDataType[EDataType["double"] = 11] = "double";
    EDataType[EDataType["inet"] = 12] = "inet";
    EDataType[EDataType["integer"] = 13] = "integer";
    EDataType[EDataType["interval"] = 14] = "interval";
    EDataType[EDataType["json"] = 15] = "json";
    EDataType[EDataType["jsonb"] = 16] = "jsonb";
    EDataType[EDataType["line"] = 17] = "line";
    EDataType[EDataType["lseg"] = 18] = "lseg";
    EDataType[EDataType["macaddr"] = 19] = "macaddr";
    EDataType[EDataType["macaddr8"] = 20] = "macaddr8";
    EDataType[EDataType["money"] = 21] = "money";
    EDataType[EDataType["numeric"] = 22] = "numeric";
    EDataType[EDataType["path"] = 23] = "path";
    EDataType[EDataType["pg_lsn"] = 24] = "pg_lsn";
    EDataType[EDataType["pg_snapshot"] = 25] = "pg_snapshot";
    EDataType[EDataType["point"] = 26] = "point";
    EDataType[EDataType["polygon"] = 27] = "polygon";
    EDataType[EDataType["real"] = 28] = "real";
    EDataType[EDataType["smallint"] = 29] = "smallint";
    EDataType[EDataType["smallserial"] = 30] = "smallserial";
    EDataType[EDataType["serial"] = 31] = "serial";
    EDataType[EDataType["text"] = 32] = "text";
    EDataType[EDataType["_text"] = 33] = "_text";
    EDataType[EDataType["time"] = 34] = "time";
    EDataType[EDataType["timetz"] = 35] = "timetz";
    EDataType[EDataType["timestamp"] = 36] = "timestamp";
    EDataType[EDataType["timestamptz"] = 37] = "timestamptz";
    EDataType[EDataType["tsquery"] = 38] = "tsquery";
    EDataType[EDataType["tsvector"] = 39] = "tsvector";
    EDataType[EDataType["txid_snapshot"] = 40] = "txid_snapshot";
    EDataType[EDataType["uuid"] = 41] = "uuid";
    EDataType[EDataType["xml"] = 42] = "xml";
    EDataType[EDataType["geometry"] = 43] = "geometry";
    EDataType[EDataType["link"] = 44] = "link";
    EDataType[EDataType["result"] = 45] = "result";
    EDataType[EDataType["period"] = 46] = "period"; // result
})(EDataType || (exports.EDataType = EDataType = {}));
