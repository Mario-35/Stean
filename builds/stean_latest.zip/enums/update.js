"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EUpdate = void 0;
/**
 * EUpdate Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var EUpdate;
(function (EUpdate) {
    EUpdate["beforeAll"] = "beforeAll";
    EUpdate["afterAll"] = "afterAll";
    EUpdate["decoders"] = "decoders";
    EUpdate["triggers"] = "triggers";
})(EUpdate || (exports.EUpdate = EUpdate = {}));
