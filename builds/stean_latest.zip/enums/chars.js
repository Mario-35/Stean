"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EChar = void 0;
/**
 * char Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var EChar;
(function (EChar) {
    EChar["del"] = "\uD83D\uDDD1\uFE0F";
    EChar["forbidden"] = "\u26D4\uFE0F";
    EChar["key"] = "\uD83D\uDD11";
    EChar["lock"] = "\uD83D\uDD0F";
    EChar["notimplemented"] = "\uD83D\uDEA7";
    EChar["notOk"] = "\u274C";
    EChar["ok"] = "\u2714\uFE0F\uFE0F";
    EChar["search"] = "\uD83D\uDD0E";
    EChar["time"] = "\u23F2\uFE0F";
    EChar["date"] = "\uD83D\uDDD3\uFE0F";
    EChar["tools"] = "\uD83D\uDEE0\uFE0F";
    EChar["unlock"] = "\uD83D\uDD10";
    EChar["wait"] = "\u23F3";
    EChar["web"] = "\uD83C\uDF0D";
    EChar["mail"] = "\uD83D\uDCE7";
    EChar["attention"] = "\u26A0\uFE0F";
    EChar["write"] = "\uD83D\uDCBE";
    EChar["copyright"] = "\u00A9\uFE0F";
    EChar["arrowleft"] = "\uD83E\uDC78";
    EChar["arrowright"] = "\uD83E\uDC7A";
})(EChar || (exports.EChar = EChar = {}));
