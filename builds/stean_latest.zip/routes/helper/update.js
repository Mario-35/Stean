"use strict";
/**
 * Update Helpers.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.update = void 0;
const child_process_1 = require("child_process");
const update = () => {
    (0, child_process_1.execSync)('sh ../../update.sh');
    process.exit(100);
};
exports.update = update;
