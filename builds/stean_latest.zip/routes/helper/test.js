"use strict";
/**
 * Test Helpers.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTest = void 0;
const parser_1 = require("../../odata/parser/parser");
const getTest = async (ctx) => {
    const a = `$expand=Products($filter=hour('alfred') eq 'cake')`;
    try {
        return (0, parser_1.query)(decodeURIComponent(a));
    }
    catch (error) {
        console.log(error);
        return { error: error };
    }
};
exports.getTest = getTest;
