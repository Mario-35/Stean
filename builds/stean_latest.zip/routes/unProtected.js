"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.unProtectedRoutes = void 0;
/**
* Unprotected Routes for API
*
* @copyright 2020-present Inrae
* @author mario.adam@inrae.fr
*
*/
const koa_router_1 = __importDefault(require("koa-router"));
const authentication_1 = require("../authentication");
const helpers_1 = require("../helpers");
const dataAccess_1 = require("../db/dataAccess");
const odata_1 = require("../odata");
const messages_1 = require("../messages");
const configuration_1 = require("../configuration");
const createDb_1 = require("../db/createDb");
const helpers_2 = require("../db/helpers");
const models_1 = require("../models");
const helper_1 = require("./helper");
const helpers_3 = require("../db/helpers");
const views_1 = require("../views/");
const helpers_4 = require("../views/helpers");
const enums_1 = require("../enums");
const monitoring_1 = require("../db/monitoring");
const logs_1 = require("../views/class/logs");
const log_1 = require("../log");
exports.unProtectedRoutes = new koa_router_1.default();
// ALl others
exports.unProtectedRoutes.get("/(.*)", async (ctx) => {
    switch (ctx.decodedUrl.path.toUpperCase()) {
        // Root path
        case `/`:
            ctx.body = models_1.models.getRoot(ctx);
            ctx.type = helpers_1.returnFormats.json.type;
            return;
        // tests only for testing wip features
        case "UPDATE":
            (0, helper_1.update)();
            return;
        // tests only for testing wip features
        case "TEST":
            ctx.type = helpers_1.returnFormats.json.type;
            ctx.body = await (0, helper_1.getTest)(ctx);
            return;
        // metrics for moinoring
        case "METRICS":
            ctx.type = helpers_1.returnFormats.json.type;
            ctx.body = await (0, monitoring_1.getMetrics)(ctx);
            return;
        // error show in html if query call
        case "ERROR":
            const bodyError = new views_1.HtmlError(ctx, "what ?");
            ctx.type = helpers_1.returnFormats.html.type;
            ctx.body = bodyError.toString();
            return;
        // logs
        case "LOGGING":
            ;
            ctx.redirect(`${ctx.decodedUrl.origin}/logging`);
            return;
        case "LOGSBAK":
            const bodyLogsBak = new logs_1.HtmlLogs(ctx, "../../../" + enums_1.EFileName.logsBak);
            ctx.type = helpers_1.returnFormats.html.type;
            ctx.body = bodyLogsBak.toString();
            return;
        // export service
        case "EXPORT":
            ctx.type = helpers_1.returnFormats.json.type;
            ctx.body = await (0, helpers_2.exportService)(ctx);
            return;
        // User login
        case "SERVICE":
            ctx.redirect(`${ctx.decodedUrl.origin}/service`);
            return;
        case "LOGIN":
            if ((0, authentication_1.userAuthenticated)(ctx))
                ctx.redirect(`${ctx.decodedUrl.root}/status`);
            else {
                const bodyLogin = new views_1.Login(ctx, { login: true });
                ctx.type = helpers_1.returnFormats.html.type;
                ctx.body = bodyLogin.toString();
            }
            return;
        // Status user 
        case "STATUS":
            if ((0, authentication_1.userAuthenticated)(ctx)) {
                const user = await (0, authentication_1.getAuthenticatedUser)(ctx);
                if (user) {
                    const bodyStatus = new views_1.Status(ctx, user);
                    ctx.type = helpers_1.returnFormats.html.type;
                    ctx.body = bodyStatus.toString();
                    return;
                }
            }
            ctx.cookies.set("jwt-session");
            ctx.redirect(`${ctx.decodedUrl.root}/login`);
            return;
        // Create user 
        case "REGISTER":
            const bodyLogin = new views_1.Login(ctx, { login: false });
            ctx.type = helpers_1.returnFormats.html.type;
            ctx.body = bodyLogin.toString();
            return;
        // Logout user
        case "LOGOUT":
            ctx.cookies.set("jwt-session");
            if (ctx.request.header.accept && ctx.request.header.accept.includes("text/html"))
                ctx.redirect(`${ctx.decodedUrl.root}/login`);
            else
                ctx.status = 200 /* EHttpCode.ok */;
            ctx.body = {
                message: messages_1.info.logoutOk,
            };
            return;
        // Execute Sql query pass in url 
        case "SQL":
            let sql = (0, helpers_1.getUrlKey)(ctx.request.url, "query");
            if (sql) {
                sql = atob(sql);
                const resultSql = await configuration_1.config.executeSql(sql.includes("log_request") ? configuration_1.config.getService(enums_1.EConstant.admin) : ctx.service, sql);
                ctx.status = 201 /* EHttpCode.created */;
                ctx.body = [resultSql];
            }
            return;
        // Show draw.io model
        case "DRAW":
            ctx.type = helpers_1.returnFormats.xml.type;
            ctx.body = models_1.models.getDrawIo(ctx);
            return;
        // Infos and link of a services
        case "INFOS":
            ctx.type = helpers_1.returnFormats.json.type;
            ctx.body = await models_1.models.getInfos(ctx);
            return;
        case "DROP":
            console.log(log_1.log.debug_head("drop database"));
            if (ctx.service.options.includes(enums_1.EOptions.canDrop)) {
                await configuration_1.config.executeAdmin((0, helper_1.sqlStopDbName)((0, helpers_1.simpleQuotesString)(ctx.service.pg.database))).then(async () => {
                    await configuration_1.config.executeAdmin(`DROP DATABASE IF EXISTS ${ctx.service.pg.database}`);
                    try {
                        ctx.status = 201 /* EHttpCode.created */;
                        ctx.body = await (0, createDb_1.createDatabase)(ctx.service.pg.database);
                    }
                    catch (error) {
                        ctx.status = 400 /* EHttpCode.badRequest */;
                        ctx.redirect(`${ctx.decodedUrl.root}/error`);
                    }
                });
            }
            return;
        // Create DB test
        case "CREATEDBTEST":
            console.log(log_1.log.debug_head("GET createDB"));
            try {
                await configuration_1.config.connection(enums_1.EConstant.admin) `DROP DATABASE IF EXISTS test`;
                ctx.body = await (0, helpers_3.createService)(ctx, createDb_1.testDatas),
                    ctx.status = 201 /* EHttpCode.created */;
            }
            catch (error) {
                ctx.status = 400 /* EHttpCode.badRequest */;
                ctx.redirect(`${ctx.decodedUrl.root}/error`);
            }
            return;
        // Drop DB test
        case "REMOVEDBTEST":
            console.log(log_1.log.debug_head("GET remove DB test"));
            const returnDel = await configuration_1.config
                .connection(enums_1.EConstant.admin) `${(0, helper_1.sqlStopDbName)('test')}`
                .then(async () => {
                await configuration_1.config.connection(enums_1.EConstant.admin) `DROP DATABASE IF EXISTS test`;
                return true;
            });
            if (returnDel) {
                ctx.status = 204 /* EHttpCode.noContent */;
                ctx.body = returnDel;
            }
            else {
                ctx.status = 400 /* EHttpCode.badRequest */;
                ctx.redirect(`${ctx.decodedUrl.root}/error`);
            }
            return;
        // Return Query HTML Page Tool 
        case "QUERY":
            const tempContext = await (0, helpers_4.createQueryParams)(ctx);
            if (tempContext) {
                const bodyQuery = new views_1.Query(ctx, tempContext);
                ctx.set("script-src", "self");
                ctx.set("Content-Security-Policy", "self");
                ctx.type = helpers_1.returnFormats.html.type;
                ctx.body = bodyQuery.toString();
            }
            return;
    } // END Switch
    // API GET REQUEST  
    if (ctx.decodedUrl.path.includes(ctx.service.apiVersion) || ctx.decodedUrl.version) {
        console.log(log_1.log.debug_head(`unProtected GET ${ctx.service.apiVersion}`));
        // decode odata url infos
        const odataVisitor = await (0, odata_1.createOdata)(ctx);
        if (odataVisitor) {
            ctx.odata = odataVisitor;
            if (ctx.odata.returnNull === true) {
                ctx.body = { values: [] };
                return;
            }
            console.log(log_1.log.debug_head(`GET ${ctx.service.apiVersion}`));
            // Create api object
            const objectAccess = new dataAccess_1.apiAccess(ctx);
            if (objectAccess) {
                // Get all
                if (ctx.odata.entity && ctx.odata.single === false) {
                    const returnValue = await objectAccess.getAll();
                    if (returnValue) {
                        const datas = ctx.odata.returnFormat === helpers_1.returnFormats.json
                            ? { "@iot.count": returnValue.id,
                                "@iot.nextLink": returnValue.nextLink,
                                "@iot.prevLink": returnValue.prevLink,
                                value: returnValue.body }
                            : returnValue.body;
                        ctx.type = ctx.odata.returnFormat.type;
                        ctx.body = ctx.odata.returnFormat.format(datas, ctx);
                        if (returnValue.selfLink)
                            ctx.set("Location", returnValue.selfLink);
                    }
                    else
                        ctx.throw(404 /* EHttpCode.notFound */);
                    // Get One
                }
                else if (ctx.odata.single === true) {
                    const returnValue = await objectAccess.getSingle();
                    if (returnValue && returnValue.body) {
                        ctx.type = ctx.odata.returnFormat.type;
                        ctx.body = ctx.odata.returnFormat.format(returnValue.body);
                    }
                    else
                        ctx.throw(404 /* EHttpCode.notFound */, { detail: `id : ${ctx.odata.id} not found` });
                }
                else
                    ctx.throw(400 /* EHttpCode.badRequest */);
            }
        }
    }
});
