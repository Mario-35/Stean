"use strict";
/**
 * Index Routes
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.routerHandle = exports.protectedRoutes = exports.unProtectedRoutes = void 0;
const authentication_1 = require("../authentication");
const constants_1 = require("../constants");
const log_1 = require("../log");
const enums_1 = require("../enums");
const helpers_1 = require("../helpers");
const helper_1 = require("./helper");
const messages_1 = require("../messages");
const configuration_1 = require("../configuration");
const models_1 = require("../models");
var unProtected_1 = require("./unProtected");
Object.defineProperty(exports, "unProtectedRoutes", { enumerable: true, get: function () { return unProtected_1.unProtectedRoutes; } });
var protected_1 = require("./protected");
Object.defineProperty(exports, "protectedRoutes", { enumerable: true, get: function () { return protected_1.protectedRoutes; } });
const querystring_1 = __importDefault(require("querystring"));
const writeLogToDb_1 = require("../log/writeLogToDb");
const logs_1 = require("../views/class/logs");
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const routerHandle = async (ctx, next) => {
    ctx.body = ctx.request.body;
    configuration_1.config.writeTrace(ctx);
    // First Install 
    if (configuration_1.config.configFileExist() === false)
        await (0, helper_1.firstInstall)(ctx);
    // create token
    (0, helpers_1.createBearerToken)(ctx);
    // decode url
    const decodedUrl = (0, helper_1.decodeUrl)(ctx);
    if (!decodedUrl) {
        // Get all infos services
        switch (ctx.path.toLocaleUpperCase()) {
            // get infos
            case "/INFOS":
                ctx.body = configuration_1.config.getInfosForAll(ctx);
                return;
            // service assistant
            case "/SERVICE":
                await (0, helper_1.firstInstall)(ctx);
                return;
            // logging for all 
            case "/LOGGING":
                const bodyLogs = new logs_1.HtmlLogs(ctx, "../../" + enums_1.EFileName.logs);
                ctx.type = helpers_1.returnFormats.html.type;
                ctx.body = bodyLogs.toString();
                return;
        }
        return;
    }
    ;
    // set decodedUrl context
    ctx.decodedUrl = decodedUrl;
    if (constants_1._DEBUG)
        console.log(log_1.log.object("decodedUrl", decodedUrl));
    if (!decodedUrl.service)
        throw new Error(messages_1.errors.noNameIdentified);
    if (decodedUrl.service && decodedUrl.configName)
        ctx.service = configuration_1.config.getService(decodedUrl.configName);
    else
        return;
    // forcing post loras with different version IT'S POSSIBLE BECAUSE COLUMN ARE THE SAME FOR ALL VERSION
    if (decodedUrl.version != ctx.service.apiVersion) {
        if (!(ctx.request.method === "POST" && ctx.originalUrl.includes(`${decodedUrl.version}/Loras`)))
            ctx.redirect(ctx.request.method === "GET"
                ? ctx.originalUrl.replace(String(decodedUrl.version), ctx.service.apiVersion)
                : `${ctx.decodedUrl.linkbase}/${ctx.service.apiVersion}/`);
    }
    // try to clean query string
    ctx.querystring = decodeURIComponent(querystring_1.default.unescape(ctx.querystring));
    // prepare logs object
    try {
        if (ctx.service.extensions.includes(enums_1.EExtensions.logs))
            ctx.log = {
                datas: { ...ctx.body },
                code: -999,
                method: ctx.method,
                url: ctx.url,
                database: ctx.service.pg.database,
                user_id: (0, helpers_1.getUserId)(ctx).toString(),
            };
    }
    catch (error) {
        ctx.log = undefined;
    }
    // get model
    ctx.model = models_1.models.filtered(ctx.service);
    try {
        // Init config context
        if (!ctx.service)
            return;
        ctx.user = (0, authentication_1.decodeToken)(ctx);
        await next().then(async () => { });
    }
    catch (error) {
        console.log(error);
        if (ctx.service && ctx.service.extensions.includes(enums_1.EExtensions.logs))
            (0, writeLogToDb_1.writeLogToDb)(ctx, error);
        const tempError = {
            code: error.statusCode,
            message: error.message,
            detail: error.detail,
        };
        ctx.status = error.statusCode || error.status || 500 /* EHttpCode.internalServerError */;
        ctx.body = error.link ? { ...tempError, link: error.link, } : tempError;
    }
};
exports.routerHandle = routerHandle;
