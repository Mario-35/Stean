"use strict";
/**
 * Log class
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.log = void 0;
const util_1 = __importDefault(require("util"));
const enums_1 = require("../enums");
const constants_1 = require("../constants");
// class to logCreate configs environements
class Log {
    debugFile = false;
    line = (nb) => "═".repeat(nb);
    logAll = (input, colors) => typeof input === "object" ? util_1.default.inspect(input, { showHidden: false, depth: null, colors: colors || false, }) : input;
    separator = (title, nb) => `${(0, enums_1.color)(32 /* EColor.Green */)} ${this.line(nb)} ${(0, enums_1.color)(33 /* EColor.Yellow */)} ${title} ${(0, enums_1.color)(32 /* EColor.Green */)} ${this.line(nb)}${(0, enums_1.color)(0 /* EColor.Reset */)}`;
    logCleInfos = (cle, infos) => `${(0, enums_1.color)(32 /* EColor.Green */)} ${cle} ${(0, enums_1.color)(37 /* EColor.White */)} : ${(0, enums_1.color)(36 /* EColor.Cyan */)} ${this.logAll(infos, this.debugFile)}${(0, enums_1.color)(0 /* EColor.Reset */)}`;
    booting(cle, value) {
        return `\x1b[${36 /* EColor.Cyan */}m${cle}\x1b[${37 /* EColor.White */}m ${value}\x1b[${0 /* EColor.Reset */}m`;
    }
    showAll(input, colors) {
        return typeof input === "object" ? util_1.default.inspect(input, { showHidden: false, depth: null, colors: colors || false, }) : input;
    }
    create(cle, value) {
        return `${(0, enums_1.color)(37 /* EColor.White */)} -->${(0, enums_1.color)(36 /* EColor.Cyan */)} ${cle} ${(0, enums_1.color)(37 /* EColor.White */)} ${this.showAll(value)}${(0, enums_1.color)(0 /* EColor.Reset */)}`;
    }
    message(cle, infos) {
        return `${(0, enums_1.color)(33 /* EColor.Yellow */)}${cle} ${(0, enums_1.color)(37 /* EColor.White */)}:${(0, enums_1.color)(36 /* EColor.Cyan */)} ${this.showAll(infos)}${(0, enums_1.color)(0 /* EColor.Reset */)}`;
    }
    query(sql) {
        if (constants_1._DEBUG)
            return `${(0, enums_1.color)(93 /* EColor.Code */)}${"=".repeat(5)}[ Query Start ]${"=".repeat(5)}\n${(0, enums_1.color)(92 /* EColor.Sql */)} ${this.showAll(sql)}\n${(0, enums_1.color)(92 /* EColor.Sql */)}${(0, enums_1.color)(93 /* EColor.Code */)}${(0, enums_1.color)(0 /* EColor.Reset */)}`;
    }
    queryError(query, error) {
        return `${(0, enums_1.color)(32 /* EColor.Green */)} ${"=".repeat(15)} ${(0, enums_1.color)(36 /* EColor.Cyan */)} ERROR ${(0, enums_1.color)(32 /* EColor.Green */)} ${"=".repeat(15)}${(0, enums_1.color)(0 /* EColor.Reset */)}
      ${(0, enums_1.color)(31 /* EColor.Red */)} ${error} ${(0, enums_1.color)(34 /* EColor.Blue */)}
      ${(0, enums_1.color)(36 /* EColor.Cyan */)} ${this.showAll(query, false)}${(0, enums_1.color)(0 /* EColor.Reset */)}`;
    }
    // Usefull for id not used ;)
    oData(infos) {
        if (infos && constants_1._DEBUG) {
            const tmp = `${(0, enums_1.color)(37 /* EColor.White */)} ${infos} ${(0, enums_1.color)(0 /* EColor.Reset */)}`;
            return `${(0, enums_1.color)(31 /* EColor.Red */)} ${"=".repeat(8)} ${(0, enums_1.color)(36 /* EColor.Cyan */)} ${new Error().stack?.split("\n")[2].trim().split("(")[0].split("at ")[1].trim()} ${tmp}${(0, enums_1.color)(31 /* EColor.Red */)} ${"=".repeat(8)}${(0, enums_1.color)(0 /* EColor.Reset */)}`;
        }
        return infos;
    }
    // log an object or json
    object(title, input) {
        if (constants_1._DEBUG) {
            const res = [this._head(title)];
            Object.keys(input).forEach((cle) => {
                res.push(this.logCleInfos("  " + cle, input[cle]));
            });
            return res.join("\n");
        }
    }
    url(link) {
        return `${"\uD83C\uDF0D" /* EChar.web */} ${(0, enums_1.color)(39 /* EColor.Default */)} : ${(0, enums_1.color)(36 /* EColor.Cyan */)} ${link}${(0, enums_1.color)(0 /* EColor.Reset */)}`;
    }
    _head(cle, infos) {
        return infos ? `${(0, enums_1.color)(32 /* EColor.Green */)}${this.line(12)} ${(0, enums_1.color)(36 /* EColor.Cyan */)} ${cle} ${(0, enums_1.color)(37 /* EColor.White */)} ${this.logAll(infos, this.debugFile)} ${(0, enums_1.color)(32 /* EColor.Green */)} ${this.line(12)}${(0, enums_1.color)(0 /* EColor.Reset */)}` : this.separator(cle, 12);
    }
    debug_head(cle, infos) {
        if (constants_1._DEBUG)
            return this._head(cle, infos);
    }
    _infos(cle, infos) {
        if (constants_1._DEBUG)
            return `${(0, enums_1.color)(32 /* EColor.Green */)} ${cle} ${(0, enums_1.color)(37 /* EColor.White */)} : ${(0, enums_1.color)(36 /* EColor.Cyan */)} ${this.logAll(infos, this.debugFile)}${(0, enums_1.color)(0 /* EColor.Reset */)}`;
    }
    debug_infos(cle, infos) {
        if (constants_1._DEBUG)
            return this._infos(cle, infos);
    }
    _result(cle, infos) {
        return `${(0, enums_1.color)(32 /* EColor.Green */)}     >>${(0, enums_1.color)(30 /* EColor.Black */)} ${cle} ${(0, enums_1.color)(39 /* EColor.Default */)} : ${(0, enums_1.color)(36 /* EColor.Cyan */)} ${this.logAll(infos, this.debugFile)}${(0, enums_1.color)(0 /* EColor.Reset */)}`;
    }
    debug_result(cle, infos) {
        if (constants_1._DEBUG)
            return this._result(cle, infos);
    }
    error(cle, infos) {
        return infos
            ? `${(0, enums_1.color)(31 /* EColor.Red */)} ${cle} ${(0, enums_1.color)(34 /* EColor.Blue */)} : ${(0, enums_1.color)(33 /* EColor.Yellow */)} ${this.logAll(infos, this.debugFile)}${(0, enums_1.color)(0 /* EColor.Reset */)}`
            : `${(0, enums_1.color)(31 /* EColor.Red */)} Error ${(0, enums_1.color)(34 /* EColor.Blue */)} : ${(0, enums_1.color)(33 /* EColor.Yellow */)} ${this.logAll(cle)}${(0, enums_1.color)(0 /* EColor.Reset */)}`;
    }
    whereIam(infos) {
        if (constants_1._DEBUG) {
            const tmp = infos ? `${(0, enums_1.color)(39 /* EColor.Default */)} ${infos} ${(0, enums_1.color)(0 /* EColor.Reset */)}` : '';
            return `${(0, enums_1.color)(31 /* EColor.Red */)}${this.line(4)} ${(0, enums_1.color)(36 /* EColor.Cyan */)} ${new Error().stack?.split("\n")[2].trim().split("(")[0].split("at ")[1].trim()} ${tmp}${(0, enums_1.color)(31 /* EColor.Red */)} ${this.line(4)}${(0, enums_1.color)(0 /* EColor.Reset */)}`;
        }
        ;
    }
    logo(ver) {
        return `${(0, enums_1.color)(93 /* EColor.Code */)}${(0, enums_1.color)(92 /* EColor.Sql */)}\n ____ __________    _     _   _ \n/ ___|_ __  ____|  / \\   | \\ | |\n\\___ \\| | |  _|   / _ \\  |  \\| |\n ___) | | | |___ / ___ \\ | |\\  |\n|____/|_| |_____|_/   \\_\\|_| \\_|  ${(0, enums_1.color)(34 /* EColor.Blue */)}run API ----> ${(0, enums_1.color)(32 /* EColor.Green */)}${ver}${(0, enums_1.color)(92 /* EColor.Sql */)}${(0, enums_1.color)(93 /* EColor.Code */)}\n${"\uD83C\uDF0D" /* EChar.web */} ${(0, enums_1.color)(37 /* EColor.White */)}https://github.com/Mario-35/Stean/ ${"\uD83D\uDCE7" /* EChar.mail */} ${(0, enums_1.color)(33 /* EColor.Yellow */)} mario.adam@inrae.fr${(0, enums_1.color)(0 /* EColor.Reset */)}`;
    }
}
exports.log = new Log();
