"use strict";
/**
 * writeLogToDb
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeLogToDb = void 0;
const helpers_1 = require("../helpers");
const models_1 = require("../models");
const _1 = require(".");
const helpers_2 = require("../models/helpers");
const configuration_1 = require("../configuration");
const enums_1 = require("../enums");
const writeLogToDb = async (ctx, ...error) => {
    console.log(_1.log.whereIam(ctx.traceId));
    if (ctx.odata.replay === false && ctx.log && ctx.log.method != "GET") {
        ctx.log.code = error && error["code"] ? +error["code"] : +ctx.response.status;
        ctx.log.error = error;
        ctx.log.datas = ctx.body;
        ctx.log.datas = (0, helpers_1.hidePassword)(ctx.log.datas);
        try {
            if (ctx.body && typeof ctx.body === "string")
                ctx.log.returnid = JSON.parse(ctx.body)[enums_1.EConstant.id];
        }
        catch (error) {
            ctx.log.returnid = undefined;
        }
        await configuration_1.config.connection(ctx.service.name).unsafe(`INSERT INTO ${(0, helpers_1.doubleQuotesString)(models_1.models.DBFull(ctx.service).Logs.table)} ${(0, helpers_2.createInsertValues)(ctx, ctx.log, models_1.models.DBFull(ctx.service).Logs.name)} returning id`).then((res) => {
        }).catch((err) => {
            process.stdout.write(err + "\n");
        });
    }
};
exports.writeLogToDb = writeLogToDb;
