"use strict";
/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Query interface
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
