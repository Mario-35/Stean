"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.blankUserToken = void 0;
exports.blankUserToken = { id: 0, username: "", password: "", PDCUAS: [false, false, false, false, false, false] };
