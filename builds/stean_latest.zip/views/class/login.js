"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.Login=void 0;const messages_1=require("../../messages"),core_1=require("./core");class Login extends core_1.CoreHtmlView{constructor(e,s){super(e),this.login(s)}login(s){var e=e=>s.why&&s.why[e]?`<div class="alert">${s.why[e]}</div>`:"",a=this.ctx.decodedUrl.linkbase+"/"+this.ctx.config.apiVersion;this._HTMLResult=[`
          <!DOCTYPE html>
            <html>
              ${this.head("Login")}    
            <body>
                <div class="login-wrap">
                  <div class="login-html">
                    ${this.title("Identification")}
                    <input  id="tab-1" type="radio" name="tab" class="sign-in" ${s.login?" checked":""}>
                    <label for="tab-1" class="tab">Sign In</label>
                    <input  id="tab-2" type="radio" name="tab" class="sign-up" ${s.login?"":"checked"}>
                    <label for="tab-2" class="tab">Sign Up</label>
                    <div class="login-form">
                      <form action="${a}/login" method="post">
                        <div class="sign-in-htm">
                          ${this.addTextInput({name:"username",label:"Username",value:""})}
                          ${this.addTextInput({name:"password",label:"Password",value:"",password:!0})}
                          ${this.addCheckBox({name:"check",checked:!0,label:" Keep me Signed in"})}
                          ${this.addSubmitButton("Sign In")}
                          ${this.hr()}
                          ${this.addButton(a+"/Query","Return to Query")}
                          <div class="foot-lnk">
                            <a href="#forgot">Forgot Password?</a>
                          </div>
                        </div>
                      </form>
            
                      <form action="${a}/register" method="post">
                        <div class="sign-up-htm">
                          ${this.addTextInput({name:"username",label:messages_1.infos.user,value:s.body&&s.body.username?s.body.username:"",alert:e("username"),toolType:"Name "+messages_1.infos.least5Tool})}
                          ${this.addTextInput({name:"pass",label:messages_1.infos.pass,password:!0,value:s.body&&s.body.password?s.body.password:"",alert:e("password"),toolType:messages_1.infos.passTool})}
                          ${this.addTextInput({name:"repeat",label:messages_1.infos.rep,password:!0,value:"",alert:e("repeat"),toolType:messages_1.infos.repTool})}
                          ${this.addTextInput({name:"mail",label:"Email address",value:s.body&&s.body.email?s.body.email:"",alert:e("email"),toolType:messages_1.infos.mailTool})}
                          ${this.addSubmitButton("Sign UP")}
                          ${this.hr()}                                
                          <div class="foot-lnk">
                            <label for="tab-1">Already Member ?</a>
                          </div>
                        </div>
                      </form>
                  </div>
                </div>
              </div>
            </body>                  
          </html>`]}}exports.Login=Login;