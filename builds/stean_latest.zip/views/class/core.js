Object.defineProperty(exports,"__esModule",{value:!0}),exports.CoreHtmlView=void 0;let css_1=require("../css");class CoreHtmlView{ctx;_HTMLResult;constructor(e,t){this.ctx=e,this._HTMLResult=t?"string"==typeof t?[t]:t:[]}makeIdName(e){return"reg"+e}title(e){return`<div class="title">${e}</div>`}hr(){return'<div class="hr"></div>'}head(e,t){return`<head>
                <meta charset="utf-8">
                <style>${(0,css_1.addCssFile)(t||["userForm.css","message.css"])}</style>
                <title>${e}</title>
              </head>`}foot(e){let t=[this.hr()];return e.forEach(e=>{t.push(`
          <div class="inner">
            <a  href="${e.href}" 
                class="${e.class}">${e.name}</a>
          </div>`)}),t.join()}addSubmitButton(e){return`<div class="group">
                <input type="submit" class="button" value="${e}">
              </div>`}AddErrorMessage(e){return"undefined"===e?"":`<div class="message-container">
        <div class="error">
                ${e}
        </div>
      </div>`}addButton(e,t){return`<div class="group">
                <a href="${e}" class="button" >${t}</a>
              </div>`}addCheckBox(e){var t=this.makeIdName(e.name);return`<div class="group"> 
                <input  id="${t}"
                        name="${e.name}"
                        type="checkbox" 
                        class="check"${!0===e.checked?" checked":""}> 
                <label for="${t}"><span class="icon"></span>${e.label||e.name}</label>
              </div>`}multiSelectItemCheck(t,e){let s=[];return e.forEach(e=>{s.push(`<label for="${e}"> <input type="checkbox" id="${t}${e}" name="${t}${e}" />${e}</label>`)}),s.join("")}multiSelectItem(e){let s=[];return e.forEach((e,t)=>{s.push(`<option value="${e}">${e}</option>`)}),s.join("")}addSelect(e){var t=this.makeIdName(e.name);return`<div class="group">
                <label  for="${t}" class="label">
                 ${e.message}
                </label>
                <select class="select" id="${t}" name="${e.name}">
                  ${this.multiSelectItem(e.list)}
                </select>
              </div>`}addMultiSelect(e){var t=this.makeIdName(e.name);return`
                <div class="group selectBox" onclick="showCheckboxes(${t})">
                <select>
                  <option >${e.message}</option>
                </select>
                <div class="overSelect"></div>
              </div>
              <div id="${t}" class="checkboxes" checked="checked">
                ${this.multiSelectItemCheck(e.name,e.list)} 
            </div>`}addTextInput(e){var t=this.makeIdName(e.name);return`<div class="group">
                <label  for="${t}" class="label">${e.label} </label>
                ${e.toolType?`<div class='tooltip help'>
                        <span>?</span>
                        <div class='content'>
                          <b></b>
                          <p>${e.toolType}</p>
                        </div>
                      </div>`:""}
                <input  id="${t}" 
                        name="${e.name}" 
                        type="${e.password&&1==e.password?"password":"text"}" 
                        class="input" 
                        ${e.disabled?"disabled":""}
                        value="${e.value}">
                        ${e.alert||""}
              </div>`}addHidden(e,t){return`<input type="hidden" id="${e}" name="${e}" value="${t}" />`}toArray(){return this._HTMLResult}toString(){return this._HTMLResult.filter(e=>""!==e).join("")}}exports.CoreHtmlView=CoreHtmlView;