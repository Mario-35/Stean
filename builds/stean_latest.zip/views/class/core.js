Object.defineProperty(exports,"__esModule",{value:!0}),exports.CoreHtmlView=void 0;let log_1=require("../../log"),css_1=require("../css");class CoreHtmlView{ctx;_HTMLResult;constructor(e,t){this.ctx=e,this._HTMLResult=t?"string"==typeof t?[t]:t:[]}title(e){return`<div class="title">${e}</div>`}hr(){return'<div class="hr"></div>'}head(e,t){return`<head>
                <meta charset="utf-8">
                <style>${(0,css_1.addCssFile)(t||["userForm.css","message.css"])}</style>
                <title>${e}</title>
              </head>`}foot(e){let t=[this.hr()];return e.forEach(e=>{t.push(`
          <div class="inner">
            <a  href="${e.href}" 
                class="${e.class}">${e.name}</a>
          </div>`)}),t.join()}addSubmitButton(e){return`<div class="group">
                <input type="submit" class="button" value="${e}">
              </div>`}AddErrorMessage(e){return"undefined"===e?"":`<div class="message-container">
        <div class="error">
                ${e}
        </div>
      </div>`}addButton(e,t){return`<div class="group">
                <a href="${e}" class="button" >${t}</a>
              </div>`}addCheckBox(e){return`<div class="group"> 
                <input  id="${e.name}"
                        name="${e.name}"
                        type="checkbox" 
                        class="check"${!0===e.checked?" checked":""}> 
                <label for="${e.name}"><span class="icon"></span>${e.label||e.name}</label>
              </div>`}multiSelectItemCheck(t,e){let l=[];return e.forEach(e=>{l.push(`<label for="${e}"> <input type="checkbox" id="${t}${e}" name="${t}${e}" />${e}</label>`)}),l.join("")}multiSelectItem(e){let l=[];return e.forEach((e,t)=>{l.push(`<option value="${e}">${e}</option>`)}),l.join("")}addSelect(e){return`<div class="group">
                <label  for="${e.name}" class="label">
                 ${e.message}
                </label>
                <select class="select" id="${e.name}" name="${e.name}">
                  ${this.multiSelectItem(e.list)}
                </select>
              </div>`}addMultiSelect(e){var t=e.list.map((e,t)=>`<option value="${e}">${e}</option>`);return`<div class="group">
                <label  for="${e.name}" class="label">Select ${e.name}</label>
                <select id="${e.name}" name="${e.name}" multiple onchange="${e.name}.value = Array.from(this.selectedOptions).map(x=>x.value??x.text)"> ${t} </select>
                </div>`}addTextInput(e){return`<div class="group">
                <label  for="${e.name}" class="label">${e.label} </label>
                ${e.toolType?`<div class='tooltip help'>
                        <span>?</span>
                        <div class='content'>
                          <b></b>
                          <p>${e.toolType}</p>
                        </div>
                      </div>`:""}
                <input  id="${e.name}" 
                        name="${e.name}" 
                        type="${e.password&&1==e.password?"password":"text"}" 
                        class="input" 
                        ${e.disabled?"disabled":""}
                        ${e.onlyAlpha?'onkeypress="clsAlphaNoOnly(event)"':""}
                        value="${e.value}">
                        ${e.alert||""}
              </div>`}addHidden(e,t){return"string"==typeof t?`<input type="hidden" id="${e}" name="${e}" value="${t}" />`:`<input type="hidden" id="${e}" name="${e}" value="${t.body[e]||""}" />`}toArray(){return this._HTMLResult}toString(){return this._HTMLResult.filter(e=>""!==e).join("")}addMultiJs(){return'var style=document.createElement("style");function MultiselectDropdown(e,t){var l=document.getElementById(e);function s(e,t){var l=document.createElement(e);return void 0!==t&&Object.keys(t).forEach((e=>{"class"===e?Array.isArray(t[e])?t[e].forEach((e=>""!==e?l.classList.add(e):0)):""!==t[e]&&l.classList.add(t[e]):"style"===e?Object.keys(t[e]).forEach((s=>{l.style[s]=t[e][s]})):"text"===e?""===t[e]?l.innerHTML="&nbsp;":l.innerText=t[e]:l[e]=t[e]})),l}var c=s("div",{class:"multiselect-dropdown"});c.id="multiselect-"+l.id,l.style.display="none",l.parentNode.insertBefore(c,l.nextSibling);var d=s("div",{class:"multiselect-dropdown-list-wrapper"}),i=s("div",{class:"multiselect-dropdown-list",style:{height:"15rem"}});c.appendChild(d),d.appendChild(i),l.loadOptions=()=>{i.innerHTML="",Array.from(l.options).map((e=>{e.selected=t.split(",").includes(e.value);var c=s("div",{class:e.selected?"checked":"",optEl:e}),d=s("input",{type:"checkbox",checked:e.selected});c.appendChild(d),c.appendChild(s("label",{text:e.text})),c.addEventListener("click",(()=>{c.classList.toggle("checked"),c.querySelector("input").checked=!c.querySelector("input").checked,c.optEl.selected=!c.optEl.selected,l.dispatchEvent(new Event("change"))})),d.addEventListener("click",(e=>{d.checked=!d.checked})),e.listitemEl=c,i.appendChild(c)})),c.listEl=d,c.refresh=()=>{c.querySelectorAll("span.optext, span.placeholder").forEach((e=>c.removeChild(e)));var e=Array.from(l.selectedOptions);e.length>(l.attributes["multiselect-max-items"]?.value??5)?c.appendChild(s("span",{class:["optext","maxselected"],text:e.length+" "+l.name})):e.map((e=>{var t=s("span",{class:"optext",text:e.text,srcOption:e});"true"!==l.attributes["multiselect-hide-x"]?.value&&t.appendChild(s("span",{class:"optdel",text:"🗙",onclick:e=>{t.srcOption.listitemEl.dispatchEvent(new Event("click")),c.refresh(),e.stopPropagation()}})),c.appendChild(t)})),0==l.selectedOptions.length&&c.appendChild(s("span",{class:"placeholder",text:l.attributes.placeholder?.value??l.placeholder}))},c.refresh()},l.loadOptions(),c.addEventListener("click",(()=>{c.listEl.style.display="block"})),document.addEventListener("click",(function(e){c.contains(e.target)||(d.style.display="none",c.refresh())}))}style.setAttribute("id","multiselect_dropdown_styles");'}}exports.CoreHtmlView=CoreHtmlView;