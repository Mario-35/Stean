Object.defineProperty(exports,"__esModule",{value:!0}),exports.Service=void 0;let enums_1=require("../../enums"),messages_1=require("../../messages"),models_1=require("../../models"),core_1=require("./core");class Service extends core_1.CoreHtmlView{constructor(e,s){super(e),this.service(s)}service(s){var e=e=>s.why&&s.why[e]?`<div class="alert">${s.why[e]}</div>`:"";this._HTMLResult=[`
          <!DOCTYPE html>
            <html>
              ${this.head("Login")}    
            <body>
                <script>
                  var expanded = false;
                  function showCheckboxes(checkboxes) {
                      regextensions.style.display = "none";
                      regoptions.style.display = "none";
                    if (!expanded) {
                      checkboxes.style.display = "block";
                      expanded = true;
                    } else {
                      checkboxes.style.display = "none";
                      expanded = false;
                      update();
                    }
                  }
                </script> 
              <div class="login-wrap">
              <div class="login-html" color="#FF0000">
                    ${this.title(`${"_first"===s.body._src?"First":"New"} service`)}
                    <input  id="tab-1" type="radio" name="tab" class="sign-in" checked>
                    <label for="tab-1" class="tab">New service</label>
                    <input id="tab-2" type="radio" name="tab" class="sign-up">
                    <label for="tab-2" class="tab">New User</label>
                    <div class="login-form">
                      <form action="/service" method="post">
                        <div class="sign-in-htm">
                          ${this.addHidden("_src","_first"===s.body._src?"_createService":"_addService")}
                          ${this.addHidden("_host",s.why&&s.why._host?s.why._host:"")}
                          ${this.addHidden("_username",s.why&&s.why._username?s.why._username:"")}
                          ${this.addHidden("_password",s.why&&s.why._password?s.why._password:"")}
                          ${this.addTextInput({name:"name",label:"Service name",value:s.body&&s.body.name||"",alert:e("name"),toolType:"Name "+messages_1.info.least5Tool})}
                          ${this.addTextInput({name:"port",label:messages_1.info.pg+" port",value:s.body&&s.body.port||"5432",alert:e("port"),toolType:messages_1.info.portTool})}
                          ${this.addTextInput({name:"database",label:`${messages_1.info.pg} ${messages_1.info.db} name`,value:"",alert:e("database"),toolType:`name of ${messages_1.info.pg} `+messages_1.info.db})} </td>
                          ${this.addSelect({name:"version",list:models_1.models.listVersion().map(e=>e.replace("_",".")),message:"Select version",value:"",alert:e("repeat"),toolType:messages_1.info.repTool})}
                          ${this.addMultiSelect({name:"extensions",list:(0,enums_1.enumKeys)(enums_1.EExtensions),message:"Select extensions"})}                            
                          ${this.addMultiSelect({name:"options",list:(0,enums_1.enumKeys)(enums_1.EOptions),message:"Select Options"})}
                        </div> 
                        <div class="sign-up-htm">
                          ${this.addTextInput({name:"host",label:"host",value:s.why&&s.why._host?s.why._host:"localhost",alert:e("host"),toolType:"Host "+messages_1.info.least5Tool})}
                          ${this.addTextInput({name:"username",label:messages_1.info.firstUser,value:s.body&&s.body.username||messages_1.info.newUser,alert:e("username"),toolType:"Name "+messages_1.info.least5Tool})}
                          ${this.addTextInput({name:"password",label:"New user "+messages_1.info.pass,password:!0,value:s.body&&s.body.password||"",alert:e("password"),toolType:messages_1.info.passTool})}
                          ${this.addTextInput({name:"repeat",label:messages_1.info.rep+" "+messages_1.info.pass,password:!0,value:"",alert:e("repeat"),toolType:messages_1.info.repTool})}
                          ${this.addSubmitButton(messages_1.info.createServ)}
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </body>  
              <script>
                function update() { 
                  if (regversion.value === 'v0.9') {
                    extensionsfile.checked = true;
                    extensionsbase.checked = false;
                    extensionslora.checked = false;
                    extensionstasking.checked = false;
                    extensionsmultiDatastream.checked = false;
                    extensionshighPrecision.checked = false;
                    extensionsresultNumeric.checked = false;
                  } else {
                      extensionsfile.checked = false;
                      extensionsbase.checked = true;
                  }
                }
                regversion.addEventListener("change", () => {
                  update();
                });
              </script>                 
            </html>`]}}exports.Service=Service;