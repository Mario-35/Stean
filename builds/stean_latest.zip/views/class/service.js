Object.defineProperty(exports,"__esModule",{value:!0}),exports.Service=void 0;let enums_1=require("../../enums"),log_1=require("../../log"),messages_1=require("../../messages"),models_1=require("../../models"),core_1=require("./core");class Service extends core_1.CoreHtmlView{constructor(e,s){super(e),this.service(s)}service(s){var e=e=>s.why&&s.why[e]?`<div class="alert">${s.why[e]}</div>`:"";this._HTMLResult=[`
          <!DOCTYPE html>
            <html>
              ${this.head("Login")}    
            <body>
                <script>
                  var expanded = false;
                  function showCheckboxes(checkboxes) {
                      update();
                      regextensions.style.display = "none";
                      regoptions.style.display = "none";
                    if (!expanded) {
                      checkboxes.style.display = "block";
                      expanded = true;
                    } else {
                      checkboxes.style.display = "none";
                      expanded = false;
                    }
                  }
                </script> 
              <div class="login-wrap">
              <div class="login-html" color="#FF0000">
                    ${this.title(`${"_first"===s.body._src?"First":"New"} service`)}
                    <input  id="tab-1" type="radio" name="tab" class="sign-in" checked>
                    <label for="tab-1" class="tab">New service</label>
                    <input id="tab-2" type="radio" name="tab" class="sign-up">
                    <label for="tab-2" class="tab">New User</label>
                    <div class="login-form">
                      <form action="/service" method="post">
                        <div class="sign-in-htm">
                          ${this.addHidden("_src","_first"===s.body._src?"_createService":"_addService")}
                          ${this.addHidden("host",s)}
                          ${this.addHidden("port",s)}
                          ${this.addHidden("adminname",s)}
                          ${this.addHidden("adminpassword",s)}
                          ${this.addTextInput({name:"name",label:"Service name",value:s.body&&s.body.name||"",alert:e("name"),toolType:"Name "+messages_1.info.least5Tool,onlyAlpha:!0})}
                          ${this.addTextInput({name:"database",label:`${messages_1.info.pg} ${messages_1.info.db} name`,value:s.body&&s.body.database||"",alert:e("database"),toolType:`name of ${messages_1.info.pg} `+messages_1.info.db,onlyAlpha:!0})} </td>
                          ${this.addSelect({name:"version",list:models_1.models.listVersion().reverse().map(e=>e.replace("_",".")),message:"Select version",value:s.body&&s.body.version||"",alert:e("repeat"),toolType:messages_1.info.repTool})}
                          ${this.addMultiSelect({name:"extensions",list:(0,enums_1.enumKeys)(enums_1.EExtensions).filter(e=>!["file","base"].includes(e)),message:"Select Extensions",values:s.body&&s.body.extensions||[""]})}                            
                          ${this.addMultiSelect({name:"options",list:(0,enums_1.enumKeys)(enums_1.EOptions),message:"Select Options",values:s.body&&s.body.options||[""]})}
                        </div> 
                        <div class="sign-up-htm">
                          ${this.addTextInput({name:"username",label:messages_1.info.firstUser,value:"",alert:e("username"),disabled:!0})}
                          ${this.addTextInput({name:"password",label:"New user "+messages_1.info.pass,password:!0,value:s.body&&s.body.password||"",alert:e("password"),toolType:messages_1.info.passTool})}
                          ${this.addTextInput({name:"repeat",label:messages_1.info.rep+" "+messages_1.info.pass,password:!0,value:"",alert:e("repeat"),toolType:messages_1.info.repTool})}
                          ${this.addSubmitButton(messages_1.info.createServ)}
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </body>  
              <script>
                function clsAlphaNoOnly (e) {
                  var regex = new RegExp("^[a-zA-Z0-9]+$");
                  var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
                  if (regex.test(str)) {
                      return true;
                  }
                  e.preventDefault();
                  return false;
                }
                function update() { 
                  username.value = database.value;
                  if (version.value === 'v0.9') {
                    
                  }
                }
                username.addEventListener("change", () => {
                  update();
                });
                version.addEventListener("change", () => {
                  update();
                });
                ${this.addMultiJs()}
                MultiselectDropdown("extensions", "${s.body.extensions}");
                MultiselectDropdown("options", "${s.body.options}");
              </script>                 
            </html>`]}}exports.Service=Service;