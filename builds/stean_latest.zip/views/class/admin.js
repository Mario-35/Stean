"use strict";
/**
 * HTML Views First Install for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Admin = void 0;
const log_1 = require("../../log");
const messages_1 = require("../../messages");
const core_1 = require("./core");
const service_1 = require("./service");
class Admin extends core_1.CoreHtmlView {
    constructor(ctx, datas) {
        console.log(log_1.log.whereIam("View"));
        super(ctx);
        this.admin(ctx, datas);
    }
    admin(ctx, datas) {
        if (datas.body._src === "_admin") {
            return new service_1.Service(ctx, { login: false, url: ctx.request.url, body: datas.body, why: {} });
        }
        const alert = (name) => (datas.why && datas.why[name] ? `<div class="alert">${datas.why[name]}</div>` : "");
        this._HTMLResult = [`
            <!DOCTYPE html>
            <html>
              ${this.head("Login")}    
              <body>
                <div class="login-wrap">
                  <div class="login-html">
                    ${this.title("Authentification")}
                    <div class="login-form">
                      <form action="/service" method="post">
                          ${this.addHidden("_src", "_admin")}
                          ${this.addTextInput({ name: "host", label: messages_1.info.host, value: datas.body && datas.body["host"] || "localhost", alert: alert("host") })}
                          ${this.addTextInput({ name: "port", label: messages_1.info.pg + " port", value: datas.body && datas.body.port || "5432", toolType: messages_1.info.portTool, alert: alert("port") })}
                          ${this.addTextInput({ name: "adminname", label: messages_1.info.user, value: datas.body && datas.body.adminname || "postgres", alert: alert("adminname") })}
                          ${this.addTextInput({ name: "adminpassword", label: messages_1.info.pass, value: "", password: true, alert: alert("adminpassword") })}
                          ${this.hr()}
                          ${this.addSubmitButton(messages_1.info.conn)}
                          ${datas.why && datas.why["_error"] ? this.AddErrorMessage(datas.why["_error"]) : ""}
                      </form>
                    </div>
                  </div>
                </div>
              </body>                  
            </html>`];
    }
    ;
}
exports.Admin = Admin;
