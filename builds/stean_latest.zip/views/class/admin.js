Object.defineProperty(exports,"__esModule",{value:!0}),exports.Admin=void 0;let messages_1=require("../../messages"),core_1=require("./core"),service_1=require("./service");class Admin extends core_1.CoreHtmlView{constructor(e,s){super(e),this.admin(e,s)}admin(e,s){if("_admin"===s.body._src)return new service_1.Service(e,{login:!1,url:e.request.url,body:s.body,why:{}});e=e=>s.why&&s.why[e]?`<div class="alert">${s.why[e]}</div>`:"";this._HTMLResult=[`
            <!DOCTYPE html>
            <html>
              ${this.head("Login")}    
              <body>
                <div class="login-wrap">
                  <div class="login-html">
                    ${this.title("Authentification")}
                    <div class="login-form">
                      <form action="/service" method="post">
                          ${this.addHidden("_src","_admin")}
                          ${this.addHidden("host","localhost")}
                          ${this.addTextInput({name:"username",label:messages_1.infos.user,value:s.body&&s.body.username||"postgres",alert:e("username")})}
                          ${this.addTextInput({name:"password",label:messages_1.infos.pass,password:!0,value:"",alert:e("password")})}
                          ${this.hr()}
                          ${this.addSubmitButton(messages_1.infos.conn)}
                          ${s.why&&s.why._error?this.AddErrorMessage(s.why._error):""}
                      </form>
                    </div>
                  </div>
                </div>
              </body>                  
            </html>`]}}exports.Admin=Admin;