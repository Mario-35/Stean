"use strict";var __importDefault=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(exports,"__esModule",{value:!0}),exports.HtmlLogs=void 0;const core_1=require("./core"),fs_1=__importDefault(require("fs")),path_1=__importDefault(require("path"));class HtmlLogs extends core_1.CoreHtmlView{constructor(e,t){t=fs_1.default.readFileSync(path_1.default.resolve(__dirname,t),"utf8");super(e),this.logs(t)}logs(e){this._HTMLResult=[`
        <!DOCTYPE html>
            <html>
                <body style="background-color:#353535;">
                    ${e}
                </body>
            </html>`]}}exports.HtmlLogs=HtmlLogs;