"use strict";
/**
 * HTML Views First Install for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.First = void 0;
const log_1 = require("../../log");
const messages_1 = require("../../messages");
const core_1 = require("./core");
class First extends core_1.CoreHtmlView {
    constructor(ctx, datas) {
        console.log(log_1.log.whereIam("View"));
        super(ctx);
        this.first(datas);
    }
    first(datas) {
        const alert = (name) => (datas.why && datas.why[name] ? `<div class="alert">${datas.why[name]}</div>` : "");
        this._HTMLResult = [`
            <!DOCTYPE html>
            <html>
              ${this.head("Login")}    
              <body>
                <div class="login-wrap">
                  <div class="login-html" color="#FF0000">
                    ${this.title("First Start")}
                    <input id="tab-1" type="radio" name="tab" class="sign-in" checked>
                    <label for="tab-1" class="tab">${messages_1.info.pg} Admin</label>
                    <input id="tab-2" type="radio" name="tab" class="sign-up">
                    <label for="tab-2" class="tab">Help</label>
                    <div class="login-form">
                      <form action="/service" method="post">
                        <div class="sign-in-htm">
                          ${this.addHidden("_src", "_first")}
                          ${this.addTextInput({ name: "host", label: messages_1.info.host, value: datas.body && datas.body.host || "localhost", alert: alert("host"), toolType: messages_1.info.least5Tool })}
                          ${this.addTextInput({ name: "port", label: messages_1.info.pg + " port", value: datas.body && datas.body.port || "5432", toolType: messages_1.info.portTool, alert: alert("port") })}
                          ${this.addTextInput({ name: "adminname", label: messages_1.info.user, value: datas.body && datas.body.adminname || "postgres", alert: alert("username"), toolType: messages_1.info.least5Tool })}
                          ${this.addTextInput({ name: "adminpassword", label: messages_1.info.pass, password: true, value: "", alert: alert("password"), toolType: messages_1.info.passTool })}
                          ${this.addTextInput({ name: "repeat", label: messages_1.info.rep, password: true, value: "", alert: alert("repeat"), toolType: messages_1.info.repTool })}
                          ${this.addSubmitButton(messages_1.info.dbPgConn)}
                          ${datas.why && datas.why["_error"] ? this.AddErrorMessage(datas.why["_error"]) : ""}
                        </div> 
                        <div class="sign-up-htm">
                          <span>
                            You have to create configuration to start the API<br>
                            <br>
                            You have to put user admin postgresSql connection in PostgresSql Admin in tab above (This user must have right to create databases).<br>
                            <br>
                            When the connection test succed you can create your first service.
                          </span>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </body>                  
            </html>`];
    }
    ;
}
exports.First = First;
