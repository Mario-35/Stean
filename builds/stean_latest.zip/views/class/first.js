"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.First=void 0;const messages_1=require("../../messages"),core_1=require("./core");class First extends core_1.CoreHtmlView{constructor(s,e){super(s),this.first(e)}first(e){var s=s=>e.why&&e.why[s]?`<div class="alert">${e.why[s]}</div>`:"";this._HTMLResult=[`
            <!DOCTYPE html>
            <html>
              ${this.head("Login")}    
              <body>
                <div class="login-wrap">
                  <div class="login-html" color="#FF0000">
                    ${this.title("First Start")}
                    <input id="tab-1" type="radio" name="tab" class="sign-in" checked>
                    <label for="tab-1" class="tab">${messages_1.infos.pg} Admin</label>
                    <input id="tab-2" type="radio" name="tab" class="sign-up">
                    <label for="tab-2" class="tab">Help</label>
                    <div class="login-form">
                      <form action="/install" method="post">
                        <div class="sign-in-htm">
                        ${this.addHidden("_src","_first")}
                        ${this.addTextInput({name:"host",label:messages_1.infos.host,value:e.body&&e.body.host||"localhost",alert:s("host"),toolType:messages_1.infos.least5Tool})}
                        ${this.addTextInput({name:"username",label:messages_1.infos.user,value:e.body&&e.body.username||"postgres",alert:s("username"),toolType:messages_1.infos.least5Tool})}
                        ${this.addTextInput({name:"password",label:messages_1.infos.pass,password:!0,value:"",alert:s("password"),toolType:messages_1.infos.passTool})}
                        ${this.addTextInput({name:"repeat",label:messages_1.infos.rep,password:!0,value:"",alert:s("repeat"),toolType:messages_1.infos.repTool})}
                        ${this.addSubmitButton(messages_1.infos.dbPgConn)}
                        ${e.why&&e.why._error?this.AddErrorMessage(e.why._error):""}
                        </div> 
                        <div class="sign-up-htm">
                        <span>
                          You have to create configuration to start the API<br>
                          <br>
                          You have to put user admin postgresSql connection in PostgresSql Admin in tab above (This user must have right to create databases).<br>
                          <br>
                          When the connection test succed you can create your first service.
                        </span>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </body>                  
            </html>`]}}exports.First=First;