"use strict";
/**
 * blankUser
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.blankUser = blankUser;
const enums_1 = require("../../enums");
function blankUser(ctx) {
    return {
        id: 0,
        username: "query",
        password: "",
        email: "",
        database: ctx.service.pg.database,
        canPost: !ctx.service.extensions.includes(enums_1.EExtensions.users),
        canDelete: !ctx.service.extensions.includes(enums_1.EExtensions.users),
        canCreateUser: !ctx.service.extensions.includes(enums_1.EExtensions.users),
        canCreateDb: !ctx.service.extensions.includes(enums_1.EExtensions.users),
        admin: false,
        superAdmin: false
    };
}
;
