"use strict";
/**
 * Constants of API
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.appVersion = exports.uploadPath = exports.packageJsonPath = exports.rootpath = exports._READY = exports._DEBUG = exports._TRACE = exports.TIMESTAMP = exports.ESCAPE_SIMPLE_QUOTE = exports.ESCAPE_ARRAY_JSON = void 0;
exports.setDebug = setDebug;
exports.setReady = setReady;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const ESCAPE_ARRAY_JSON = (input) => input ? input.replace("[", "{").replace("]", "}") : undefined;
exports.ESCAPE_ARRAY_JSON = ESCAPE_ARRAY_JSON;
const ESCAPE_SIMPLE_QUOTE = (input) => input.replace(/[']+/g, "''");
exports.ESCAPE_SIMPLE_QUOTE = ESCAPE_SIMPLE_QUOTE;
const TIMESTAMP = () => { const d = new Date(); return d.toLocaleTimeString(); };
exports.TIMESTAMP = TIMESTAMP;
function setDebug(input) { exports._DEBUG = input; }
function setReady(input) { exports._READY = input; }
exports._TRACE = true;
exports._DEBUG = false;
exports._READY = false;
exports.rootpath = path_1.default.join(path_1.default.resolve(__dirname, process.env.NODE_ENV?.trim() === "production" ? "../api" : "../../src/server/"));
exports.packageJsonPath = path_1.default.join(__dirname, process.env.NODE_ENV?.trim() === "production" ? "./package.json" : "../../package.json");
exports.uploadPath = path_1.default.join(path_1.default.resolve(__dirname, process.env.NODE_ENV?.trim() === "production" ? "../upload/" : "../../upload/"));
exports.appVersion = String(JSON.parse(String(fs_1.default.readFileSync(exports.packageJsonPath, "utf-8"))).version);
