"use strict";
/**
 * loginUser
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.loginUser = void 0;
const _1 = require(".");
const configuration_1 = require("../configuration");
const helpers_1 = require("../helpers");
const getUser = async (configName, username, password) => {
    const query = await configuration_1.config.connection(configName) `SELECT * FROM "user" WHERE username = ${username} LIMIT 1`;
    if (query.length === 1) {
        const user = { ...query[0] };
        if (user && password.trim() === (0, helpers_1.decrypt)(user.password)) {
            const token = (0, _1.createToken)(user, password);
            user.token = token;
            return Object.freeze(user);
        }
    }
};
// ctx for koa connection and set undefined for mqtt
const loginUser = async (ctx, login) => {
    if (login)
        return await getUser(login.configName, login.username, login.password);
    if (ctx) {
        const body = ctx.request.body;
        if (body["username"] && body["password"]) {
            const user = await getUser(ctx.service.name, body["username"], body["password"]);
            if (user) {
                ctx.cookies.set("jwt-session", user["token"]);
                return user;
            }
            else
                ctx.throw(401 /* EHttpCode.Unauthorized */);
        }
        else
            ctx.throw(401 /* EHttpCode.Unauthorized */);
    }
};
exports.loginUser = loginUser;
