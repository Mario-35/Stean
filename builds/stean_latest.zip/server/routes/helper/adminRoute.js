"use strict";
/**
 * adminRoute connection page.
 *
 * @copyright 2020-present Inrae
 * @review 31-01-2024
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminRoute = void 0;
const _1 = require(".");
const helpers_1 = require("../../helpers");
const views_1 = require("../../views");
/**
 * Generate admin page
 *
 * @param ctx koa context
 * @param message optional mussage
 */
const adminRoute = async (ctx, message) => {
    ctx.set("script-src", "self");
    ctx.set("Content-Security-Policy", "self");
    ctx.type = helpers_1.returnFormats.html.type;
    const connection = await (0, _1.postgresAdmin)(ctx);
    if (connection?.startsWith("[error]"))
        ctx.body = new views_1.HtmlError(ctx, { message: connection.replace("[error]", ""), url: ctx.path }).toString();
    else
        ctx.body = new views_1.Admin(ctx, { connection: connection, url: ctx.request.url, body: ctx.request.body, why: {}, message: message }).toString();
};
exports.adminRoute = adminRoute;
