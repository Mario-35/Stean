"use strict";
/**
 * exportRoute connection page.
 *
 * @copyright 2020-present Inrae
 * @review 31-01-2024
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.exportRoute = void 0;
const configuration_1 = require("../../configuration");
const helpers_1 = require("../../helpers");
/**
 * Generate uxport root page
 *
 * @param ctx koa context
 */
const exportRoute = async (ctx) => {
    ctx.type = helpers_1.returnFormats.json.type;
    ctx.body = await configuration_1.config.export();
};
exports.exportRoute = exportRoute;
