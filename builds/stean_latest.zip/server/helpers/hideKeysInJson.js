"use strict";
/**
 * hideKeysInJson
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.hideKeysInJson = void 0;
const tests_1 = require("./tests");
/**
 *
 * @param object string
 * @param key or array of keys to hide
 * @returns object without keys
 */
const hideKeysInJson = (obj, keys = "") => {
    if (typeof keys === "string")
        keys = [keys];
    for (const [k, v] of Object.entries(obj)) {
        keys.forEach((key) => {
            if (k.includes(key))
                delete obj[k];
            else if (k.includes("password"))
                obj[k] = "*****";
            else if ((0, tests_1.isObject)(v))
                (0, exports.hideKeysInJson)(v, keys);
        });
    }
    return obj;
};
exports.hideKeysInJson = hideKeysInJson;
