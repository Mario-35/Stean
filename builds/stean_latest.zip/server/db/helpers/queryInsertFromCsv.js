Object.defineProperty(exports,"__esModule",{value:!0}),exports.queryInsertFromCsv=queryInsertFromCsv;let _1=require("."),log_1=require("../../log"),entities_1=require("../../models/entities"),helpers_1=require("../../helpers");async function queryInsertFromCsv(e,o){let a=await(0,_1.columnsNameFromHydrasCsv)(o);if(a){e=await(0,_1.streamCsvFile)(e,o,a);if(log_1.logging.message("COPY TO "+o.tempTable,0<e?"✔️️":"❌").to().log().file(),0<e){let r=(0,helpers_1.splitLast)(o.filename,"/"),l=(new Date).toLocaleString(),s=[];return Object.keys(o.columns).forEach((e,t)=>{e=o.columns[e];s.push(`INSERT INTO "${entities_1.OBSERVATION.table}" 
          ("${e.stream.type?.toLowerCase()}_id", "featureofinterest_id", "phenomenonTime", "resultTime", "result", "resultQuality")
            SELECT 
            ${e.stream.id}, 
            ${e.stream.FoId},  
            ${a.dateSql}, 
            ${a.dateSql},
            json_build_object('value', 
            CASE "${o.tempTable}".value${e.column}
              WHEN '---' THEN NULL 
              WHEN '#REF!' THEN NULL 
              ELSE CAST(REPLACE(value${e.column},',','.') AS float) 
            END),
            '{"import": "${r}","date": "${l}"}'  
           FROM "${o.tempTable}" ON CONFLICT DO NOTHING returning 1`)}),{count:e,query:s}}}}