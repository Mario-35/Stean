Object.defineProperty(exports,"__esModule",{value:!0}),exports.asGeoJSON=void 0;let _1=require("."),asGeoJSON=e=>`SELECT JSONB_BUILD_OBJECT(
    'type', 
    'FeatureCollection', 
    'features', 
    (${(0,_1.asJson)({query:e.toString(),singular:!1,strip:!1,count:!1})}));`;exports.asGeoJSON=asGeoJSON;