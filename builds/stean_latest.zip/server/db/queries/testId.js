"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.testId = void 0;
/**
 * testId
*
* @copyright 2020-present Inrae
* @author mario.adam@inrae.fr
*
*/
const testId = (table, id) => `SELECT 
CASE WHEN EXISTS(
  SELECT 
    1 
  FROM 
    "${table}" 
  WHERE 
    "id" = ${id}
) THEN (
  SELECT 
    "id" 
  FROM 
    "${table}" 
  WHERE 
    "id" = ${id}
) END AS "id"`;
exports.testId = testId;
