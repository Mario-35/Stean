"use strict";
/**
 * Logs entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logs = void 0;
const common_1 = require("./common");
const configuration_1 = require("../../configuration");
const log_1 = require("../../log");
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
class Logs extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    // Override Get All logs
    async getAll() {
        console.log(log_1.log.whereIam());
        // create query
        this.ctx.odata.query.where.add(`"url" LIKE '%${this.ctx.service.name}%'`);
        let sql = this.ctx.odata.getSql();
        // Return results
        if (sql)
            return await configuration_1.config.trace.getValues(sql).then(async (res) => {
                return res[0] > 0
                    ? this.formatReturnResult({
                        [enums_1.EConstant.count]: this.ctx.odata.returnFormat === helpers_1.returnFormats.dataArray ? +Object.entries(res[1][0]["dataArray"]).length : +res[0],
                        [enums_1.EConstant.nextLink]: this.nextLink(res[0]),
                        [enums_1.EConstant.prevLink]: this.prevLink(res[0]),
                        value: res[1]
                    })
                    : this.formatReturnResult({ body: res[0] == 0 ? [] : res[0] });
            });
    }
    // Override Get one logs
    async getSingle() {
        console.log(log_1.log.whereIam());
        // create query
        this.ctx.odata.query.where.add(` AND url LIKE '%${this.ctx.service.name}%'`);
        const sql = this.ctx.odata.getSql();
        // Return results
        if (sql)
            return await configuration_1.config.trace
                .getValues(sql)
                .then((res) => {
                if (this.ctx.odata.query.select && this.ctx.odata.onlyValue === true) {
                    const temp = res[this.ctx.odata.query.select[0] == "id" ? enums_1.EConstant.id : 0];
                    if (typeof temp === "object") {
                        this.ctx.odata.returnFormat = helpers_1.returnFormats.json;
                        return this.formatReturnResult({ body: temp });
                    }
                    else
                        return this.formatReturnResult({ body: String(temp) });
                }
                return this.formatReturnResult({
                    body: this.ctx.odata.single === true ? res[1][0] : { value: res[1] }
                });
            })
                .catch((err) => this.ctx.throw(400 /* EHttpCode.badRequest */, { code: 400 /* EHttpCode.badRequest */, detail: err }));
    }
    // Override Post service
    async post(dataInput) {
        console.log(log_1.log.whereIam());
        // This function not exists
        return;
    }
    // Override Update service
    async update(dataInput) {
        console.log(log_1.log.whereIam());
        // This function not exists
        return;
    }
    // Override Delete service
    async delete(idInput) {
        console.log(log_1.log.whereIam(idInput));
        // This function not exists
        return;
    }
}
exports.Logs = Logs;
