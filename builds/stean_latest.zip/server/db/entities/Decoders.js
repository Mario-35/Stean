"use strict";
/**
 * Decoders entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Decoders = void 0;
const common_1 = require("./common");
const helpers_1 = require("../../helpers");
const lora_1 = require("../../lora");
const log_1 = require("../../log");
const entities_1 = require("../../models/entities");
const configuration_1 = require("../../configuration");
/**
 * Decoders Class
 */
class Decoders extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    // Override get all decoders to be able to search by deveui instead of id only
    async getAll() {
        console.log(log_1.log.whereIam());
        if (this.ctx.odata.payload) {
            const result = {};
            const decoders = await configuration_1.config.executeSql(this.ctx.service, `SELECT "id", "name", "code", "nomenclature", "synonym" FROM "${entities_1.DECODER.table}"`);
            await (0, helpers_1.asyncForEach)(
            // Start connectionsening ALL entries in config file
            Object(decoders), async (decoder) => {
                if (this.ctx.odata.payload) {
                    const temp = (0, lora_1.decodingPayload)({ name: decoder["name"], code: String(decoder["code"]), nomenclature: decoder["nomenclature"] }, this.ctx.odata.payload);
                    result[decoder["id"]] = temp;
                }
            });
            return this.formatReturnResult({ body: result });
        }
        else
            return await super.getAll();
    }
    // Override get one decoders to be able to search by deveui instead of id only
    async getSingle() {
        console.log(log_1.log.whereIam());
        if (this.ctx.odata.payload) {
            const decoder = await configuration_1.config.executeSql(this.ctx.service, `SELECT "id", "name", "code", "nomenclature", "synonym" FROM "${entities_1.DECODER.table}" WHERE id = ${this.ctx.odata.id}`);
            return decoder[0]
                ? this.formatReturnResult({
                    body: (0, lora_1.decodingPayload)({ name: decoder[0]["name"], code: String(decoder[0]["code"]), nomenclature: decoder[0]["nomenclature"] }, this.ctx.odata.payload)
                })
                : undefined;
        }
        else
            return await super.getSingle();
    }
}
exports.Decoders = Decoders;
