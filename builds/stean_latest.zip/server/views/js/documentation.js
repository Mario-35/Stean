function methodClass(e){return`<span class="method meth-${e}">${e}</span>`}function getMenuMain(e){for(;e&&!e.classList.contains("patrom-accordion-content");)e=e.parentElement;if((e=e.previousElementSibling).classList.contains("patrom-accordion-label"))return e.innerHTML}function getExamples(a,s){let c=['<div class="patrom-tabs">'];return Object.keys(a).forEach((e,t)=>{c.push(`<input type="radio" name="tabs" id="tab${t}" ${0==t?'checked="checked"':""}>`,`<label for="tab${t}">${e}</label>`,'<div class="patrom-tab">',`<code class='language-${e}'>`,"http"===e?_PARAMS.services.test.base+"/"+a[e].replace("DATASSATAD",s):a[e].replace("DATASSATAD",s),"</code>","</div>")}),c.push("</div>"),replaceProxy(c.join(""))}function getContent(e){return`<article class="">
    <div class="pull-left">
      <h1>${e.short}</h1>
    </div>
    ${e.description?`<section><p>${e.description}</p></section>`:""}
	${e.examples?`<div class="pull-center">${e.examples.http}</div>`:""}
    ${getDatasTabs(e)}    
    ${e.examples?`    <div class="pull-left">
      <h1>Examples</h1>
    </div>
	<section>${getExamples(e.examples,e.params)}</section>`:""}
  </article>`}function getDatasTabs(e){let a=0;function t(e,t){return`<li class="tab__item">
              <input class="tab__radio" type="radio" name="tab" id="tab_id_${a+=1}" ${1===a?'checked="checked"':""}/>
              <label class="tab__label" for="tab_id_${a}">${e}</label>
              <div class="tab__content">
                ${t}                 
              </div>
            </li>`}e=`
          <div class="tab">
            <div class="tab__body">
              <ul class="tab__list">
                ${e.params?t("Params",'<div class="view"> <div id="params"></div></div>'):""}
                ${e.success?t("Success",'<div class="view"> <div id="success"></div></div>'):""}
                ${e.error?t("Error",'<div class="view"> <div id="error"></div></div>'):""}
                ${e.structure?t("Structure",`<div class="view">${getStructure(e.structure)}</div>`):""}
              </ul>
            </div>
          </div>`;return 0===a?"":e}function getStructure(a){let s=["<table>","<thead>","<tr>",'<th style="width: 20%">Champ</th>','<th style="width: 5%">Requis</th>','<th style="width: 10%">Type</th>','<th style="width: 55%">Description</th>',"</tr>","</thead>","<tbody>"];return["columns","relations"].forEach(t=>{Object.keys(a[t]).forEach(e=>{s.push("<tr>",`<td>${e}</td>`,`<td>${1==a[t][e].requis?"✔️":"❌"}</td>`,`<td>${a[t][e].type}</td>`,`<td>${a[t][e].description}</td>`,"</tr>")})}),s.push("</tbody>","</table>"),s.join("")}function replaceProxy(e){return e.replaceAll("proxy",_PARAMS.services.test.base)}function showDoc(e){var t=window.location.href.split("?")[1],a=e?getMenuMain(e.srcElement):t?t.split("=")[0]:"sensorThings",a=docDatas[a][e?e.srcElement.id:t&&t.includes("=")?t.split("=")[1]:0],e=getContent(a);if(document.getElementById("content").innerHTML=e,document.getElementById("two").style.overflow="auto",a.params&&(t=new JSONViewer,params.appendChild(t.getContainer()),t.showJSON(JSON.parse(replaceProxy(a.params)))),a.success){e=new JSONViewer;success.appendChild(e.getContainer());try{e.showJSON(JSON.parse(replaceProxy(a.success)))}catch(e){}}a.error&&(t=new JSONViewer,error.appendChild(t.getContainer()),t.showJSON(JSON.parse(a.error)))}function filterDoc(){let s=search.value;Object.keys(docDatas).forEach(t=>{let a=!1;Object.keys(docDatas[t]).forEach(e=>{docDatas[t][e].description.includes(s)&&(a=!0);e=getElement(t+"-"+e);0==a?e.classList.add("hide"):e.classList.remove("hide"),0==a?e.parentElement.parentElement.classList.add("hide"):e.parentElement.parentElement.classList.remove("hide")})})}function createSideBar(){let t=[`<div class="patrom-row">
                    	<div class="patrom-col col-span-12 fullWidth">
                      		<input type="text" id="search" class="patrom-text-input" value="" placeholder="filter">
                      		<button class="patrom-icon-button" onclick="filterDoc(event)"> 🔎 </button>
                      		<label class="patrom-switch">
                        		<input id="theme" type="checkbox" class="patrom-switch__input" onchange="localStorage.setItem('theme', localStorage.getItem('theme') === 'dark' ? 'light' : 'dark'); document.documentElement.className = localStorage.getItem('theme');">
                        		<div class="patrom-switch__theme"></div>
                      		</label>
                    	</div>
                    </div>`];return Object.keys(docDatas).forEach((a,e)=>{t.push(`<div class="patrom-accordion">
						<input class="patrom-accordion-check" type="checkbox" id="chck${e}">
						<label class="patrom-accordion-label" for="chck${e}" id="Labelchck${e}">${a}</label>
						<div class="patrom-accordion-content">        
							${Object.keys(docDatas[a]).map((e,t)=>`<div class="patrom-row"  id="${a}-${t}">
							<div class="patrom-col col-span-12" fullWidth">
								${methodClass(docDatas[a][e].type)}
								<label class="menuItem" onclick="showDoc(event)" id="${t}">${docDatas[a][e].short} </label>                      
							</div></div>`).join("")}  
						</div>
					</div>`)}),t.join("")}new SplitterBar(container,first,two),document.getElementById("menuTabs").innerHTML=createSideBar(),jsonViewer=new JSONViewer,showDoc(),wait(!1);