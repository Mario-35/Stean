var __importDefault=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(exports,"__esModule",{value:!0}),exports.HtmlLogs=void 0;let core_1=require("./core"),fs_1=__importDefault(require("fs"));class HtmlLogs extends core_1.CoreHtmlView{constructor(e,t){var o=fs_1.default.readFileSync(t.url,"utf8");super(e,t),this.logs(o)}logs(e){this._HTMLResult=[`
        <!DOCTYPE html>
            <html>
                <body style="background-color:#353535;">
                    ${e}
                </body>
            </html>`]}}exports.HtmlLogs=HtmlLogs;