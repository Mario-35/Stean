Object.defineProperty(exports,"__esModule",{value:!0}),exports.Status=void 0;let configuration_1=require("../../configuration"),enums_1=require("../../enums"),log_1=require("../../log"),core_1=require("./core");class Status extends core_1.CoreHtmlView{constructor(e,t){super(e,t),t.user&&this.status(e,t.user)}status(e,t){var s=configuration_1.config.getConfigNameFromDatabase(t.database),e=e._.inExtension(enums_1.EExtensions.users);this._HTMLResult=[`<!DOCTYPE html>
        <html> 
            ${this.head("Status")}
            <body>
                <div class="login-wrap">
                    <div class="login-html">
                        ${this.title("Status")}
                        <h3>Username : ${t.username}</h3> 
                        <h3>Hosting : ${"all"==t.database?"all":s?configuration_1.config.getService(s).pg.host:"Not Found"}</h3>
                        <h3>Database : ${t.database}</h3>
                        <h3>Status : ${!(t.id&&0<t.id)&&e?"❌":"✔️️"}</h3> 
                        <h3>Post : ${!0!==t.canPost&&e?"❌":"✔️️"}</h3>
                        <h3>Delete : ${!0!==t.canDelete&&e?"❌":"✔️️"}</h3>
                        <h3>Create User: ${!0===t.canCreateUser?"✔️️":"❌"}</h3>
                        <h3>Create Service : ${!0===t.canCreateDb?"✔️️":"❌"}</h3>
                        <h3>Admin : ${!0===t.admin?"✔️️":"❌"}</h3>
                        <h3>Super admin : ${!0===t.superAdmin?"✔️️":"❌"}</h3>
                        ${this.foot([{href:this.ctx._.root()+"/Logout",class:"button-logout",name:"Logout"},{href:this.ctx._.root()+"/Query",class:"button-query",name:"Query"}])}
                    </div>
                </div>
            </body>
        </html>`]}}exports.Status=Status;