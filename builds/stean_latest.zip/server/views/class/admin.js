var __importDefault=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(exports,"__esModule",{value:!0}),exports.Admin=void 0;let configuration_1=require("../../configuration"),enums_1=require("../../enums"),helpers_1=require("../../helpers"),log_1=require("../../log"),models_1=require("../../models"),paths_1=require("../../paths"),css_1=require("../css"),js_1=require("../js"),core_1=require("./core"),fs_1=__importDefault(require("fs")),path_1=__importDefault(require("path"));class Admin extends core_1.CoreHtmlView{constructor(e,s){super(e,s),this.init()}init(){!0===this.adminConnection?this.adminHtml():this.adminLogin("admin")}adminHtml(){let i=configuration_1.config.getInfosForAll(this.ctx);var e=this.ctx.header.referer?.split("/"),e=(e&&(e[e.length-1]="service"),{addUrl:e?.join("/"),services:i,versions:models_1.models.listVersion().reverse().map(e=>e.replace("_",".")),extensions:(0,enums_1.enumKeys)(enums_1.EExtensions).filter(e=>!["file","base"].includes(e)),options:(0,enums_1.enumKeys)(enums_1.EOptions),logsFiles:paths_1.paths.logFile.list()});let s=e=>e.replace(".min",""),t=(this._HTMLResult=fs_1.default.readFileSync(path_1.default.resolve(__dirname,"../html/","admin.html")).toString().replace(/<link /g,"\n<link ").replace(/<script /g,"\n<script ").replace(/<\/script>/g,"<\/script>\n").replace(/\r\n/g,"\n").split("\n").map(e=>e.trim()).filter(e=>""!=e.trim()),(e,s)=>{var i=this._HTMLResult.indexOf(e);(0<i||0<(i=this._HTMLResult.indexOf((0,helpers_1.removeAllQuotes)(e))))&&(this._HTMLResult[i]=s)});(0,css_1.listaddCssFiles)().forEach(e=>{t(`<link rel="stylesheet" href="${s(e)}">`,`<style>${(0,css_1.addCssFile)(e)}</style>`)}),(0,js_1.listaddJsFiles)().forEach(e=>{t(`<script src="${s(e)}"></script>`,`<script>${(0,js_1.addJsFile)(e)}</script>`)});var n=Object.keys(i).filter(e=>e!==enums_1.EConstant.test).map(s=>`<div class="card">
                <div class="title">${s}</div>
                <button class="copy-btn" id="copy${s}" onclick="copyService('${s}')"> COPY </button>
                <div class="product">
                    <span class="service-name">${i[s].version}</span>
                    <span id="root" class="service-root" onclick="location.href = '${i[s].root}';">${i[s].root}</span>
                </div>
                <div class="description">
                    <fieldset id="options${s}">
                        <legend>Options</legend>
                        <ul class="card-list">
                            <li class="card-list-item icon-${i[s].service.options.includes(enums_1.EOptions.canDrop)?"yes":"no"}">canDrop</li>
                            <li class="card-list-item icon-${i[s].service.options.includes(enums_1.EOptions.forceHttps)?"yes":"no"}">forceHttps</li>
                            <li class="card-list-item icon-${i[s].service.options.includes(enums_1.EOptions.stripNull)?"yes":"no"}">stripNull</li>
                            <li class="card-list-item icon-${i[s].service.options.includes(enums_1.EOptions.unique)?"yes":"no"}">unique</li>
                        </ul>
                    </fieldset>
    
                    <select id="infos${s}" size="5">
                        ${i[s].service.extensions.map(e=>`<option value="${e}">${e}</option>`).join("\n")}
                    </select>
    
                </div>
                <ul class="list" id="list${s}">
                ${Object.keys(i[s].stats).map(e=>`<li>${e} : ${i[s].stats[e]}</li>`).join("")}
                </ul>
                <div class="description">
                    <span class="page" onclick="editPage('${s}', this)">${i[s].service.nb_page}</span>
                    <span class="csv" onclick="editCsv('${s}', this)">${i[s].service.csvDelimiter}</span>
                    <select class="patrom-select tabindex="1" name="marios" id="marios" onchange="selectChange('${s}', this)">
                        <option selected="selected">Services</option>
                        <option>Statistiques</option>
                        ${i[s].service.extensions.includes("users")?"<option>Users</option>":""} 
                    </select>
                </div>
                </div>`);this.replacers({cards:n.join("")}),this.replacer("_PARAMS={}","_PARAMS="+JSON.stringify(e,this.bigIntReplacer))}}exports.Admin=Admin;