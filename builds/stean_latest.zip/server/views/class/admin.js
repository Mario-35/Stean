var __importDefault=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(exports,"__esModule",{value:!0}),exports.Admin=void 0;let configuration_1=require("../../configuration"),enums_1=require("../../enums"),helpers_1=require("../../helpers"),log_1=require("../../log"),models_1=require("../../models"),paths_1=require("../../paths"),css_1=require("../css"),js_1=require("../js"),core_1=require("./core"),fs_1=__importDefault(require("fs")),path_1=__importDefault(require("path"));class Admin extends core_1.CoreHtmlView{constructor(e,s){super(e,s),this.init()}init(){!0===this.adminConnection?this.adminHtml():this.adminLogin("admin")}adminHtml(){let i=configuration_1.config.getInfosForAll(this.ctx);var e=this.ctx.header.referer?.split("/");e&&(e[e.length-1]="service");let t={addUrl:e?.join("/"),services:i,versions:models_1.models.listVersion().reverse().map(e=>e.replace("_",".")),extensions:(0,enums_1.enumKeys)(enums_1.EExtensions).filter(e=>!["file","base"].includes(e)),options:(0,enums_1.enumKeys)(enums_1.EOptions),logsFiles:paths_1.paths.logFile.list()},s=e=>e.replace(".min",""),n=(this._HTMLResult=fs_1.default.readFileSync(path_1.default.resolve(__dirname,"../html/","admin.html")).toString().replace(/<link /g,enums_1.EConstant.return+"<link ").replace(/<script /g,enums_1.EConstant.return+"<script ").replace(/<\/script>/g,"<\/script>"+enums_1.EConstant.return).replace(/\r\n/g,enums_1.EConstant.return).split(enums_1.EConstant.return).map(e=>e.trim()).filter(e=>""!=e.trim()),(e,s)=>{var i=this._HTMLResult.indexOf(e);(0<i||0<(i=this._HTMLResult.indexOf((0,helpers_1.removeAllQuotes)(e))))&&(this._HTMLResult[i]=s)});(0,css_1.listaddCssFiles)().forEach(e=>{n(`<link rel="stylesheet" href="${s(e)}">`,`<style>${(0,css_1.addCssFile)(e)}</style>`)}),(0,js_1.listaddJsFiles)().forEach(e=>{n(`<script src="${s(e)}"></script>`,`<script>${(0,js_1.addJsFile)(e)}</script>`)});e=Object.keys(i).filter(e=>e!==enums_1.EConstant.test).map(s=>`<div class="card">
                <div class="title" onclick="selectCard('${s}')">${s}</div>
                <button class="del-btn" id="del${s}" onclick="delService('${s}')"> X </button>
                <div class="product">
                    <span class="service-name">${i[s].service.apiVersion}&nbsp;:&nbsp;</span>
                    <span id="root" class="service-root" onclick="location.href = '${i[s].root}';">${i[s].root}</span>
                </div>
                <div class="description">
                    <div id="editList${s}"class="editList">
                        <textarea></textarea>
                    </div>
                    <fieldset id="options${s}">
                        <legend>Options</legend>
                        <ul class="card-list">
                        ${t.options.map(e=>`<li class="card-list-item canPoint icon-${i[s].service.options.includes(e)?"yes":"no"}" onclick="selectChange('${s}', this)">${e}</li>`).join("")}
                        </ul>
                    </fieldset>
    
                    <select id="infos${s}" size="5">
                        ${i[s].service.extensions.map(e=>`<option value="${e}">${e}</option>`).join(enums_1.EConstant.return)}
                    </select>
    
                </div>
                <div class="description">
                    <span class="service-name">csv delimiter:</span>
                    <span class="csv canPoint" onclick="editCsv('${s}', this)">${i[s].service.csvDelimiter}</span>
                    <select class="patrom-select tabindex="1" onchange="selectChange('${s}', this)">
                        <option selected="selected">Services</option>                        
                        ${i[s].service.extensions.includes("users")&&i[s].service.users?"<option>Users</option>":""} 
                        ${i[s].service.extensions.includes("lora")?"<option>Loras</option>":""} 
                        ${i[s].service.extensions.includes("lora")?"<option>Synonyms</option>":""} 
                    </select>
                </div>


                <div class="description">
                    <span class="service-name">items per page :</span>
                    <span class="page canPoint" onclick="editPage('${s}', this)">${i[s].service.nb_page}</span>
                </div>
                <div class="description">
                    <span class="service-name">point per graph :</span>
                    <span class="page canPoint" onclick="editGraph('${s}', this)">${i[s].service.nb_graph}</span>
                </div>







                </div>`);this.replacers({cards:e.join("")}),this.replacer("_PARAMS={}","_PARAMS="+JSON.stringify(t,this.bigIntReplacer))}}exports.Admin=Admin;