Object.defineProperty(exports,"__esModule",{value:!0}),exports.HtmlError=void 0;let log_1=require("../../log"),core_1=require("./core");class HtmlError extends core_1.CoreHtmlView{constructor(r,e){super(r,e),this.error(e.url)}error(r){this._HTMLResult=[`
        <!DOCTYPE html>
            <html>
                ${this.head("Error")}
                <body>
                    <div class="login-wrap">
                        <div class="login-html">
                            ${this.title("Error")}
                            <h1>Error.</h1>
                            <div class="hr">
                            </div>
                            <h3>On error page</h3> <h3>${r}</h3>
                            ${this.hr()}
                            <div id="outer">
                                <div class="inner">
                                    <a href="/Login" class="button-submit">Login</a>
                                </div>
                                <div class="inner">
                                    <a  href="${this.ctx.decodedUrl.linkbase+`/${this.ctx.service.apiVersion}/Query`}" class="button">query</a>
                                </div>
                            </div>
                        </div>
                    </body>
                </html>`]}}exports.HtmlError=HtmlError;