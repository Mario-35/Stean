"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Core = void 0;
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
class Core {
    _;
    cast;
    constructor(dataType, cast) {
        this._ = {
            dataType: dataType,
            create: `${enums_1.EDataType[dataType.toString()]}@NULL@@UNIQUE@@DEFAULT@`.toUpperCase(),
            alias(options) {
                return (0, helpers_1.doubleQuotes)(options.columnName);
            }
        };
        this.cast = cast;
    }
    coalesce(input) {
        this._.coalesce = input;
        return this;
    }
    defaultOrder(input) {
        this._.orderBy = input;
        return this;
    }
    column() {
        this._.create = this._.create.replace("@DEFAULT@", "").replace("@NULL@", "").replace("@UNIQUE@", "");
        return this._;
    }
    notNull() {
        this._.create = this._.create.replace("@NULL@", " NOT NULL");
        return this;
    }
    unique() {
        this._.create = this._.create.replace("@UNIQUE@", " UNIQUE");
        return this;
    }
    default(input) {
        if (typeof input === "number")
            input = String(input);
        this._.create = this._.create.replace("@DEFAULT@", input.trim() !== "" ? ` DEFAULT '${input.trim()}'${this.cast ? `::${this.cast}` : ""}` : "");
        this._.verify = {
            list: [],
            default: input.trim()
        };
        return this;
    }
    relation(input) {
        this._.entityRelation = input.trim();
        return this;
    }
}
exports.Core = Core;
