"use strict";
/**
 * formatColumnValue
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatColumnValue = formatColumnValue;
const constants_1 = require("../../constants");
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const log_1 = require("../../log");
/**
 *
 * @param columnName string
 * @param value
 * @param type
 * @returns string or undefined
 */
function formatColumnValue(columnName, value, column) {
    const idLink = (value) => {
        return value.hasOwnProperty(enums_1.EConstant.name)
            ? `(SELECT "id" FROM "${columnName.split("_")[0]}" WHERE "name" = '${(0, constants_1.ESCAPE_SIMPLE_QUOTE)(value[enums_1.EConstant.name])}')`
            : value.hasOwnProperty(enums_1.EConstant.id)
                ? value[enums_1.EConstant.id]
                : (0, helpers_1.removeFirstAndEnd)(value, "@");
    };
    console.log(log_1.log.debug_head(`${columnName} [${column.dataType}] ==> ${value}`));
    if (value)
        switch (value) {
            case void 0:
                return "";
            case null:
                return "null";
            case value.isRawInstance:
                return value.toQuery();
            default:
                switch (column.dataType) {
                    case enums_1.EDataType.bigint:
                        return isNaN(value) ? idLink(value) : value;
                    case enums_1.EDataType.bool:
                        if (value === "false")
                            value = 0;
                        return `'${value ? 1 : 0}'`;
                    case enums_1.EDataType.json:
                    case enums_1.EDataType.jsonb:
                        return (0, helpers_1.simpleQuotesString)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(JSON.stringify(value)));
                    case enums_1.EDataType._text:
                        return (0, helpers_1.isString)(value) ? (0, helpers_1.simpleQuotesString)(value) : (0, helpers_1.simpleQuotesString)(`{${value.map((e) => (0, helpers_1.doubleQuotes)((0, helpers_1.removeFirstEndSimpleQuotes)(e))).join(",")}}`);
                    case enums_1.EDataType.any:
                        return (0, helpers_1.simpleQuotesString)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(JSON.stringify(value)));
                    case enums_1.EDataType.date:
                    case enums_1.EDataType.time:
                    case enums_1.EDataType.timestamp:
                    case enums_1.EDataType.timestamptz:
                        return (0, helpers_1.simpleQuotesString)(value);
                    case enums_1.EDataType.link:
                        return idLink(value);
                    case enums_1.EDataType.text:
                        try {
                            return value.includes("'") ? (0, helpers_1.simpleQuotesString)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(value)) : (0, helpers_1.simpleQuotesString)(value);
                        }
                        catch (error) {
                            return (0, helpers_1.simpleQuotesString)(typeof value === "object" ? JSON.stringify(value) : value);
                        }
                    default:
                        process.stdout.write(`====[ERROR]=========${column.dataType}] ===============` + enums_1.EConstant.return);
                        break;
                }
                if (String(value).startsWith("(SELECT"))
                    return `${value}`;
                try {
                    return value.includes("'") ? (0, helpers_1.simpleQuotesString)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(value)) : (0, helpers_1.simpleQuotesString)(value);
                }
                catch (error) {
                    return (0, helpers_1.simpleQuotesString)(value);
                }
        }
}
