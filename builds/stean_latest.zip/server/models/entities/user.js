"use strict";
/**
 * entity User.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.USER = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.USER = new entity_1.Entity("Users", {
    createOrder: -1,
    type: enums_1.EentityType.table,
    order: 21,
    columns: {
        id: new types_1.Bigint().generated().column(),
        username: new types_1.Text().notNull().unique().defaultOrder("asc").column(),
        email: new types_1.Text().column(),
        password: new types_1.Text().column(),
        database: new types_1.Text().column(),
        canPost: new types_1.Bool().column(),
        canDelete: new types_1.Bool().column(),
        canCreateUser: new types_1.Bool().column(),
        canCreateDb: new types_1.Bool().column(),
        admin: new types_1.Bool().column(),
        superAdmin: new types_1.Bool().column()
    },
    relations: {}
});
