"use strict";
/**
 * createDefaultContext
 *
 * @copyright 2022-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDefaultContext = createDefaultContext;
const enums_1 = require("../../../enums");
function createDefaultContext(def) {
    return {
        target: def || enums_1.EQuery.Where,
        key: undefined,
        entity: undefined,
        table: undefined,
        identifier: undefined,
        relation: undefined,
        literal: undefined,
        sign: undefined,
        sql: undefined,
        onEachResult: undefined,
        in: undefined
    };
}
