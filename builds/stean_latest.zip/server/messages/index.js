"use strict";
/**
 * Index messages
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorMessage = exports.getErrorCode = exports.infos = exports.info = exports.errors = exports.msg = void 0;
const enums_1 = require("../enums");
const error_json_1 = __importDefault(require("./error.json"));
const infos_json_1 = __importDefault(require("./infos.json"));
const msg = (...args) => {
    for (let i = 1; i < args.length; i++)
        args[0] = args[0].replace(`$${i}`, args[i]);
    return args[0];
};
exports.msg = msg;
exports.errors = error_json_1.default;
exports.info = infos_json_1.default;
const infos = (input) => input.map((e) => exports.info[e]).join(" ");
exports.infos = infos;
const getErrorCode = (err, actual) => {
    if (err["where"] && err["where"].includes("verifyid"))
        return 404 /* EHttpCode.notFound */;
    return actual;
};
exports.getErrorCode = getErrorCode;
const errorMessage = (message) => process.stdout.write(`${(0, enums_1.color)(31 /* EColor.Red */)} ------ERROR------${message} ${(0, enums_1.color)(0 /* EColor.Reset */)}` + enums_1.EConstant.return);
exports.errorMessage = errorMessage;
