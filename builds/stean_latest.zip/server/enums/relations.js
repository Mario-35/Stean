"use strict";
/**
 * relations Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ERelations = void 0;
var ERelations;
(function (ERelations) {
    ERelations[ERelations["nop"] = 0] = "nop";
    ERelations[ERelations["defaultUnique"] = 1] = "defaultUnique";
    ERelations[ERelations["belongsTo"] = 2] = "belongsTo";
    ERelations[ERelations["belongsToMany"] = 3] = "belongsToMany";
    ERelations[ERelations["hasMany"] = 4] = "hasMany";
    ERelations[ERelations["hasOne"] = 5] = "hasOne"; // adds a foreign key to the target and singular association.
})(ERelations || (exports.ERelations = ERelations = {}));
