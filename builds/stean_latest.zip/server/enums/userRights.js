"use strict";
/**
 * userRights Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EUserRights = void 0;
var EUserRights;
(function (EUserRights) {
    EUserRights[EUserRights["Post"] = 0] = "Post";
    EUserRights[EUserRights["Delete"] = 1] = "Delete";
    EUserRights[EUserRights["Create"] = 2] = "Create";
    EUserRights[EUserRights["UserCreate"] = 3] = "UserCreate";
    EUserRights[EUserRights["Admin"] = 4] = "Admin";
    EUserRights[EUserRights["SuperAdmin"] = 5] = "SuperAdmin";
})(EUserRights || (exports.EUserRights = EUserRights = {}));
