"use strict";
/**
 * observationType Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EObservationType = void 0;
var EObservationType;
(function (EObservationType) {
    EObservationType["http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_CategoryObservation"] = "_resulttext";
    EObservationType["http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_CountObservation"] = "number";
    EObservationType["http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement"] = "number";
    EObservationType["http://www.opengis.net/def/observation-type/ogc-om/2.0/om_complex-observation"] = "array";
    EObservationType["http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Observation"] = "any";
    EObservationType["http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_TruthObservation"] = "_resultBoolean";
    EObservationType["http://www.opengis.net/def/observation-type/ogc-omxml/2.0/swe-array-observation"] = "object";
})(EObservationType || (exports.EObservationType = EObservationType = {}));
