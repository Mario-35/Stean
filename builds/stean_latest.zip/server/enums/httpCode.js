"use strict";
/**
 * http ccde Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EHttpCode = void 0;
var EHttpCode;
(function (EHttpCode) {
    EHttpCode[EHttpCode["ok"] = 200] = "ok";
    EHttpCode[EHttpCode["created"] = 201] = "created";
    EHttpCode[EHttpCode["noContent"] = 204] = "noContent";
    EHttpCode[EHttpCode["badRequest"] = 400] = "badRequest";
    EHttpCode[EHttpCode["Unauthorized"] = 401] = "Unauthorized";
    EHttpCode[EHttpCode["refused"] = 403] = "refused";
    EHttpCode[EHttpCode["notFound"] = 404] = "notFound";
    EHttpCode[EHttpCode["conflict"] = 409] = "conflict";
    EHttpCode[EHttpCode["internalServerError"] = 500] = "internalServerError";
    EHttpCode[EHttpCode["serverNotRespond"] = 504] = "serverNotRespond";
    EHttpCode[EHttpCode["redirectionPerm"] = 301] = "redirectionPerm";
    EHttpCode[EHttpCode["redirectionTemp"] = 302] = "redirectionTemp";
})(EHttpCode || (exports.EHttpCode = EHttpCode = {}));
