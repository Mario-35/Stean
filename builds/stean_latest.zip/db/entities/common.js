"use strict";
/**
 * Common class entity
 *f
 * @copyright 2020-present Inrae
 * @review 29-01-2024
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Common = void 0;
const index_1 = require("../../helpers/index");
const helpers_1 = require("../helpers");
const messages_1 = require("../../messages");
const log_1 = require("../../log");
const configuration_1 = require("../../configuration");
const enums_1 = require("../../enums");
const queries_1 = require("../queries");
const lora_1 = require("../../lora");
// Common class
class Common {
    ctx;
    nextLinkBase;
    linkBase;
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        this.ctx = ctx;
        this.nextLinkBase = (0, helpers_1.removeKeyFromUrl)(`${this.ctx.decodedUrl.root}/${this.ctx.href.split(`${ctx.service.apiVersion}/`)[1]}`, ["top", "skip"]);
        this.linkBase = `${this.ctx.decodedUrl.root}/${this.constructor.name}`;
    }
    // Get a key value
    getKeyValue(input, key) {
        let result = undefined;
        if (input[key]) {
            result = input[key][enums_1.EConstant.id] ? input[key][enums_1.EConstant.id] : input[key];
            delete input[key];
        }
        return result;
    }
    // Get a list of key values
    getKeysValue(input, keys) {
        keys.forEach((key) => {
            const temp = this.getKeyValue(input, key);
            if (temp)
                return temp;
        });
        return undefined;
    }
    // Only for override
    formatDataInput(input) {
        return input;
    }
    // create a blank ReturnResult
    formatReturnResult(args) {
        console.log(log_1.log.whereIam());
        return {
            ...{
                id: undefined,
                selfLink: args.body && typeof args.body === 'object' ? args.body['@iot.selfLink'] : undefined,
                nextLink: args.nextLink ? args.nextLink : undefined,
                prevLink: args.prevLink ? args.prevLink : undefined,
                body: undefined,
                total: undefined,
            },
            ...args,
        };
    }
    // Create the nextLink
    nextLink = (resLength) => {
        if (this.ctx.odata.limit < 1)
            return;
        const max = this.ctx.odata.limit > 0
            ? +this.ctx.odata.limit
            : +this.ctx.service.nb_page;
        if (resLength >= max)
            return `${encodeURI(this.nextLinkBase)}${this.nextLinkBase.includes("?") ? "&" : "?"}$top=${this.ctx.odata.limit}&$skip=${this.ctx.odata.skip + this.ctx.odata.limit}`;
    };
    // Create the prevLink
    prevLink = (resLength) => {
        if (this.ctx.odata.limit < 1)
            return;
        const prev = this.ctx.odata.skip - this.ctx.odata.limit;
        if (((this.ctx.service.nb_page && resLength >= this.ctx.service.nb_page) || this.ctx.odata.limit) && prev >= 0)
            return `${encodeURI(this.nextLinkBase)}${this.nextLinkBase.includes("?") ? "&" : "?"}$top=${this.ctx.odata.limit}&$skip=${prev}`;
    };
    // Return all items
    async getAll() {
        console.log(log_1.log.whereIam());
        // create query
        let sql = this.ctx.odata.getSql();
        if (this.ctx.odata.replay === true)
            await (0, lora_1.replayLoraLogs)(this.ctx, sql);
        // Return results
        if (sql) {
            switch (this.ctx.odata.returnFormat) {
                case index_1.returnFormats.sql:
                    return this.formatReturnResult({ body: sql });
                case index_1.returnFormats.csv:
                    sql = (0, queries_1.asCsv)(sql, this.ctx.service.csvDelimiter);
                    configuration_1.config.writeLog(log_1.log.query(sql));
                    this.ctx.attachment(`${this.ctx.odata.entity?.name || "export"}.csv`);
                    return this.formatReturnResult({ body: await configuration_1.config
                            .connection(this.ctx.service.name)
                            .unsafe(sql)
                            .readable() });
                default:
                    return await configuration_1.config.executeSqlValues(this.ctx.service, sql).then(async (res) => {
                        return (res[0] > 0)
                            ? this.formatReturnResult({
                                id: isNaN(res[0][0]) ? undefined : +res[0],
                                nextLink: this.nextLink(res[0]),
                                prevLink: this.prevLink(res[0]),
                                body: res[1],
                            })
                            : this.formatReturnResult({ body: res[0] == 0 ? [] : res[0] });
                    }).catch((err) => this.ctx.throw(400 /* EHttpCode.badRequest */, { code: 400 /* EHttpCode.badRequest */, detail: err.message }));
            }
        }
    }
    // Return one item
    async getSingle() {
        console.log(log_1.log.whereIam());
        // create query
        const sql = this.ctx.odata.getSql();
        // Return results
        if (sql)
            switch (this.ctx.odata.returnFormat) {
                case index_1.returnFormats.sql:
                    return this.formatReturnResult({ body: sql });
                case index_1.returnFormats.GeoJSON:
                    return await configuration_1.config.executeSqlValues(this.ctx.service, sql).then((res) => {
                        return this.formatReturnResult({ body: res[0] });
                    });
                default:
                    return await configuration_1.config.executeSqlValues(this.ctx.service, sql).then((res) => {
                        if (this.ctx.odata.query.select && this.ctx.odata.onlyValue === true) {
                            const temp = res[this.ctx.odata.query.select[0] == "id" ? enums_1.EConstant.id : 0];
                            if (typeof temp === "object") {
                                this.ctx.odata.returnFormat = index_1.returnFormats.json;
                                return this.formatReturnResult({ body: temp });
                            }
                            else
                                return this.formatReturnResult({ body: String(temp), });
                        }
                        return this.formatReturnResult({
                            id: isNaN(res[0]) ? undefined : +res[0],
                            nextLink: this.nextLink(res[0]),
                            prevLink: this.prevLink(res[0]),
                            body: this.ctx.odata.single === true ? res[1][0] : { value: res[1] },
                        });
                    }).catch((err) => this.ctx.throw(400 /* EHttpCode.badRequest */, { code: 400 /* EHttpCode.badRequest */, detail: err }));
            }
    }
    // Execute multilines SQL in one query
    async addWultipleLines(dataInput) {
        console.log(log_1.log.whereIam());
        process.stdout.write("***********************************************************************************************************" + "\n");
        // stop save to log cause if datainput too big 
        if (this.ctx.log)
            this.ctx.log.datas = { datas: messages_1.info.MultilinesNotSaved };
        // create queries
        const sqls = Object(dataInput).map((datas) => {
            const modifiedDatas = this.formatDataInput(datas);
            if (modifiedDatas) {
                const sql = this.ctx.odata.postSql(modifiedDatas);
                if (sql)
                    return sql;
            }
        });
        // return results
        const results = [];
        // execute query
        await configuration_1.config.executeSqlValues(this.ctx.service, sqls.join(";")).then((res) => results.push(res[0]))
            .catch((error) => {
            console.log(error);
            this.ctx.throw(400 /* EHttpCode.badRequest */, { code: 400 /* EHttpCode.badRequest */, detail: error["detail"] });
        });
        // Return results
        return this.formatReturnResult({
            body: results,
        });
    }
    // Post an item
    async post(dataInput) {
        console.log(log_1.log.whereIam());
        // Format datas
        dataInput = this.formatDataInput(dataInput);
        if (!dataInput)
            return;
        // create query
        const sql = this.ctx.odata.postSql(dataInput);
        // Return results
        if (sql)
            switch (this.ctx.odata.returnFormat) {
                case index_1.returnFormats.sql:
                    return this.formatReturnResult({ body: sql });
                default:
                    return await configuration_1.config.executeSqlValues(this.ctx.service, sql)
                        .then((res) => {
                        if (res[0]) {
                            if (res[0].duplicate)
                                this.ctx.throw(409 /* EHttpCode.conflict */, {
                                    code: 409 /* EHttpCode.conflict */,
                                    detail: `${this.constructor.name} already exist`,
                                    link: `${this.linkBase}(${[res[0].duplicate]})`,
                                });
                            return this.formatReturnResult({
                                body: res[0][0],
                                query: sql,
                            });
                        }
                    })
                        .catch((err) => {
                        const code = (0, messages_1.getErrorCode)(err, 400);
                        this.ctx.throw(code, { code: code, detail: err.message });
                    });
            }
    }
    // Update an item
    async update(idInput, dataInput) {
        console.log(log_1.log.whereIam());
        // Format datas
        dataInput = this.formatDataInput(dataInput);
        if (!dataInput)
            return;
        // create Query
        const sql = this.ctx.odata.patchSql(dataInput);
        // Return results
        if (sql)
            switch (this.ctx.odata.returnFormat) {
                case index_1.returnFormats.sql:
                    return this.formatReturnResult({ body: sql });
                default:
                    return await configuration_1.config.executeSqlValues(this.ctx.service, sql)
                        .then((res) => {
                        if (res[0]) {
                            return this.formatReturnResult({
                                body: res[0][0],
                                query: sql,
                            });
                        }
                    })
                        .catch((err) => {
                        const code = (0, messages_1.getErrorCode)(err, 400);
                        this.ctx.throw(code, { code: code, detail: err.message });
                    });
            }
    }
    // Delete an item
    async delete(idInput) {
        console.log(log_1.log.whereIam());
        // create Query
        const sql = `DELETE FROM ${(0, index_1.doubleQuotesString)(this.ctx.model[this.constructor.name].table)} WHERE "id" = ${idInput} RETURNING id`;
        // Return results
        if (sql)
            switch (this.ctx.odata.returnFormat) {
                case index_1.returnFormats.sql:
                    return this.formatReturnResult({ body: sql });
                default:
                    return this.formatReturnResult({ id: await configuration_1.config.executeSqlValues(this.ctx.service, sql).then((res) => res[0]).catch(() => BigInt(0)) });
            }
    }
}
exports.Common = Common;
