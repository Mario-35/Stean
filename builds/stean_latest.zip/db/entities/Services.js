"use strict";
/**
 * Services entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Services = void 0;
const common_1 = require("./common");
const configuration_1 = require("../../configuration");
const helpers_1 = require("../../helpers");
const helpers_2 = require("../helpers");
const authentication_1 = require("../../authentication");
const log_1 = require("../../log");
const enums_1 = require("../../enums");
class Services extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    // Override Get All serwices
    async getAll() {
        console.log(log_1.log.whereIam());
        let can = (0, authentication_1.userAuthenticated)(this.ctx);
        if (can) {
            can = (this.ctx.user.PDCUAS[4] === true);
            if (this.ctx.user.PDCUAS[5] === true)
                can = true;
        }
        // Return result If not authorised    
        if (!can)
            return this.formatReturnResult({
                body: (0, helpers_1.hidePassword)(configuration_1.config.getService(this.ctx.service.name))
            });
        // Return result
        return this.formatReturnResult({
            body: (0, helpers_1.hidePassword)(configuration_1.config.getServicesNames().map((elem) => ({
                [elem]: { ...configuration_1.config.getService(elem) }
            })))
        });
    }
    // Override Get One serwice
    async getSingle() {
        console.log(log_1.log.whereIam());
        // Return result If not authorised
        if (!(0, authentication_1.userAuthenticated)(this.ctx))
            this.ctx.throw(401 /* EHttpCode.Unauthorized */);
        // Return result
        return this.formatReturnResult({
            body: (0, helpers_1.hideKeysInJson)(configuration_1.config.getService(typeof this.ctx.odata.id === "string" ? this.ctx.odata.id : this.ctx.service.name), ["entities"]),
        });
    }
    // Override Post service
    async post(dataInput) {
        console.log(log_1.log.whereIam());
        if (!this.ctx.service.extensions.includes(enums_1.EExtensions.users))
            this.ctx.throw(401 /* EHttpCode.Unauthorized */);
        if (dataInput && dataInput["create"] && dataInput["create"]["name"]) {
            return this.formatReturnResult({
                body: await (0, helpers_2.createService)(this.ctx, dataInput),
            });
        }
        if (!(0, authentication_1.userAuthenticated)(this.ctx))
            this.ctx.throw(401 /* EHttpCode.Unauthorized */);
        if (dataInput) {
            const added = await configuration_1.config.addConfig(dataInput);
            if (added)
                return this.formatReturnResult({
                    body: (0, helpers_1.hidePassword)(added),
                });
        }
    }
    // Override Update service
    async update(idInput, dataInput) {
        console.log(log_1.log.whereIam());
        // This function not exists
        return;
    }
    // Override Delete service
    async delete(idInput) {
        console.log(log_1.log.whereIam(idInput));
        // This function not exists
        return;
    }
}
exports.Services = Services;
