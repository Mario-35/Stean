"use strict";
/**
 * Observations entity.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Observations = void 0;
const common_1 = require("./common");
const helpers_1 = require("../helpers");
const helpers_2 = require("../../helpers");
const messages_1 = require("../../messages");
const queries_1 = require("../queries");
const enums_1 = require("../../enums");
const log_1 = require("../../log");
const configuration_1 = require("../../configuration");
class Observations extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    // Prepare odservations 
    async prepareInputResult(dataInput) {
        console.log(log_1.log.whereIam());
        // IF MultiDatastream
        if ((dataInput["MultiDatastream"] && dataInput["MultiDatastream"] != null) || (this.ctx.odata.parentEntity && this.ctx.odata.parentEntity.name.startsWith("MultiDatastream"))) {
            // get MultiDatastream search ID
            const searchID = dataInput["MultiDatastream"] && dataInput["MultiDatastream"] != null
                ? BigInt(dataInput["MultiDatastream"][enums_1.EConstant.id])
                : (0, helpers_2.getBigIntFromString)(this.ctx.odata.parentId);
            if (!searchID)
                this.ctx.throw(404 /* EHttpCode.notFound */, { code: 404 /* EHttpCode.notFound */, detail: (0, messages_1.msg)(messages_1.errors.noFound, "MultiDatastreams"), });
            // Search id keys
            const tempSql = await configuration_1.config.executeSqlValues(this.ctx.service, (0, queries_1.multiDatastreamsUnitsKeys)(searchID));
            if (tempSql[0] === null)
                this.ctx.throw(404 /* EHttpCode.notFound */, { code: 404 /* EHttpCode.notFound */, detail: (0, messages_1.msg)(messages_1.errors.noFound, "MultiDatastreams"), });
            const multiDatastream = tempSql[0];
            if (dataInput["result"] && typeof dataInput["result"] == "object") {
                console.log(log_1.log.debug_infos("result : keys", `${Object.keys(dataInput["result"]).length} : ${multiDatastream.length}`));
                if (Object.keys(dataInput["result"]).length != multiDatastream.length) {
                    this.ctx.throw(400 /* EHttpCode.badRequest */, {
                        code: 400 /* EHttpCode.badRequest */,
                        detail: (0, messages_1.msg)(messages_1.errors.sizeResultUnitOfMeasurements, String(Object.keys(dataInput["result"]).length), multiDatastream.length),
                    });
                }
                dataInput["result"] = { value: Object.values(dataInput["result"]), valueskeys: dataInput["result"], };
            }
        } // IF Datastream
        else if ((dataInput["Datastream"] && dataInput["Datastream"] != null) || (this.ctx.odata.parentEntity && this.ctx.odata.parentEntity.name.startsWith("Datastream"))) {
            if (dataInput["result"] && typeof dataInput["result"] != "object")
                dataInput["result"] = this.ctx.service.extensions.includes(enums_1.EExtensions.resultNumeric)
                    ? dataInput["result"]
                    : { value: dataInput["result"] };
            // if no stream go out with error
        }
        else if (this.ctx.request.method === "POST") {
            this.ctx.throw(404 /* EHttpCode.notFound */, { code: 404 /* EHttpCode.notFound */, detail: messages_1.errors.noStream });
        }
        return dataInput;
    }
    formatDataInput(input) {
        console.log(log_1.log.whereIam());
        if (input)
            if (!input["resultTime"] && input["phenomenonTime"])
                input["resultTime"] = input["phenomenonTime"];
        return input;
    }
    // Override post to prepare datas before use super class
    async post(dataInput) {
        console.log(log_1.log.whereIam());
        if (dataInput)
            dataInput = await this.prepareInputResult(dataInput);
        if (dataInput["import"]) {
        }
        else
            return await super.post(dataInput);
    }
    // Override update to prepare datas before use super class
    async update(idInput, dataInput) {
        console.log(log_1.log.whereIam());
        if (dataInput)
            dataInput = await this.prepareInputResult(dataInput);
        if (dataInput)
            dataInput["validTime"] = await (0, helpers_1.getDBDateNow)(this.ctx.service);
        if (dataInput && dataInput["resultQuality"] && dataInput["resultQuality"]["nameOfMeasure"]) {
            dataInput["result"] = { quality: dataInput["result"] };
        }
        return await super.update(idInput, dataInput);
    }
}
exports.Observations = Observations;
