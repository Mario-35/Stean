Object.defineProperty(exports,"__esModule",{value:!0}),exports.createIndexes=void 0;let configuration_1=require("../../configuration"),enums_1=require("../../enums"),helpers_1=require("../../helpers"),log_1=require("../../log"),createIndexes=e=>{var a=[`WITH datastreams AS (
        select distinct "datastream_id" AS id from observation
        ),
        datas AS (
            SELECT 
                "datastream_id" AS id,
                min("phenomenonTime") AS pmin ,
                max("phenomenonTime") AS pmax,
                min("resultTime") AS rmin,
                max("resultTime") AS rmax
            FROM observation, datastreams where  "datastream_id" = datastreams.id group by "datastream_id"
        )
        UPDATE "datastream" SET 
            "_phenomenonTimeStart" =  datas.pmin ,
            "_phenomenonTimeEnd" = datas.pmax,
            "_resultTimeStart" = datas.rmin,
            "_resultTimeEnd" = datas.rmax
        FROM datas where "datastream".id = datas.id`];configuration_1.config.getConfig(e).extensions.includes(enums_1.EExtensions.multiDatastream)&&a.push(`WITH multidatastreams AS (
                select distinct "multidatastream_id" AS id from observation
            ),
            datas AS (
                SELECT 
                    "multidatastream_id" AS id,
                    min("phenomenonTime") AS pmin ,
                    max("phenomenonTime") AS pmax,
                    min("resultTime") AS rmin,
                    max("resultTime") AS rmax
                FROM observation, multidatastreams where "multidatastream_id" = multidatastreams.id group by "multidatastream_id"
            )
            UPDATE "multidatastream" SET 
                "_phenomenonTimeStart" =  datas.pmin ,
                "_phenomenonTimeEnd" = datas.pmax,
                "_resultTimeStart" = datas.rmin,
                "_resultTimeEnd" = datas.rmax
            FROM datas where "multidatastream".id = datas.id`),(async(a,e)=>(await(0,helpers_1.asyncForEach)(e,async e=>{await configuration_1.config.connection(a).unsafe(e).catch(e=>!1)}),log_1.log.create(`Indexes : [${a}]`,"✔️️")))(e,a)};exports.createIndexes=createIndexes;