"use strict";
/**
 * addToService
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addToService = void 0;
const helpers_1 = require("../../helpers");
const log_1 = require("../../log");
const models_1 = require("../../models");
const entities_1 = require("../../models/entities");
const helpers_2 = require("../../models/helpers");
const helper_1 = require("../../odata/visitor/helper");
const dataAccess_1 = require("../dataAccess");
const executeSqlValues_1 = require("./executeSqlValues");
const addToService = async (ctx, dataInput) => {
    console.log(log_1.log.whereIam());
    const results = {};
    const temp = (0, helper_1.blankRootPgVisitor)(ctx, entities_1.LORA);
    if (temp) {
        ctx.odata = temp;
        const objectAccess = new dataAccess_1.apiAccess(ctx);
        await (0, helpers_1.asyncForEach)(dataInput["value"], async (line) => {
            if (line["payload"] != "000000000000000000")
                try {
                    const datas = line["value"]
                        ? { "timestamp": line["phenomenonTime"], "value": line["value"], "deveui": line["deveui"].toUpperCase() }
                        : { "timestamp": line["phenomenonTime"], "frame": line["payload"].toUpperCase(), "deveui": line["deveui"].toUpperCase() };
                    await objectAccess.post(datas);
                }
                catch (error) {
                    const datas = {
                        method: "PAYLOADS",
                        code: error["code"] ? +error["code"] : +ctx.response.status,
                        url: "/Loras",
                        database: ctx.service.pg.database,
                        datas: line,
                        user_id: String(ctx.user.id),
                        error: error
                    };
                    await (0, executeSqlValues_1.executeSqlValues)(ctx.service, `INSERT INTO ${(0, helpers_1.doubleQuotesString)(models_1.models.DBFull(ctx.service).Logs.table)} ${(0, helpers_2.createInsertValues)(ctx, datas, models_1.models.DBFull(ctx.service).Logs.name)} returning id`);
                }
        });
    }
    return results;
};
exports.addToService = addToService;
