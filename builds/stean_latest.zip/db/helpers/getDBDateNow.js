"use strict";
/**
 * getDBDateNow
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDBDateNow = void 0;
const configuration_1 = require("../../configuration");
const getDBDateNow = async (service) => await configuration_1.config.executeSqlValues(service, "SELECT current_timestamp;").then((res) => res[0]);
exports.getDBDateNow = getDBDateNow;
