Object.defineProperty(exports,"__esModule",{value:!0}),exports.queryInsertFromCsv=queryInsertFromCsv;let _1=require("."),log_1=require("../../log");async function queryInsertFromCsv(a,l){let u=await(0,_1.columnsNameFromHydrasCsv)(l);if(u){var e=await(0,_1.streamCsvFile)(a,l,u);if(0<e){let r=l.filename.split("/").reverse()[0],o=(new Date).toLocaleString(),s=[];return Object.keys(l.columns).forEach((e,t)=>{e=l.columns[e];s.push(`INSERT INTO "${a.model.Observations.table}" 
          ("${e.stream.type?.toLowerCase()}_id", "featureofinterest_id", "phenomenonTime", "resultTime", "result", "resultQuality")
            SELECT 
            ${e.stream.id}, 
            ${e.stream.FoId},  
            ${u.dateSql}, 
            ${u.dateSql},
            json_build_object('value', 
            CASE "${l.tempTable}".value${e.column}
              WHEN '---' THEN NULL 
              ELSE CAST(REPLACE(value${e.column},',','.') AS float) 
            END),
            '{"import": "${r}","date": "${o}"}'  
           FROM "${l.tempTable}" ON CONFLICT DO NOTHING returning 1`)}),{count:e,query:s}}}}