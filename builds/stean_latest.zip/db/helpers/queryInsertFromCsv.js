Object.defineProperty(exports,"__esModule",{value:!0}),exports.queryInsertFromCsv=queryInsertFromCsv;let _1=require("."),log_1=require("../../log");async function queryInsertFromCsv(s,l){let u=await(0,_1.columnsNameFromHydrasCsv)(l);if(u){var e=await(0,_1.streamCsvFile)(s,l,u);if((0,_1.curation)(s,l,u),0<e){let r=l.filename.split("/").reverse()[0],o=(new Date).toLocaleString(),a=[];return Object.keys(l.columns).forEach((e,t)=>{e=l.columns[e];a.push(`INSERT INTO "${s.model.Observations.table}" 
          ("${e.stream.type?.toLowerCase()}_id", "featureofinterest_id", "phenomenonTime", "resultTime", "result", "resultQuality")
            SELECT 
            ${e.stream.id}, 
            ${e.stream.FoId},  
            ${u.dateSql}, 
            ${u.dateSql},
            json_build_object('value', 
            CASE "${l.tempTable}".value${e.column}
              WHEN '---' THEN NULL 
              WHEN '#REF!' THEN NULL 
              ELSE CAST(REPLACE(value${e.column},',','.') AS float) 
            END),
            '{"import": "${r}","date": "${o}"}'  
           FROM "${l.tempTable}" ON CONFLICT DO NOTHING returning 1`)}),{count:e,query:a}}}}