"use strict";
/**
 * getColumnsNamesFromCsvFile
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getColumnsNamesFromCsvFile = void 0;
const fs_1 = __importDefault(require("fs"));
const readline_1 = __importDefault(require("readline"));
const log_1 = require("../../log");
const getColumnsNamesFromCsvFile = async (filename) => {
    console.log(log_1.log.whereIam());
    const fileStream = fs_1.default.createReadStream(filename);
    const rl = readline_1.default.createInterface({
        input: fileStream,
        crlfDelay: Infinity,
    });
    // Note: we use the crlfDelay option to recognize all instances of CR LF
    // ('\r\n') in filename as a single line break.
    for await (const line of rl) {
        try {
            const cols = line
                .split(";")
                .map((e) => e.replace(/\./g, "").toLowerCase());
            fileStream.destroy();
            return cols;
        }
        catch (error) {
            console.log(error);
        }
    }
};
exports.getColumnsNamesFromCsvFile = getColumnsNamesFromCsvFile;
