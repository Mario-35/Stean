Object.defineProperty(exports,"__esModule",{value:!0}),exports.asJson=void 0;let asJson=s=>""===s.query.trim()?"":`SELECT ${1==s.count?(s.fullCount?`(${s.fullCount})`:"COUNT(t)")+`,
	`:""}${s.fields?s.fields.join(",\n\t"):""}COALESCE(${!0===s.singular?"ROW_TO_JSON":`${!0===s.strip?"JSON_STRIP_NULLS(":""} JSON_AGG`}(t)${!0===s.strip?")":""}, '${!0===s.singular?"{}":"[]"}') AS results
	FROM (
	${s.query}) AS t`;exports.asJson=asJson;