Object.defineProperty(exports,"__esModule",{value:!0}),exports.datastreamUoM=void 0;let datastreamUoM=e=>`SELECT 
"unitOfMeasurement"->'name' AS keys
  FROM 
    "datastream" 
  WHERE id = ${e.parentId}
`;exports.datastreamUoM=datastreamUoM;