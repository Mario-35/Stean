Object.defineProperty(exports,"__esModule",{value:!0}),exports.asCsv=void 0,process.stdout.write("!----------------------------------- asCsv. -----------------------------------!\n");let asCsv=s=>`COPY (
  ${s}
  ) to stdout WITH (FORMAT CSV, NULL "NULL", HEADER, DELIMITER ';')`;exports.asCsv=asCsv;