Object.defineProperty(exports,"__esModule",{value:!0}),exports.asCsv=void 0;let asCsv=s=>`COPY (
  ${s}
  ) to stdout WITH (FORMAT CSV, NULL "NULL", HEADER, DELIMITER ';')`;exports.asCsv=asCsv;