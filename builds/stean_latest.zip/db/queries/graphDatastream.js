Object.defineProperty(exports,"__esModule",{value:!0}),exports.graphDatastream=void 0;let _1=require("."),helpers_1=require("../../helpers"),graphDatastream=(e,r,t)=>{var a=(0,_1.interval)(t);let s="string"==typeof r?(0,_1.createIdList)(r):[String(r)],i=t.toPgQuery();return`SELECT ( 
            SELECT 
              CONCAT( description, '|', "unitOfMeasurement" ->> 'name', '|', "unitOfMeasurement" ->> 'symbol' ) 
            FROM "${e}"
              WHERE id = ${s[0]} 
           ) AS infos, 
    STRING_AGG(concat, ',') AS datas 
    `+(1===s.length?`FROM (${a.replace("@GRAPH@",`CONCAT('[new Date("', TO_CHAR("resultTime", 'YYYY/MM/DD HH24:MI'), '"), ', result->'value' ,']')`)}) AS nop`:` FROM (
            SELECT CONCAT( '[new Date("', TO_CHAR( date, 'YYYY/MM/DD HH24:MI' ), '"), ', ${s.map((e,r)=>`coalesce(mario.res${r+1},'null'),','`)}, ']' ) 
              FROM (
                SELECT 
                  distinct COALESCE( ${s.map((e,r)=>`result${r+1}.date`).join(",")} ) AS date, 
                  ${s.map((e,r)=>`COALESCE( result${r+1}.res :: TEXT, 'null' ) AS res`+(r+1)).join(",")} FROM ${s.map((e,r)=>`${1<r+1?"FULL JOIN ":""}
                  (
                    SELECT 
                      round_minutes("resultTime", 15) as date, 
                      ${s.filter(e=>+e!==r+1).map((e,r)=>"null as res"+(r+1)).join(",")} , 
                      result -> 'value' as res 
                    FROM 
                      "observation" 
                    WHERE 
                      "observation"."id" in ( SELECT "observation"."id" from "observation" WHERE "observation"."datastream_id" = ${s[r]} ) 
                    ORDER BY ${i&&i.orderBy?" "+(0,helpers_1.cleanStringComma)(i.orderBy,["ASC","DESC"]):'"resultTime" ASC '}
                    ${t.limit?"LIMIT "+t.limit:""}
                  ) as result${r+1} `+(1<r+1?` ON result${r}.date = result${r+1}.date`:"")).join(" ")} 
              ) AS mario
          ) AS nop`)};exports.graphDatastream=graphDatastream;