Object.defineProperty(exports,"__esModule",{value:!0}),exports.graphDatastream=void 0,process.stdout.write("!----------------------------------- graphDatastream. -----------------------------------!\n");let _1=require("."),helpers_1=require("../../helpers"),graphDatastream=(e,t,r)=>{var a=(0,_1.interval)(r);let s="string"==typeof t?(0,_1.createIdList)(t):[String(t)],i=r.toPgQuery();return`SELECT ( 
            SELECT 
              CONCAT( description, '|', "unitOfMeasurement" ->> 'name', '|', "unitOfMeasurement" ->> 'symbol' ) 
            FROM "${e}"
              WHERE id = ${s[0]} 
           ) AS infos, 
    STRING_AGG(concat, ',') AS datas 
    `+(1===s.length?`FROM (${a.replace("@GRAPH@",`CONCAT('[new Date("', TO_CHAR("resultTime", 'YYYY/MM/DD HH24:MI'), '"), ', result->'value' ,']')`)}) AS nop`:` FROM (
            SELECT CONCAT( '[new Date("', TO_CHAR( date, 'YYYY/MM/DD HH24:MI' ), '"), ', ${s.map((e,t)=>`coalesce(mario.res${t+1},'null'),','`)}, ']' ) 
              FROM (
                SELECT 
                  distinct COALESCE( ${s.map((e,t)=>`result${t+1}.date`).join(",")} ) AS date, 
                  ${s.map((e,t)=>`COALESCE( result${t+1}.res :: TEXT, 'null' ) AS res`+(t+1)).join(",")} FROM ${s.map((e,t)=>`${1<t+1?"FULL JOIN ":""}
                  (
                    SELECT 
                      round_minutes("resultTime", 15) as date, 
                      ${s.filter(e=>+e!==t+1).map((e,t)=>"null as res"+(t+1)).join(",")} , 
                      result -> 'value' as res 
                    FROM 
                      "observation" 
                    WHERE 
                      "observation"."id" in ( SELECT "observation"."id" from "observation" WHERE "observation"."datastream_id" = ${s[t]} ) 
                    ORDER BY ${i&&i.orderBy?" "+(0,helpers_1.cleanStringComma)(i.orderBy,["ASC","DESC"]):'"resultTime" ASC '}
                    ${r.limit?"LIMIT "+r.limit:""}
                  ) as result${t+1} `+(1<t+1?` ON result${t}.date = result${t+1}.date`:"")).join(" ")} 
              ) AS mario
          ) AS nop`)};exports.graphDatastream=graphDatastream;