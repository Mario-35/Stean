Object.defineProperty(exports,"__esModule",{value:!0}),exports.resultKeys=void 0;let resultKeys=(e,t)=>`SELECT 
  DISTINCT JSONB_OBJECT_KEYS(${e}) AS k 
FROM 
  "observation" 
WHERE 
  JSONB_TYPEOF(${e}) LIKE 'object' 
  AND "observation"."id" IN (
    SELECT 
      "observation"."id" 
    FROM 
      "observation" 
    WHERE 
      "observation"."${t.parentEntity?.table}_id" = ${t.parentId}
  )`;exports.resultKeys=resultKeys;