"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resultKeys = void 0;
const resultKeys = (column, input) => `SELECT 
  DISTINCT JSONB_OBJECT_KEYS(${column}) AS k 
FROM 
  "observation" 
WHERE 
  JSONB_TYPEOF(${column}) LIKE 'object' 
  AND "observation"."id" IN (
    SELECT 
      "observation"."id" 
    FROM 
      "observation" 
    WHERE 
      "observation"."${input.parentEntity?.table}_id" = ${input.parentId}
  )`;
exports.resultKeys = resultKeys;
