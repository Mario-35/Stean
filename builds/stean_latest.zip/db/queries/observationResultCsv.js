Object.defineProperty(exports,"__esModule",{value:!0}),exports.observationResultCsv=void 0;let observationResultCsv=e=>`SELECT
    concat_ws(
        ' ',
        e'SELECT *,',
        string_agg(
            distinct concat(
                e'${e.replace(/[']+/g,"@")}->@', k,e'@ AS ',k
            ), ', '
        ), ' FROM "observation"'
    ) as query
from (
    SELECT jsonb_object_keys(${e}) AS k
    FROM "observation"
    WHERE jsonb_typeof(${e}) LIKE 'object'
) as generate`;exports.observationResultCsv=observationResultCsv;