"use strict";
/**
 * Api dataAccess
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.apiAccess = void 0;
const entities = __importStar(require("../entities/index"));
const helpers_1 = require("../../helpers");
const models_1 = require("../../models");
const log_1 = require("../../log");
const messages_1 = require("../../messages");
// Interface API
class apiAccess {
    myEntity;
    ctx;
    constructor(ctx, entity) {
        this.ctx = ctx;
        const entityName = entity ? models_1.models.getEntityName(this.ctx.service, entity) : this.ctx.odata.entity ? this.ctx.odata.entity.name : "none";
        console.log(log_1.log.whereIam(entityName));
        if (entityName && entityName in entities) {
            // @ts-ignore
            this.myEntity = new entities[(this.ctx, entityName)](ctx);
        }
        else
            log_1.log.error(messages_1.errors.noValidEntity, entityName);
    }
    formatDataInput(input) {
        console.log(log_1.log.whereIam());
        return this.myEntity ? this.myEntity.formatDataInput(input) : input;
    }
    async getAll() {
        console.log(log_1.log.whereIam());
        if (this.myEntity)
            return await this.myEntity.getAll();
    }
    async getSingle() {
        console.log(log_1.log.whereIam());
        if (this.myEntity)
            return await this.myEntity.getSingle();
    }
    async post(dataInput) {
        console.log(log_1.log.whereIam());
        if (this.myEntity)
            return (0, helpers_1.isArray)(this.ctx.body)
                ? await this.myEntity.addWultipleLines(dataInput || this.ctx.body)
                : await this.myEntity.post(dataInput || this.ctx.body);
    }
    async update(idInput) {
        console.log(log_1.log.whereIam());
        if (this.myEntity)
            return await this.myEntity.update(idInput, this.ctx.body);
    }
    async delete(idInput) {
        console.log(log_1.log.whereIam());
        if (this.myEntity)
            return await this.myEntity.delete(idInput);
    }
}
exports.apiAccess = apiAccess;
