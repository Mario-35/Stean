"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Geometry = void 0;
const enums_1 = require("../../enums");
const core_1 = require("./core");
class Geometry extends core_1.Core {
    constructor() {
        super(enums_1.EDataType.jsonb, "geometry");
    }
}
exports.Geometry = Geometry;
