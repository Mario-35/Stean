"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Tmperiod = void 0;
const enums_1 = require("../../enums");
const helpers_1 = require("../helpers");
const core_1 = require("./core");
class Tmperiod extends core_1.Core {
    constructor(tz) {
        super(enums_1.EDataType.period, tz.toUpperCase());
    }
    source(source) {
        this._entityRelation = (0, helpers_1.singular)(source).toLowerCase();
        return this;
    }
}
exports.Tmperiod = Tmperiod;
