"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Core = void 0;
class Core {
    _override;
    _dataType;
    _orderBy;
    _cast;
    _create;
    _coalesce;
    _entityRelation = undefined;
    _verify = {
        list: undefined,
        default: undefined
    };
    constructor(dataType, cast, entityRelation) {
        this._dataType = dataType;
        this._cast = cast;
        this._create = `@CAST@@NULL@@UNIQUE@@DEFAULT@`;
        this._entityRelation = entityRelation;
    }
    coalesce(input) {
        this._coalesce = input;
        return this;
    }
    defaultOrder(input) {
        this._orderBy = input;
        return this;
    }
    type() {
        if (this._override)
            return this._override;
        const res = {
            dataType: this._dataType,
            create: this._create.replace('@CAST@', this._cast).replace('@DEFAULT@', '').replace('@NULL@', '').replace('@UNIQUE@', ''),
            alias() { },
        };
        if (this._orderBy)
            res.orderBy = this._orderBy;
        if (this._entityRelation)
            res.entityRelation = this._entityRelation;
        if (this._coalesce)
            res.coalesce = this._coalesce;
        if (this._verify.default && this._verify.list)
            res.verify = {
                list: this._verify.list,
                default: this._verify.default
            };
        return res;
    }
    notNull() {
        this._create = this._create.replace('@NULL@', ' NOT NULL');
        return this;
    }
    unique() {
        this._create = this._create.replace('@UNIQUE@', ' UNIQUE');
        return this;
    }
    default(input) {
        if (typeof input === "number")
            input = String(input);
        this._create = this._create.replace('@DEFAULT@', input.trim() !== "" ? ` DEFAULT '${input.trim()}'::${this._cast}` : '');
        this._verify.default = input.trim();
        return this;
    }
    relation(input) {
        this._entityRelation = input.trim();
        return this;
    }
    alias(alias, create, dataType) {
        this._override = {
            create: "JSONB NULL",
            alias(service, test) {
                return `"result"->'line'${test && test["as"] === true ? ` AS "result"` : ''}`;
            },
            dataType: dataType
        };
        return this;
    }
}
exports.Core = Core;
