"use strict";
/**
 * createBlankEntity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBlankEntity = void 0;
const _1 = require(".");
const enums_1 = require("../../enums");
const messages_1 = require("../../messages");
const createBlankEntity = (name) => {
    const entity = enums_1.allEntities[name];
    if (entity) {
        return {
            type: enums_1.ETable.blank,
            name: name,
            singular: (0, _1.singular)(entity),
            table: "",
            createOrder: 99,
            order: 0,
            orderBy: "",
            columns: {},
            relations: {},
            constraints: {},
            indexes: {},
        };
    }
    throw new Error((0, messages_1.msg)(messages_1.errors.noValidEntity, name));
};
exports.createBlankEntity = createBlankEntity;
