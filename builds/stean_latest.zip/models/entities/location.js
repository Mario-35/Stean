"use strict";
/**
 * entity Location
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LOCATION = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.LOCATION = new entity_1.Entity("Locations", {
    createOrder: 2,
    type: enums_1.ETable.table,
    order: 6,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        name: new types_1.Text().notNull().type(),
        // name: new Text().notNull().default(info.noName).unique().type(),
        description: new types_1.Text().notNull().type(),
        // description: new Text().notNull().default(info.noDescription).type(),
        encodingType: new types_1.Text().notNull().default("application/vnd.geo+json").type(),
        location: new types_1.Jsonb().notNull().type(),
    },
    relations: {
        Things: {
            type: enums_1.ERelations.belongsToMany,
            entityRelation: "ThingsLocations"
        },
        HistoricalLocations: {
            type: enums_1.ERelations.belongsToMany,
        },
    },
});
