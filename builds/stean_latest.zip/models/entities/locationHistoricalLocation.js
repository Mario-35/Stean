"use strict";
/**
 * entity LocationHistoricalLocation
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LOCATIONHISTORICALLOCATION = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.LOCATIONHISTORICALLOCATION = new entity_1.Entity("LocationsHistoricalLocations", {
    createOrder: -1,
    type: enums_1.ETable.link,
    order: -1,
    columns: {
        location_id: new types_1.Bigint().notNull().type(),
        historicallocation_id: new types_1.Bigint().notNull().type(),
    },
    relations: {},
});
