"use strict";
/**
 * entity ObservedProperty
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OBSERVEDPROPERTY = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.OBSERVEDPROPERTY = new entity_1.Entity("ObservedProperties", {
    createOrder: 5,
    type: enums_1.ETable.table,
    order: 8,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        name: new types_1.Text().notNull().type(),
        // name: new Text().notNull().default(info.noName).unique().type(),
        description: new types_1.Text().notNull().type(),
        // description: new Text().notNull().default(info.noDescription).type(),
        definition: new types_1.Text().notNull().default('no definition').type()
    },
    relations: {
        Datastreams: {
            type: enums_1.ERelations.hasMany
        },
        MultiDatastreams: {
            type: enums_1.ERelations.hasMany,
            entityRelation: "MultiDatastreamObservedProperties",
        },
    },
});
