"use strict";
/**
 * entity User.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.USER = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.USER = new entity_1.Entity("Users", {
    createOrder: -1,
    type: enums_1.ETable.table,
    order: 21,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        username: new types_1.Text().notNull().unique().defaultOrder("asc").type(),
        email: new types_1.Text().type(),
        password: new types_1.Text().type(),
        database: new types_1.Text().type(),
        canPost: new types_1.Bool().type(),
        canDelete: new types_1.Bool().type(),
        canCreateUser: new types_1.Bool().type(),
        canCreateDb: new types_1.Bool().type(),
        admin: new types_1.Bool().type(),
        superAdmin: new types_1.Bool().type(),
    },
    relations: {},
});
