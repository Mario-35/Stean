"use strict";
/**
 * entity Log
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LOG = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.LOG = new entity_1.Entity("Logs", {
    createOrder: -1,
    type: enums_1.ETable.table,
    order: -1,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        date: new types_1.Timestamp("tz").notNull().defaultCurrent().defaultOrder("desc").type(),
        user_id: new types_1.Bigint().type(),
        method: new types_1.Text().type(),
        code: new types_1.Bigint().type(),
        url: new types_1.Text().type(),
        datas: new types_1.Jsonb().type(),
        database: new types_1.Text().type(),
        returnid: new types_1.Text().type(),
        error: new types_1.Jsonb().type(),
    },
    relations: {},
});
