"use strict";
/**
 * entity HistoricalLocation
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.HISTORICALLOCATION = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.HISTORICALLOCATION = new entity_1.Entity("HistoricalLocations", {
    createOrder: -1,
    order: 5,
    type: enums_1.ETable.table,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        time: new types_1.Timestamp("tz").type(),
        thing_id: new types_1.Bigint().notNull().type(),
    },
    relations: {
        Thing: {
            type: enums_1.ERelations.belongsTo
        },
        Locations: {
            type: enums_1.ERelations.belongsTo,
            entityRelation: "LocationsHistoricalLocations"
        },
    },
});
