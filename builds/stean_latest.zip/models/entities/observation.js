"use strict";
/**
 * entity Observation
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OBSERVATION = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.OBSERVATION = new entity_1.Entity("Observations", {
    createOrder: 12,
    type: enums_1.ETable.table,
    order: 7,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        phenomenonTime: new types_1.Timestamp("tz").notNull().defaultOrder("asc").type(),
        result: new types_1.Result().type(),
        resultTime: new types_1.Timestamp("tz").notNull().type(),
        resultQuality: new types_1.Jsonb().type(),
        validTime: new types_1.Timestamp("tz").notNull().defaultCurrent().type(),
        parameters: new types_1.Jsonb().type(),
        datastream_id: new types_1.Relation().relation("Datastreams").type(),
        multidatastream_id: new types_1.Relation().relation("MultiDatastreams").type(),
        featureofinterest_id: new types_1.Relation().relation("FeaturesOfInterest").notNull().default(1).type()
    },
    relations: {
        Datastream: {
            type: enums_1.ERelations.belongsTo,
            unique: ["phenomenonTime", "resultTime", "datastream_id", "featureofinterest_id"],
        },
        MultiDatastream: {
            type: enums_1.ERelations.belongsTo,
            unique: ["phenomenonTime", "resultTime", "multidatastream_id", "featureofinterest_id"],
        },
        FeatureOfInterest: {
            type: enums_1.ERelations.belongsTo
        },
    },
});
