"use strict";
/**
 * entity Lora
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LORA = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const messages_1 = require("../../messages");
const types_1 = require("../types");
exports.LORA = new entity_1.Entity("Loras", {
    createOrder: 11,
    type: enums_1.ETable.table,
    order: 11,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        name: new types_1.Text().notNull().default(messages_1.info.noName).unique().type(),
        description: new types_1.Text().notNull().default(messages_1.info.noDescription).type(),
        properties: new types_1.Jsonb().type(),
        deveui: new types_1.Text().unique().type(),
        decoder_id: new types_1.Relation().notNull().relation("Decoders").type(),
        datastream_id: new types_1.Relation().relation("Datastreams").unique().type(),
        multidatastream_id: new types_1.Relation().relation("MultiDatastreams").unique().type()
    },
    relations: {
        Datastream: {
            type: enums_1.ERelations.belongsTo
        },
        MultiDatastream: {
            type: enums_1.ERelations.belongsTo
        },
        Decoder: {
            type: enums_1.ERelations.belongsTo
        },
    },
});
