"use strict";
/**
 * lines line
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LINE = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.LINE = new entity_1.Entity("Lines", {
    createOrder: 2,
    type: enums_1.ETable.table,
    order: 2,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        result: new types_1.Result().lines().type(),
        file_id: new types_1.Relation().relation("Files").type(),
    },
    relations: {
        File: {
            type: enums_1.ERelations.belongsTo
        },
    },
});
