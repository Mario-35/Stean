"use strict";
/**
 * getUrlKey
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUrlKey = getUrlKey;
/**
 *
 * @param input url string
 * @param key
 * @returns string value
 */
function getUrlKey(input, key) {
    let result = undefined;
    try {
        input
            .split("?")[1]
            .split("$")
            .forEach((e) => {
            if (e.toUpperCase().startsWith(`${key.toUpperCase()}=`))
                result = e.split("=")[1];
        });
    }
    catch (error) {
        return result;
    }
    return result;
}
