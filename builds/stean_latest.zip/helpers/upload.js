"use strict";
/**
 * upload.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.upload = void 0;
const busboy_1 = __importDefault(require("busboy"));
const path_1 = __importDefault(require("path"));
const util_1 = __importDefault(require("util"));
const fs_1 = __importDefault(require("fs"));
const enums_1 = require("../enums");
/**
 *
 * @param ctx Koa context
 * @returns KeyString
 */
const upload = (ctx) => {
    // Init results
    const data = {};
    // Create promise
    return new Promise(async (resolve, reject) => {
        const allowedExtName = ["csv", "txt", "json"];
        // Init path
        if (!fs_1.default.existsSync(enums_1.EConstant.uploadPath)) {
            const mkdir = util_1.default.promisify(fs_1.default.mkdir);
            await mkdir(enums_1.EConstant.uploadPath).catch((error) => {
                data["state"] = "ERROR";
                reject(error);
            });
        }
        // Create Busboy object
        const busboy = new busboy_1.default({ headers: ctx.req.headers });
        // Stream
        busboy.on("file", (fieldname, file, filename) => {
            const extname = path_1.default.extname(filename).substring(1);
            if (!allowedExtName.includes(extname)) {
                data["state"] = "UPLOAD UNALLOWED FILE";
                file.resume();
                reject(data);
            }
            else {
                file.pipe(fs_1.default.createWriteStream(enums_1.EConstant.uploadPath + "/" + filename));
                data["file"] = enums_1.EConstant.uploadPath + "/" + filename;
                file.on("data", (chunk) => {
                    data["state"] = `GET ${chunk.length} bytes`;
                });
                file.on("error", (error) => {
                    console.log(error);
                });
                file.on("end", () => {
                    data["state"] = "UPLOAD FINISHED";
                    data[fieldname] = enums_1.EConstant.uploadPath + "/" + filename;
                });
            }
        });
        busboy.on("field", (fieldname, value) => {
            data[fieldname] = value;
        });
        // catch error
        busboy.on("error", (error) => {
            console.log(error);
            data["state"] = "ERROR";
            reject(error);
        });
        // finish
        busboy.on("finish", () => {
            data["state"] = "DONE";
            resolve(data);
        });
        // run it
        ctx.req.pipe(busboy);
    });
};
exports.upload = upload;
