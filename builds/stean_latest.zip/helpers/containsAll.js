"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.containsAll = void 0;
/**
* containsAll
*
* @copyright 2020-present Inrae
* @author mario.adam@inrae.fr
*
*/
const containsAll = (arr1, arr2) => arr1 && arr2 ? arr1.every(i => arr2.includes(i)) : false;
exports.containsAll = containsAll;
