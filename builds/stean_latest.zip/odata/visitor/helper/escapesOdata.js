"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.escapesOdata = void 0;
/**
 * escapesOdata
 *
 * @copyright 2022-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
const escapesOdata = (input) => {
    const codes = { "/": "%252F", "\\": "%255C" };
    if (input.includes("%27")) {
        const pop = [];
        input.split("%27").forEach((v, i) => {
            if (i === 1)
                Object.keys(codes).forEach((code) => v = v.split(code).join(codes[code]));
            pop.push(v);
        });
        return pop.join("%27");
    }
    return input;
};
exports.escapesOdata = escapesOdata;
