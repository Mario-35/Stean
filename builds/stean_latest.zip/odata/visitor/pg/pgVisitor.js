"use strict";
/**
 * pgVisitor for odata
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PgVisitor = void 0;
const helpers_1 = require("../../../helpers");
const literal_1 = require("../../parser/literal");
const sqlLiteral_1 = require("../../parser/sqlLiteral");
const helper_1 = require("../helper");
const messages_1 = require("../../../messages");
const enums_1 = require("../../../enums");
const models_1 = require("../../../models");
const log_1 = require("../../../log");
const constants_1 = require("../../../constants");
const visitor_1 = require("./visitor");
const helpers_2 = require("../../../models/helpers");
const tests_1 = require("../../../helpers/tests");
const entities_1 = require("../../../models/entities");
class PgVisitor extends visitor_1.Visitor {
    entity = undefined;
    columnSpecials = {};
    replay = false;
    navigation = undefined;
    // parent entity
    parentEntity = undefined;
    id = BigInt(0);
    parentId = BigInt(0);
    subQuery = { select: "", from: [], keys: [] };
    intervalColumns = undefined;
    splitResult;
    interval;
    payload;
    skip = 0;
    limit = 0;
    count = false;
    numeric = false;
    returnNull = false;
    navigationProperty;
    parameters = [];
    ast;
    showRelations = true;
    debugOdata = (0, helpers_1.isTest)() ? false : constants_1._DEBUG;
    single = false;
    constructor(ctx, options = {}) {
        console.log(log_1.log.whereIam());
        super(ctx, options);
    }
    // ***********************************************************************************************************************************************************************
    // ***                                                           ROSSOURCES                                                                                            ***
    // ***********************************************************************************************************************************************************************
    noLimit() {
        this.limit = 0;
        this.skip = 0;
    }
    swapEntity(newEntity, id) {
        this.parentEntity = this.entity;
        this.entity = newEntity;
        this.parentId = this.id;
        this.id = id ? id : BigInt(0);
    }
    testo(input) {
        console.log(`******************* ${input} ********************`);
        console.log(`entity  =====> ${this.entity}  id : [${this.id}]`);
        console.log(`parent  =====> ${this.parentEntity}  id : [${this.parentId}]`);
        console.log("***************************************");
    }
    addToIntervalColumns(input) {
        // TODO test with create    
        if (input.endsWith('Time"'))
            input = `step AS ${input}`;
        else if (input === (0, helpers_1.doubleQuotesString)(enums_1.EConstant.id))
            input = `coalesce(${(0, helpers_1.doubleQuotesString)(enums_1.EConstant.id)}, 0) AS ${(0, helpers_1.doubleQuotesString)(enums_1.EConstant.id)}`;
        else if (input.startsWith("CONCAT"))
            input = `${input}`;
        else if (input[0] !== "'")
            input = `${input}`;
        if (this.intervalColumns)
            this.intervalColumns.push(input);
        else
            this.intervalColumns = [input];
    }
    getColumn(input, operation, context) {
        console.log(log_1.log.whereIam(input));
        const tempEntity = context.target === enums_1.EQuery.Where && context.identifier
            ? models_1.models.getEntity(this.ctx.service, context.identifier.split(".")[0])
            : this.isSelect(context)
                ? models_1.models.getEntity(this.ctx.service, this.entity || this.parentEntity || this.navigationProperty)
                : undefined;
        if (input.startsWith("result/")) {
            this.columnSpecials["result"] = input.split("result/")[1].split("/").map(e => `"result"->'value'->'${e}' AS "${e}"`);
            return "result";
        }
        const columnName = input === "result"
            ? this.formatColumnResult(context, operation)
            : tempEntity
                ? this.getColumnNameOrAlias(tempEntity, input, this.createDefaultOptions())
                : undefined;
        if (columnName)
            return columnName;
        if (this.isSelect(context) && tempEntity && tempEntity.relations[input]) {
            const entityName = models_1.models.getEntityName(this.ctx.service, input);
            return tempEntity && entityName
                ? `CONCAT('${this.ctx.decodedUrl.root}/${tempEntity.name}(', "${tempEntity.table}"."id", ')/${entityName}') AS "${entityName}${enums_1.EConstant.navLink}"`
                : undefined;
        }
    }
    // ***********************************************************************************************************************************************************************
    // ***                                                              QUERY                                                                                              ***
    // ***********************************************************************************************************************************************************************
    formatColumnResult(context, operation, ForceString) {
        console.log("formatColumnResult");
        console.log(this.parentEntity?.name === entities_1.DATASTREAM.name);
        switch (context.target) {
            case enums_1.EQuery.Where:
                const nbs = Array.from({ length: this.parentEntity?.name === entities_1.DATASTREAM.name ? 1 : 5 }, (v, k) => k + 1);
                const translate = `TRANSLATE (SUBSTRING ("result"->>'value' FROM '(([0-9]+.*)*[0-9]+)'), '[]','')`;
                const isOperation = operation.trim() != "";
                return ForceString || (0, tests_1.isFile)(this.ctx)
                    ? `@EXPRESSIONSTRING@ ALL (ARRAY_REMOVE( ARRAY[\n${nbs.map(e => `${isOperation ? `${operation} (` : ''} SPLIT_PART ( ${translate}, ',', ${e}))`).join(",\n")}], null))`
                    : `@EXPRESSION@ ALL (ARRAY_REMOVE( ARRAY[\n${nbs.map(e => `${isOperation ? `${operation} (` : ''}NULLIF (SPLIT_PART ( ${translate}, ',', ${e}),'')::numeric${isOperation ? `)` : ''}`).join(",\n")}], null))`;
            default:
                return `CASE 
          WHEN JSONB_TYPEOF( "result"->'value') = 'number' THEN ("result"->${this.numeric == true ? '>' : ''}'value')::jsonb
          WHEN JSONB_TYPEOF( "result"->'value') = 'array'  THEN ("result"->'${this.valueskeys == true ? 'valueskeys' : 'value'}')::jsonb
          ELSE ("result"->'${this.valueskeys == true ? 'valueskeys' : 'value'}')::jsonb
      END${this.isSelect(context) === true ? ' AS "result"' : ''}`;
        }
    }
    getColumnNameOrAlias(entity, column, options) {
        let result = undefined;
        if (entity && column != "" && entity.columns[column]) {
            result = entity.columns[column].alias(this.ctx.service, options);
            if (!result)
                result = (0, helpers_1.doubleQuotesString)(column);
        }
        return result ? `${options.table === true && result && result[0] === '"' ? `"${entity.table}".${result}` : result}` : undefined;
    }
    ;
    clear(input) {
        if (input.includes('@START@')) {
            input = input.split('@START@').join("(");
            input = input.split('@END@').join('') + ')';
        }
        return input;
    }
    start(node) {
        console.log(log_1.log.debug_head("Start PgVisitor"));
        const temp = this.Visit(node);
        this.verifyQuery();
        // Logs.infos("PgVisitor", temp);
        temp.query.where.init(this.clear(temp.query.where.toString()));
        return temp;
    }
    verifyQuery = () => {
        console.log(log_1.log.debug_head("verifyQuery"));
        const expands = [];
        if (this.includes)
            this.includes.forEach((element) => {
                if (element.ast.type === "ExpandItem")
                    expands.push(element.ast.raw.split("(")[0]);
            });
        expands.forEach((elem) => {
            const elems = elem.split("/");
            if (this.entity)
                elems.unshift(this.entity.name);
            if (elems[0]) {
                if (!Object.keys(this.ctx.model[elems[0]].relations).includes(elems[1]))
                    this.ctx.throw(400 /* EHttpCode.badRequest */, {
                        detail: `Invalid expand path ${elems[1]} for ${elems[0]}`,
                    });
            }
            else
                this.ctx.throw(400 /* EHttpCode.badRequest */, { detail: (0, messages_1.msg)(messages_1.errors.invalid, "entity") + elems[0] });
        });
        if (this.entity && (0, tests_1._isObservation)(this.entity) === true && this.splitResult !== undefined && Number(this.parentId) == 0) {
            this.ctx.throw(400 /* EHttpCode.badRequest */, { detail: messages_1.errors.splitNotAllowed });
        }
        if (this.returnFormat === helpers_1.returnFormats.dataArray && BigInt(this.id) > 0 && !this.parentEntity) {
            this.ctx.throw(400 /* EHttpCode.badRequest */, { detail: messages_1.errors.dataArrayNotAllowed });
        }
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    Visit(node, context) {
        this.ast = this.ast || node;
        context = context || { target: enums_1.EQuery.Where, key: undefined, entity: undefined, table: undefined, identifier: undefined, identifierType: undefined, relation: undefined, literal: undefined, sign: undefined, sql: undefined, in: undefined };
        if (node) {
            const visitor = this[`Visit${node.type}`];
            if (visitor) {
                visitor.call(this, node, context);
                if (this.debugOdata) {
                    console.log(log_1.log._infos("Visit", `Visit${node.type}`));
                    console.log(log_1.log._result("node.raw", node.raw));
                    console.log(log_1.log._result("this.query.where", this.query.where.toString()));
                    console.log(log_1.log._infos("context", context));
                }
            }
            else {
                log_1.log.error(`Node error =================> Visit${node.type}`);
                log_1.log.error(node);
                throw new Error(`Unhandled node type: ${node.type}`);
            }
        }
        if (this.entity && node == this.ast) {
            if (this.entity.name.startsWith("Lora")) {
                if (typeof this.id == "string") {
                    this.query.where.init(`"lora"."deveui" = '${this.id}'`);
                }
            }
        }
        return this;
    }
    isSelect = (context) => (context.target ? context.target === enums_1.EQuery.Select : false);
    VisitExpand(node, context) {
        node.value.items.forEach((item) => {
            const expandPath = item.value.path.raw;
            let visitor = this.includes ? this.includes.filter((v) => v.navigationProperty == expandPath)[0] : undefined;
            if (!visitor) {
                visitor = new PgVisitor(this.ctx, { ...this.options });
                this.includes ? this.includes.push(visitor) : this.includes = [visitor];
            }
            visitor.Visit(item, context);
        });
    }
    VisitEntity(node, context) {
        this.Visit(node.value.path, context);
        if (node.value.options)
            node.value.options.forEach((item) => this.Visit(item, context));
    }
    VisitSplitResult(node, context) {
        this.Visit(node.value.path, context);
        if (node.value.options)
            node.value.options.forEach((item) => this.Visit(item, context));
        this.splitResult = (0, helpers_1.removeAllQuotes)(node.value).split(",");
    }
    VisitInterval(node, context) {
        this.Visit(node.value.path, context);
        if (node.value.options)
            node.value.options.forEach((item) => this.Visit(item, context));
        this.interval = node.value;
        if (this.interval)
            this.noLimit();
    }
    VisitPayload(node, context) {
        this.Visit(node.value.path, context);
        if (node.value.options)
            node.value.options.forEach((item) => this.Visit(item, context));
        this.payload = node.value;
    }
    VisitReplay(node, context) {
        this.replay = true;
        this.returnFormat = helpers_1.returnFormats.sql;
    }
    VisitDebug(node, context) {
        this.Visit(node.value.path, context);
        if (node.value.options)
            node.value.options.forEach((item) => this.Visit(item, context));
    }
    VisitResultFormat(node, context) {
        if (node.value.format)
            this.returnFormat = helpers_1.returnFormats[node.value.format];
        if ([helpers_1.returnFormats.dataArray, helpers_1.returnFormats.graph, helpers_1.returnFormats.graphDatas, helpers_1.returnFormats.csv].includes(this.returnFormat))
            this.noLimit();
        this.showRelations = false;
        if ((0, helpers_1.isGraph)(this)) {
            this.showRelations = false;
        }
    }
    VisitExpandItem(node, context) {
        this.Visit(node.value.path, context);
        if (node.value.options)
            node.value.options.forEach((item) => this.Visit(item, context));
    }
    VisitExpandPath(node, context) {
        this.navigationProperty = node.raw;
    }
    // Start loop process
    VisitQueryOptions(node, context) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        node.value.options.forEach((option) => this.Visit(option, context));
    }
    VisitInlineCount(node, context) {
        this.count = literal_1.Literal.convert(node.value.value, node.value.raw);
    }
    VisitFilter(node, context) {
        context.target = enums_1.EQuery.Where;
        if (this.query.where.toString().trim() != "")
            this.addToWhere(" AND ", context);
        this.Visit(node.value, context);
    }
    VisitOrderBy(node, context) {
        context.target = enums_1.EQuery.OrderBy;
        node.value.items.forEach((item, i) => {
            this.Visit(item, context);
            if (i < node.value.items.length - 1)
                this.query.orderBy.add(", ");
        });
    }
    VisitOrderByItem(node, context) {
        this.Visit(node.value.expr, context);
        if (this.query.orderBy.notNull())
            this.query.orderBy.add(node.value.direction > 0 ? " ASC" : " DESC");
    }
    VisitSkip(node, context) {
        this.skip = +node.value.raw;
    }
    VisitTop(node, context) {
        this.limit = +node.value.raw;
    }
    VisitSelect(node, context) {
        context.target = enums_1.EQuery.Select;
        node.value.items.forEach((item) => {
            this.Visit(item, context);
        });
    }
    VisitSelectItem(node, context) {
        const tempColumn = this.getColumn(node.raw, "", context);
        if ((0, tests_1.isFile)(this.ctx)) {
            context.identifier = `(result->'valueskeys')->>'${node.raw}' AS "${node.raw}"`;
            // this.ctx.columnSpecials["result"] =`(result->'valueskeys')->>'${node.raw}' AS "${node.raw}"`;
        }
        else
            context.identifier = tempColumn ? tempColumn : node.raw;
        if (context.target)
            // @ts-ignore
            this.query[context.target].add(tempColumn ? `${tempColumn}${enums_1.EConstant.columnSeparator}` : `${(0, helpers_1.doubleQuotesString)(node.raw)}${enums_1.EConstant.columnSeparator}`);
        this.showRelations = false;
    }
    VisitAndExpression(node, context) {
        this.Visit(node.value.left, context);
        this.addToWhere(context.in && context.in === true ? " INTERSECT " : " AND ", context);
        this.Visit(node.value.right, context);
    }
    VisitOrExpression(node, context) {
        this.Visit(node.value.left, context);
        this.addToWhere(" OR ", context);
        this.Visit(node.value.right, context);
    }
    VisitNotExpression(node, context) {
        this.addToWhere(" NOT ", context);
        this.Visit(node.value, context);
    }
    VisitBoolParenExpression(node, context) {
        this.addToWhere("(", context);
        this.Visit(node.value, context);
        this.addToWhere(")", context);
    }
    VisitCommonExpression(node, context) {
        this.Visit(node.value, context);
    }
    VisitFirstMemberExpression(node, context) {
        this.Visit(node.value, context);
    }
    VisitMemberExpression(node, context) {
        this.Visit(node.value, context);
    }
    VisitPropertyPathExpression(node, context) {
        if (node.value.current && node.value.next) {
            // deterwine if its column AND JSON
            if (this.entity && models_1.models.getRelationColumnTable(this.ctx.service, this.entity, node.value.current.raw) === enums_1.EColumnType.Column
                && models_1.models.isColumnType(this.ctx.service, this.entity, node.value.current.raw, "json")
                && node.value.next.raw[0] == "/") {
                this.addToWhere(`${(0, helpers_1.doubleQuotesString)(node.value.current.raw)}->>${(0, helpers_1.simpleQuotesString)(node.value.next.raw.slice(1))}`, context);
            }
            else if (node.value.next.raw[0] == "/") {
                this.Visit(node.value.current, context);
                context.identifier += ".";
                this.Visit(node.value.next, context);
            }
            else {
                this.Visit(node.value.current, context);
                context.identifier += ".";
                this.Visit(node.value.next, context);
            }
        }
        else
            this.Visit(node.value, context);
    }
    VisitSingleNavigationExpression(node, context) {
        if (node.value.current && node.value.next) {
            this.Visit(node.value.current, context);
            this.Visit(node.value.next, context);
        }
        else
            this.Visit(node.value, context);
    }
    VisitLesserThanExpression(node, context) {
        context.sign = "<";
        if (!this.VisitDateType(node, context)) {
            this.Visit(node.value.left, context);
            this.addExpressionToWhere(node, context);
            this.Visit(node.value.right, context);
        }
    }
    VisitLesserOrEqualsExpression(node, context) {
        context.sign = "<=";
        if (!this.VisitDateType(node, context)) {
            this.Visit(node.value.left, context);
            this.addExpressionToWhere(node, context);
            this.Visit(node.value.right, context);
        }
    }
    VisitDateType(node, context) {
        if (this.entity && context.sign && models_1.models.getRelationColumnTable(this.ctx.service, this.entity, node.value.left.raw) === enums_1.EColumnType.Column && models_1.models.isColumnType(this.ctx.service, this.entity, node.value.left.raw, "date")) {
            const testIsDate = (0, helper_1.oDataDateFormat)(node, context.sign);
            const columnName = this.getColumnNameOrAlias(this.ctx.model[context.identifier || this.entity.name], node.value.left.raw, { table: true, as: true, cast: false, ...this.createDefaultOptions() });
            if (testIsDate) {
                this.addToWhere(`${columnName
                    ? columnName
                    : `${(0, helpers_1.doubleQuotesString)(node.value.left.raw)}`}${testIsDate}`, context);
                return true;
            }
        }
        return false;
    }
    inverseSign(input) {
        if (input)
            switch (input) {
                case ">": return "<";
                case ">=": return "<=";
                case "<": return ">";
                case "<=": return ">=";
                default:
                    return input;
            }
    }
    addToWhere(value, context) {
        if (context.target === enums_1.EQuery.Geo)
            this.subQuery.where ? this.subQuery.where += value : this.subQuery.where = value;
        else
            this.query.where.add(value);
    }
    addExpressionToWhere(node, context) {
        if (this.query.where.toString().includes("@EXPRESSION@"))
            this.query.where.replace("@EXPRESSION@", `@EXPRESSION@ ${this.inverseSign(context.sign)}`);
        else if (!this.query.where.toString().includes("@EXPRESSIONSTRING@") && this.inverseSign(context.sign))
            // Important to keep space
            this.addToWhere(" " + context.sign, context);
    }
    VisitGreaterThanExpression(node, context) {
        context.sign = ">";
        if (!this.VisitDateType(node, context)) {
            this.Visit(node.value.left, context);
            this.addExpressionToWhere(node, context);
            this.Visit(node.value.right, context);
        }
    }
    VisitGreaterOrEqualsExpression(node, context) {
        context.sign = ">=";
        if (!this.VisitDateType(node, context)) {
            this.Visit(node.value.left, context);
            this.addExpressionToWhere(node, context);
            this.Visit(node.value.right, context);
        }
    }
    createDefaultOptions() {
        return {
            valueskeys: this.valueskeys,
            numeric: this.numeric
        };
    }
    createComplexWhere(entity, node, context) {
        if (context.target) {
            if (!models_1.models.getEntity(this.ctx.service, entity))
                return;
            const tempEntity = models_1.models.getEntity(this.ctx.service, node.value.name);
            if (tempEntity) {
                const relation = (0, helpers_2.relationInfos)(this.ctx, entity, node.value.name);
                if (context.relation) {
                    context.sql = `${(0, helpers_1.formatPgTableColumn)(this.ctx.model[entity].table, relation.column)} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(tempEntity.table, relation.rightKey)} FROM ${(0, helpers_1.formatPgTableColumn)(tempEntity.table)}`;
                }
                else {
                    context.relation = node.value.name;
                    context.table = tempEntity.table;
                }
                if (!context.key && context.relation) {
                    context.key = relation.column;
                    // @ts-ignore
                    this.query[context.target].add((0, helpers_1.doubleQuotesString)(relation.column));
                }
            }
        }
    }
    VisitODataIdentifier(node, context) {
        const alias = this.getColumn(node.value.name, "", context);
        node.value.name = alias ? alias : node.value.name;
        if (context.relation && context.identifier && models_1.models.isColumnType(this.ctx.service, this.ctx.model[context.relation], (0, helpers_1.removeAllQuotes)(context.identifier).split(".")[0], "json")) {
            context.identifier = `${(0, helpers_1.doubleQuotesString)(context.identifier.split(".")[0])}->>${(0, helpers_1.simpleQuotesString)(node.raw)}`;
        }
        else {
            if (context.target === enums_1.EQuery.Where && this.entity)
                this.createComplexWhere(context.identifier ? context.identifier.split(".")[0] : this.entity.name, node, context);
            if (!context.relation && !context.identifier && alias && context.target) {
                // @ts-ignore
                this.query[context.target].add(alias);
            }
            else {
                context.identifier = node.value.name;
                if (this.entity && context.target && !context.key) {
                    let alias = this.getColumnNameOrAlias(this.entity, node.value.name, this.createDefaultOptions());
                    alias = context.target === enums_1.EQuery.Where ? alias?.split(" AS ")[0] : enums_1.EQuery.OrderBy ? (0, helpers_1.doubleQuotesString)(node.value.name) : alias;
                    // @ts-ignore
                    this.query[context.target].add(node.value.name.includes("->>") || node.value.name.includes("->") || node.value.name.includes("::")
                        ? node.value.name
                        : this.entity && this.ctx.model[this.entity.name]
                            ? alias
                                ? alias
                                : ''
                            : (0, helpers_1.doubleQuotesString)(node.value.name));
                }
            }
        }
    }
    VisitEqualsExpression(node, context) {
        context.sign = "=";
        if (!this.VisitDateType(node, context)) {
            this.Visit(node.value.left, context);
            this.addExpressionToWhere(node, context);
            this.Visit(node.value.right, context);
            this.query.where.replace(/= null/, "IS NULL");
        }
    }
    VisitNotEqualsExpression(node, context) {
        context.sign = "<>";
        if (!this.VisitDateType(node, context)) {
            this.Visit(node.value.left, context);
            this.addExpressionToWhere(node, context);
            this.Visit(node.value.right, context);
            this.query.where.replace(/<> null$/, "IS NOT NULL");
        }
    }
    VisitLiteral(node, context) {
        if (this.entity && context.relation && context.table && context.target === enums_1.EQuery.Where) {
            const temp = this.query.where.toString().split(" ").filter(e => e != "");
            context.sign = temp.pop();
            this.query.where.init(temp.join(" "));
            const relation = (0, helpers_2.relationInfos)(this.ctx, this.entity.name, context.relation);
            this.addToWhere(` ${context.in && context.in === true ? '' : ' IN @START@'}(SELECT ${this.entity.relations[context.relation] ? (0, helpers_1.doubleQuotesString)(relation.rightKey) : `${(0, helpers_1.doubleQuotesString)(context.table)}."id"`} FROM ${(0, helpers_1.doubleQuotesString)(context.table)} WHERE `, context);
            context.in = true;
            if (context.identifier) {
                if (context.identifier.startsWith("CASE") || context.identifier.startsWith("("))
                    this.addToWhere(`${context.identifier} ${context.sign} ${sqlLiteral_1.SQLLiteral.convert(node.value, node.raw)})`, context);
                else if (context.identifier.includes("@EXPRESSION@")) {
                    const tempEntity = models_1.models.getEntity(this.ctx.service, context.relation);
                    const alias = tempEntity ? this.getColumnNameOrAlias(tempEntity, context.identifier, this.createDefaultOptions()) : undefined;
                    this.addToWhere((context.sql)
                        ? `${context.sql} ${context.target} ${(0, helpers_1.doubleQuotesString)(context.identifier)}))@END@`
                        : `${alias ? alias : `${context.identifier.replace("@EXPRESSION@", ` ${sqlLiteral_1.SQLLiteral.convert(node.value, node.raw)} ${this.inverseSign(context.sign)}`)}`})`, context);
                }
                else {
                    const tempEntity = models_1.models.getEntity(this.ctx.service, context.relation);
                    const quotes = context.identifier[0] === '"' ? '' : '"';
                    const alias = tempEntity ? this.getColumnNameOrAlias(tempEntity, context.identifier, this.createDefaultOptions()) : undefined;
                    this.addToWhere((context.sql)
                        ? `${context.sql} ${context.target} ${(0, helpers_1.doubleQuotesString)(context.identifier)} ${context.sign} ${sqlLiteral_1.SQLLiteral.convert(node.value, node.raw)}))@END@`
                        : `${alias ? '' : `${context.table}.`}${alias ? alias : `${quotes}${context.identifier}${quotes}`} ${context.sign} ${sqlLiteral_1.SQLLiteral.convert(node.value, node.raw)})`, context);
                }
            }
        }
        else {
            const temp = context.literal = node.value == "Edm.Boolean" ? node.raw : sqlLiteral_1.SQLLiteral.convert(node.value, node.raw);
            if (this.query.where.toString().includes("@EXPRESSION@"))
                this.query.where.replace("@EXPRESSION@", temp);
            else if (this.query.where.toString().includes("@EXPRESSIONSTRING@"))
                this.query.where.replace("@EXPRESSIONSTRING@", `${temp} ${this.inverseSign(context.sign)}`);
            else
                this.addToWhere(temp, context);
        }
    }
    VisitInExpression(node, context) {
        this.Visit(node.value.left, context);
        this.addToWhere(" IN (", context);
        this.Visit(node.value.right, context);
        this.addToWhere(":list)", context);
    }
    VisitArrayOrObject(node, context) {
        this.addToWhere(context.literal = sqlLiteral_1.SQLLiteral.convert(node.value, node.raw), context);
    }
    VisitMethodCallExpression(node, context) {
        const method = node.value.method;
        const params = node.value.parameters || [];
        const isColumn = (input) => {
            const entity = this.entity;
            const column = typeof input === "string" ? input : decodeURIComponent(literal_1.Literal.convert(params[input].value, params[input].raw));
            if (column.includes("/")) {
                const temp = column.split("/");
                if (entity && entity.relations.hasOwnProperty(temp[0])) {
                    const tempEntity = models_1.models.getEntity(this.ctx.service, temp[0]);
                    if (tempEntity)
                        return temp[1];
                }
            }
            else if (entity && entity.columns.hasOwnProperty(column))
                return column;
            else if (entity && entity.relations.hasOwnProperty(enums_1.EConstant.encoding))
                return enums_1.EConstant.encoding;
        };
        const columnOrData = (index, operation, ForceString) => {
            // convert into string
            const test = decodeURIComponent(literal_1.Literal.convert(params[index].value, params[index].raw));
            // if (FeatureOfInterest/feature)
            if (this.entity && test.includes("/")) {
                const tests = test.split("/");
                const relation = (0, helpers_2.relationInfos)(this.ctx, this.entity.name, tests[0]);
                if (relation && relation.entity) {
                    const relationEntity = models_1.models.getEntity(this.ctx.service, tests[0]);
                    if (relationEntity)
                        this.subQuery.from.push(relationEntity.table);
                    this.query.where.add(`${(0, helpers_1.formatPgTableColumn)(relation.entity.table, relation.leftKey)} = "src"."id"`);
                    return (0, helpers_1.formatPgTableColumn)(tests[0], tests[1]);
                }
            }
            if (test === "result")
                return this.formatColumnResult(context, operation, ForceString);
            const column = isColumn(test);
            return column ? (0, helpers_1.doubleQuotesString)(column) : (0, helpers_1.simpleQuotesString)(geoColumnOrData(index, false));
        };
        const geoColumnOrData = (index, srid) => {
            const temp = decodeURIComponent(literal_1.Literal.convert(params[index].value, params[index].raw)).replace("geography", "");
            return this.entity && this.entity.columns[temp]
                ? temp
                : `${srid === true ? "SRID=4326;" : ""}${(0, helpers_1.removeAllQuotes)(temp)}`;
        };
        const cleanData = (index) => params[index].value == "Edm.String"
            ? (0, helpers_1.removeAllQuotes)(literal_1.Literal.convert(params[index].value, params[index].raw))
            : literal_1.Literal.convert(params[index].value, params[index].raw);
        const order = params.length === 2 ? isColumn(0) ? [0, 1] : [1, 0] : [0];
        switch (String(method.split(".")[0])) {
            case "contains":
                this.Visit(params[0], context);
                this.addToWhere(` ~* '${sqlLiteral_1.SQLLiteral.convert(params[1].value, params[1].raw).slice(1, -1)}'`, context);
                break;
            case "containsAny":
                this.addToWhere("array_to_string(", context);
                this.Visit(params[0], context);
                this.addToWhere(`, ' ') ~* '${sqlLiteral_1.SQLLiteral.convert(params[1].value, params[1].raw).slice(1, -1)}'`, context);
                break;
            case "endswith":
                this.addToWhere(`${columnOrData(0, "", true)}  ILIKE '%${cleanData(1)}'`, context);
                break;
            case "startswith":
                this.addToWhere(`${columnOrData(0, "", true)} ILIKE '${cleanData(1)}%'`, context);
                break;
            case "substring":
                this.addToWhere((params.length == 3)
                    ? ` SUBSTR(${columnOrData(0, "", true)}, ${cleanData(1)} + 1, ${cleanData(2)})`
                    : ` SUBSTR(${columnOrData(0, "", true)}, ${cleanData(1)} + 1)`, context);
                break;
            case "substringof":
                this.addToWhere(`${columnOrData(0, "", true)} ILIKE '%${cleanData(1)}%'`, context);
                break;
            case "indexof":
                this.addToWhere(` POSITION('${cleanData(1)}' IN ${columnOrData(0, "", true)})`, context);
                break;
            case "concat":
                this.addToWhere(`(${columnOrData(0, "concat", true)} || '${cleanData(1)}')`, context);
                break;
            case "length":
                // possibilty calc length string of each result or result 
                this.addToWhere((decodeURIComponent(literal_1.Literal.convert(params[0].value, params[0].raw)) === "result")
                    ? `${columnOrData(0, "CHAR_LENGTH", true)}`
                    : `CHAR_LENGTH(${columnOrData(0, "CHAR_LENGTH", true)})`, context);
                break;
            case "tolower":
                this.addToWhere(`LOWER(${columnOrData(0, "", true)})`, context);
                break;
            case "toupper":
                this.addToWhere(`UPPER(${columnOrData(0, "", true)})`, context);
                break;
            case "year":
            case "month":
            case "day":
            case "hour":
            case "minute":
            case "second":
                this.addToWhere(`EXTRACT(${method.toUpperCase()} FROM ${columnOrData(0, "", false)})`, context);
                break;
            case "round":
            case "floor":
            case "ceiling":
                this.addToWhere(columnOrData(0, method.toUpperCase(), false), context);
                break;
            case "now":
                this.addToWhere("NOW()", context);
                break;
            case "date":
                this.addToWhere(`${method.toUpperCase()}(`, context);
                this.Visit(params[0], context);
                this.addToWhere(")", context);
                break;
            case "time":
                this.addToWhere(`(${columnOrData(0, "", true)})::time`, context);
                break;
            case "geo":
                const tmpGeo = new helper_1.OdataGeoColumn(this, method, columnOrData(order[0], "", true));
                context = tmpGeo.createColumn(columnOrData(order[1], "", true), context);
                // if (method === "geo.length")
                //   context = tmpGeo.createColumn(`ST_Length(ST_MakeLine(ST_AsText(@GEO@), ${columnOrData(order[1], "", true)}))`, context);
                // else 
                //   context = tmpGeo.createColumn(`${method.toUpperCase().replace("GEO.", "ST_")}(ST_AsText(@GEO@), ${columnOrData(order[1], "", true)})`, context);
                break;
            case "trim":
                this.addToWhere(`TRIM(BOTH '${params.length == 2 ? cleanData(1) : " "}' FROM ${columnOrData(0, "", true)})`, context);
                break;
            case "mindatetime":
                this.addToWhere(`MIN(${this.query.where.toString().split('" ')[0]}")`, context);
                break;
        }
    }
    toString() {
        return this.query.toString(this);
    }
    toPgQuery() {
        return this.query.toPgQuery(this);
    }
}
exports.PgVisitor = PgVisitor;
