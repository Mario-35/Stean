"use strict";
/**
 * OrderBy builder
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderBy = void 0;
const _1 = require(".");
class OrderBy extends _1.Core {
    constructor(input) {
        super(input);
    }
}
exports.OrderBy = OrderBy;
