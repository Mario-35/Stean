"use strict";
/**
 * core builder
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Core = void 0;
const helpers_1 = require("../../../helpers");
class Core {
    _src;
    constructor(input) {
        this._src = input ? typeof input === "string" ? [input] : input : [];
    }
    addKey(input) {
        const addTo = (input) => {
            input.forEach(key => {
                key = key.includes(" AS ") ? key.split(" AS ")[1] : key;
                key = key.includes(".") && !key.includes("@iot") ? key.split(".")[1] : key;
                if (!this._src.includes(key) && key.trim() !== "")
                    this._src.push((0, helpers_1.removeAllQuotes)(key));
            });
        };
        addTo((typeof input === "string") ? [input] : input);
    }
    add(input) {
        this._src.push(input);
    }
    init(input) {
        this._src = [input];
    }
    toArray() {
        return this._src;
    }
    toString() {
        return this._src.join("");
    }
    notNull() {
        return this._src.filter(e => e + "").length > 0;
    }
    replace(from, to) {
        this._src = this._src.map(e => typeof e === "string" ? e.replace(from, to) : e);
    }
    pop() {
        return this._src.pop();
    }
}
exports.Core = Core;
