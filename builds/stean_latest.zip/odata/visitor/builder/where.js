"use strict";
/**
 * Where builder
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Where = void 0;
const _1 = require(".");
class Where extends _1.Core {
    constructor(input) {
        super(input);
    }
}
exports.Where = Where;
