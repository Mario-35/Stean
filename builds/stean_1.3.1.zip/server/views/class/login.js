Object.defineProperty(exports,"__esModule",{value:!0}),exports.Login=void 0;let log_1=require("../../log"),core_1=require("./core");class Login extends core_1.CoreHtmlView{constructor(e,t){super(e,t),this.login(t)}login(t){var e=e=>t.why&&t.why[e]?`<div class="alert">${t.why[e]}</div>`:"";this._HTMLResult=[`
          <!DOCTYPE html>
            <html>
              ${this.head("Login")}    
            <body>
                <div class="login-wrap">
                  <div class="login-html">
                    ${this.title("Identification")}
                    <input  id="tab-1" type="radio" name="tab" class="sign-in" ${t.login?" checked":""}>
                    <label for="tab-1" class="tab">Sign In</label>
                    <input  id="tab-2" type="radio" name="tab" class="sign-up" ${t.login?"":"checked"}>
                    <label for="tab-2" class="tab">Sign Up</label>
                    <div class="login-form">
                      <form action="${this.ctx._.root}/login" method="post">
                        <div class="sign-in-htm">
                          ${this.textInput({name:"username",label:"Username",value:""})}
                          ${this.textInput({name:"password",label:"Password",value:"",password:!0})}
                          ${this.checkBox({name:"check",checked:!0,label:" Keep me Signed in"})}
                          ${this.submitButton("Sign In")}
                          ${this.hr()}
                          ${this.button(this.ctx._.root+"/Query","Return to Query")}
                          <div class="foot-lnk">
                            <a href="#forgot">Forgot Password?</a>
                          </div>
                        </div>
                      </form>
            
                      <form action="${this.ctx._.root}/register" method="post">
                        <div class="sign-up-htm">
                          ${this.textInput({name:"username",label:"username",value:t.body&&t.body.username?t.body.username:"",alert:e("username"),toolType:"Name Must be at least 5 chars"})}
                          ${this.textInput({name:"pass",label:"password",password:!0,value:t.body&&t.body.password?t.body.password:"",alert:e("password"),toolType:"At least one number, one lowercase and one uppercase letter, at least six characters that are letters, numbers or the underscore"})}
                          ${this.textInput({name:"repeat",label:"repeat",password:!0,value:"",alert:e("repeat"),toolType:"Same as password"})}
                          ${this.textInput({name:"mail",label:"Email address",value:t.body&&t.body.email?t.body.email:"",alert:e("email"),toolType:"A valid email address"})}
                          ${this.submitButton("Sign UP")}
                          ${this.hr()}                                
                          <div class="foot-lnk">
                            <label for="tab-1">Already Member ?</a>
                          </div>
                        </div>
                      </form>
                  </div>
                </div>
              </div>
            </body>                  
          </html>`]}}exports.Login=Login;