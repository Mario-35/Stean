"use strict";
/**
 * Paths
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.paths = void 0;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const files_1 = require("./files");
const enums_1 = require("../enums");
/**
 * Paths Class
 */
class Paths {
    // root (where "package.json" found)
    root;
    // root app (index)
    app = path_1.default.join(path_1.default.resolve(__dirname), "../");
    pkg = "package.json";
    logFile;
    configFile;
    key;
    constructor() {
        // Important to be first
        this.root = this.searchRootApp(path_1.default.join(__dirname)) || "Error";
        // check upload directory exists
        if (!fs_1.default.existsSync(this.upload()))
            fs_1.default.mkdirSync(this.upload());
        // backup log create new one stream it
        this.logFile = new files_1.File(path_1.default.join(this.root, "logs/"), "logs.html", ["backup", "stream"]);
        this.logFile.writeStream(`<!DOCTYPE html>${enums_1.EConstant.return}<html>${enums_1.EConstant.return}<body style="background-color:#353535;">`);
        // get config file
        this.configFile = new files_1.File(path_1.default.join(this.app, "/configuration/"), "configuration.json", []);
        // check .key and create defaulh one if not exist or corrupt
        try {
            this.key = fs_1.default.readFileSync(path_1.default.join(this.app, "/configuration/", ".key"), "utf8");
        }
        catch (error) {
            this.key = "zLwX893Mtt9Rc0TKvlInDXuZTFj9rxDV";
            fs_1.default.writeFileSync(path_1.default.join(this.app, "/configuration/", ".key"), this.key, { encoding: "utf-8" });
        }
    }
    searchRootApp(startPath) {
        let i = 1;
        // it's not reachable it's only to exclude infinite loop
        while (i < 50) {
            const file = path_1.default.join(startPath, "../".repeat(i), this.pkg);
            if (fs_1.default.existsSync(file))
                return path_1.default.join(startPath, "../".repeat(i), "/");
            i++;
        }
        throw new Error(`No root (${this.pkg}) found`);
    }
    updateFile() {
        return path_1.default.join(this.upload(), "update.zip");
    }
    upload() {
        return path_1.default.join(this.root, "upload/");
    }
    packageFile(myPath) {
        return myPath ? path_1.default.join(myPath, this.pkg) : path_1.default.join(this.root, this.pkg);
    }
    newVersion(create) {
        const folder = path_1.default.join(this.root, "newVersion/");
        if (create === true && !fs_1.default.existsSync(folder))
            fs_1.default.mkdirSync(folder);
        return folder;
    }
}
exports.paths = new Paths();
