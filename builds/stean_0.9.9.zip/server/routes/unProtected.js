"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.unProtectedRoutes = void 0;
/**
 * Unprotected Routes for API
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
const koa_router_1 = __importDefault(require("koa-router"));
const authentication_1 = require("../authentication");
const helpers_1 = require("../helpers");
const dataAccess_1 = require("../db/dataAccess");
const odata_1 = require("../odata");
const messages_1 = require("../messages");
const configuration_1 = require("../configuration");
const createDb_1 = require("../db/createDb");
const helpers_2 = require("../db/helpers");
const models_1 = require("../models");
const helper_1 = require("./helper");
const helpers_3 = require("../db/helpers");
const views_1 = require("../views/");
const helpers_4 = require("../views/helpers");
const enums_1 = require("../enums");
const monitoring_1 = require("../db/monitoring");
const log_1 = require("../log");
exports.unProtectedRoutes = new koa_router_1.default();
// ALL others
// API GET REQUEST
exports.unProtectedRoutes.get("/(.*)", async (ctx) => {
    switch (ctx.decodedUrl.path.toUpperCase()) {
        // Root path
        case `/`:
            ctx.body = models_1.models.getRoot(ctx);
            ctx.type = helpers_1.returnFormats.json.type;
            return;
        // tests only for testing wip features
        case "TEST":
            if (!(0, helpers_1.isAdmin)(ctx.service)) {
                ctx.type = helpers_1.returnFormats.json.type;
                ctx.body = await (0, helper_1.testRoute)(ctx);
                return;
            }
            ctx.throw(404 /* EHttpCode.notFound */);
        // metrics for monitoring
        case "METRICS":
            ctx.type = helpers_1.returnFormats.json.type;
            ctx.body = await (0, monitoring_1.getMetrics)(ctx.service);
            return;
        // error show in html if query call
        case "ERROR":
            const bodyError = new views_1.HtmlError(ctx, { url: "what ?" });
            ctx.type = helpers_1.returnFormats.html.type;
            ctx.body = bodyError.toString();
            return;
        // logs
        case "LOGGING":
            ctx.redirect(`${ctx.decodedUrl.origin}/logging`);
            return;
        // export service
        case "EXPORT":
            ctx.type = helpers_1.returnFormats.json.type;
            ctx.body = await (0, helpers_2.exportService)(ctx);
            return;
        // Admin page login
        case "ADMIN":
            ctx.redirect(`${ctx.decodedUrl.origin}/admin`);
            return;
        // User login
        case "LOGIN":
            if ((0, authentication_1.userAuthenticated)(ctx))
                ctx.redirect(`${ctx.decodedUrl.root}/status`);
            else {
                const bodyLogin = new views_1.Login(ctx, { url: "", login: true });
                ctx.type = helpers_1.returnFormats.html.type;
                ctx.body = bodyLogin.toString();
            }
            return;
        // Status user
        case "STATUS":
            if ((0, authentication_1.userAuthenticated)(ctx)) {
                const user = await (0, authentication_1.getAuthenticatedUser)(ctx);
                if (user) {
                    const bodyStatus = new views_1.Status(ctx, { url: "", user: user });
                    ctx.type = helpers_1.returnFormats.html.type;
                    ctx.body = bodyStatus.toString();
                    return;
                }
            }
            ctx.cookies.set("jwt-session");
            ctx.redirect(`${ctx.decodedUrl.root}/login`);
            return;
        // Create user
        case "REGISTER":
            const bodyLogin = new views_1.Login(ctx, { url: "", login: false });
            ctx.type = helpers_1.returnFormats.html.type;
            ctx.body = bodyLogin.toString();
            return;
        // Logout user
        case "LOGOUT":
            ctx.cookies.set("jwt-session");
            if (ctx.request.header.accept && ctx.request.header.accept.includes(enums_1.EEncodingType.html))
                ctx.redirect(`${ctx.decodedUrl.root}/login`);
            else
                ctx.status = 200 /* EHttpCode.ok */;
            ctx.body = {
                message: messages_1.info.logoutOk
            };
            return;
        // Execute Sql query pass in url
        case "SQL":
            let sql = (0, helpers_1.getUrlKey)(ctx.request.url, "query");
            if (sql) {
                sql = atob(sql);
                const resultSql = await configuration_1.config.executeSql(sql.includes("log_request") ? configuration_1.config.getService(enums_1.EConstant.admin) : ctx.service, sql);
                ctx.status = 201 /* EHttpCode.created */;
                ctx.body = [resultSql];
            }
            return;
        // Show draw.io model
        case "DRAW":
            ctx.type = helpers_1.returnFormats.xml.type;
            ctx.body = models_1.models.getDrawIo(ctx.service);
            return;
        // Infos and link of a services
        case "INFOS":
            ctx.type = helpers_1.returnFormats.json.type;
            ctx.body = await models_1.models.getInfos(ctx);
            return;
        // Create DB test
        case "CREATE":
            if (ctx.decodedUrl.service === enums_1.EConstant.test) {
                console.log(log_1.log.debug_head("Create service"));
                try {
                    (ctx.body = await (0, helpers_3.createService)(ctx.service, createDb_1.testDatas)), (ctx.status = 201 /* EHttpCode.created */);
                }
                catch (error) {
                    ctx.status = 400 /* EHttpCode.badRequest */;
                    ctx.redirect(`${ctx.decodedUrl.root}/error`);
                }
                return;
            }
            ctx.throw(404 /* EHttpCode.notFound */);
        // Drop DB
        case "DROP":
            console.log(log_1.log.debug_head("drop database"));
            if (ctx.service.options.includes(enums_1.EOptions.canDrop)) {
                await (0, helpers_2.disconnectDb)(ctx.service.pg.database, true);
                try {
                    ctx.status = 201 /* EHttpCode.created */;
                    ctx.body = await (0, createDb_1.createDatabase)(ctx.service.pg.database);
                }
                catch (error) {
                    ctx.status = 400 /* EHttpCode.badRequest */;
                    ctx.redirect(`${ctx.decodedUrl.root}/error`);
                }
                return;
            }
            ctx.throw(404 /* EHttpCode.notFound */);
        // Return Query HTML Page Tool
        case "QUERY":
            const tempContext = await (0, helpers_4.createQueryParams)(ctx);
            if (tempContext) {
                const bodyQuery = new views_1.Query(ctx, { url: "", queryOptions: tempContext });
                ctx.set("script-src", "self");
                ctx.set("Content-Security-Policy", "self");
                ctx.type = helpers_1.returnFormats.html.type;
                ctx.body = bodyQuery.toString();
            }
            return;
    } // END Switch
    if (ctx.decodedUrl.path.includes(ctx.service.apiVersion) || ctx.decodedUrl.version) {
        console.log(log_1.log.debug_head(`unProtected GET ${ctx.service.apiVersion}`));
        // decode odata url infos
        const odataVisitor = await (0, odata_1.createOdata)(ctx);
        if (odataVisitor) {
            ctx.odata = odataVisitor;
            if (ctx.odata.returnNull === true) {
                ctx.body = { values: [] };
                return;
            }
            console.log(log_1.log.debug_head(`GET ${ctx.service.apiVersion}`));
            // Create api object
            const objectAccess = new dataAccess_1.apiAccess(ctx);
            if (objectAccess) {
                // Get all
                if (ctx.odata.entity && ctx.odata.single === false) {
                    const returnValue = await objectAccess.getAll();
                    if (returnValue) {
                        const datas = ctx.odata.returnFormat === helpers_1.returnFormats.json ? { "@iot.count": returnValue.id, "@iot.nextLink": returnValue.nextLink, "@iot.prevLink": returnValue.prevLink, value: returnValue.body } : returnValue.body;
                        ctx.type = ctx.odata.returnFormat.type;
                        ctx.body = ctx.odata.returnFormat.format(datas, ctx);
                        if (returnValue.selfLink)
                            ctx.set("Location", returnValue.selfLink);
                    }
                    else
                        ctx.throw(404 /* EHttpCode.notFound */);
                    // Get One
                }
                else if (ctx.odata.single === true) {
                    const returnValue = await objectAccess.getSingle();
                    if (returnValue && returnValue.body) {
                        ctx.type = ctx.odata.returnFormat.type;
                        ctx.body = ctx.odata.returnFormat.format(returnValue.body);
                    }
                    else
                        ctx.throw(404 /* EHttpCode.notFound */, { detail: `id : ${ctx.odata.id} not found` });
                }
                else
                    ctx.throw(400 /* EHttpCode.badRequest */);
            }
        }
    }
});
// API PUT REQUEST only for add decoder from admin
exports.unProtectedRoutes.put("/(.*)", async (ctx) => {
    const action = ctx.request.url.split("/").reverse()[0];
    switch (action.toUpperCase()) {
        case "DECODERS":
            if (ctx.request.type.startsWith(enums_1.EEncodingType.json) && Object.keys(ctx.body).length > 0) {
                const odataVisitor = await (0, odata_1.createOdata)(ctx);
                if (odataVisitor)
                    ctx.odata = odataVisitor;
                if (ctx.odata) {
                    const objectAccess = new dataAccess_1.apiAccess(ctx);
                    const returnValue = await objectAccess.put();
                    if (returnValue) {
                        helpers_1.returnFormats.json.type;
                        if (returnValue.selfLink)
                            ctx.set("Location", returnValue.selfLink);
                        ctx.status = 201 /* EHttpCode.created */;
                        ctx.body = returnValue.body;
                    }
                }
                else
                    ctx.throw(400 /* EHttpCode.badRequest */);
            }
            break;
        case "SYNONYMS":
        case "OPTIONS":
            if (ctx.request.type.startsWith(enums_1.EEncodingType.json) && Object.keys(ctx.body).length > 0) {
                ctx.service[action] = ctx.body;
                ctx.body = await configuration_1.config.updateConfig(ctx.service);
            }
            break;
        case "NB_PAGE":
        case "CSVDELIMITER":
            if (ctx.request.type.startsWith(enums_1.EEncodingType.json) && Object.keys(ctx.body).length > 0) {
                ctx.service[action] = ctx.body[action];
                ctx.body = await configuration_1.config.updateConfig(ctx.service);
            }
            break;
        default:
            ctx.throw(400 /* EHttpCode.badRequest */);
            break;
    }
});
