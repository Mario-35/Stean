"use strict";
/**
 * createUpdateValues
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUpdateValues = createUpdateValues;
const constants_1 = require("../../constants");
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const log_1 = require("../../log");
function createUpdateValues(entity, input) {
    console.log(log_1.log.whereIam());
    return Object.keys(input)
        .map((elem) => `${(0, helpers_1.doubleQuotesString)(elem)} = ${input[elem][0] === "{" ? `${entity.columns[elem].dataType === enums_1.EDataType.result || enums_1.EDataType.jsonb ? "" : `COALESCE(${(0, helpers_1.doubleQuotesString)(elem)}, '{}'::jsonb) ||`} ${(0, helpers_1.simpleQuotesString)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(input[elem]))}::jsonb` : (0, helpers_1.simpleQuotesString)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(input[elem]))}`)
        .join();
}
