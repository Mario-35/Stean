"use strict";
/**
 * entity MultiDatastream
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MULTIDATASTREAM = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.MULTIDATASTREAM = new entity_1.Entity("MultiDatastreams", {
    createOrder: 8,
    type: enums_1.ETable.table,
    order: 2,
    columns: {
        id: new types_1.Bigint().generated("id").type(),
        name: new types_1.Text().notNull().type(),
        description: new types_1.Text().notNull().type(),
        unitOfMeasurements: new types_1.Jsonb().notNull().type(),
        observationType: new types_1.Text().notNull().default("http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement").verify(Object.keys(enums_1.EObservationType)).type(),
        multiObservationDataTypes: new types_1.Texts().type(),
        observedArea: new types_1.Geometry().type(),
        phenomenonTime: new types_1.Tmperiod("timestamp").source("Observations").coalesce("resultTime").type(),
        resultTime: new types_1.Tmperiod("timestamp").source("Observations").type(),
        thing_id: new types_1.Relation().relation("Things").type(),
        sensor_id: new types_1.Relation().relation("Sensors").type(),
        _default_featureofinterest: new types_1.Relation().relation("FeaturesOfInterest").default(1).type()
    },
    relations: {
        Thing: {
            type: enums_1.ERelations.belongsTo
        },
        Sensor: {
            type: enums_1.ERelations.belongsTo
        },
        Observations: {
            type: enums_1.ERelations.hasMany
        },
        ObservedProperties: {
            type: enums_1.ERelations.hasMany,
            entityRelation: "MultiDatastreamObservedProperties"
        },
        Lora: {
            type: enums_1.ERelations.belongsTo
        },
        FeatureOfInterest: {
            type: enums_1.ERelations.defaultUnique
        }
    }
});
