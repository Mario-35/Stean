"use strict";
/**
 * userToken interface
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.blankUserToken = void 0;
exports.blankUserToken = { id: 0, username: "", password: "", PDCUAS: [false, false, false, false, false, false] };
