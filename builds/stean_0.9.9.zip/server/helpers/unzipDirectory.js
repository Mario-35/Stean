"use strict";
/**
 * unzipDirectory
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.unzipDirectory = unzipDirectory;
const adm_zip_1 = __importDefault(require("adm-zip"));
const log_1 = require("../log");
const enums_1 = require("../enums");
/**
 * unzip Zip file
 *
 * @param inputFilePath zip source file
 * @param outputFilePath destination folder
 * @returns boolean
 */
async function unzipDirectory(inputFilePath, outputDirectory) {
    const zip = new adm_zip_1.default(inputFilePath);
    return new Promise((resolve, reject) => {
        zip.extractAllToAsync(outputDirectory, true, true, (error) => {
            if (error) {
                console.log(error);
                reject(error);
            }
            else {
                process.stdout.write(log_1.log.update(`Extracted to "${outputDirectory}" successfully` + enums_1.EConstant.return));
                resolve(true);
            }
        });
    });
}
