"use strict";
/**
 * promiseBlindExecute
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.promiseBlindExecute = promiseBlindExecute;
const child_process_1 = require("child_process");
/**
 * A promise wrapper for the child-process spawn function. Does not listen for results.
 * @param command - The command to execute.
 * @param waitTime - milisecond to wait
 */
async function promiseBlindExecute(command, waitTime) {
    return new Promise(function (resolve, reject) {
        (0, child_process_1.spawn)(command, [], { shell: true, detached: true });
        setTimeout(resolve, waitTime);
    });
}
