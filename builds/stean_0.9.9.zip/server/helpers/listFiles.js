"use strict";
/**
 * listFiles
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.listFiles = listFiles;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
/**
 *
 * @param source directory to search
 * @param extension file extenson
 * @returns Array of files
 */
function listFiles(source, extension) {
    const result = [];
    fs_1.default.readdirSync(path_1.default.join(source))
        .filter((e) => e.endsWith(`.${extension}`))
        .forEach((file) => {
        result.push(file);
    });
    return result;
}
