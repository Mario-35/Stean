"use strict";
/**
 * zipDirectory
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.zipDirectory = zipDirectory;
const adm_zip_1 = __importDefault(require("adm-zip"));
const log_1 = require("../log");
const enums_1 = require("../enums");
/**
 * Create Zip from a folder
 *
 * @param sourceDir folder path
 * @param outputFilePath destination file
 * @returns boolean
 */
async function zipDirectory(sourceDir, outputFilePath) {
    const zip = new adm_zip_1.default();
    zip.addLocalFolder(sourceDir);
    try {
        await zip.writeZipPromise(outputFilePath);
        return true;
    }
    catch (error) {
        process.stdout.write(log_1.log.update(error + enums_1.EConstant.return));
    }
    return false;
}
