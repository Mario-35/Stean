"use strict";
/**
 * Configuration class
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
const constants_1 = require("../constants");
const helpers_1 = require("../helpers");
const messages_1 = require("../messages");
const __1 = require("..");
const enums_1 = require("../enums");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const postgres_1 = __importDefault(require("postgres"));
const log_1 = require("../log");
const createDb_1 = require("../db/createDb");
const dataAccess_1 = require("../db/dataAccess");
const helpers_2 = require("./helpers");
const mqtt_1 = require("../mqtt");
const helpers_3 = require("../db/helpers");
const models_1 = require("../models");
const update_1 = require("../update");
const paths_1 = require("../paths");
const trace_1 = require("../log/trace");
const constants_2 = require("../db/constants");
/**
 * Class to create configs environements
 */
class Configuration {
    // store all services
    static services = {};
    static adminConnection;
    static MqttServer;
    static listenPorts = [];
    static appVersion = "";
    static remoteVersion;
    static upToDate = true;
    trace;
    constructor() {
        // override console log for TDD important in production build will remove all console.log
        if ((0, helpers_1.isTest)()) {
            console.log = (data) => { };
            this.readConfigFile();
        }
        else
            console.log = (data) => {
                if (data)
                    this.writeLog(data);
            };
    }
    createServiceTable() {
        return `CREATE TABLE public.services (
      "name" text NOT NULL,
      "datas" jsonb NULL,
      "stats" jsonb NULL,
      CONSTRAINT services_unik_name UNIQUE (name)
    ); CREATE INDEX services_name ON public.services USING btree (name);`;
    }
    version() {
        return Configuration.appVersion;
    }
    remoteVersion() {
        return Configuration.remoteVersion;
    }
    upToDate() {
        return Configuration.upToDate;
    }
    async updateService(input, fromInside) {
        if (input.name !== enums_1.EConstant.admin)
            return this.connection(input.name)
                .unsafe(models_1.models.getStats(input))
                .then(async (res) => {
                const datas = `UPDATE public.services SET stats = ${(0, constants_2.FORMAT_JSONB)(res[0].results[0])} WHERE name = '${input.name}'`;
                Configuration.services[input.name]._stats = res[0].results[0];
                return await this.adminConnection()
                    .unsafe(datas)
                    .then((e) => true)
                    .catch((err) => {
                    return (0, constants_1.logDbError)(err);
                });
            })
                .catch(async (err) => {
                if (!fromInside && (0, helpers_1.isTest)() === false && input.name === enums_1.EConstant.test && err.code == "3D000") {
                    await (0, helpers_3.createService)(input, createDb_1.testDatas);
                    return this.updateService(input, true);
                }
                console.log(err);
                return false;
            });
        return false;
    }
    async addService(input) {
        if (input && input.name === enums_1.EConstant.admin)
            return false;
        const datas = `INSERT INTO public.services ("name", "datas") VALUES('${input.name}', ${(0, constants_2.FORMAT_JSONB)(input)}) ON CONFLICT DO NOTHING;`;
        return await this.adminConnection()
            .unsafe(datas)
            .then((e) => true)
            .catch(async (error) => {
            console.log(error);
            if (error.code === "42P01") {
                return await this.adminConnection()
                    .unsafe(this.createServiceTable())
                    .then(async (e) => {
                    return await this.adminConnection()
                        .unsafe(datas)
                        .then((e) => true);
                })
                    .catch(async (err) => {
                    if (err.code === "42P07") {
                        return await this.adminConnection()
                            .unsafe(datas)
                            .then((e) => true);
                    }
                    else {
                        process.stdout.write(err + enums_1.EConstant.return);
                        return false;
                    }
                });
            }
            else if (error.code === "23505") {
                return true;
            }
            else {
                console.log(error);
                console.log(datas);
                process.stdout.write(error + enums_1.EConstant.return);
                return false;
            }
        });
    }
    /**
     * log message of listening
     *
     * @param what messace log
     * @param port port number
     * @param db show db infos
     */
    messageListen(what, port, db) {
        if (db)
            this.writeLog(log_1.log.booting(`${(0, enums_1.color)(35 /* EColor.Magenta */)}${messages_1.info.db} => ${(0, enums_1.color)(33 /* EColor.Yellow */)}${what}${(0, enums_1.color)(39 /* EColor.Default */)} ${messages_1.info.onLine}`, port));
        else
            this.writeLog(log_1.log.booting(`${(0, enums_1.color)(33 /* EColor.Yellow */)}${what}${(0, enums_1.color)(33 /* EColor.Yellow */)} ${(0, enums_1.color)(32 /* EColor.Green */)}${messages_1.info.listenPort}`, port));
    }
    /**
     * Override console log
     *
     * @param input
     */
    writeLog(input) {
        if (input) {
            process.stdout.write(input + enums_1.EConstant.return);
            paths_1.paths.logFile.writeStream((0, helpers_1.logToHtml)(input));
        }
    }
    /**
     * Read string (or default configuration file) as configuration file
     *
     * @param input
     * @returns true if it's done
     */
    async readConfigFile(input) {
        this.writeLog(`${(0, enums_1.color)(31 /* EColor.Red */)}${"▬".repeat(24)} ${(0, enums_1.color)(36 /* EColor.Cyan */)} ${`START ${enums_1.EConstant.appName} ${messages_1.info.ver} : ${constants_1.appVersion} [${process.env.NODE_ENV}]`} ${(0, enums_1.color)(37 /* EColor.White */)} ${new Date().toLocaleDateString()} : ${(0, constants_1.timestampNow)()} ${(0, enums_1.color)(31 /* EColor.Red */)} ${"▬".repeat(24)}${(0, enums_1.color)(0 /* EColor.Reset */)}`);
        log_1.log.newLog(log_1.log.message("Root", paths_1.paths.root));
        this.writeLog(log_1.log.message((0, messages_1.infos)(["read", "config"]), input ? "content" : paths_1.paths.configFile.fileName));
        try {
            // load File
            const fileContent = input || fs_1.default.readFileSync(paths_1.paths.configFile.fileName, "utf8");
            if (fileContent.trim() === "") {
                log_1.log.error((0, messages_1.msg)(messages_1.errors.fileEmpty, paths_1.paths.configFile.fileName), paths_1.paths.configFile.fileName);
                process.exit(111);
            }
            // decrypt file
            Configuration.services = JSON.parse((0, helpers_1.decrypt)(fileContent));
            const infosAdmin = Configuration.services[enums_1.EConstant.admin].pg;
            Configuration.adminConnection = (0, postgres_1.default)(`postgres://${infosAdmin.user}:${infosAdmin.password}@${infosAdmin.host}:${infosAdmin.port || 5432}/${enums_1.EConstant.pg}`, {
                debug: constants_1._DEBUG,
                connection: {
                    application_name: `${enums_1.EConstant.appName} ${constants_1.appVersion}`
                }
            });
            try {
                if (!(0, helpers_1.isTest)())
                    await this.adminConnection()
                        .unsafe("SELECT * FROM services")
                        .then((res) => {
                        res.forEach((element) => {
                            Configuration.services[element["name"]] = element["datas"];
                        });
                    });
            }
            catch (error) {
                console.log(error);
                if (error.code === "42P01")
                    await this.adminConnection()
                        .unsafe(this.createServiceTable())
                        .catch((e) => {
                        console.log(this.createServiceTable());
                        log_1.log.error(messages_1.errors.serviceCreateError);
                        process.exit(112);
                    });
            }
            if ((0, helpers_2.validJSONService)(Configuration.services)) {
                if ((0, helpers_1.isTest)() === true) {
                    Configuration.services[enums_1.EConstant.admin] = this.formatConfig(enums_1.EConstant.admin);
                    Configuration.services[enums_1.EConstant.test] = this.formatConfig(createDb_1.testDatas["create"]);
                }
                else {
                    Object.keys(Configuration.services).forEach(async (element) => {
                        Configuration.services[element] = this.formatConfig(element);
                        await this.addService(Configuration.services[element]);
                        await this.updateService(Configuration.services[element]);
                    });
                }
            }
            else {
                log_1.log.error(messages_1.errors.configFileError);
                process.exit(112);
            }
            // rewrite file (to update config modification except in test mode)
            if (!(0, helpers_1.isTest)() && exports.config.configFileExist() === false)
                this.writeConfig();
        }
        catch (error) {
            console.log(error);
            log_1.log.error(messages_1.errors.configFileError, error["message"]);
            process.exit(111);
        }
        this.trace = new trace_1.Trace(Configuration.adminConnection);
        return true;
    }
    /**
     *
     * @returns http port number
     */
    defaultHttp() {
        return Configuration.services[enums_1.EConstant.admin] && Configuration.services[enums_1.EConstant.admin].ports ? Configuration.services[enums_1.EConstant.admin].ports?.http || 8029 : 8029;
    }
    /** Initialivze mqtt */
    initMqtt() {
        Configuration.MqttServer = new mqtt_1.MqttServer({
            wsPort: Configuration.services[enums_1.EConstant.admin].ports?.ws || 1883,
            tcpPort: Configuration.services[enums_1.EConstant.admin].ports?.tcp || 9000
        });
    }
    /**
     *
     * @returns broker id
     */
    getBrokerId() {
        return Configuration.MqttServer.broker.id;
    }
    /**
     * Test if config file exists
     *
     * @returns configuration file present
     */
    configFileExist() {
        return fs_1.default.existsSync(paths_1.paths.configFile.fileName);
    }
    /**
     * Return infos of a service
     *
     * @param 1
     * @param name service name
     * @returns infos as IserviceInfos
     */
    getInfos = (ctx, name) => {
        const protocol = ctx.request.headers["x-forwarded-proto"] ? ctx.request.headers["x-forwarded-proto"].toString() : Configuration.services[name].options.includes(enums_1.EOptions.forceHttps) ? "https" : ctx.protocol;
        // make linkbase
        let linkBase = ctx.request.headers["x-forwarded-host"] ? `${protocol}://${ctx.request.headers["x-forwarded-host"].toString()}` : ctx.request.header.host ? `${protocol}://${ctx.request.header.host}` : "";
        // make rootName
        if (!linkBase.includes(name))
            linkBase += "/" + name;
        const version = Configuration.services[name].apiVersion || undefined;
        return {
            protocol: protocol,
            linkBase: linkBase,
            version: version || "",
            root: process.env.NODE_ENV?.trim() === enums_1.EConstant.test ? `proxy/${version || ""}` : `${linkBase}/${version || ""}`,
            model: version ? `https://app.diagrams.net/?lightbox=1&edit=_blank#U${linkBase}/${version}/draw` : "",
            service: {
                apiVersion: Configuration.services[name].apiVersion || "",
                date_format: Configuration.services[name].date_format,
                nb_page: Configuration.services[name].nb_page,
                extensions: Configuration.services[name].extensions,
                options: Configuration.services[name].options,
                synonyms: Configuration.services[name].synonyms,
                csvDelimiter: Configuration.services[name].csvDelimiter
            },
            stats: Configuration.services[name]._stats || JSON.parse("{}"),
            users: JSON.parse("{}")
        };
    };
    /**
     * Return infos for all services
     *
     * @param ctx koa context
     * @param name service name
     * @returns infos as IserviceInfos
     */
    getInfosForAll(ctx) {
        const result = {};
        this.getServicesNames().forEach((conf) => {
            result[conf] = this.getInfos(ctx, conf);
        });
        return result;
    }
    /**
     *
     * @param name service name
     * @returns service.
     */
    getService(name) {
        return Configuration.services[name];
    }
    /**
     *
     * @returns service names
     */
    getServicesNames() {
        return Object.keys(Configuration.services).filter((e) => e !== enums_1.EConstant.admin);
    }
    /**
     * Write an encrypt config file in json file
     *
     * @param input admin config file
     * @returns true if it's done
     */
    async initConfig(input) {
        this.writeLog(log_1.log.message((0, messages_1.infos)(["read", "config"]), paths_1.paths.configFile.fileName));
        return await this.readConfigFile(input);
    }
    /**
     * Write an encrypt config file in json file
     *
     * @returns true if it's done
     */
    writeConfig(input) {
        this.writeLog(log_1.log.message((0, messages_1.infos)(["write", "config"]), paths_1.paths.configFile.fileName));
        const datas = input ? JSON.stringify(input, null, 4) : JSON.stringify({ admin: Configuration.services[enums_1.EConstant.admin] }, null, 4);
        return this.writeFile(paths_1.paths.configFile.fileName, (0, helpers_1.isProduction)() === true ? (0, helpers_1.encrypt)(datas) : datas);
    }
    /**
     * Execute one query
     *
     * @param service service
     * @param query query
     * @returns result postgres.js object
     */
    async executeOneSql(service, query) {
        this.writeLog(log_1.log.query(query));
        return new Promise(async function (resolve, reject) {
            await exports.config
                .connection(service.name)
                .unsafe(query)
                .then((res) => {
                resolve(res);
            })
                .catch((err) => {
                if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                    exports.config.writeLog(log_1.log.queryError(query, err));
                reject(err);
            });
        });
    }
    /**
     * Execute multiple queries
     *
     * @param service service
     * @param query query
     * @returns result postgres.js object
     */
    async executeMultiSql(service, query) {
        this.writeLog(log_1.log.query(query));
        return new Promise(async function (resolve, reject) {
            await exports.config
                .connection(service.name)
                .begin((sql) => query.map((e) => sql.unsafe(e)))
                .then((res) => {
                resolve(res);
            })
                .catch((err) => {
                if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                    exports.config.writeLog(log_1.log.queryError(query, err));
                reject(err);
            });
        });
    }
    /**
     *
     * @param service service or service name
     * @param query one or multiple queries
     * @returns result postgres.js object
     */
    async executeSql(service, query) {
        service = typeof service === "string" ? Configuration.services[service] : service;
        return typeof query === "string" ? this.executeOneSql(service, query) : this.executeMultiSql(service, query);
    }
    /**
     *
     * @param query query
     * @returns result postgres.js object
     */
    async executeAdmin(query) {
        this.writeLog(log_1.log.query(query));
        return new Promise(async function (resolve, reject) {
            await exports.config
                .adminConnection()
                .unsafe(query)
                .then((res) => {
                resolve(res);
            })
                .catch((err) => {
                reject(err);
            });
        });
    }
    /**
     *
     * @param service service or service name
     * @param query one or multiple queries
     * @returns result postgres.js object values
     */
    async executeSqlValues(service, query) {
        this.writeLog(log_1.log.query(query));
        if (typeof query === "string") {
            return new Promise(async function (resolve, reject) {
                await exports.config
                    .connection(typeof service === "string" ? service : service.name)
                    .unsafe(query)
                    .values()
                    .then((res) => {
                    resolve(res[0]);
                })
                    .catch((err) => {
                    if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                        exports.config.writeLog(log_1.log.queryError(query, err));
                    reject(err);
                });
            });
        }
        else {
            return new Promise(async function (resolve, reject) {
                let result = {};
                await (0, helpers_1.asyncForEach)(query, async (sql) => {
                    await exports.config
                        .connection(typeof service === "string" ? service : service.name)
                        .unsafe(sql)
                        .values()
                        .then((res) => {
                        result = { ...result, ...res[0] };
                    })
                        .catch((err) => {
                        if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                            exports.config.writeLog(log_1.log.queryError(query, err));
                        reject(err);
                    });
                });
                resolve(result);
            });
        }
    }
    /**
     *
     * @param string
     * @returns Hash code number
     */
    // private hashCode(s: string): number {
    //     return s.split("").reduce((a, b) => {
    //         a = (a << 5) - a + b.charCodeAt(0);
    //         return a & a;
    //     }, 0);
    // }
    /**
     *
     * @param name connection name
     * @returns postgres postgres.js
     */
    connection(name) {
        if (!Configuration.services[name]._connection)
            this.createDbConnectionFromConfigName(name);
        return Configuration.services[name]._connection || this.createDbConnection(Configuration.services[name].pg);
    }
    /**
     *
     * @returns return postgres.js connection with admin rights
     */
    adminConnection() {
        return Configuration.adminConnection;
    }
    /**
     *
     * @param input IdbConnection
     * @returns return postgres.js connection (psql connect string)
     */
    createDbConnection(input) {
        return (0, postgres_1.default)(`postgres://${input.user}:${input.password}@${input.host}:${input.port || 5432}/${input.database}`, {
            debug: true,
            max: 2000,
            connection: {
                application_name: `${enums_1.EConstant.appName} ${constants_1.appVersion}`
            }
        });
    }
    /**
     *
     * @param input connection string name
     * @returns return postgres.js connection (psql connect string)
     */
    createDbConnectionFromConfigName(input) {
        const temp = this.createDbConnection(Configuration.services[input].pg);
        Configuration.services[input]._connection = temp;
        return temp;
    }
    /**
     *
     * @param connection name
     * @returns true if it's done
     */
    async reCreatePgFunctions(connection) {
        await (0, helpers_1.asyncForEach)((0, createDb_1.pgFunctions)(), async (query) => {
            const name = query.split(" */")[0].split("/*")[1].trim();
            await exports.config
                .connection(connection)
                .unsafe(query)
                .then(() => {
                log_1.log.create(`[${connection}] ${name}`, "\u2714\uFE0F\uFE0F" /* EChar.ok */);
            })
                .catch((error) => {
                console.log(error);
                return false;
            });
        });
        this.writeLog(log_1.log.message(messages_1.info.createFunc, connection));
        return true;
    }
    /**
     *
     * @param port listening port
     * @param message messagu info
     */
    addListening(port, message) {
        if (Configuration.listenPorts.includes(port))
            this.messageListen(`ADD ${message}`, String(port));
        else
            __1.app.listen(port, () => {
                Configuration.listenPorts.push(port);
                this.messageListen(message, String(port));
            });
    }
    /**
     * initialize configuration class
     *
     * @param input specific config file
     * @returns true if it's done
     */
    async initialisation(input) {
        const temp = await update_1.autoUpdate.compareVersions();
        Configuration.appVersion = temp.appVersion;
        Configuration.remoteVersion = temp.remoteVersion || "";
        Configuration.upToDate = temp.upToDate;
        if (this.configFileExist() === true || input) {
            await this.readConfigFile(input);
            console.log(log_1.log.message(messages_1.info.config, messages_1.info.loaded + " " + "\u2714\uFE0F\uFE0F" /* EChar.ok */));
            let status = true;
            await (0, helpers_1.asyncForEach)(
            // Start connection ALL entries in config file
            Object.keys(Configuration.services).filter((e) => e.toUpperCase() !== enums_1.EConstant.test.toUpperCase()), async (key) => {
                try {
                    await this.addToServer(key);
                }
                catch (error) {
                    console.log(error);
                    status = false;
                }
            });
            this.writeLog(log_1.log._head("mqtt"));
            this.initMqtt();
            (0, constants_1.setReady)(status);
            // note that is executed without async to not block start processus
            // if (!isTest()) {
            //     if (await testDbExists(Configuration.services[EConstant.admin].pg, EConstant.test)) {
            //         Configuration.services[EConstant.test] = this.formatConfig(testDatas["create"]);
            //     } else await createService(ctx, testDatas);
            //     this.messageListen(EConstant.test, String(this.defaultHttp()), true);
            // }
            this.writeLog(log_1.log._head("Ready", "\u2714\uFE0F\uFE0F" /* EChar.ok */));
            this.writeLog(log_1.log.logo(constants_1.appVersion));
            return status;
            // no configuration file so First install
        }
        else {
            console.log(log_1.log.message("file", paths_1.paths.configFile.fileName + " " + "\u274C" /* EChar.notOk */));
            this.addListening(this.defaultHttp(), "First launch");
            return true;
        }
    }
    /**
     * return config name from databse name
     *
     * @param input config to search
     * @returns config name or undefined
     */
    getConfigNameFromDatabase(input) {
        if (input !== "all") {
            const aliasName = Object.keys(Configuration.services).filter((configName) => Configuration.services[configName].pg.database === input)[0];
            if (aliasName)
                return aliasName;
            throw new Error(`No configuration found for ${input} name`);
        }
    }
    /**
     * return config name from config name
     *
     * @param input config to search
     * @returns config name or undefined
     */
    getConfigNameFromName(name) {
        if (name) {
            if (Object.keys(Configuration.services).includes(name))
                return name;
            Object.keys(Configuration.services).forEach((configName) => {
                if (Configuration.services[configName].alias.includes(name))
                    return configName;
            });
        }
    }
    /**
     * Return Iservice Formated for Iservice object or name found in json file
     *
     * @param input config nome to search
     * @param name name of the config (if format)
     * @returns
     */
    formatConfig(input, name) {
        if (typeof input === "string") {
            name = input;
            input = Configuration.services[input];
        }
        const goodDbName = name ? name : input["pg"] && input["pg"]["database"] ? input["pg"]["database"] : `ERROR`;
        return (0, helpers_2.formatServiceFile)(goodDbName, input);
    }
    /**
     * Add config to configuration file
     *
     * @param addJson service JSON
     * @returns formated service
     */
    async addConfig(addJson) {
        try {
            const formatedConfig = this.formatConfig(addJson);
            if (Configuration.services[formatedConfig.name]) {
                throw new Error(`Same configuration name found for ${formatedConfig.name}`);
            }
            Configuration.services[formatedConfig.name] = formatedConfig;
            if (!(0, helpers_1.isTest)()) {
                // In TDD not create service
                await this.addToServer(formatedConfig.name);
                this.addService(Configuration.services[formatedConfig.name]);
            }
            return formatedConfig;
        }
        catch (error) {
            return undefined;
        }
    }
    /**
     * Process to add an entry in server
     *
     * @param key name
     * @returns true if it's ok
     */
    async addToServer(key) {
        this.writeLog(log_1.log._head(key));
        return await this.isServiceExist(key, true)
            .then(async (res) => {
            if (res === true) {
                await dataAccess_1.userAccess.post(key, {
                    username: Configuration.services[key].pg.user,
                    email: "steandefault@email.com",
                    password: Configuration.services[key].pg.password,
                    database: Configuration.services[key].pg.database,
                    canPost: true,
                    canDelete: true,
                    canCreateUser: true,
                    canCreateDb: true,
                    superAdmin: false,
                    admin: false
                });
                if (![enums_1.EConstant.admin, enums_1.EConstant.test].includes(key))
                    (0, helpers_3.updateIndexes)(key);
                if (!Configuration.services[key].extensions.includes(enums_1.EExtensions.file) && ![enums_1.EConstant.admin, enums_1.EConstant.test].includes(key))
                    (0, helpers_3.updateIndexes)(key);
                this.messageListen(key, res ? "\uD83C\uDF0D" /* EChar.web */ : "\u274C" /* EChar.notOk */, true);
                this.addListening(this.defaultHttp(), key);
            }
            return res;
        })
            .catch((error) => {
            log_1.log.error(messages_1.errors.unableFindCreate, Configuration.services[key].pg.database);
            console.log(error);
            process.exit(111);
        });
    }
    /**
     *
     * @returns JSON service create
     */
    async export() {
        return await this.adminConnection()
            .unsafe("SELECT datas FROM services")
            .then((res) => {
            const fileContent = fs_1.default.readFileSync(paths_1.paths.configFile.fileName, "utf8");
            const result = JSON.parse((0, helpers_1.decrypt)(fileContent));
            res.forEach((e) => {
                result[e["datas"]["name"]] = e["datas"];
            });
            this.writeConfig(result);
            return (0, helpers_1.hidePassword)(result);
        });
    }
    /**
     * Create dataBase
     *
     * @param serviceName service name
     * @returns true if it's done
     */
    async createDB(connectName) {
        this.writeLog(log_1.log.booting(messages_1.info.try, Configuration.services[connectName].pg.database));
        return await (0, createDb_1.createDatabase)(connectName)
            .then(async () => {
            this.writeLog(log_1.log.booting(`${messages_1.info.db} ${messages_1.info.create} [${Configuration.services[connectName].pg.database}]`, "\u2714\uFE0F\uFE0F" /* EChar.ok */));
            this.createDbConnectionFromConfigName(connectName);
            return true;
        })
            .catch((err) => {
            log_1.log.error((0, messages_1.msg)(messages_1.info.create, messages_1.info.db), err.message);
            return false;
        });
    }
    /**
     *
     * @param serviceName service name
     * @param create create if not exist
     * @returns true if it's done
     */
    async isServiceExist(serviceName, create) {
        this.writeLog(log_1.log.booting(messages_1.info.dbExist, Configuration.services[serviceName].pg.database));
        return await this.connection(serviceName) `select 1+1 AS result`
            .then(async () => {
            const listTempTables = await this.connection(serviceName) `SELECT array_agg(table_name) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME LIKE 'temp%';`;
            const tables = listTempTables[0]["array_agg"];
            if (tables != null)
                this.writeLog(log_1.log.booting(`DELETE temp table(s) ==> \x1b[33m${serviceName}\x1b[32m`, await this.connection(serviceName)
                    .begin((sql) => {
                    tables.forEach(async (table) => {
                        await sql.unsafe(`DROP TABLE ${table}`);
                    });
                })
                    .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
                    .catch((err) => err.message)));
            await this.reCreatePgFunctions(serviceName);
            return true;
        })
            .catch(async (error) => {
            // Password authentication failed
            if (error["code"] === "ECONNREFUSED") {
                log_1.log.error(error);
            }
            else if (error["code"] === "28P01") {
                if (!(0, helpers_1.isTest)())
                    return await this.createDB(serviceName);
                // Database does not exist
            }
            else if (error["code"] === "3D000" && create == true) {
                console.log(log_1.log._infos((0, messages_1.msg)(messages_1.info.tryCreate, messages_1.info.db), Configuration.services[serviceName].pg.database));
                if (serviceName !== enums_1.EConstant.test)
                    return await this.createDB(serviceName);
            }
            else
                console.log(error);
            return false;
        });
    }
    /**
     *
     * @param path ath with filename
     * @param content content to write
     * @returns true when its done
     */
    writeFile(path, content) {
        // in some case of crash config is blank so prevent to overrite it
        fs_1.default.writeFile(
        // encrypt only in production mode
        path, content, (error) => {
            if (error) {
                console.log(error);
                return false;
            }
        });
        return true;
    }
    /**
     * Write an encrypt config file in json file
     *
     * @returns true if it's done
     */
    saveConfig(myPath) {
        this.writeLog(log_1.log.message((0, messages_1.infos)(["write", "config"]), `in ${myPath}`));
        const datas = JSON.stringify({ admin: Configuration.services[enums_1.EConstant.admin] }, null, 4);
        if (this.writeFile(path_1.default.join(myPath, "configuration.json"), (0, helpers_1.isProduction)() === true ? (0, helpers_1.encrypt)(datas) : datas) === false)
            return false;
        if (this.writeFile(path_1.default.join(myPath, ".key"), paths_1.paths.key) === false)
            return false;
        return true;
    }
    /**
     * Write an encrypt config file in json file
     *
     * @returns true if it's done
     */
    async updateConfig(input) {
        if (input.name !== enums_1.EConstant.admin) {
            const datas = `UPDATE public.services SET "datas" = ${(0, constants_2.FORMAT_JSONB)(input)} WHERE "name" = '${input.name}'`;
            return await this.adminConnection()
                .unsafe(datas)
                .then((e) => true)
                .catch((err) => {
                return (0, constants_1.logDbError)(err);
            });
        }
        return false;
    }
}
exports.config = new Configuration();
