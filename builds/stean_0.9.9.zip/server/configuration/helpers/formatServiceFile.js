"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatServiceFile = formatServiceFile;
/**
 * formatServiceFile
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
const util_1 = __importDefault(require("util"));
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const messages_1 = require("../../messages");
/**
 *
 * @param name configuration name
 * @param input record of the configuration
 * @returns service
 */
function formatServiceFile(name, input) {
    const options = input["options"] ? (0, helpers_1.unique)([...String(input["options"]).split(",")]) : [];
    const extensions = input["extensions"] ? (0, helpers_1.unique)([...String(input["extensions"]).split(",")]) : ["base"];
    const version = name === enums_1.EConstant.admin ? "v1.1" : String(input["apiVersion"]).trim();
    // if (input["extensions"]["users"]) extensions.includes("users");
    const returnValue = {
        name: name,
        ports: name === enums_1.EConstant.admin
            ? {
                http: input["ports"]["http"] || 8029,
                tcp: input["ports"]["tcp"] || 9000,
                ws: input["ports"]["ws"] || 1883
            }
            : undefined,
        pg: {
            _ready: undefined,
            host: input["pg"] && input["pg"]["host"] ? String(input["pg"]["host"]) : `ERROR`,
            port: input["pg"] && input["pg"]["port"] ? input["pg"]["port"] : 5432,
            user: input["pg"] && input["pg"]["user"] ? input["pg"]["user"] : `ERROR`,
            password: input["pg"] && input["pg"]["password"] ? input["pg"]["password"] : `ERROR`,
            database: name && name === enums_1.EConstant.test ? enums_1.EConstant.test : input["pg"] && input["pg"]["database"] ? input["pg"]["database"] : `ERROR`,
            retry: input["retry"] ? +input["retry"] : 2
        },
        apiVersion: version,
        date_format: input["date_format"] || "DD/MM/YYYY hh:mi:ss",
        nb_page: input["nb_page"] ? +input["nb_page"] : 200,
        alias: input["alias"] ? (0, helpers_1.unikeList)(String(input["alias"]).split(",")) : [],
        extensions: extensions,
        options: options,
        csvDelimiter: input["csvDelimiter"] ? input["csvDelimiter"] : ";",
        synonyms: input["synonyms"] ? input["synonyms"] : undefined,
        _connection: undefined,
        _stats: undefined
    };
    if (Object.values(returnValue).includes("ERROR"))
        throw new TypeError(`${messages_1.errors.inConfigFile} [${util_1.default.inspect(returnValue, {
            showHidden: false,
            depth: null
        })}]`);
    return returnValue;
}
