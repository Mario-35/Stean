"use strict";
/**
 * createExtension.
 *
 * @copyright 2020-present Inrae
 * @review 27-01-2024
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createExtension = void 0;
const createExtension = (name) => `CREATE EXTENSION IF NOT EXISTS ${name}`;
exports.createExtension = createExtension;
