"use strict";
/**
 * asJson.
 *
 * @copyright 2020-present Inrae
 * @review 29-10-2024
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.asJson = void 0;
const enums_1 = require("../../enums");
const asJson = (input) => input.query.trim() === ""
    ? ""
    : `SELECT ${input.count == true ? `${input.fullCount ? `(${input.fullCount})` : "COUNT(t)"},${enums_1.EConstant.return}${enums_1.EConstant.tab}` : ""}${input.fields ? input.fields.join(`,${enums_1.EConstant.return}${enums_1.EConstant.tab}`) : ""}COALESCE(${input.singular === true ? "ROW_TO_JSON" : `${input.strip === true ? "JSON_STRIP_NULLS(" : ""} JSON_AGG`}(t)${input.strip === true ? ")" : ""}, '${input.singular === true ? "{}" : "[]"}') AS results${enums_1.EConstant.return}${enums_1.EConstant.tab}FROM (${enums_1.EConstant.return}${enums_1.EConstant.tab}${input.query}) AS t`;
exports.asJson = asJson;
