"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDbTest = void 0;
const createDb_1 = require("../createDb");
const createService_1 = require("./createService");
const createDbTest = async (ctx) => {
    try {
        ctx.body = await (0, createService_1.createService)(ctx.service, createDb_1.testDatas);
        ctx.status = 201 /* EHttpCode.created */;
    }
    catch (error) {
        console.log(error);
        ctx.status = 400 /* EHttpCode.badRequest */;
        ctx.redirect(`${ctx.decodedUrl.root}/error`);
    }
};
exports.createDbTest = createDbTest;
