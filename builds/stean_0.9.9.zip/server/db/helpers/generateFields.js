"use strict";
/**
 * generateFields
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateFields = void 0;
const helpers_1 = require("../../helpers");
const generateFields = (input) => {
    let fields = [];
    if ((0, helpers_1.isGraph)(input)) {
        const table = input.parentEntity ? input.parentEntity.table : input.entity ? input.entity.table : undefined;
        fields = table ? [`(SELECT ${table}."description" FROM ${table} WHERE ${table}."id" = ${input.parentId ? input.parentId : input.id}) AS title, `] : [];
    }
    return fields;
};
exports.generateFields = generateFields;
