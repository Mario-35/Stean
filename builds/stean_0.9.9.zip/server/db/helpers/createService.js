"use strict";
/**
 * createService
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createService = void 0;
const _1 = require(".");
const configuration_1 = require("../../configuration");
const helpers_1 = require("../../helpers");
const models_1 = require("../../models");
const helpers_2 = require("../../models/helpers");
const log_1 = require("../../log");
/**
 *
 * @param ctx koa context
 * @param dataInput input key values
 * @returns result postgres.js object
 */
const createService = async (service, dataInput) => {
    console.log(log_1.log.whereIam());
    const prepareDatas = (dataInput, entity) => {
        if (entity === "Observations") {
            if (!dataInput["resultTime"] && dataInput["phenomenonTime"])
                dataInput["resultTime"] = dataInput["phenomenonTime"];
            if (!dataInput["phenomenonTime"] && dataInput["resultTime"])
                dataInput["phenomenonTime"] = dataInput["resultTime"];
        }
        return dataInput;
    };
    if (dataInput && dataInput["create"]) {
        configuration_1.config.addConfig(dataInput["create"]);
    }
    const results = {};
    const newServiceName = dataInput["create"]["name"];
    const newService = configuration_1.config.getService(newServiceName);
    const mess = `Database [${newServiceName}]`;
    try {
        await (0, _1.disconnectDb)(newServiceName, true);
        results[`Drop ${mess}`] = "\u2714\uFE0F\uFE0F" /* EChar.ok */;
    }
    catch (error) {
        results[`Drop ${mess}`] = "\u274C" /* EChar.notOk */;
        console.log(error);
    }
    try {
        await (0, _1.createDatabase)(newServiceName);
        results[`Create ${mess}`] = "\u2714\uFE0F\uFE0F" /* EChar.ok */;
    }
    catch (error) {
        results[`Create ${mess}`] = "\u274C" /* EChar.notOk */;
        console.log(error);
    }
    const tmp = models_1.models.filtered(newService);
    await (0, helpers_1.asyncForEach)(Object.keys(tmp)
        .filter((elem) => tmp[elem].createOrder > 0)
        .sort((a, b) => (tmp[a].createOrder > tmp[b].createOrder ? 1 : -1)), async (entityName) => {
        if (dataInput[entityName]) {
            const goodEntity = models_1.models.getEntity(newService, entityName);
            if (goodEntity) {
                try {
                    const sqls = dataInput[entityName].map((element) => `INSERT INTO ${(0, helpers_1.doubleQuotesString)(goodEntity.table)} ${(0, helpers_2.createInsertValues)(service, prepareDatas(element, goodEntity.name), goodEntity.name)}`);
                    await configuration_1.config
                        .executeSqlValues(configuration_1.config.getService(newServiceName), sqls.join(";"))
                        .then((res) => {
                        results[entityName] = "\u2714\uFE0F\uFE0F" /* EChar.ok */;
                    })
                        .catch((error) => {
                        console.log(error);
                        results[entityName] = "\u274C" /* EChar.notOk */;
                    });
                }
                catch (error) {
                    console.log(error);
                    results[entityName] = "\u274C" /* EChar.notOk */;
                }
            }
        }
    });
    return results;
};
exports.createService = createService;
