"use strict";
/**
 * getAuthenticatedUser
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAuthenticatedUser = void 0;
const _1 = require(".");
const dataAccess_1 = require("../db/dataAccess");
const enums_1 = require("../enums");
const helpers_1 = require("../helpers");
const log_1 = require("../log");
const helpers_2 = require("../views/helpers/");
/**
 * return Iuser from koa context
 * @param ctx koaContext
 * @returns Iuser
 */
const getAuthenticatedUser = async (ctx) => {
    console.log(log_1.log.whereIam());
    if (!ctx.service.extensions.includes(enums_1.EExtensions.users))
        return (0, helpers_2.blankUser)(ctx.service);
    const token = (0, _1.decodeToken)(ctx);
    if (token && token.id > 0) {
        const user = await dataAccess_1.userAccess.getSingle(ctx.service.name, token.id);
        if (user && token.password.match((0, helpers_1.decrypt)(user["password"])) !== null)
            return Object.freeze(user);
    }
    return undefined;
};
exports.getAuthenticatedUser = getAuthenticatedUser;
