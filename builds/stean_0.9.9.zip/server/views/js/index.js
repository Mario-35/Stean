"use strict";
/**
 * Index Js.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.listaddJsFiles = exports.addJsFile = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const addJsFile = (name) => (fs_1.default.existsSync(path_1.default.join(__dirname, "/", name)) ? fs_1.default.readFileSync(path_1.default.join(__dirname, "/", name), "utf-8") : fs_1.default.readFileSync(path_1.default.join(__dirname, "/", name.replace(".js", ".min.js")), "utf-8"));
exports.addJsFile = addJsFile;
const listaddJsFiles = () => {
    const result = [];
    fs_1.default.readdirSync(path_1.default.join(__dirname))
        .filter((e) => e.endsWith(".js"))
        .forEach((file) => {
        result.push(file);
    });
    return result;
};
exports.listaddJsFiles = listaddJsFiles;
