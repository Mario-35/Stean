var __importDefault=this&&this.__importDefault||function(t){return t&&t.__esModule?t:{default:t}};Object.defineProperty(exports,"__esModule",{value:!0}),exports.HtmlLogs=void 0;let paths_1=require("../../paths"),core_1=require("./core"),fs_1=__importDefault(require("fs"));class HtmlLogs extends core_1.CoreHtmlView{constructor(t,e){var o=fs_1.default.readFileSync(paths_1.paths.root+"logs\\"+e.url,"utf8");super(t,e),this.logs(o)}logs(t){this._HTMLResult=[`
        <!DOCTYPE html>
            <html>
                <body style="background-color:#353535;">
                    ${t}
                </body>
            </html>`]}}exports.HtmlLogs=HtmlLogs;