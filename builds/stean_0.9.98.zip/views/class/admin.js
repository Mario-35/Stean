var __importDefault=this&&this.__importDefault||function(s){return s&&s.__esModule?s:{default:s}};Object.defineProperty(exports,"__esModule",{value:!0}),exports.Admin=void 0;let configuration_1=require("../../configuration"),enums_1=require("../../enums"),helpers_1=require("../../helpers"),log_1=require("../../log"),messages_1=require("../../messages"),models_1=require("../../models"),css_1=require("../css"),js_1=require("../js"),core_1=require("./core"),fs_1=__importDefault(require("fs")),path_1=__importDefault(require("path"));class Admin extends core_1.CoreHtmlView{login=!1;constructor(s,e){super(s,e),this.init()}init(){if(this.datas.connection)try{this.login=JSON.parse((0,helpers_1.decrypt)(this.datas.connection)).login}catch(s){this.login=!1}!0===this.login?this.adminHtml():this.loginHtml()}loginHtml(){var s=s=>this.datas.why&&this.datas.why[s]?`<div class="alert">${this.datas.why[s]}</div>`:"";this._HTMLResult=["<!DOCTYPE html>","<html>",this.head("Login"),"<body>",'<div class="login-wrap">','<div class="login-html" color="#FF0000">',this.title("Admin Access"),'<input id="tab-1" type="radio" name="tab" class="sign-in" checked>',`<label for="tab-1" class="tab">${messages_1.info.pg} Admin</label>`,'<input id="tab-2" type="radio" name="tab" class="sign-up">','<label for="tab-2" class="tab">Help</label>','<div class="login-form">','<form action="/admin" method="post">','<div class="sign-in-htm">',this.datas.connection?this.addHidden("_connection",this.datas.connection):"",this.addTextInput({name:"host",label:messages_1.info.host,value:this.datas.body&&this.datas.body.host||enums_1.EConstant.host,alert:s("host")}),this.addTextInput({name:"port",label:messages_1.info.pg+" port",value:this.datas.body&&this.datas.body.port||enums_1.EConstant.port,alert:s("port")}),this.addTextInput({name:"adminname",label:messages_1.info.user,value:this.datas.body&&this.datas.body.adminname||enums_1.EConstant.pg,alert:s("username")}),this.addTextInput({name:"adminpassword",label:messages_1.info.pass,password:!0,value:"",alert:s("password")}),this.addSubmitButton(messages_1.info.conn),this.datas.connection&&this.datas.connection.startsWith("[error]")?this.AddErrorMessage(this.datas.connection.split("[error]")[1]):"","</div> ",'<div class="sign-up-htm">',"<span>","You have to create configuration to start the API<br>","<br>","You have to put user admin postgresSql connection in PostgresSql Admin in tab above (This user must have right to create databases).<br>","<br>","When the connection test succed you can access admin tab.","</span>","</div>","</form>","</div>","</div>","</div>","</body>","</html>"]}adminHtml(){let t=configuration_1.config.getInfosForAll(this.ctx);var s=this.ctx.header.referer?.split("/"),s=(s&&(s[s.length-1]="service"),{addUrl:s?.join("/"),services:t,versions:models_1.models.listVersion().reverse().map(s=>s.replace("_",".")),extensions:(0,enums_1.enumKeys)(enums_1.EExtensions).filter(s=>!["file","base"].includes(s)),options:(0,enums_1.enumKeys)(enums_1.EOptions),users:{}});let e=s=>s.replace(".min",""),i=(this._HTMLResult=fs_1.default.readFileSync(path_1.default.resolve(__dirname,"../html/","admin.html")).toString().replace(/<link /g,"\n<link ").replace(/<script /g,"\n<script ").replace(/<\/script>/g,"<\/script>\n").replace(/\r\n/g,"\n").split("\n").map(s=>s.trim()).filter(s=>""!=s.trim()),(s,e)=>{var t=this._HTMLResult.indexOf(s);(0<t||0<(t=this._HTMLResult.indexOf((0,helpers_1.removeAllQuotes)(s))))&&(this._HTMLResult[t]=e)});(0,css_1.listaddCssFiles)().forEach(s=>{i(`<link rel="stylesheet" href="${e(s)}">`,`<style>${(0,css_1.addCssFile)(s)}</style>`)}),(0,js_1.listaddJsFiles)().forEach(s=>{i(`<script src="${e(s)}"></script>`,`<script>${(0,js_1.addJsFile)(s)}</script>`)});var n=Object.keys(t).filter(s=>s!==enums_1.EConstant.test).map(e=>`<div class="card">
                <div class="title">${e}</div>
                <button class="copy-btn" id="copy${e}" onclick="copyService('${e}')"> COPY </button>
  <div class="product">
    <span class="service-name">${t[e].version}</span>
    <span class="service-root" onclick="location.href = '${t[e].root}';">${t[e].root}</span>
  </div>
  <div class="description">
    <ul class="card-list">
    <li class="card-list-item icon-${t[e].service.options.includes(enums_1.EOptions.canDrop)?"yes":"no"}">canDrop</li>
    <li class="card-list-item icon-${t[e].service.options.includes(enums_1.EOptions.forceHttps)?"yes":"no"}">forceHttps</li>
    <li class="card-list-item icon-${t[e].service.options.includes(enums_1.EOptions.stripNull)?"yes":"no"}">stripNull</li>
    <li class="card-list-item icon-${t[e].service.options.includes(enums_1.EOptions.unique)?"yes":"no"}">unique</li>
    </ul>
<select id="infos${e}" size="4">
${t[e].service.extensions.map(s=>`<option value="${s}">${s}</option>`).join("\n")}
  </select>
  
  </div>
	<ul class="list" id="list${e}">
    ${Object.keys(t[e].stats).map(s=>`<li>${s} : ${t[e].stats[s]}</li>`).join("")}
	</ul>
  <div class="description">
    <span class="page" onclick="editPage('${e}', this)">${t[e].service.nb_page}</span>
    <span class="csv" onclick="editCsv('${e}', this)">${t[e].service.csvDelimiter}</span>
    <select class="patrom-select tabindex="1" name="marios" id="marios" onchange="selectChange('${e}', this)">
        <option selected="selected">Services</option>
        <option>Statistiques</option>
        <option>Users</option>
    </select>
  </div>
</div>`);this.replacers({cards:n.join("")}),this.replacer("_PARAMS={}","_PARAMS="+JSON.stringify(s,this.bigIntReplacer))}}exports.Admin=Admin;