"use strict";
/**
 * AutoUpdate
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.autoUpdate = void 0;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const child_process_1 = require("child_process");
const https_1 = __importDefault(require("https"));
const constants_1 = require("../constants");
const httpsDownload_1 = require("./helpers/httpsDownload ");
const log_1 = require("../log");
const adm_zip_1 = __importDefault(require("adm-zip"));
class AutoUpdate {
    repository = 'https://github.com/Mario-35/Stean';
    branch = 'main';
    exitOnComplete = true;
    async zipDirectory(sourceDir, outputFilePath) {
        const zip = new adm_zip_1.default();
        zip.addLocalFolder(sourceDir);
        await zip.writeZipPromise(outputFilePath);
        console.log(`Zip file created: ${outputFilePath}`);
    }
    ;
    async unzipDirectory(inputFilePath, outputDirectory) {
        const zip = new adm_zip_1.default(inputFilePath);
        return new Promise((resolve, reject) => {
            zip.extractAllToAsync(outputDirectory, true, true, (error) => {
                if (error) {
                    console.log(error);
                    reject(error);
                }
                else {
                    console.log(`Extracted to "${outputDirectory}" successfully`);
                    resolve();
                }
            });
        });
    }
    ;
    /**
     * Checks local version against the remote version & then updates if different.
     */
    async autoUpdate() {
        const versionCheck = await this.compareVersions();
        if (versionCheck.upToDate)
            return true;
        return await this.update();
    }
    /**
     * @typedef VersionResults
     * @param {Boolean} UpToDate - If the local version is the same as the remote version.
     * @param {String} appVersion - The version of the local application.
     * @param {String} remoteVersion - The version of the application in the git repository.
     *
     * Checks the local version of the application against the remote repository.
     * @returns {VersionResults} - An object with the results of the version comparison.
     */
    async compareVersions() {
        try {
            process.stdout.write(log_1.log.booting("Current version", constants_1.appVersion) + "\n");
            let remoteVersion = await this.readRemoteVersion();
            if (remoteVersion) {
                process.stdout.write(log_1.log.booting("Remote version", remoteVersion + "\n"));
                if (constants_1.appVersion != remoteVersion)
                    return { upToDate: false, appVersion: constants_1.appVersion, remoteVersion };
            }
            else
                return { upToDate: false, appVersion: 'Error', remoteVersion: 'Error' };
            return { upToDate: true, appVersion: constants_1.appVersion, remoteVersion };
        }
        catch (err) {
            process.stdout.write('Auto Git Update - Error comparing local and remote versions.' + "\n");
            process.stdout.write(err + "\n");
            return { upToDate: false, appVersion: 'Error', remoteVersion: 'Error' };
        }
    }
    /**
     * Clones the git repository, purges ignored files, and installs the update over the local application.
     * A backup of the application is created before the update is installed.
     * If configured, a completion command will be executed and the process for the app will be stopped.
     * @returns {Boolean} The result of the update.
     */
    async update(no) {
        if (no) {
            try {
                process.stdout.write('Auto Git Update - Updating application from ' + this.repository + "\n");
                if (await this.downloadUpdate() === true) {
                    await this.backupApp();
                    await this.installUpdate();
                    await this.installDependencies();
                    // process.stdout.write('Auto Git Update - Finished installing updated version.' + "\n");
                    await this.promiseBlindExecute("npm run dev");
                    process.exit(1);
                }
            }
            catch (err) {
                process.stdout.write('Auto Git Update - Error updating application' + "\n");
                process.stdout.write(err + "\n");
            }
        }
        return false;
    }
    /**
     * Creates a backup of the application, including node modules.
     * The backup is stored in the configured tempLocation. Only one backup is kept at a time.
     */
    async backupApp() {
        const dateFile = `${new Date().toLocaleDateString()}-${new Date().toLocaleTimeString()}`.split("/").join("").split(":").join("");
        await this.zipDirectory(constants_1.rootpath, constants_1.uploadPath + `/backup${dateFile}.zip`);
        process.stdout.write('Auto Git Update - Backing up app to ' + constants_1.uploadPath + "\n");
        return true;
    }
    /**
     * Downloads the update from the configured git repository.
     * The repo is cloned to the configured tempLocation.
     */
    async downloadUpdate() {
        return await (0, httpsDownload_1.httpsDownload)(this.repository + "/raw/main/builds/stean_latest.zip", 'update.zip').then(() => true);
    }
    /**
     * Runs npm install to update/install application dependencies.
     */
    installDependencies() {
        return new Promise(function (resolve, reject) {
            //If this.testing is enabled, use alternative path to prevent overwrite of app. 
            let destination = path_1.default.join(constants_1.rootpath + "/updateTest");
            process.stdout.write('Auto Git Update - Installing application dependencies in ' + destination);
            // Generate and execute command
            let command = `cd ${destination} && npm install`;
            let child = (0, child_process_1.exec)(command);
            // Wait for results
            child.stdout?.on('end', resolve);
            child.stdout?.on('data', data => process.stdout.write('Auto Git Update - npm install: ' + data.replace(/\r?\n|\r/g, '')));
            child.stderr?.on('data', data => {
                if (data.toLowerCase().includes('error')) {
                    // npm passes warnings as errors, only reject if "error" is included
                    data = data.replace(/\r?\n|\r/g, '');
                    process.stdout.write('Auto Git Update - Error installing dependencies' + "\n");
                    process.stdout.write('Auto Git Update - ' + data + "\n");
                    reject();
                }
                else {
                    process.stdout.write('Auto Git Update - ' + data + "\n");
                }
            });
        });
    }
    /**
     * Purge ignored files from the update, copy the files to the app directory, and install new modules
     * The update is installed from  the configured tempLocation.
     */
    async installUpdate() {
        let source = path_1.default.join(constants_1.uploadPath + '/update.zip');
        let destination = path_1.default.join(constants_1.rootpath + "/updateTest");
        await this.unzipDirectory(source, destination);
        process.stdout.write('Auto Git Update - Installing update...');
        process.stdout.write('Auto Git Update - Source: ' + source);
        process.stdout.write('Auto Git Update - Destination: ' + destination);
        fs_1.default.copyFile(constants_1.rootpath + "/configuration/.key", constants_1.rootpath + "/updateTest/configuration/.key", (err) => {
            if (err) {
                console.log("Error Found:", err);
                return false;
            }
        });
        fs_1.default.copyFile(constants_1.rootpath + "/configuration/configuration.json", constants_1.rootpath + "/updateTest/configuration/configuration.json", (err) => {
            if (err) {
                console.log("Error Found:", err);
                return false;
            }
        });
        return true;
    }
    /**
     * Reads the applications version from the git repository.
     */
    async readRemoteVersion() {
        try {
            await (0, httpsDownload_1.httpsDownload)(this.repository.replace('github.com', 'raw.githubusercontent.com') + `/refs/heads/${this.branch}/package.json`, "2package.json");
            return JSON.parse(fs_1.default.readFileSync(path_1.default.join(constants_1.uploadPath, "2package.json"), "utf-8")).version;
        }
        catch (error) {
            console.log(error);
        }
    }
    /**
     * A promise wrapper for the child-process spawn function. Does not listen for results.
     * @param {String} command - The command to execute.
     */
    promiseBlindExecute(command) {
        return new Promise(function (resolve, reject) {
            (0, child_process_1.spawn)(command, [], { shell: true, detached: true });
            setTimeout(resolve, 1000);
        });
    }
    /**
     * A promise wrapper for sending a get https requests.
     * @param {String} url - The Https address to request.
     * @param {String} options - The request options.
     */
    promiseHttpsRequest(url, options) {
        return new Promise(function (resolve, reject) {
            let req = https_1.default.request(url, options, res => {
                //Construct response
                let body = '';
                res.on('data', data => { body += data; });
                res.on('end', function () {
                    if (res && res.statusCode && res.statusCode === 200)
                        return resolve(body);
                    process.stdout.write('Auto Git Update - Bad Response ' + res.statusCode + "\n");
                    reject(res.statusCode);
                });
            });
            process.stdout.write('Auto Git Update - Sending request to ' + url + "\n");
            process.stdout.write('Auto Git Update - Options: ' + JSON.stringify(options) + "\n");
            req.on('error', reject);
            req.end();
        });
    }
    async sleep(time) {
        return new Promise(function (resolve, reject) {
            setTimeout(resolve, time);
        });
    }
}
exports.autoUpdate = new AutoUpdate();
