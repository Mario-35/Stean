"use strict";
/**
 * httpsDownload
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.httpsDownload = httpsDownload;
const https_1 = __importDefault(require("https"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const constants_1 = require("../constants");
function httpsDownload(url, filename) {
    return new Promise((resolve, reject) => {
        const req = https_1.default
            .request(url, { headers: { "User-Agent": "javascript" } }, (response) => {
            if (response.statusCode === 302 && response.headers.location != null) {
                httpsDownload(buildNextUrl(url, response.headers.location), filename).then(resolve).catch(reject);
                return;
            }
            const file = fs_1.default.createWriteStream(buildDestinationPath(url, filename));
            response.pipe(file);
            file.on("finish", () => {
                file.close();
                resolve();
            });
        })
            .on("error", reject);
        req.end();
    });
}
function buildNextUrl(current, next) {
    const isNextUrlAbsolute = RegExp("^(?:[a-z]+:)?//").test(next);
    if (isNextUrlAbsolute) {
        return next;
    }
    else {
        const currentURL = new URL(current);
        const fullHost = `${currentURL.protocol}//${currentURL.hostname}${currentURL.port ? ":" + currentURL.port : ""}`;
        return `${fullHost}${next}`;
    }
}
function buildDestinationPath(url, filename) {
    return path_1.default.join(constants_1.paths.upload, filename ?? generateFilenameFromPath(url));
}
function generateFilenameFromPath(url) {
    const urlParts = url.split("/");
    return urlParts[urlParts.length - 1] ?? "";
}
