"use strict";
/**
 * promiseBlindExecute
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.promiseHttpsRequest = promiseHttpsRequest;
const https_1 = __importDefault(require("https"));
const log_1 = require("../log");
/**
 * A promise wrapper for sending a get https requests.
 * @param {String} url - The Https address to request.
 * @param {String} options - The request options.
 */
function promiseHttpsRequest(url, options) {
    return new Promise(function (resolve, reject) {
        let req = https_1.default.request(url, options, (res) => {
            //Construct response
            let body = "";
            res.on("data", (data) => {
                body += data;
            });
            res.on("end", function () {
                if (res && res.statusCode && res.statusCode === 200)
                    return resolve(body);
                process.stdout.write(log_1.log.update("Bad Response " + res.statusCode + "\n"));
                reject(res.statusCode);
            });
        });
        process.stdout.write(log_1.log.update("Sending request to " + url + "\n"));
        process.stdout.write(log_1.log.update("Options: " + JSON.stringify(options) + "\n"));
        req.on("error", reject);
        req.end();
    });
}
