"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EColor = void 0;
/**
 * colors Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var EColor;
(function (EColor) {
    EColor[EColor["Reset"] = 0] = "Reset";
    EColor[EColor["Black"] = 30] = "Black";
    EColor[EColor["Red"] = 31] = "Red";
    EColor[EColor["Green"] = 32] = "Green";
    EColor[EColor["Yellow"] = 33] = "Yellow";
    EColor[EColor["Blue"] = 34] = "Blue";
    EColor[EColor["Magenta"] = 35] = "Magenta";
    EColor[EColor["Cyan"] = 36] = "Cyan";
    EColor[EColor["White"] = 37] = "White";
    EColor[EColor["Default"] = 39] = "Default";
    EColor[EColor["Sql"] = 92] = "Sql";
    EColor[EColor["Logo"] = 91] = "Logo";
    EColor[EColor["Code"] = 93] = "Code";
})(EColor || (exports.EColor = EColor = {}));
