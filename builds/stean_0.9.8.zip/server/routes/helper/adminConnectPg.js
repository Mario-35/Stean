"use strict";
/**
 * adminConnection connection page.
 *
 * @copyright 2020-present Inrae
 * @review 31-01-2024
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminConnectPg = adminConnectPg;
const postgres_1 = __importDefault(require("postgres"));
const _1 = require(".");
const configuration_1 = require("../../configuration");
const helpers_1 = require("../../helpers");
async function adminConnectPg(ctx) {
    const why = {};
    // test if connection is in context
    if (ctx.request.body && ctx.request.body["_connection"])
        return ctx.request.body["_connection"];
    const src = JSON.parse(JSON.stringify(ctx.request.body, null, 2));
    function verifyItems(src, search) {
        let error = false;
        function verifyItem(search) {
            if (src.hasOwnProperty(search))
                return;
            why[search] = `${search} not define`;
            error = true;
        }
        search.forEach((e) => {
            verifyItem(e);
        });
        return error;
    }
    if (verifyItems(src, ["optName", "optVersion", "optPassword", "optRepeat", "datas"]) === false) {
        if (await configuration_1.config.addConfig(JSON.parse(src["datas"])))
            ctx.redirect(`${ctx.request.origin}/admin`);
    }
    if (verifyItems(src, ["host", "adminname", "port", "adminpassword"]) === true)
        return;
    return await (0, postgres_1.default)(`postgres://${src["adminname"]}:${src["adminpassword"]}@${src["host"]}:${src["port"]}/postgres`, {}) `select 1+1 AS result`
        .then(async () => {
        if (configuration_1.config.configFileExist() === false)
            if (await configuration_1.config.initConfig(JSON.stringify({ "admin": (0, _1.formatConfig)(src, true) }, null, 2)))
                await (0, _1.adminRoute)(ctx);
        return (0, helpers_1.encrypt)(JSON.stringify({ login: true, "host": src["host"], "adminname": src["adminname"], "port": src["port"], "adminpassword": src["adminpassword"] }));
    })
        .catch((error) => {
        // TODO
        return `[error]${decodeURI(error.message)}`;
    });
}
