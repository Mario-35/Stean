"use strict";
/**
 * createToken
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createToken = void 0;
const enums_1 = require("../enums");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
/**
 * create a token for Iuser
 * @param input Iuser
 * @param password string
 * @returns token as string
 */
const createToken = (input, password) => {
    return jsonwebtoken_1.default.sign({
        data: {
            id: input.id,
            username: input.username,
            password: password,
            PDCUAS: [input.canPost, input.canDelete, input.canCreateDb, input.canCreateUser, input.admin, input.superAdmin]
        },
        exp: Math.floor(Date.now() / 1000) + 60 * 60 // 60 seconds * 60 minutes = 1 hour
    }, enums_1.EConstant.key);
};
exports.createToken = createToken;
