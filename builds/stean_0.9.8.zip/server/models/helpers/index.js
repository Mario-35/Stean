"use strict";
/**
 * Index Models Helpers
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.link = exports.expand = exports.createBlankEntity = exports.singular = exports.relationInfos = exports.formatColumnValue = exports.createUpdateValues = exports.createInsertValues = exports.idColumnName = void 0;
const relationInfos_1 = require("./relationInfos");
var idColumnName_1 = require("./idColumnName");
Object.defineProperty(exports, "idColumnName", { enumerable: true, get: function () { return idColumnName_1.idColumnName; } });
var createInsertValues_1 = require("./createInsertValues");
Object.defineProperty(exports, "createInsertValues", { enumerable: true, get: function () { return createInsertValues_1.createInsertValues; } });
var createUpdateValues_1 = require("./createUpdateValues");
Object.defineProperty(exports, "createUpdateValues", { enumerable: true, get: function () { return createUpdateValues_1.createUpdateValues; } });
var formatColumnValue_1 = require("./formatColumnValue");
Object.defineProperty(exports, "formatColumnValue", { enumerable: true, get: function () { return formatColumnValue_1.formatColumnValue; } });
var relationInfos_2 = require("./relationInfos");
Object.defineProperty(exports, "relationInfos", { enumerable: true, get: function () { return relationInfos_2.relationInfos; } });
var singular_1 = require("./singular");
Object.defineProperty(exports, "singular", { enumerable: true, get: function () { return singular_1.singular; } });
var createBlankEntity_1 = require("./createBlankEntity");
Object.defineProperty(exports, "createBlankEntity", { enumerable: true, get: function () { return createBlankEntity_1.createBlankEntity; } });
const expand = (ctx, entityName, entityRelation) => (0, relationInfos_1.relationInfos)(ctx, entityName, entityRelation).expand;
exports.expand = expand;
const link = (ctx, entityName, entityRelation) => (0, relationInfos_1.relationInfos)(ctx, entityName, entityRelation).link;
exports.link = link;
