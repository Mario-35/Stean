"use strict";
/**
 * oData ODataUri
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const lexer_1 = __importDefault(require("./lexer"));
const query_1 = __importDefault(require("./query"));
const resourcePath_1 = __importDefault(require("./resourcePath"));
var ODataUri;
(function (ODataUri) {
    function odataUri(value, index, metadataContext) {
        let resource = resourcePath_1.default.resourcePath(value, index, metadataContext);
        while (!resource && index < value.length) {
            while (value[++index] !== 0x2f && index < value.length)
                ;
            resource = resourcePath_1.default.resourcePath(value, index, metadataContext);
        }
        if (!resource)
            return;
        const start = index;
        index = resource.next;
        metadataContext = resource.metadata;
        let query;
        if (value[index] === 0x3f) {
            query = query_1.default.queryOptions(value, index + 1, metadataContext);
            if (!query)
                return;
            index = query.next;
            delete resource.metadata;
        }
        return lexer_1.default.tokenize(value, start, index, { resource, query }, lexer_1.default.TokenType.ODataUri, { metadata: metadataContext });
    }
    ODataUri.odataUri = odataUri;
})(ODataUri || (ODataUri = {}));
exports.default = ODataUri;
