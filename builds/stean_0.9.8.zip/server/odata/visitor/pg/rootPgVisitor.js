"use strict";
/**
 * pgVisitor for odata
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RootPgVisitor = void 0;
const helper_1 = require("../helper");
const enums_1 = require("../../../enums");
const log_1 = require("../../../log");
const _1 = require("../.");
const models_1 = require("../../../models");
const messages_1 = require("../../../messages");
const helpers_1 = require("../../../models/helpers");
const helpers_2 = require("../../../helpers");
class RootPgVisitor extends _1.PgVisitor {
    static root = true;
    special = [];
    constructor(ctx, options = {}, node, special) {
        console.log(log_1.log.whereIam());
        super(ctx, options);
        if (special)
            this.special = special;
        if (node)
            this.StartVisitRessources(node);
    }
    verifyRessources = () => {
        console.log(log_1.log.debug_head("verifyRessources"));
    };
    VisitRessources(node, context) {
        const ressource = this[`VisitRessources${node.type}`];
        if (ressource) {
            ressource.call(this, node, context);
            if (this.debugOdata) {
                console.log(log_1.log.debug_infos("VisitRessources", `VisitRessources${node.type}`));
                console.log(log_1.log.debug_infos("node.raw", node.raw));
                console.log(log_1.log._result("this.query.where", this.query.where.toString()));
            }
        }
        else {
            log_1.log.error(`Ressource Not Found ============> VisitRessources${node.type}`);
            throw new Error(`Unhandled node type: ${node.type}`);
        }
        return this;
    }
    VisitRessourcesResourcePatheTik(nodeName, id) {
        if (this.entity && this.entity.relations[nodeName]) {
            const where = this.parentEntity ? `(SELECT ID FROM (${this.query.toWhere(this)}) as nop)${id ? `and id = ${id}` : ""}` : this.id;
            const whereSql = (0, helpers_1.link)(this.ctx, this.entity.name, nodeName)
                .split("$ID")
                .join(where);
            this.query.where.init(whereSql);
            const tempEntity = models_1.models.getEntity(this.ctx.service, nodeName);
            if (tempEntity) {
                this.swapEntity(tempEntity);
                this.single = tempEntity.singular === nodeName || BigInt(this.id) > 0 ? true : false;
            }
        }
        else if (this.entity && this.entity.columns[nodeName]) {
            this.query.select.add(`${(0, helpers_2.doubleQuotesString)(nodeName)}${enums_1.EConstant.columnSeparator}`);
            this.showRelations = false;
        }
    }
    VisitRessourcesResourcePath(node, context) {
        if (node.value.resource)
            this.VisitRessources(node.value.resource, context);
        if (node.value.navigation)
            this.VisitRessources(node.value.navigation, context);
        if (this.special) {
            this.special.forEach((element) => {
                const nodeName = element.includes("(") ? element.split("(")[0] : element;
                const id = element.includes("(") ? String(element.split("(")[1].split(")")[0]) : undefined;
                this.VisitRessourcesResourcePatheTik(nodeName, id);
            });
        }
    }
    VisitRessourcesEntitySetName(node, _context) {
        this.entity = models_1.models.getEntityStrict(this.ctx.service, node.value.name);
        if (!this.entity)
            this.ctx.throw(404 /* EHttpCode.notFound */, "Not Found");
    }
    VisitRessourcesRefExpression(node, _context) {
        if (node.type == "RefExpression" && node.raw == "/$ref")
            this.onlyRef = true;
    }
    VisitRessourcesValueExpression(node, _context) {
        if (node.type == "ValueExpression" && node.raw == "/$value")
            this.onlyValue = true;
    }
    VisitRessourcesCollectionNavigation(node, context) {
        if (node.value.path)
            this.VisitRessources(node.value.path, context);
    }
    VisitRessourcesCollectionNavigationPath(node, context) {
        if (node.value.predicate)
            this.VisitRessources(node.value.predicate, context);
        if (node.value.navigation)
            this.VisitRessources(node.value.navigation, context);
    }
    VisitRessourcesSimpleKey(node, context) {
        if (node.value.value.type === "KeyPropertyValue") {
            this.single = true;
            this.VisitRessources(node.value.value, context);
        }
    }
    VisitRessourcesKeyPropertyValue(node, _context) {
        this.id = this.ctx.decodedUrl.idStr ? this.ctx.decodedUrl.idStr : node.value == "Edm.SByte" ? BigInt(node.raw) : node.raw;
        this.query.where.notNull;
        const condition = this.ctx.decodedUrl.idStr ? `"lora"."deveui" = '${this.ctx.decodedUrl.idStr}'` : ` id = ${this.id}`;
        if (this.query.where.notNull() === true)
            this.query.where.add(` AND ${condition}`);
        else
            this.query.where.init(condition);
    }
    VisitRessourcesSingleNavigation(node, context) {
        if (node.value.path && node.value.path.type === "PropertyPath")
            this.VisitRessources(node.value.path, context);
    }
    VisitRessourcesEntityCollectionNavigationProperty(node, context) {
        if (node.value.name.includes("/")) {
            node.value.name.split("/").forEach((element) => {
                node.value.name = element;
                this.VisitRessourcesEntityCollectionNavigationProperty(node, context);
            });
        }
        else if (this.entity && this.entity.relations[node.value.name]) {
            const where = this.parentEntity ? `(SELECT ID FROM (${this.query.toWhere(this)}) as nop)` : this.id;
            const whereSql = (0, helpers_1.link)(this.ctx, this.entity.name, node.value.name)
                .split("$ID")
                .join(where);
            this.query.where.init(whereSql);
            const tempEntity = models_1.models.getEntity(this.ctx.service, node.value.name);
            if (tempEntity) {
                this.swapEntity(tempEntity);
                this.single = tempEntity.singular === node.value.name || BigInt(this.id) > 0 ? true : false;
            }
        }
        else if (this.entity && this.entity.columns[node.value.name]) {
            this.query.select.add(`${(0, helpers_2.doubleQuotesString)(node.value.name)}${enums_1.EConstant.columnSeparator}`);
            this.showRelations = false;
        }
        else
            this.ctx.throw(404 /* EHttpCode.notFound */, { code: 404 /* EHttpCode.notFound */, detail: messages_1.errors.notValid });
    }
    VisitRessourcesPropertyPath(node, context) {
        if (node.value.path)
            this.VisitRessources(node.value.path, context);
        if (node.value.navigation)
            this.VisitRessources(node.value.navigation, context);
    }
    VisitRessourcesODataUri(node, context) {
        this.VisitRessources(node.value.resource, context);
        this.VisitRessources(node.value.query, context);
    }
    StartVisitRessources(node) {
        console.log(log_1.log.debug_head("INIT PgVisitor"));
        this.limit = this.ctx.service.nb_page || 200;
        this.numeric = this.ctx.service.extensions.includes(enums_1.EExtensions.resultNumeric);
        const temp = this.VisitRessources(node);
        this.verifyRessources();
        return temp;
    }
    getSql() {
        if (this.includes)
            this.includes.forEach((include) => {
                if (include.navigationProperty.includes("/")) {
                    const names = include.navigationProperty.split("/");
                    include.navigationProperty = names[0];
                    const visitor = new _1.PgVisitor(this.ctx, { ...this.options });
                    if (visitor) {
                        const nameEntity = models_1.models.getEntity(this.ctx.service, names[0]);
                        if (nameEntity) {
                            visitor.entity = nameEntity;
                            visitor.navigationProperty = names[1];
                            if (include.includes)
                                include.includes.push(visitor);
                            else
                                include.includes = [visitor];
                        }
                    }
                }
            });
        return this.onlyValue ? this.toString() : this.returnFormat.generateSql(this);
    }
    patchSql(datas) {
        try {
            return (0, helper_1.postSqlFromPgVisitor)(datas, this);
        }
        catch (error) {
            return undefined;
        }
    }
    postSql(datas) {
        try {
            return (0, helper_1.postSqlFromPgVisitor)(datas, this);
        }
        catch (error) {
            return undefined;
        }
    }
}
exports.RootPgVisitor = RootPgVisitor;
