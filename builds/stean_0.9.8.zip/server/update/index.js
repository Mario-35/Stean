"use strict";
/**
 * AutoUpdate
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.autoUpdate = void 0;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const child_process_1 = require("child_process");
const constants_1 = require("../constants");
const httpsDownload_1 = require("../helpers/httpsDownload ");
const log_1 = require("../log");
const configuration_1 = require("../configuration");
const helpers_1 = require("../helpers");
const enums_1 = require("../enums");
/**
 * AutoUpdate Class
 */
class AutoUpdate {
    static repository = "https://github.com/Mario-35/Stean";
    static branch = "main";
    exitOnComplete = true;
    /**
     * Checks the local version of the application against the remote repository.
     *
     * @param UpToDate - If the local version is the same as the remote version.
     * @param appVersion - The version of the local application.
     * @param remoteVersion - The version of the application in the git repository.
     * @returns An object with the results of the version comparison.
     */
    async compareVersions() {
        try {
            const remoteVersion = await this.readRemoteVersion();
            if (remoteVersion) {
                if (constants_1.appVersion != remoteVersion)
                    return { upToDate: false, appVersion: constants_1.appVersion, remoteVersion };
            }
            else
                return { upToDate: false, appVersion: "Error", remoteVersion: "Error" };
            return { upToDate: true, appVersion: constants_1.appVersion, remoteVersion };
        }
        catch (err) {
            process.stdout.write(log_1.log.update(err + "\n"));
            return { upToDate: false, appVersion: "Error", remoteVersion: "Error" };
        }
    }
    /**
     * Clones the git repository, purges ignored files, and installs the update over the local application.
     * A backup of the application is created before the update is installed.
     * If configured, a completion command will be executed and the process for the app will be stopped.
     * @returns {Boolean} The result of the update.
     */
    async update() {
        try {
            process.stdout.write(log_1.log._head("Updating application" + "\n"));
            if ((await this.downloadUpdate()) === true) {
                await this.backupApp();
                await this.installUpdate();
                await this.installDependencies();
                // await this.promiseBlindExecute("npm run dev");
                process.exit(111);
            }
        }
        catch (err) {
            log_1.log.error("update", "Error updating application");
            process.stdout.write(log_1.log.update(err + "\n"));
        }
        return false;
    }
    /**
     * Creates a backup of the application, including node modules.
     * The backup is stored in the configured tempLocation. Only one backup is kept at a time.
     */
    async backupApp() {
        await (0, helpers_1.zipDirectory)(constants_1.rootApp, constants_1.paths.upload + `backup${constants_1._TEMP_NAME_FILE}.zip`);
        process.stdout.write(log_1.log.update("Backing up app to " + constants_1.paths.upload + "\n"));
        return true;
    }
    /**
     * Downloads the update from the configured git repository.
     * The repo is cloned to the configured tempLocation.
     */
    async downloadUpdate() {
        process.stdout.write(log_1.log.update("Download from " + AutoUpdate.repository + "\n"));
        return await (0, httpsDownload_1.httpsDownload)(AutoUpdate.repository + "/raw/main/builds/stean_latest.zip", "update.zip").then(() => true);
    }
    /**
     * Runs npm install to update/install application dependencies.
     */
    installDependencies() {
        return new Promise(function (resolve, reject) {
            //If this.testing is enabled, use alternative path to prevent overwrite of app.
            let destination = path_1.default.join(constants_1.paths.newVersion);
            process.stdout.write(log_1.log.update("Installing application dependencies in " + destination + "\n"));
            // Generate and execute command
            let command = `cd ${destination} && npm install`;
            let child = (0, child_process_1.exec)(command);
            // Wait for results
            child.stdout?.on("end", resolve);
            child.stdout?.on("data", (data) => process.stdout.write(log_1.log.update("npm install: " + data.replace(/\r?\n|\r/g, "")) + "\n"));
            child.stderr?.on("data", (data) => {
                if (data.toLowerCase().includes("error")) {
                    // npm passes warnings as errors, only reject if "error" is included
                    data = data.replace(/\r?\n|\r/g, "");
                    process.stdout.write(log_1.log.update("Error installing dependencies" + "\n"));
                    process.stdout.write(log_1.log.update(data + "\n"));
                    reject();
                }
                else {
                    process.stdout.write(log_1.log.update(data + "\n"));
                }
            });
        });
    }
    /**
     * Purge ignored files from the update, copy the files to the app directory, and install new modules
     * The update is installed from  the configured tempLocation.
     */
    async installUpdate() {
        await (0, helpers_1.unzipDirectory)(path_1.default.join(constants_1.paths.upload + enums_1.EFileName.update), constants_1.paths.newVersion);
        configuration_1.config.saveConfig(constants_1.paths.newVersion + "/configuration");
        return true;
    }
    /**
     * Reads the applications version from the git repository.
     */
    async readRemoteVersion() {
        try {
            await (0, httpsDownload_1.httpsDownload)(AutoUpdate.repository.replace("github.com", "raw.githubusercontent.com") + `/refs/heads/${AutoUpdate.branch}/${enums_1.EFileName.package}`, enums_1.EFileName.package);
            return JSON.parse(fs_1.default.readFileSync(path_1.default.join(constants_1.paths.upload, enums_1.EFileName.package), "utf-8")).version;
        }
        catch (error) {
            console.log(error);
            return;
        }
    }
}
exports.autoUpdate = new AutoUpdate();
