"use strict";
/**
 * HTML Views First Install for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Update = void 0;
const log_1 = require("../../log");
const update_1 = require("../../update");
const core_1 = require("./core");
class Update extends core_1.CoreHtmlView {
    constructor(ctx, datas) {
        console.log(log_1.log.whereIam("View"));
        super(ctx, datas);
        this.init();
    }
    init() {
        if (this.adminConnection === true)
            update_1.autoUpdate.update();
        else
            this.adminLogin("update");
    }
}
exports.Update = Update;
