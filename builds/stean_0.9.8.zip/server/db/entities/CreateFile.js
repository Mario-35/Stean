"use strict";
/**
 * CreateFile entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateFile = void 0;
const common_1 = require("./common");
const helpers_1 = require("../helpers");
const messages_1 = require("../../messages/");
const entities = __importStar(require("../entities/index"));
const helpers_2 = require("../../helpers");
const fs_1 = require("fs");
const stream_1 = require("stream");
const configuration_1 = require("../../configuration");
const log_1 = require("../../log");
const enums_1 = require("../../enums");
const entities_1 = require("../../models/entities");
/**
 * CreateFile Class
 */
class CreateFile extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.log.whereIam());
        super(ctx);
    }
    streamCsvFileInFiles = async (ctx, paramsFile) => {
        console.log(log_1.log.debug_head("streamCsvFileInPostgreSqlFileInDatastream"));
        const headers = await (0, helpers_1.getColumnsNamesFromCsvFile)(paramsFile.filename);
        if (!headers) {
            ctx.throw(400 /* EHttpCode.badRequest */, {
                code: 400 /* EHttpCode.badRequest */,
                detail: messages_1.errors.noHeaderCsv + paramsFile.filename
            });
        }
        const nameOfFile = paramsFile.filename.split("/").reverse()[0];
        const createDataStream = async () => {
            const copyCtx = Object.assign({}, ctx.odata);
            ctx.odata.entity = entities_1.FILE;
            // IMPORTANT TO ADD instead update
            ctx.odata.returnFormat = helpers_2.returnFormats.json;
            ctx.log = undefined;
            // @ts-ignore
            const objectFile = new entities[entities_1.FILE.name](ctx);
            try {
                return await objectFile.post({
                    "name": nameOfFile,
                    "description": `${entities_1.FILE.name} import file ${nameOfFile}`
                });
            }
            catch (err) {
                console.log(err);
                ctx.odata.query.where.init(`"name" ~* '${nameOfFile}'`);
                const returnValueError = await objectFile.getAll();
                ctx.odata = copyCtx;
                if (returnValueError) {
                    returnValueError.body = returnValueError.body ? returnValueError.body[0] : {};
                    if (returnValueError.body)
                        await configuration_1.config.executeSqlValues(ctx.service, `DELETE FROM "${entities_1.LINE.table}" WHERE "file_id" = ${returnValueError.body[enums_1.EConstant.id]}`);
                    return returnValueError;
                }
            }
            finally {
                ctx.odata = copyCtx;
            }
        };
        const returnValue = await createDataStream().catch((err) => console.log(err));
        const controller = new AbortController();
        const readable = (0, fs_1.createReadStream)(paramsFile.filename);
        const cols = [];
        headers.forEach((value) => cols.push(`${value} TEXT NULL`));
        const createTable = `CREATE TABLE public."${paramsFile.tempTable}" (${cols});`;
        await configuration_1.config.executeSqlValues(ctx.service, createTable);
        const writable = configuration_1.config
            .connection(ctx.service.name)
            .unsafe(`COPY ${paramsFile.tempTable}  (${headers.join(",")}) FROM STDIN WITH(FORMAT csv, DELIMITER ';'${paramsFile.header})`)
            .writable();
        return await new Promise(async (resolve, reject) => {
            readable
                .pipe((0, stream_1.addAbortSignal)(controller.signal, await writable))
                .on("close", async () => {
                const sql = `INSERT INTO "${entities_1.LINE.table}" 
                    (
                    "file_id", 
                    "result") 
                    SELECT '${Number(returnValue.body[enums_1.EConstant.id])}', 
                    json_build_object('valueskeys',ROW_TO_JSON(p)) FROM (SELECT * FROM ${paramsFile.tempTable}) AS p 
                    ON CONFLICT DO NOTHING`;
                await configuration_1.config.connection(this.ctx.service.name).unsafe(sql);
                if (returnValue)
                    resolve(returnValue);
            })
                .on("error", (err) => {
                log_1.log.error("ABORTED-STREAM");
                reject(err);
            });
        });
    };
    async getAll() {
        this.ctx.throw(400 /* EHttpCode.badRequest */, { code: 400 /* EHttpCode.badRequest */ });
    }
    async getSingle() {
        console.log(log_1.log.whereIam());
        this.ctx.throw(400 /* EHttpCode.badRequest */, { code: 400 /* EHttpCode.badRequest */ });
    }
    async post(dataInput) {
        console.log(log_1.log.whereIam(dataInput));
        if (this.ctx.datas) {
            const myColumns = [];
            return this.formatReturnResult({
                body: await this.streamCsvFileInFiles(this.ctx, {
                    tempTable: `temp${Date.now().toString()}`,
                    filename: this.ctx.datas["file"],
                    columns: myColumns,
                    header: ", HEADER",
                    stream: []
                })
            });
        }
        else {
            log_1.log.error("No Datas");
            return;
        }
    }
}
exports.CreateFile = CreateFile;
