"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createExtension = void 0;
/**
 * createExtension.
 *
 * @copyright 2020-present Inrae
 * @review 27-01-2024
 * @author mario.adam@inrae.fr
 *
 */
const createExtension = (name) => `CREATE EXTENSION IF NOT EXISTS ${name}`;
exports.createExtension = createExtension;
