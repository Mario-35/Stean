"use strict";
/**
 * Index of The API
 *
 * @copyright 2020-present Inrae
 * @review 29-01-2024
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.server = exports.app = void 0;
const path_1 = __importDefault(require("path"));
const koa_1 = __importDefault(require("koa"));
const koa_bodyparser_1 = __importDefault(require("koa-bodyparser"));
const koa_logger_1 = __importDefault(require("koa-logger"));
const koa_helmet_1 = __importDefault(require("koa-helmet"));
const koa_json_1 = __importDefault(require("koa-json"));
const cors_1 = __importDefault(require("@koa/cors"));
const koa_static_1 = __importDefault(require("koa-static"));
const koa_favicon_1 = __importDefault(require("koa-favicon"));
const log_1 = require("./log");
const configuration_1 = require("./configuration");
const models_1 = require("./models");
const helpers_1 = require("./helpers");
const enums_1 = require("./enums");
const routes_1 = require("./routes/");
// Initialisation of models
models_1.models.init();
// new koa server https://koajs.com/
exports.app = new koa_1.default();
exports.app.use((0, koa_favicon_1.default)(__dirname + "/favicon.ico"));
// add public folder [static]
exports.app.use((0, koa_static_1.default)(path_1.default.join(__dirname, "/apidoc")));
// helmet protection https://github.com/venables/koa-helmet
exports.app.use(koa_helmet_1.default.contentSecurityPolicy({ directives: enums_1.EConstant.helmetConfig }));
// bodybarser https://github.com/koajs/bodyparser
exports.app.use((0, koa_bodyparser_1.default)({ enableTypes: ["json", "text", "form"] }));
// router
exports.app.use(routes_1.routerHandle);
// logger https://github.com/koajs/logger
if (!(0, helpers_1.isTest)())
    exports.app.use((0, koa_logger_1.default)((str) => {
        if (str.includes("/logs"))
            return;
        str = `[39m ${new Date().toLocaleString()}${str}`;
        process.stdout.write(str + "\n");
        if (configuration_1.config.logFile)
            configuration_1.config.logFile.write((0, helpers_1.logToHtml)(str));
    }));
// add json capabilities to KOA server
exports.app.use((0, koa_json_1.default)());
// add cors capabilities to KOA server
exports.app.use((0, cors_1.default)());
// free routes
exports.app.use(routes_1.unProtectedRoutes.routes());
// authenticated routes
exports.app.use(routes_1.protectedRoutes.routes());
// Start server initialisaion
exports.server = (0, helpers_1.isTest)()
    ? // TDD init
        exports.app.listen(configuration_1.config.getService(enums_1.EConstant.admin).ports?.http || 8029, async () => {
            await configuration_1.config.connection(enums_1.EConstant.admin) `SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE pid <> pg_backend_pid() AND datname = 'test'`.then(async () => {
                await configuration_1.config.connection(enums_1.EConstant.admin) `DROP DATABASE IF EXISTS test`;
            });
            console.log(log_1.log.message(`${enums_1.EConstant.appName} version : ${enums_1.EConstant.appVersion}`, "ready " + "\u2714\uFE0F\uFE0F" /* EChar.ok */));
        })
    : // Production or dev init
        configuration_1.config.init();
