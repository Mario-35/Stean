"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EExtensions = void 0;
/**
 * extensions Enum
 *
 * @copyright 2020-present Inrae
 * @review 29-10-2024
 * @author mario.adam@inrae.fr
 *
 */
var EExtensions;
(function (EExtensions) {
    EExtensions["base"] = "base";
    EExtensions["file"] = "file";
    EExtensions["logs"] = "logs";
    EExtensions["users"] = "users";
    EExtensions["lora"] = "lora";
    EExtensions["tasking"] = "tasking";
    EExtensions["mqtt"] = "mqtt";
    EExtensions["multiDatastream"] = "multiDatastream";
    EExtensions["highPrecision"] = "highPrecision";
    EExtensions["resultNumeric"] = "resultNumeric";
})(EExtensions || (exports.EExtensions = EExtensions = {}));
