"use strict";
/**
 * oData Query
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __importDefault(require("./utils"));
const lexer_1 = __importDefault(require("./lexer"));
const primitiveLiteral_1 = __importDefault(require("./primitiveLiteral"));
const nameOrIdentifier_1 = __importDefault(require("./nameOrIdentifier"));
const expressions_1 = __importDefault(require("./expressions"));
const helpers_1 = require("../../helpers");
var Query;
(function (Query) {
    const addToIndex = (value, index, name) => {
        if (utils_1.default.equals(value, index, `%24${name}`)) {
            return name.length + 3;
        }
        else if (utils_1.default.equals(value, index, `$${name}`)) {
            return name.length + 1;
        }
    };
    function queryOptions(value, index, metadataContext) {
        let token = Query.queryOption(value, index, metadataContext);
        if (!token)
            return;
        const start = index;
        index = token.next;
        const options = [];
        while (token) {
            options.push(token);
            // &
            if (value[index] !== 0x26)
                break;
            index++;
            token = Query.queryOption(value, index, metadataContext);
            if (!token)
                return;
            index = token.next;
        }
        return lexer_1.default.tokenize(value, start, index, { options }, lexer_1.default.TokenType.QueryOptions);
    }
    Query.queryOptions = queryOptions;
    function queryOption(value, index, metadataContext) {
        return Query.systemQueryOption(value, index, metadataContext) || Query.aliasAndValue(value, index) || Query.customQueryOption(value, index);
    }
    Query.queryOption = queryOption;
    function systemQueryOption(value, index, metadataContext) {
        return (Query.expand(value, index, metadataContext) ||
            Query.filter(value, index) ||
            Query.format(value, index) ||
            Query.resultFormat(value, index) ||
            Query.splitResult(value, index) ||
            Query.interval(value, index) ||
            Query.payload(value, index) ||
            Query.id(value, index) ||
            Query.InlineCount(value, index) ||
            Query.orderby(value, index) ||
            Query.search(value, index) ||
            Query.select(value, index) ||
            Query.skip(value, index) ||
            Query.skiptoken(value, index) ||
            Query.top(value, index) ||
            Query.log(value, index) ||
            Query.debug(value, index) ||
            Query.replay(value, index));
    }
    Query.systemQueryOption = systemQueryOption;
    function customQueryOption(value, index) {
        const key = nameOrIdentifier_1.default.odataIdentifier(value, index);
        if (!key)
            return;
        const start = index;
        index = key.next;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        while (value[index] !== 0x26 && index < value.length)
            index++;
        if (index === eq)
            return;
        return lexer_1.default.tokenize(value, start, index, { key: key.raw, value: utils_1.default.stringify(value, eq, index) }, lexer_1.default.TokenType.CustomQueryOption);
    }
    Query.customQueryOption = customQueryOption;
    function replay(value, index) {
        const start = index;
        const add = addToIndex(value, start, "replay");
        if (add)
            index += add;
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        const token = primitiveLiteral_1.default.booleanValue(value, index);
        if (!token)
            return;
        index = token.next;
        return lexer_1.default.tokenize(value, start, index, token, lexer_1.default.TokenType.Replay);
    }
    Query.replay = replay;
    function debug(value, index) {
        const start = index;
        const add = addToIndex(value, start, "debug");
        if (add)
            index += add;
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        const token = primitiveLiteral_1.default.booleanValue(value, index);
        if (!token)
            return;
        index = token.next;
        return lexer_1.default.tokenize(value, start, index, token, lexer_1.default.TokenType.Debug);
    }
    Query.debug = debug;
    function splitResult(value, index) {
        const start = index;
        const add = addToIndex(value, start, "splitResult");
        if (add)
            index += add;
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        while (value[index] !== 0x26 && index < value.length)
            index++;
        if (index === eq)
            return;
        return lexer_1.default.tokenize(value, start, index, utils_1.default.stringify(value, eq, index), lexer_1.default.TokenType.splitResult);
    }
    Query.splitResult = splitResult;
    function payload(value, index) {
        const start = index;
        const add = addToIndex(value, start, "payload");
        if (add)
            index += add;
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        while (value[index] !== 0x26 && index < value.length)
            index++;
        if (index === eq)
            return;
        return lexer_1.default.tokenize(value, start, index, utils_1.default.stringify(value, eq, index), lexer_1.default.TokenType.payload);
    }
    Query.payload = payload;
    function interval(value, index) {
        const start = index;
        const add = addToIndex(value, start, "interval");
        if (add)
            index += add;
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        while (value[index] !== 0x26 && index < value.length)
            index++;
        if (index === eq)
            return;
        return lexer_1.default.tokenize(value, start, index, utils_1.default.stringify(value, eq, index), lexer_1.default.TokenType.interval);
    }
    Query.interval = interval;
    function resultFormat(value, index) {
        const start = index;
        const add = addToIndex(value, start, "resultFormat");
        if (add)
            index += add;
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        let format;
        Object.keys(helpers_1.returnFormats).forEach((key) => {
            if (utils_1.default.equals(value, index, key)) {
                format = key;
                index += key.length;
            }
        });
        if (format)
            return lexer_1.default.tokenize(value, start, index, { format }, lexer_1.default.TokenType.resultFormat);
    }
    Query.resultFormat = resultFormat;
    function id(value, index) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24id")) {
            index += 5;
        }
        else if (utils_1.default.equals(value, index, "$id")) {
            index += 3;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        while (value[index] !== 0x26 && index < value.length)
            index++;
        if (index === eq)
            return;
        return lexer_1.default.tokenize(value, start, index, utils_1.default.stringify(value, eq, index), lexer_1.default.TokenType.Id);
    }
    Query.id = id;
    function expand(value, index, metadataContext) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24expand")) {
            index += 9;
        }
        else if (utils_1.default.equals(value, index, "$expand")) {
            index += 7;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        const items = [];
        let token = Query.expandItem(value, index, metadataContext);
        if (!token)
            return;
        index = token.next;
        while (token) {
            items.push(token);
            const comma = lexer_1.default.COMMA(value, index);
            if (comma) {
                index = comma;
                token = Query.expandItem(value, index, metadataContext);
                if (!token)
                    return;
                index = token.next;
            }
            else
                break;
        }
        return lexer_1.default.tokenize(value, start, index, { items }, lexer_1.default.TokenType.Expand);
    }
    Query.expand = expand;
    function expandItem(value, index, metadataContext) {
        const start = index;
        const star = lexer_1.default.STAR(value, index);
        if (star) {
            index = star;
            const ref = expressions_1.default.refExpr(value, index);
            if (ref) {
                index = ref.next;
                return lexer_1.default.tokenize(value, start, index, { path: "*", ref }, lexer_1.default.TokenType.ExpandItem);
            }
            else {
                const open = lexer_1.default.OPEN(value, index);
                if (open) {
                    index = open;
                    const token = Query.levels(value, index);
                    if (!token)
                        return;
                    index = token.next;
                    const close = lexer_1.default.CLOSE(value, index);
                    if (!close)
                        return;
                    index = close;
                    return lexer_1.default.tokenize(value, start, index, { path: "*", levels: token }, lexer_1.default.TokenType.ExpandItem);
                }
            }
        }
        const path = Query.expandPath(value, index, metadataContext);
        if (!path)
            return;
        index = path.next;
        const tokenValue = { path };
        const ref = expressions_1.default.refExpr(value, index);
        if (ref) {
            index = ref.next;
            tokenValue.ref = ref;
            const open = lexer_1.default.OPEN(value, index);
            if (open) {
                index = open;
                let option = Query.expandRefOption(value, index);
                if (!option)
                    return;
                const refOptions = [];
                while (option) {
                    refOptions.push(option);
                    index = option.next;
                    const semi = lexer_1.default.SEMI(value, index);
                    if (semi) {
                        index = semi;
                        option = Query.expandRefOption(value, index);
                        if (!option)
                            return;
                    }
                    else
                        break;
                }
                const close = lexer_1.default.CLOSE(value, index);
                if (!close)
                    return;
                index = close;
                tokenValue.options = refOptions;
            }
        }
        else {
            const count = expressions_1.default.countExpr(value, index);
            if (count) {
                index = count.next;
                tokenValue.count = count;
                const open = lexer_1.default.OPEN(value, index);
                if (open) {
                    index = open;
                    let option = Query.expandCountOption(value, index);
                    if (!option)
                        return;
                    const countOptions = [];
                    while (option) {
                        countOptions.push(option);
                        index = option.next;
                        const semi = lexer_1.default.SEMI(value, index);
                        if (semi) {
                            index = semi;
                            option = Query.expandCountOption(value, index);
                            if (!option)
                                return;
                        }
                        else
                            break;
                    }
                    const close = lexer_1.default.CLOSE(value, index);
                    if (!close)
                        return;
                    index = close;
                    tokenValue.options = countOptions;
                }
            }
            else {
                const open = lexer_1.default.OPEN(value, index);
                if (open) {
                    index = open;
                    let option = Query.expandOption(value, index);
                    if (!option)
                        return;
                    const options = [];
                    while (option) {
                        options.push(option);
                        index = option.next;
                        const semi = lexer_1.default.SEMI(value, index);
                        if (semi) {
                            index = semi;
                            option = Query.expandOption(value, index);
                            if (!option)
                                return;
                        }
                        else
                            break;
                    }
                    const close = lexer_1.default.CLOSE(value, index);
                    if (!close)
                        return;
                    index = close;
                    tokenValue.options = options;
                }
            }
        }
        return lexer_1.default.tokenize(value, start, index, tokenValue, lexer_1.default.TokenType.ExpandItem);
    }
    Query.expandItem = expandItem;
    function expandCountOption(value, index) {
        return Query.filter(value, index) || Query.search(value, index);
    }
    Query.expandCountOption = expandCountOption;
    function expandRefOption(value, index) {
        return (Query.expandCountOption(value, index) ||
            Query.orderby(value, index) ||
            Query.skip(value, index) ||
            Query.top(value, index) ||
            Query.InlineCount(value, index));
    }
    Query.expandRefOption = expandRefOption;
    function expandOption(value, index) {
        return Query.expandRefOption(value, index) || Query.select(value, index) || Query.expand(value, index) || Query.levels(value, index);
    }
    Query.expandOption = expandOption;
    function expandPath(value, index, metadataContext) {
        const start = index;
        const path = [];
        const token = nameOrIdentifier_1.default.qualifiedEntityTypeName(value, index, metadataContext) || nameOrIdentifier_1.default.qualifiedComplexTypeName(value, index, metadataContext);
        if (token) {
            index = token.next;
            path.push(token);
            if (value[index] !== 0x2f)
                return;
            index++;
            metadataContext = token.value.metadata;
            delete token.value.metadata;
        }
        let complex = nameOrIdentifier_1.default.complexProperty(value, index, metadataContext) || nameOrIdentifier_1.default.complexColProperty(value, index, metadataContext);
        while (complex) {
            if (value[complex.next] === 0x2f) {
                index = complex.next + 1;
                path.push(complex);
                const complexTypeName = nameOrIdentifier_1.default.qualifiedComplexTypeName(value, index, metadataContext);
                if (complexTypeName) {
                    if (value[complexTypeName.next] === 0x2f) {
                        index = complexTypeName.next + 1;
                        path.push(complexTypeName);
                    }
                    metadataContext = complexTypeName.value.metadata;
                    delete complexTypeName.value.metadata;
                }
                complex = nameOrIdentifier_1.default.complexProperty(value, index, metadataContext) || nameOrIdentifier_1.default.complexColProperty(value, index, metadataContext);
            }
            else
                break;
        }
        const nav = nameOrIdentifier_1.default.navigationProperty(value, index, metadataContext);
        if (!nav)
            return;
        index = nav.next;
        path.push(nav);
        metadataContext = nav.metadata;
        delete nav.metadata;
        if (value[index] === 0x2f) {
            const typeName = nameOrIdentifier_1.default.qualifiedEntityTypeName(value, index + 1, metadataContext);
            if (typeName) {
                index = typeName.next;
                path.push(typeName);
                metadataContext = typeName.value.metadata;
                delete typeName.value.metadata;
            }
        }
        return lexer_1.default.tokenize(value, start, index, path, lexer_1.default.TokenType.ExpandPath);
    }
    Query.expandPath = expandPath;
    function search(value, index) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24search")) {
            index += 9;
        }
        else if (utils_1.default.equals(value, index, "$search")) {
            index += 7;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        const expr = Query.searchExpr(value, index);
        if (!expr)
            return;
        index = expr.next;
        return lexer_1.default.tokenize(value, start, index, expr, lexer_1.default.TokenType.Search);
    }
    Query.search = search;
    function searchExpr(value, index) {
        const token = Query.searchParenExpr(value, index) || Query.searchTerm(value, index);
        if (!token)
            return;
        // const start = index;
        index = token.next;
        const expr = Query.searchAndExpr(value, index) || Query.searchOrExpr(value, index);
        if (expr) {
            const left = lexer_1.default.clone(token);
            token.next = expr.value.next;
            token.value = {
                left: left,
                right: expr.value
            };
            token.type = expr.type;
            token.raw = utils_1.default.stringify(value, token.position, token.next);
            if (token.type === lexer_1.default.TokenType.SearchAndExpression && token.value.right.type === lexer_1.default.TokenType.SearchOrExpression) {
                token.value.left = lexer_1.default.tokenize(value, token.value.left.position, token.value.right.value.left.next, {
                    left: token.value.left,
                    right: token.value.right.value.left
                }, token.type);
                token.type = token.value.right.type;
                token.value.right = token.value.right.value.right;
            }
        }
        return token;
    }
    Query.searchExpr = searchExpr;
    function searchTerm(value, index) {
        return Query.searchNotExpr(value, index) || Query.searchPhrase(value, index) || Query.searchWord(value, index);
    }
    Query.searchTerm = searchTerm;
    function searchNotExpr(value, index) {
        let rws = lexer_1.default.RWS(value, index);
        if (!rws || !utils_1.default.equals(value, rws, "NOT"))
            return;
        const start = index;
        index = rws + 3;
        rws = lexer_1.default.RWS(value, index);
        if (!rws || rws === index)
            return;
        index = rws;
        const expr = Query.searchPhrase(value, index) || Query.searchWord(value, index);
        if (!expr)
            return;
        index = expr.next;
        return lexer_1.default.tokenize(value, start, index, expr, lexer_1.default.TokenType.SearchNotExpression);
    }
    Query.searchNotExpr = searchNotExpr;
    function searchOrExpr(value, index) {
        let rws = lexer_1.default.RWS(value, index);
        if (!rws || rws === index || !utils_1.default.equals(value, rws, "OR"))
            return;
        const start = index;
        index = rws + 2;
        rws = lexer_1.default.RWS(value, index);
        if (!rws || rws === index)
            return;
        index = rws;
        const token = Query.searchExpr(value, index);
        if (!token)
            return;
        index = token.next;
        return lexer_1.default.tokenize(value, start, index, token, lexer_1.default.TokenType.SearchOrExpression);
    }
    Query.searchOrExpr = searchOrExpr;
    function searchAndExpr(value, index) {
        let rws = lexer_1.default.RWS(value, index);
        if (!rws || rws === index || !utils_1.default.equals(value, rws, "AND"))
            return;
        const start = index;
        index = rws + 3;
        rws = lexer_1.default.RWS(value, index);
        if (!rws || rws === index)
            return;
        index = rws;
        const token = Query.searchExpr(value, index);
        if (!token)
            return;
        index = token.next;
        return lexer_1.default.tokenize(value, start, index, token, lexer_1.default.TokenType.SearchAndExpression);
    }
    Query.searchAndExpr = searchAndExpr;
    function searchPhrase(value, index) {
        let mark = lexer_1.default.quotationMark(value, index);
        if (!mark || mark === index)
            return;
        const start = index;
        index = mark;
        const valueStart = index;
        let ch = lexer_1.default.qcharNoAMPDQUOTE(value, index);
        while (ch && ch > index && !lexer_1.default.OPEN(value, index) && !lexer_1.default.CLOSE(value, index)) {
            index = ch;
            ch = lexer_1.default.qcharNoAMPDQUOTE(value, index);
        }
        const valueEnd = index;
        mark = lexer_1.default.quotationMark(value, index);
        if (!mark)
            return;
        index = mark;
        return lexer_1.default.tokenize(value, start, index, utils_1.default.stringify(value, valueStart, valueEnd), lexer_1.default.TokenType.SearchPhrase);
    }
    Query.searchPhrase = searchPhrase;
    function searchWord(value, index) {
        const next = utils_1.default.required(value, index, lexer_1.default.ALPHA, 1);
        if (!next)
            return;
        const start = index;
        index = next;
        const token = lexer_1.default.tokenize(value, start, index, null, lexer_1.default.TokenType.SearchWord);
        token.value = token.raw;
        return token;
    }
    Query.searchWord = searchWord;
    function searchParenExpr(value, index) {
        const open = lexer_1.default.OPEN(value, index);
        if (!open)
            return;
        const start = index;
        index = open;
        let temp = lexer_1.default.BWS(value, index);
        if (!temp)
            return;
        index = temp;
        const expr = Query.searchExpr(value, index);
        if (!expr)
            return;
        index = expr.next;
        temp = lexer_1.default.BWS(value, index);
        if (!temp)
            return;
        index = temp;
        const close = lexer_1.default.CLOSE(value, index);
        if (!close)
            return;
        index = close;
        return lexer_1.default.tokenize(value, start, index, expr, lexer_1.default.TokenType.SearchParenExpression);
    }
    Query.searchParenExpr = searchParenExpr;
    function levels(value, index) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24levels")) {
            index += 9;
        }
        else if (utils_1.default.equals(value, index, "$levels")) {
            index += 7;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        let level;
        if (utils_1.default.equals(value, index, "max")) {
            level = "max";
            index += 3;
        }
        else {
            const token = primitiveLiteral_1.default.int32Value(value, index);
            if (!token)
                return;
            level = token.raw;
            index = token.next;
        }
        return lexer_1.default.tokenize(value, start, index, level, lexer_1.default.TokenType.Levels);
    }
    Query.levels = levels;
    function filter(value, index) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24filter")) {
            index += 9;
        }
        else if (utils_1.default.equals(value, index, "$filter")) {
            index += 7;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        const expr = expressions_1.default.boolCommonExpr(value, index);
        if (!expr)
            return;
        index = expr.next;
        return lexer_1.default.tokenize(value, start, index, expr, lexer_1.default.TokenType.Filter);
    }
    Query.filter = filter;
    function orderby(value, index) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24orderby")) {
            index += 10;
        }
        else if (utils_1.default.equals(value, index, "$orderby")) {
            index += 8;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        const items = [];
        let token = Query.orderbyItem(value, index);
        if (!token)
            return;
        index = token.next;
        while (token) {
            items.push(token);
            const comma = lexer_1.default.COMMA(value, index);
            if (comma) {
                index = comma;
                token = Query.orderbyItem(value, index);
                if (!token)
                    return;
                index = token.next;
            }
            else
                break;
        }
        return lexer_1.default.tokenize(value, start, index, { items }, lexer_1.default.TokenType.OrderBy);
    }
    Query.orderby = orderby;
    function orderbyItem(value, index) {
        const expr = expressions_1.default.commonExpr(value, index);
        if (!expr)
            return;
        const start = index;
        index = expr.next;
        let direction = 1;
        const rws = lexer_1.default.RWS(value, index);
        if (rws && rws > index) {
            index = rws;
            if (utils_1.default.equals(value, index, "asc"))
                index += 3;
            else if (utils_1.default.equals(value, index, "desc")) {
                index += 4;
                direction = -1;
            }
            else
                return;
        }
        return lexer_1.default.tokenize(value, start, index, { expr, direction }, lexer_1.default.TokenType.OrderByItem);
    }
    Query.orderbyItem = orderbyItem;
    function skip(value, index) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24skip")) {
            index += 7;
        }
        else if (utils_1.default.equals(value, index, "$skip")) {
            index += 5;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        const token = primitiveLiteral_1.default.int32Value(value, index);
        if (!token)
            return;
        index = token.next;
        return lexer_1.default.tokenize(value, start, index, token, lexer_1.default.TokenType.Skip);
    }
    Query.skip = skip;
    function top(value, index) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24top")) {
            index += 6;
        }
        else if (utils_1.default.equals(value, index, "$top")) {
            index += 4;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        const token = primitiveLiteral_1.default.int32Value(value, index);
        if (!token)
            return;
        index = token.next;
        return lexer_1.default.tokenize(value, start, index, token, lexer_1.default.TokenType.Top);
    }
    Query.top = top;
    function log(value, index) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24log")) {
            index += 6;
        }
        else if (utils_1.default.equals(value, index, "$log")) {
            index += 4;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        const token = primitiveLiteral_1.default.int32Value(value, index);
        if (!token)
            return;
        index = token.next;
        return lexer_1.default.tokenize(value, start, index, token, lexer_1.default.TokenType.Log);
    }
    Query.log = log;
    function format(value, index) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24format")) {
            index += 9;
        }
        else if (utils_1.default.equals(value, index, "$format")) {
            index += 7;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        let format;
        if (utils_1.default.equals(value, index, "atom")) {
            format = "atom";
            index += 4;
        }
        else if (utils_1.default.equals(value, index, "json")) {
            format = "json";
            index += 4;
        }
        else if (utils_1.default.equals(value, index, "xml")) {
            format = "xml";
            index += 3;
        }
        if (format)
            return lexer_1.default.tokenize(value, start, index, { format }, lexer_1.default.TokenType.Format);
    }
    Query.format = format;
    function InlineCount(value, index) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24count")) {
            index += 8;
        }
        else if (utils_1.default.equals(value, index, "$count")) {
            index += 6;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        const token = primitiveLiteral_1.default.booleanValue(value, index);
        if (!token)
            return;
        index = token.next;
        return lexer_1.default.tokenize(value, start, index, token, lexer_1.default.TokenType.InlineCount);
    }
    Query.InlineCount = InlineCount;
    function select(value, index) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24select")) {
            index += 9;
        }
        else if (utils_1.default.equals(value, index, "$select")) {
            index += 7;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        const items = [];
        let token = Query.selectItem(value, index);
        if (!token)
            return;
        while (token) {
            items.push(token);
            index = token.next;
            const comma = lexer_1.default.COMMA(value, index);
            if (comma) {
                index = comma;
                token = Query.selectItem(value, index);
                if (!token)
                    return;
            }
            else
                break;
        }
        return lexer_1.default.tokenize(value, start, index, { items }, lexer_1.default.TokenType.Select);
    }
    Query.select = select;
    function selectItem(value, index) {
        const start = index;
        let item = {};
        const op = Query.allOperationsInSchema(value, index);
        const star = lexer_1.default.STAR(value, index);
        if (op > index) {
            item = { namespace: utils_1.default.stringify(value, index, op - 2), value: "*" };
            index = op;
        }
        else if (star) {
            item = { value: "*" };
            index = star;
        }
        else {
            item = {};
            const name = nameOrIdentifier_1.default.qualifiedEntityTypeName(value, index) || nameOrIdentifier_1.default.qualifiedComplexTypeName(value, index);
            if (name && value[name.next] !== 0x2f)
                return;
            else if (name && value[name.next] === 0x2f) {
                index++;
                item["name"] = name;
            }
            const select = Query.selectProperty(value, index) || Query.qualifiedActionName(value, index) || Query.qualifiedFunctionName(value, index);
            if (!select)
                return;
            index = select.next;
            item = name ? { name, select } : select;
        }
        if (index > start)
            return lexer_1.default.tokenize(value, start, index, item, lexer_1.default.TokenType.SelectItem);
    }
    Query.selectItem = selectItem;
    function allOperationsInSchema(value, index) {
        const namespaceNext = nameOrIdentifier_1.default.namespace(value, index);
        const star = lexer_1.default.STAR(value, namespaceNext + 1);
        if (namespaceNext > index && value[namespaceNext] === 0x2e && star)
            return star;
        return index;
    }
    Query.allOperationsInSchema = allOperationsInSchema;
    function selectProperty(value, index) {
        const token = Query.selectPath(value, index) ||
            nameOrIdentifier_1.default.primitiveProperty(value, index) ||
            nameOrIdentifier_1.default.primitiveColProperty(value, index) ||
            nameOrIdentifier_1.default.navigationProperty(value, index);
        if (!token)
            return;
        const start = index;
        index = token.next;
        if (token.type === lexer_1.default.TokenType.SelectPath) {
            if (value[index] === 0x2f) {
                index++;
                const prop = Query.selectProperty(value, index);
                if (!prop)
                    return;
                const path = lexer_1.default.clone(token);
                token.next = prop.next;
                token.raw = utils_1.default.stringify(value, start, token.next);
                token.value = { path, next: prop };
            }
        }
        return token;
    }
    Query.selectProperty = selectProperty;
    function selectPath(value, index) {
        const token = nameOrIdentifier_1.default.complexProperty(value, index) || nameOrIdentifier_1.default.complexColProperty(value, index);
        if (!token)
            return;
        const start = index;
        index = token.next;
        let tokenValue = token;
        if (value[index] === 0x2f) {
            const name = nameOrIdentifier_1.default.qualifiedComplexTypeName(value, index + 1);
            if (name) {
                index = name.next;
                tokenValue = { prop: token, name };
            }
        }
        return lexer_1.default.tokenize(value, start, index, tokenValue, lexer_1.default.TokenType.SelectPath);
    }
    Query.selectPath = selectPath;
    function qualifiedActionName(value, index) {
        const namespaceNext = nameOrIdentifier_1.default.namespace(value, index);
        if (namespaceNext === index || value[namespaceNext] !== 0x2e)
            return;
        const start = index;
        index = namespaceNext + 1;
        const action = nameOrIdentifier_1.default.action(value, index);
        if (!action)
            return;
        action.value.namespace = utils_1.default.stringify(value, start, namespaceNext);
        return lexer_1.default.tokenize(value, start, action.next, action, lexer_1.default.TokenType.Action);
    }
    Query.qualifiedActionName = qualifiedActionName;
    function qualifiedFunctionName(value, index) {
        const namespaceNext = nameOrIdentifier_1.default.namespace(value, index);
        if (namespaceNext === index || value[namespaceNext] !== 0x2e)
            return;
        const start = index;
        index = namespaceNext + 1;
        const fn = nameOrIdentifier_1.default.odataFunction(value, index);
        if (!fn)
            return;
        fn.value.namespace = utils_1.default.stringify(value, start, namespaceNext);
        index = fn.next;
        const tokenValue = { name: fn };
        const open = lexer_1.default.OPEN(value, index);
        if (open) {
            index = open;
            tokenValue.parameters = [];
            const param = expressions_1.default.parameterName(value, index);
            if (!param)
                return;
            while (param) {
                index = param.next;
                tokenValue.parameters.push(param);
                const comma = lexer_1.default.COMMA(value, index);
                if (comma) {
                    index = comma;
                    const param = expressions_1.default.parameterName(value, index);
                    if (!param)
                        return;
                }
                else
                    break;
            }
            const close = lexer_1.default.CLOSE(value, index);
            if (!close)
                return;
            index = close;
        }
        return lexer_1.default.tokenize(value, start, index, tokenValue, lexer_1.default.TokenType.Function);
    }
    Query.qualifiedFunctionName = qualifiedFunctionName;
    function skiptoken(value, index) {
        const start = index;
        if (utils_1.default.equals(value, index, "%24skiptoken")) {
            index += 12;
        }
        else if (utils_1.default.equals(value, index, "$skiptoken")) {
            index += 10;
        }
        else
            return;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        let ch = lexer_1.default.qcharNoAMP(value, index);
        if (!ch)
            return;
        const valueStart = index;
        while (ch && ch > index) {
            index = ch;
            ch = lexer_1.default.qcharNoAMP(value, index);
        }
        return lexer_1.default.tokenize(value, start, index, utils_1.default.stringify(value, valueStart, index), lexer_1.default.TokenType.SkipToken);
    }
    Query.skiptoken = skiptoken;
    function aliasAndValue(value, index) {
        const alias = expressions_1.default.parameterAlias(value, index);
        if (!alias)
            return;
        const start = index;
        index = alias.next;
        const eq = lexer_1.default.EQ(value, index);
        if (!eq)
            return;
        index = eq;
        const paramValue = expressions_1.default.parameterValue(value, index);
        if (!paramValue)
            return;
        index = paramValue.next;
        return lexer_1.default.tokenize(value, start, index, {
            alias,
            value: paramValue
        }, lexer_1.default.TokenType.AliasAndValue);
    }
    Query.aliasAndValue = aliasAndValue;
})(Query || (Query = {}));
exports.default = Query;
