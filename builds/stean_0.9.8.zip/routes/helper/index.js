"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchLastModified = exports.updateRoute = exports.adminRoute = exports.formatConfig = exports.adminConnectPg = exports.update = exports.getTest = exports.decodeUrl = exports.sqlStopDbName = exports.checkPassword = exports.emailIsValid = void 0;
/**
 * Routes Helpers.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
const emailIsValid = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
exports.emailIsValid = emailIsValid;
// at least one number, one lowercase and one uppercase letter
// at least six characters that are letters, numbers or the underscore
const checkPassword = (str) => /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])\w{6,}$/.test(str);
exports.checkPassword = checkPassword;
const sqlStopDbName = (dbName) => `SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE pid <> pg_backend_pid() AND datname = ${dbName};`;
exports.sqlStopDbName = sqlStopDbName;
var decodeUrl_1 = require("./decodeUrl");
Object.defineProperty(exports, "decodeUrl", { enumerable: true, get: function () { return decodeUrl_1.decodeUrl; } });
var test_1 = require("./test");
Object.defineProperty(exports, "getTest", { enumerable: true, get: function () { return test_1.getTest; } });
var update_1 = require("./update");
Object.defineProperty(exports, "update", { enumerable: true, get: function () { return update_1.update; } });
var adminConnectPg_1 = require("./adminConnectPg");
Object.defineProperty(exports, "adminConnectPg", { enumerable: true, get: function () { return adminConnectPg_1.adminConnectPg; } });
var formatConfig_1 = require("./formatConfig");
Object.defineProperty(exports, "formatConfig", { enumerable: true, get: function () { return formatConfig_1.formatConfig; } });
var adminRoute_1 = require("./adminRoute");
Object.defineProperty(exports, "adminRoute", { enumerable: true, get: function () { return adminRoute_1.adminRoute; } });
var updateRoute_1 = require("./updateRoute");
Object.defineProperty(exports, "updateRoute", { enumerable: true, get: function () { return updateRoute_1.updateRoute; } });
var fetchLastModified_1 = require("./fetchLastModified");
Object.defineProperty(exports, "fetchLastModified", { enumerable: true, get: function () { return fetchLastModified_1.fetchLastModified; } });
