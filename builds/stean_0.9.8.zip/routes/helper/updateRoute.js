"use strict";
/**
 * adminRoute connection page.
 *
 * @copyright 2020-present Inrae
 * @review 31-01-2024
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateRoute = void 0;
const helpers_1 = require("../../helpers");
const views_1 = require("../../views");
const adminConnectPg_1 = require("./adminConnectPg");
const updateRoute = async (ctx) => {
    ctx.set("script-src", "self");
    ctx.set("Content-Security-Policy", "self");
    ctx.type = helpers_1.returnFormats.html.type;
    ctx.body = new views_1.Update(ctx, { connection: await (0, adminConnectPg_1.adminConnectPg)(ctx), url: ctx.request.url, body: ctx.request.body, why: {} }).toString();
};
exports.updateRoute = updateRoute;
