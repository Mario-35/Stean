"use strict";
/**
* validJSONService
*
* @copyright 2020-present Inrae
* @author mario.adam@inrae.fr
*
*/
Object.defineProperty(exports, "__esModule", { value: true });
exports.validJSONService = validJSONService;
const enums_1 = require("../../enums");
/**
 * Verify is valid config
 *
 * @param input record service
 * @returns true if the service is valid
 */
function validJSONService(input) {
    if (!input.hasOwnProperty(enums_1.EConstant.admin))
        return false;
    if (!input[enums_1.EConstant.admin].hasOwnProperty("pg"))
        return false;
    const admin = input[enums_1.EConstant.admin]["pg"];
    if (!admin.hasOwnProperty("host"))
        return false;
    if (!admin.hasOwnProperty("user"))
        return false;
    if (!admin.hasOwnProperty("password"))
        return false;
    if (!admin.hasOwnProperty("database"))
        return false;
    return true;
}
