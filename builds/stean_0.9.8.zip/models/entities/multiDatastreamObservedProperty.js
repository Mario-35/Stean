"use strict";
/**
 * entity MultiDatastreamObservedProperty
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MULTIDATASTREAMOBSERVEDPROPERTY = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.MULTIDATASTREAMOBSERVEDPROPERTY = new entity_1.Entity("MultiDatastreamObservedProperties", {
    createOrder: 9,
    type: enums_1.ETable.link,
    order: -1,
    columns: {
        multidatastream_id: new types_1.Bigint().notNull().type(),
        observedproperty_id: new types_1.Bigint().notNull().type(),
    },
    relations: {}
});
