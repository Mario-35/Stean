"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.testDatas = exports.pgFunctions = exports.createDatabase = void 0;
/**
 * createDatabase Index
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var createDatabase_1 = require("./createDatabase");
Object.defineProperty(exports, "createDatabase", { enumerable: true, get: function () { return createDatabase_1.createDatabase; } });
var pgFunctions_1 = require("./pgFunctions");
Object.defineProperty(exports, "pgFunctions", { enumerable: true, get: function () { return pgFunctions_1.pgFunctions; } });
var tests_1 = require("./tests");
Object.defineProperty(exports, "testDatas", { enumerable: true, get: function () { return tests_1.testDatas; } });
