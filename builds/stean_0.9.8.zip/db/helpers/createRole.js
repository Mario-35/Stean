"use strict";
/**
* createRole
*
* @copyright 2020-present Inrae
* @author mario.adam@inrae.fr
*
*/
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRole = void 0;
const configuration_1 = require("../../configuration");
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
/**
 *
 * @param service service
 * @returns return ok or notOk
 */
const createRole = async (service) => {
    const connection = configuration_1.config.connection(enums_1.EConstant.admin);
    return new Promise(async function (resolve, reject) {
        await connection.unsafe(`SELECT COUNT(*) FROM pg_user WHERE usename = ${(0, helpers_1.simpleQuotesString)(service.pg.user)};`)
            .then(async (res) => {
            if (res[0].count == 0) {
                await connection.unsafe(`CREATE ROLE ${service.pg.user} WITH PASSWORD ${(0, helpers_1.simpleQuotesString)(service.pg.password)} ${enums_1.EConstant.rights}`)
                    .catch((err) => {
                    reject(err);
                });
            }
            else {
                await connection.unsafe(`ALTER ROLE ${service.pg.user} WITH PASSWORD ${(0, helpers_1.simpleQuotesString)(service.pg.password)}  ${enums_1.EConstant.rights}`)
                    .catch((err) => {
                    reject(err);
                });
            }
        });
        resolve(`${service.pg.user} ${"\u2714\uFE0F\uFE0F" /* EChar.ok */}`);
    });
};
exports.createRole = createRole;
