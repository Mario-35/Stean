"use strict";
/**
 * createTable
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTable = void 0;
const configuration_1 = require("../../configuration");
const log_1 = require("../../log");
const helpers_1 = require("../../helpers");
/**
 *
 * @param serviceName name of the service
 * @param tableEntity entity to create
 * @param doAfter query to execute after create table Ok
 * @returns record log report
 */
const createTable = async (serviceName, tableEntity, doAfter) => {
    console.log(log_1.log.debug_head(`CreateTable [${tableEntity.table || `pseudo ${tableEntity.name}`}] for ${serviceName}`));
    if (!tableEntity)
        return {};
    const space = 5;
    const tab = () => " ".repeat(space);
    const tabIeInsert = [];
    const tableConstraints = [];
    const returnValue = {};
    let insertion = "";
    if (!configuration_1.config.connection(serviceName)) {
        log_1.log.error("connection Error");
        return { error: "connection Error" };
    }
    Object.keys(tableEntity.columns).forEach((column) => {
        if (tableEntity.columns[column].create.trim() != "")
            tabIeInsert.push(`${(0, helpers_1.doubleQuotesString)(column)} ${tableEntity.columns[column].create}`);
    });
    insertion = tabIeInsert.join(", ");
    Object.keys(tableEntity.constraints).forEach((constraint) => {
        tableConstraints.push(`ALTER TABLE ONLY ${(0, helpers_1.doubleQuotesString)(tableEntity.table)} ADD CONSTRAINT ${(0, helpers_1.doubleQuotesString)(constraint)} ${tableEntity.constraints[constraint]}`);
    });
    let sql = `CREATE TABLE ${(0, helpers_1.doubleQuotesString)(tableEntity.table)} (${insertion});`;
    console.log(log_1.log.query(sql));
    if (tableEntity.table.trim() != "")
        returnValue[String(`Create table ${(0, helpers_1.doubleQuotesString)(tableEntity.table)}`)] =
            await configuration_1.config.connection(serviceName).unsafe(sql)
                .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
                .catch((error) => error.message);
    const indexes = tableEntity.indexes;
    const tabTemp = [];
    // CREATE INDEXES
    if (indexes)
        Object.keys(indexes).forEach((index) => {
            tabTemp.push(`CREATE INDEX "${index}" ${indexes[index]}`);
        });
    if (tabTemp.length > 0) {
        sql = tableConstraints.join(";");
        console.log(log_1.log.query(sql));
        returnValue[`${tab()}Create indexes for ${tableEntity.name}`] =
            await configuration_1.config.connection(serviceName).unsafe(sql)
                .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
                .catch((error) => error.message);
    }
    // CREATE CONSTRAINTS
    if (tableConstraints.length > 0) {
        sql = tabTemp.join(";");
        console.log(log_1.log.query(sql));
        returnValue[`${tab()}Create constraints for ${tableEntity.table}`] =
            await configuration_1.config.connection(serviceName).unsafe(sql)
                .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
                .catch((error) => error.message);
    }
    // CREATE SOMETHING AFTER
    if (tableEntity.after) {
        log_1.log.query(tableEntity.after);
        if (tableEntity.after.toUpperCase().startsWith("INSERT"))
            returnValue[`${tab()}Something to do after for ${tableEntity.table}`] =
                await configuration_1.config.connection(serviceName).unsafe(tableEntity.after)
                    .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
                    .catch((error) => {
                    log_1.log.error(error);
                    return error.message;
                });
    }
    // CREATE SOMETHING AFTER (migration)
    if (doAfter) {
        log_1.log.query(doAfter);
        returnValue[`${tab()} doAfter ${tableEntity.table}`] = await configuration_1.config.connection(serviceName).unsafe(doAfter)
            .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
            .catch((error) => error.message);
    }
    return returnValue;
};
exports.createTable = createTable;
