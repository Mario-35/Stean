Object.defineProperty(exports,"__esModule",{value:!0}),exports.queries=void 0;let enums_1=require("../../enums"),helpers_1=require("../../helpers"),entities_1=require("../../models/entities");class Queries{creatdeDB(e){return`CREATE DATABASE ${e};`}terminate(e){return`SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE pid <> pg_backend_pid() AND datname = '${e}';`}dropDB(e){return`DROP DATABASE IF EXISTS ${e};`}insertConfig(e,t){return`INSERT INTO public.services ("name", "datas") VALUES('${e}', ${t}) ON CONFLICT (name) DO UPDATE SET datas = ${t};`}updateConfig(e,t){return`UPDATE public.services SET "datas" = ${t} WHERE "name" = '${e}';`}deleteConfig(e){return`DELETE FROM public.services WHERE "name" = '${e}';`}logsAndTriggers(e){return`SET session_replication_role = ${!0===e?"DEFAULT":"replica"};`}deleteFromId(e,t){return t?`DELETE FROM "${e}" WHERE "id" = ${t} RETURNING id`:""}getIdFromName(e,t){return`SELECT id FROM "${e}" WHERE "name" = '${t}'`}addNbToTable(e){return`ALTER TABLE IF EXISTS "${e}" ADD COLUMN IF NOT EXISTS _nb BIGINT NULL;`}updateNb(e,t){return`UPDATE "observation" SET _nb = row_number FROM ( SELECT ROW_NUMBER() OVER ( PARTITION BY ${e}_id ORDER BY "phenomenonTime" ), id FROM "observation" WHERE ${e}_id IS NOT NULL ) i WHERE "observation".id = i.id${!0===t?"":" AND _nb IS NULL"};`}logLevel(e){return`SET client_min_messages TO ${e};`}createExtension(e){return"CREATE EXTENSION IF NOT EXISTS "+e}drop(e){return`DROP TABLE "${e}";`}createTableService(){return'CREATE TABLE public.services ( "name" text NOT NULL, "datas" jsonb NULL, CONSTRAINT services_unik_name UNIQUE (name) ); CREATE INDEX services_name ON public.services USING btree (name);'}createRole(e,t){return`CREATE ROLE ${e} WITH PASSWORD '${t}' `+this.rights()}rights(){return"SUPERUSER CREATEDB NOCREATEROLE INHERIT LOGIN NOREPLICATION NOBYPASSRLS CONNECTION LIMIT -1"}updateRole(e,t){return`ALTER ROLE ${e} WITH PASSWORD '${t}' `+this.rights()}countUser(e){return`SELECT COUNT(*) FROM pg_user WHERE usename = '${e}';`}createTrigger(e,t){return`CREATE TRIGGER "${e}_${t}" BEFORE INSERT OR DELETE ON "${e}" FOR EACH ROW EXECUTE PROCEDURE ${t}();`}dropTrigger(e,t){return`DROP TRIGGER IF EXISTS "${e}_${t}" ON "${e}";`}asCsv(e,t){return`COPY (${e}) TO STDOUT WITH (FORMAT CSV, NULL "NULL", HEADER, DELIMITER '${t}')`}asJson(e){return""===e.query.trim()?"":`SELECT ${1==e.count?`${e.fullCount?`(${e.fullCount})`:`COUNT(t) AS "${enums_1.EConstant.count}"`},`+enums_1.EConstant.return+enums_1.EConstant.tab:""}${e.fields?e.fields.join(","+enums_1.EConstant.return+enums_1.EConstant.tab):""}COALESCE(${!0===e.singular?"ROW_TO_JSON":`${!0===e.strip?"JSON_STRIP_NULLS(":""} JSON_AGG`}(t)${!0===e.strip?")":""}, '${!0===e.singular?"{}":"[]"}') AS value${enums_1.EConstant.return}${enums_1.EConstant.tab}FROM (${enums_1.EConstant.return}${enums_1.EConstant.tab}${e.query}) AS t`}asDataArray(t){let r=!0===t.onlyRef?[enums_1.EConstant.selfLink]:t.toPgQuery()?.keys.map(e=>(0,helpers_1.formatPgString)(e))||[];return t.includes&&t.includes.forEach(e=>{e.entity&&r.push(e.entity.singular)}),this.asJson({query:`SELECT (ARRAY[${enums_1.EConstant.newline}	${r.map(e=>(0,helpers_1.simpleQuotes)((0,helpers_1.escapeSimpleQuotes)(e))).join(`,${enums_1.EConstant.newline}	`)}]) AS "components", JSONB_AGG(allkeys) AS "dataArray" FROM (SELECT JSON_BUILD_ARRAY(${enums_1.EConstant.newline}	${r.map(e=>""+(0,helpers_1.doubleQuotes)(e)+(e=>{if(e=e===enums_1.EConstant.id?"id":e,t.entity?.columns[e])switch(t.entity.columns[e].dataType){case enums_1.EDataType.bigint:case enums_1.EDataType.smallint:case enums_1.EDataType.integer:case enums_1.EDataType.any:return"";default:return"::text"}return""})(e)).join(`,${enums_1.EConstant.newline}	`)}) AS allkeys ${enums_1.EConstant.return}${enums_1.EConstant.tab}FROM (${t.toString()}) AS p) AS l`,singular:!1,strip:!1,count:!0})}asGeoJSON(e){return`SELECT JSONB_BUILD_OBJECT(
        'type', 
        'FeatureCollection', 
        'features', 
        (${this.asJson({query:e.toString(),singular:!1,strip:!1,count:!1})})) AS value;`}createIdList(e){let t=[];if(e.includes(":")){var r=e.split(":");for(let e=+r[0];e<=+r[1];e++)t.push(String(e))}else e.includes(",")?t=e.split(","):t.push(String(e));return t.filter(e=>""!=e.trim())}interval(e){return e.interval?`WITH src as (
    ${e.toString()}
), 
range_values AS (
    SELECT 
        min(srcdate) as minval, 
        max(srcdate) as maxval 
    FROM 
        src
), 
time_range AS (
    SELECT 
        generate_series( minval :: timestamp, maxval :: timestamp, '${e.interval||"1 day"}' :: interval ):: TIMESTAMP WITHOUT TIME ZONE as step 
    FROM 
        range_values
) 
SELECT 
    ${e.intervalColumns?e.intervalColumns.filter(e=>""!=e).join(", "):""} 
FROM 
    src RIGHT JOIN time_range on srcdate = step`:e.toString()}graphDatastream(e,t,r){var a=this.interval(r);let s="string"==typeof t?this.createIdList(t):[String(t)],n=r.toPgQuery();return`SELECT ( 
                SELECT 
                  CONCAT( description, '|', "unitOfMeasurement" ->> 'name', '|', "unitOfMeasurement" ->> 'symbol' ) 
                FROM "${e}"
                  WHERE id = ${s[0]} 
               ) AS infos, 
        STRING_AGG(concat, ',') AS datas 
        `+(1===s.length?`FROM (${a.replace("@GRAPH@",`CONCAT('[new Date("', TO_CHAR("resultTime", 'YYYY/MM/DD HH24:MI'), '"), ', result->'value' ,']')`)}) AS z`:` FROM (
                SELECT CONCAT( '[new Date("', TO_CHAR( date, 'YYYY/MM/DD HH24:MI' ), '"), ', ${s.map((e,t)=>`coalesce(y.res${t+1},'null'),','`)}, ']' ) 
                  FROM (
                    SELECT 
                      DISTINCT COALESCE( ${s.map((e,t)=>`result${t+1}.date`).join(",")} ) AS date, 
                      ${s.map((e,t)=>`COALESCE( result${t+1}.res :: TEXT, 'null' ) AS res`+(t+1)).join(",")} FROM ${s.map((e,t)=>`${1<t+1?"FULL JOIN ":""}
                      (
                        SELECT 
                          round_minutes("resultTime", 15) AS date, 
                          ${s.filter(e=>+e!==t+1).map((e,t)=>"null AS res"+(t+1)).join(",")}, 
                          result -> 'value' AS res 
                        FROM 
                          "datastream_id${s[t]}"  
                        ORDER BY ${n&&n.orderBy?" "+(0,helpers_1.cleanStringComma)(n.orderBy,["ASC","DESC"]):'"resultTime" ASC '}
                        ${r.limit?"LIMIT "+r.limit:""}
                      ) AS result${t+1} `+(1<t+1?` ON result${t}.date = result${t+1}.date`:"")).join(" ")} 
                  ) AS y
              ) AS z`)}graphMultiDatastream(e,t,r){var a=this.interval(r);let s="string"==typeof t?this.createIdList(t):[String(t)],n=r.toPgQuery();return 1===s.length?`WITH 
          src AS (
            SELECT 
              id, 
              description, 
              jsonb_array_elements("unitOfMeasurements")->>'name' AS name, 
              jsonb_array_elements("unitOfMeasurements")->>'symbol' AS symbol 
            FROM 
            (SELECT * FROM ${e} WHERE id = ${t} ) AS l
          ),  
          results AS (
            SELECT 
              src.id, 
              src.description, 
              src.name, 
              src.symbol, 
              (
                SELECT 
                  STRING_AGG(concat, ',') AS datas 
                FROM (
                    ${a.replace("@GRAPH@",`CONCAT('[new Date("', round_minutes("resultTime", 5), '"), ', result->'value'->(select array_position(array(select jsonb_array_elements("unitOfMeasurements")->> 'name' FROM ( SELECT * FROM ${e} WHERE id = ${t} ) AS l), src.name)-1),']')`)}
                    ) AS nop )
            FROM 
              "multidatastream" 
            INNER JOIN src ON multidatastream.id = src.id
          ) 
          SELECT * FROM results `+(r.splitResult?`WHERE name in ('${r.splitResult.join(enums_1.EConstant.simpleQuotedComa)}')`:""):`WITH 
      src AS (
        SELECT 
          id, 
          description, 
          jsonb_array_elements("unitOfMeasurements")->> 'name' AS name, 
          jsonb_array_elements("unitOfMeasurements")->> 'symbol' AS symbol 
        FROM 
        ( SELECT * FROM ${e} WHERE id = ${s[0]} ) AS l
      ), 
      results AS (
        SELECT 
          src.id, 
          src.description, 
          src.name, 
          src.symbol, 
          (
            SELECT 
              STRING_AGG(concat, ',') AS datas 
            FROM 
              (
                SELECT 
                  CONCAT(
                    '[new Date("', 
                    TO_CHAR(date, 'YYYY/MM/DD HH24:MI'), 
                    '"), ', 
                    ${s.map((e,t)=>`coalesce(y.res${t+1},'null'),','`)}, 
                    ']'
                  ) 
                FROM 
                  (
                    SELECT 
                      distinct COALESCE(
                        ${s.map((e,t)=>`result${t+1}.date`).join(",")}
                      ) AS date, 
                      ${s.map((e,t)=>`COALESCE(
                        result${t+1}.res :: TEXT, 'null'
                      ) AS res`+(t+1)).join(",")} 
                    FROM ${s.map((e,t)=>`${1<t+1?"FULL JOIN ":""}
                    (
                      SELECT 
                        round_minutes("resultTime", 15) as date, 
                        ${s.filter(e=>+e!==t+1).map((e,t)=>"null as res"+(t+1)).join(",")} ,
                        result -> 'value' ->(
                          select 
                            array_position(
                              array(
                                select jsonb_array_elements("unitOfMeasurements")->> 'name' FROM ( SELECT * FROM multidatastream WHERE id = ${s[t]} ) as one
                              ), src.name
                            )-1
                        ) as res
                      FROM 
                        "observation" 
                      WHERE 
                        "observation"."id" in (
                          SELECT 
                            "observation"."id" 
                          from 
                            "observation" 
                          WHERE 
                            "observation"."multidatastream_id" = ${s[t]}
                        ) 
                      ORDER BY ${n&&n.orderBy?" "+(0,helpers_1.cleanStringComma)(n.orderBy,["ASC","DESC"]):'"resultTime" ASC '}
                        ${r.limit?"LIMIT "+r.limit:""}
                    ) as result${t+1} `+(1<t+1?` ON result${t}.date = result${t+1}.date`:"")).join(" ")} 
                  ) As y
              ) AS z
          ) 
        FROM 
          "multidatastream" 
          INNER JOIN src ON multidatastream.id = src.id
      ) 
      SELECT * FROM results`}streamFromDeveui(e,t){return`SELECT 
            "lorastream"."${e}_id" 
          FROM 
            "lorastream" 
          WHERE 
            "lorastream"."lora_id" = (SELECT id FROM "lora" WHERE deveui = '${t}')`}multiDatastreamFromDeveui(e){return`(SELECT jsonb_agg(tmp.units -> 'name') AS keys FROM ( SELECT jsonb_array_elements("unitOfMeasurements") AS units ) AS tmp ) FROM "multidatastream" WHERE "multidatastream".id = (${this.streamFromDeveui("multidatastream",e)})`}multiDatastreamKeys(e){return`SELECT jsonb_agg(tmp.units -> 'name') AS keys FROM ( SELECT jsonb_array_elements("unitOfMeasurements") AS units FROM "multidatastream" WHERE id = ${e} ) AS tmp`}streamInfosFromDeveui(e){return`WITH multidatastream AS (
  SELECT 
    JSON_AGG(t) AS multidatastream 
  FROM 
    (
      SELECT 
        id AS multidatastream, 
        id, 
        _default_featureofinterest, 
        thing_id, 
        (
          SELECT 
            JSONB_AGG(tmp.units -> 'name') AS keys 
          FROM 
            (
              SELECT 
                JSONB_ARRAY_ELEMENTS("unitOfMeasurements") AS units
            ) AS tmp
        ) 
      FROM 
        "multidatastream" 
      WHERE 
        "multidatastream".id = (${this.streamFromDeveui("multidatastream",e)}
        )
    ) AS t
), 
datastream AS (
  SELECT 
    json_agg(t) AS datastream 
  FROM 
    (
      SELECT 
        id AS datastream, 
        id, 
        _default_featureofinterest, 
        thing_id, 
        '{}' :: jsonb AS keys 
      FROM 
        "datastream"
      WHERE 
        "datastream".id = (${this.streamFromDeveui("datastream",e)}
        )
    ) AS t
) 
SELECT 
  datastream.datastream, 
  multidatastream.multidatastream 
FROM 
  multidatastream, 
  datastream
`}multiDatastreamsUnitsKeys(e){return`SELECT jsonb_agg(tmp.units -> 'name') AS keys FROM ( SELECT jsonb_array_elements("unitOfMeasurements") AS units FROM "multidatastream" WHERE id = ${e} ) AS tmp`}multiDatastreamUoM(e){return`SELECT jsonb_agg(tmp.units -> 'name') AS keys FROM ( SELECT jsonb_array_elements("unitOfMeasurements") AS units FROM "multidatastream" WHERE id = ${e.parentId} ) AS tmp `}resultKeys(e,t){return`SELECT DISTINCT JSONB_OBJECT_KEYS(${e}) AS k FROM "observation" WHERE JSONB_TYPEOF(${e}) LIKE 'object' AND "observation"."id" IN ( SELECT "observation"."id" FROM "observation" WHERE "observation"."${t.parentEntity?.table}_id" = ${t.parentId} )`}testId(e,t){return`SELECT CASE WHEN EXISTS( SELECT 1 FROM "${e}" WHERE "id" = ${t} ) THEN ( SELECT "id" FROM "${e}" WHERE "id" = ${t} ) END AS "id"`}getDecoder(e){return`SELECT "id", "name", "code", "nomenclature", "synonym" FROM "${entities_1.DECODER.table}"`+(e?" WHERE "+e:"")}getDecoderFromDeveui(e){return this.getDecoder(` id = (SELECT "decoder_id" FROM "${entities_1.LORA.table}" WHERE "deveui" = '${e}') LIMIT 1`)}countAll(){return"SELECT JSON_AGG(t) AS results FROM ( select table_name, ( xpath( '/row/c/text()', query_to_xml( format( 'select count(*) AS c from %I.%I', table_schema, table_name ), false, true, '' ) ) ) [1] :: text :: int AS count from information_schema.tables where table_name IN ( SELECT (inhrelid :: regclass):: text AS child FROM pg_catalog.pg_inherits WHERE inhparent = 'observation' :: regclass OR inhparent = 'datastream_id0' :: regclass ) order by count DESC ) AS t "}listPartionned(){return"SELECT array_agg(table_name) from information_schema.tables where table_name IN ( SELECT (inhrelid :: regclass):: text AS child FROM pg_catalog.pg_inherits WHERE inhparent = 'observation' :: regclass OR inhparent = 'datastream_id0' :: regclass )"}getDate(){return"SELECT current_timestamp;"}count(e,t){return`SELECT COUNT("${t||"*"}")::int FROM "${e}";`}last(e,t){return`SELECT "${t||"*"}" FROM "${e}" ORDER BY "${t||"*"}" DESC LIMIT 1`}getUser(e){return`SELECT "username" FROM "${entities_1.USER.table}" WHERE username = '${e}' LIMIT 1`}getFromIdOrName(e,t,r){return`SELECT "${t}" FROM "${e}" WHERE `+(r[enums_1.EConstant.id]?"id="+r[enums_1.EConstant.id]:r[enums_1.EConstant.name]?`name='${r[enums_1.EConstant.name]}'`:"ERROR")}cluster(e){return`CLUSTER ${e} USING "${e}_nb";`}createClusterIndex(e){return`CREATE UNIQUE INDEX IF NOT EXISTS "${e}_nb" on ${e} (_nb);`}}exports.queries=new Queries;