"use strict";
/**
 * Constants of API
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports._REPLAY = exports._READY = exports._DEBUG = exports.timestampNow = exports.ESCAPE_SIMPLE_QUOTE = exports.appVersion = void 0;
exports.setReplay = setReplay;
exports.setDebug = setDebug;
exports.setReady = setReady;
exports.logDbError = logDbError;
const fs_1 = __importDefault(require("fs"));
const paths_1 = require("./paths");
const enums_1 = require("./enums");
const log_1 = require("./log");
process.env.NODE_ENV = process.env.NODE_ENV || "production";
const _appVersion = () => {
    const d = fs_1.default.fstatSync(fs_1.default.openSync(paths_1.paths.packageFile(), "r")).mtime;
    return {
        version: String(JSON.parse(String(fs_1.default.readFileSync(paths_1.paths.packageFile(), "utf-8"))).version),
        date: d.toLocaleDateString() + "-" + d.toLocaleTimeString()
    };
};
exports.appVersion = _appVersion();
const ESCAPE_SIMPLE_QUOTE = (input) => input.replace(/[']+/g, "''");
exports.ESCAPE_SIMPLE_QUOTE = ESCAPE_SIMPLE_QUOTE;
const timestampNow = () => new Date().toLocaleTimeString();
exports.timestampNow = timestampNow;
function setReplay(input) {
    exports._REPLAY = input;
}
function setDebug(input) {
    exports._DEBUG = input;
}
function setReady(input) {
    exports._READY = input;
    return input;
}
exports._DEBUG = process.env.NODE_ENV?.trim() === enums_1.EConstant.test || false;
exports._READY = false;
exports._REPLAY = undefined;
// function to be used in catch
function logDbError(err) {
    console.log(err);
    log_1.logging.error(err);
    return false;
}
