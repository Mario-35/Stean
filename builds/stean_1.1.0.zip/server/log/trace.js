"use strict";
/**
 * Trace class
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Trace = void 0;
const constants_1 = require("../constants");
const helpers_1 = require("../helpers");
const _1 = require(".");
const paths_1 = require("../paths");
const enums_1 = require("../enums");
const constants_2 = require("../db/constants");
/**
 * Class to trace requests
 */
class Trace {
    static adminConnection;
    constructor(adminConnection) {
        Trace.adminConnection = adminConnection;
    }
    queryReplay(ctx, error) {
        return `INSERT INTO public.log ( method, url ${(0, helpers_1.notNull)(error) ? ", error" : ""}) VALUES( 'REPLAY', '${ctx.decodedUrl.root}/Logs(${constants_1._REPLAY})' ${(0, helpers_1.notNull)(error) ? `,${(0, constants_2.FORMAT_JSONB)(error)}` : ""}) RETURNING id;`;
    }
    query(ctx, error) {
        return ctx.traceId && error ? `UPDATE public.log SET error = ${(0, constants_2.FORMAT_JSONB)(error)} WHERE id = ${ctx.traceId}` : `INSERT INTO public.log (method, url${(0, helpers_1.notNull)(ctx.body) ? ", datas" : ""}${(0, helpers_1.notNull)(error) ? ", error" : ""}) VALUES('${ctx.method}', '${ctx.request.url}'${(0, helpers_1.notNull)(ctx.body) ? `,${(0, constants_2.FORMAT_JSONB)(ctx.body)}` : ""}${(0, helpers_1.notNull)(error) ? `,${(0, constants_2.FORMAT_JSONB)(error)}` : ""}) RETURNING id;`;
    }
    /**
     * Add to trace
     *
     * @param ctx koa context
     */
    async write(ctx) {
        console.log(_1.log.whereIam());
        if (ctx.request.url.includes("Replays(") || ctx.request.url.includes("$replay=") || constants_1._REPLAY)
            return;
        if (ctx.method !== "GET") {
            const datas = this.query(ctx);
            await Trace.adminConnection
                .unsafe(datas)
                .then((res) => {
                ctx.traceId = BigInt(res[0].id);
            })
                .catch(async (error) => {
                console.log(error);
                if (error.code === "42P01") {
                    await Trace.adminConnection.unsafe(`CREATE TABLE public.log ( id int8 GENERATED ALWAYS AS IDENTITY( INCREMENT BY 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1 NO CYCLE ) NOT NULL, "date" timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL, "method" text NULL, url text NULL, datas jsonb NULL, CONSTRAINT log_pkey PRIMARY KEY (id) ); CREATE INDEX log_id ON public.log USING btree (id); `).catch((err) => process.stdout.write(err + enums_1.EConstant.return));
                    Trace.adminConnection.unsafe(datas);
                }
                else
                    process.stdout.write(error + enums_1.EConstant.return);
            });
        }
    }
    /**
     * Trace error
     *
     * @param ctx koa context
     */
    async error(ctx, error) {
        console.log(_1.log.whereIam());
        if (ctx.request.url.includes("Replays("))
            return;
        try {
            await Trace.adminConnection.unsafe(constants_1._REPLAY ? this.queryReplay(ctx, error) : this.query(ctx, error));
        }
        catch (err) {
            console.log("---- [Error Log Error]-------------");
            console.log(err);
        }
    }
    async get(query) {
        return new Promise(async function (resolve, reject) {
            await Trace.adminConnection
                .unsafe(query)
                .then((res) => {
                resolve(res[0]);
            })
                .catch((err) => {
                if (!(0, helpers_1.isTest)() && +err["code"] === 23505) {
                    const input = _1.log.queryError(query, err);
                    process.stdout.write(input + enums_1.EConstant.return);
                    paths_1.paths.logFile.writeStream((0, helpers_1.logToHtml)(input));
                }
                reject(err);
            });
        });
    }
    async getValues(query) {
        return new Promise(async function (resolve, reject) {
            await Trace.adminConnection
                .unsafe(query)
                .values()
                .then((res) => {
                resolve(res[0]);
            })
                .catch((err) => {
                if (!(0, helpers_1.isTest)() && +err["code"] === 23505) {
                    const input = _1.log.queryError(query, err);
                    process.stdout.write(input + enums_1.EConstant.return);
                    paths_1.paths.logFile.writeStream((0, helpers_1.logToHtml)(input));
                }
                reject(err);
            });
        });
    }
    async rePlay(ctx) {
        console.log(_1.log.whereIam());
        await this.get(`SELECT * FROM log WHERE id=${ctx.decodedUrl.id}`).then(async (input) => {
            if (["POST", "PUT", "PATCH"].includes(input.method)) {
                // const id = getBigIntFromString(input.url );
                try {
                    await fetch(ctx.decodedUrl.origin + input.url + "?$replay=" + ctx.decodedUrl.id, {
                        method: input.method,
                        headers: {
                            "Content-Type": enums_1.EEncodingType.json
                        },
                        body: JSON.stringify(input.datas)
                    });
                    return true;
                }
                catch (error) {
                    console.log(error);
                    return false;
                }
            }
        });
        return false;
    }
}
exports.Trace = Trace;
