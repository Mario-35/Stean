"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logging = void 0;
const constants_1 = require("../constants");
const enums_1 = require("../enums");
const util_1 = __importDefault(require("util"));
const helpers_1 = require("../helpers");
const paths_1 = require("../paths");
// class to logCreate configs environements
class Logging {
    static _s = "";
    init(input, col) {
        Logging._s = "";
        if (input)
            this.text(input, col);
        return this;
    }
    color(col) {
        Logging._s += `\x1b[${col || 37 /* EColor.White */}m`;
        return this;
    }
    text(text, col) {
        this.color(col);
        Logging._s += this.objet(text);
        return this;
    }
    line(nb, col) {
        this.color(col);
        Logging._s += "▬".repeat(nb);
        return this;
    }
    space(text) {
        Logging._s += text ? ` ${text} ` : " ";
        return this;
    }
    whereIam(input, infos) {
        Logging._s = "";
        if (constants_1._DEBUG) {
            this.color(91 /* EColor.Logo */);
            Logging._s += "===> ";
            this.message(new Error().stack?.split(enums_1.EConstant.return)[2].trim().split("(")[0].split("at ")[1].trim() || "Error", input?.split(enums_1.EConstant.return)[2].trim().split("(")[0].split("at ")[1].trim(), "FROM");
            if (infos)
                this.space(infos);
            this.color(91 /* EColor.Logo */);
            Logging._s += " <===";
        }
        return this;
    }
    toDebugString() {
        if (constants_1._DEBUG) {
            const tmp = Logging._s;
            Logging._s = "";
            return tmp;
        }
    }
    toString() {
        const tmp = Logging._s;
        Logging._s = "";
        return tmp;
    }
    sep(input, col) {
        this.color(col || 36 /* EColor.Cyan */);
        Logging._s += ` ${input || ":"} `;
        return this;
    }
    date(col) {
        this.color(col || 32 /* EColor.Green */);
        Logging._s += ` ${new Date().toLocaleDateString()} : ${(0, constants_1.timestampNow)()} `;
        return this;
    }
    separator(title, col) {
        Logging._s = this.init()
            .line(20, col || 31 /* EColor.Red */)
            .space()
            .text(title)
            .space()
            .line(20, col || 31 /* EColor.Red */)
            .toString();
        return this;
    }
    objet(input) {
        return typeof input === "object" ? util_1.default.inspect(input, { showHidden: false, depth: null, colors: true }) : input;
    }
    error(cle, infos) {
        this.init(String(cle), 36 /* EColor.Cyan */);
        this.sep();
        this.color(35 /* EColor.Magenta */);
        if (infos)
            this.objet(infos);
        return this;
    }
    /**
     *
     * @param cle key message
     * @param infos  message
     * @returns formated string
     */
    message(cle, infos, sep) {
        this.text(cle, 32 /* EColor.Green */).sep(sep).color(37 /* EColor.White */);
        Logging._s += this.objet(infos);
        return this;
    }
    write(test) {
        if (test === true && Logging._s) {
            const tmp = this.toString();
            if (tmp) {
                process.stdout.write(tmp + enums_1.EConstant.return);
                // write in stream file
                paths_1.paths.logFile.writeStream((0, helpers_1.logToHtml)(tmp + enums_1.EConstant.return));
            }
        }
        return this;
    }
    result(test) {
        return test;
    }
    /**
     *
     * @param sql sql query
     * @returns formated string
     */
    query(src, sql) {
        if (constants_1._DEBUG) {
            this.separator("[ Query " + src + " ]");
            Logging._s += enums_1.EConstant.return;
            this.color(36 /* EColor.Cyan */);
            Logging._s += this.objet(sql);
        }
        return this;
    }
    /**
     * format Sql error
     *
     * @param query sql query
     * @param error error message
     * @returns formated string
     */
    queryError(query, error) {
        this.separator("ERROR");
        Logging._s += this.objet(error);
        Logging._s += this.objet(query);
        return this;
    }
    head(cle, col = 36 /* EColor.Cyan */) {
        Logging._s = "";
        if (constants_1._DEBUG) {
            this.line(12, col);
            this.color(37 /* EColor.White */);
            this.space(cle);
            this.line(12, col);
        }
        return this;
    }
    logo() {
        Logging._s = `${(0, enums_1.color)(93 /* EColor.Code */)}${(0, enums_1.color)(92 /* EColor.Sql */)}${enums_1.EConstant.return} ____ __________    _     _   _ ${enums_1.EConstant.return}/ ___|_ __  ____|  / \\   | \\ | |${enums_1.EConstant.return}\\___ \\| | |  _|   / _ \\  |  \\| |${enums_1.EConstant.return} ___) | | | |___ / ___ \\ | |\\  |${enums_1.EConstant.return}|____/|_| |_____|_/   \\_\\|_| \\_|  ${(0, enums_1.color)(34 /* EColor.Blue */)}run API ${"\uD83E\uDC7A" /* EChar.arrowright */} ${(0, enums_1.color)(32 /* EColor.Green */)} ${constants_1.appVersion.version} du ${constants_1.appVersion.date} ${(0, enums_1.color)(92 /* EColor.Sql */)}${(0, enums_1.color)(93 /* EColor.Code */)}${enums_1.EConstant.return}${"\uD83C\uDF0D" /* EChar.web */} ${(0, enums_1.color)(37 /* EColor.White */)}https://github.com/Mario-35/Stean/ ${"\uD83D\uDCE7" /* EChar.mail */} ${(0, enums_1.color)(33 /* EColor.Yellow */)} mario.adam@inrae.fr${(0, enums_1.color)(0 /* EColor.Reset */)}${enums_1.EConstant.return}`;
        return this;
    }
    status(test, cle) {
        Logging._s += "    ";
        this.color(92 /* EColor.Sql */);
        this.space("\uD83E\uDC7A" /* EChar.arrowright */);
        this.color(39 /* EColor.Default */);
        this.space(cle);
        this.space(test ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : "\u274C" /* EChar.notOk */);
        return this;
    }
}
exports.logging = new Logging();
