"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.debugoBJ = exports.debug = void 0;
exports.myParent = myParent;
exports.whoIsMyDaddy = whoIsMyDaddy;
const fs_1 = __importDefault(require("fs"));
const enums_1 = require("../enums");
const util_1 = __importDefault(require("util"));
const debug = (query) => {
    fs_1.default.appendFile("messages.txt", query + enums_1.EConstant.return, function (err) {
        if (err)
            throw err;
    });
};
exports.debug = debug;
const debugoBJ = (query) => {
    fs_1.default.appendFile("messages.txt", util_1.default.inspect(query, { showHidden: false, depth: null, colors: false }) + enums_1.EConstant.return, function (err) {
        if (err)
            throw err;
    });
};
exports.debugoBJ = debugoBJ;
function myParent() {
    return new Error().stack?.split("\n")[2].trim().split("(")[0].split("at ")[1].trim() || "none";
}
function whoIsMyDaddy() {
    try {
        throw new Error();
    }
    catch (e) {
        if (e) {
            // matches this function, the caller and the parent
            const allMatches = e.stack.match(/(\w+)@|at (\w+) \(/g);
            // match parent function name
            const parentMatches = allMatches[2].match(/(\w+)@|at (\w+) \(/);
            // return only name
            return parentMatches[1] || parentMatches[2];
        }
        return "None";
    }
}
