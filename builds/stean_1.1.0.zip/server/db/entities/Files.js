"use strict";
/**
 * Files entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Files = void 0;
const common_1 = require("./common");
const log_1 = require("../../log");
/**
 * Files Class
 */
class Files extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.logging.whereIam(new Error().stack).toString());
        super(ctx);
    }
}
exports.Files = Files;
