"use strict";
/**
 * Datastreams entity
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Datastreams = void 0;
const log_1 = require("../../log");
const messages_1 = require("../../messages");
const entities_1 = require("../../models/entities");
const common_1 = require("./common");
/**
 * Datastreams Class
 */
class Datastreams extends common_1.Common {
    constructor(ctx) {
        console.log(log_1.logging.whereIam(new Error().stack).toString());
        super(ctx);
    }
    formatDataInput(input) {
        console.log(log_1.logging.whereIam(new Error().stack).toString());
        if (input) {
            const colName = "observationType";
            if (input[colName]) {
                if (!entities_1.DATASTREAM.columns[colName].verify?.list.includes(input[colName]))
                    this.ctx.throw(400 /* EHttpCode.badRequest */, { code: 400 /* EHttpCode.badRequest */, detail: messages_1.errors[colName] });
            }
            else
                input[colName] = entities_1.DATASTREAM.columns[colName].verify?.default;
        }
        return input;
    }
}
exports.Datastreams = Datastreams;
