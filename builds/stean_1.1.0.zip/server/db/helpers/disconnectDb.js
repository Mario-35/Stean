"use strict";
/**
 * disconnectDb.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.disconnectDb = void 0;
const configuration_1 = require("../../configuration");
/**
 *
 * @param dbName name of the database to close
 * @param drop true to drop database
 * @returns operation result
 */
const disconnectDb = async (dbName, drop) => {
    try {
        return await configuration_1.config.executeAdmin(`SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE pid <> pg_backend_pid() AND datname = '${dbName}'`).then(async () => {
            if (drop === true)
                await configuration_1.config.executeAdmin(`DROP DATABASE IF EXISTS ${dbName}`);
            return true;
        });
    }
    catch (error) {
        console.log(error);
    }
    return false;
};
exports.disconnectDb = disconnectDb;
