"use strict";
/**
 * executeSql
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeSql = void 0;
const configuration_1 = require("../../configuration");
const log_1 = require("../../log");
const helpers_1 = require("../../helpers");
const constants_1 = require("../../constants");
const executeSqlOne = async (service, query) => {
    log_1.logging.query("executeSqlOne", query).write(constants_1._DEBUG);
    return new Promise(async function (resolve, reject) {
        await configuration_1.config
            .connection(service.name)
            .unsafe(query)
            .then((res) => {
            resolve(res);
        })
            .catch((err) => {
            if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                log_1.logging.queryError(query, err).write(true);
            reject(err);
        });
    });
};
const executeSqlMulti = async (service, query) => {
    log_1.logging.query("executeSqlMulti", query).write(constants_1._DEBUG);
    return new Promise(async function (resolve, reject) {
        await configuration_1.config
            .connection(service.name)
            .begin((sql) => query.map((e) => sql.unsafe(e)))
            .then((res) => {
            resolve(res);
        })
            .catch((err) => {
            if (!(0, helpers_1.isTest)() && +err["code"] === 23505)
                log_1.logging.queryError(query, err).write(true);
            reject(err);
        });
    });
};
const executeSql = async (service, query) => (typeof query === "string" ? executeSqlOne(service, query) : executeSqlMulti(service, query));
exports.executeSql = executeSql;
