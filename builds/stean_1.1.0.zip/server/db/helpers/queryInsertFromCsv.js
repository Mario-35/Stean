"use strict";
/**
 * queryInsertFromCsv.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryInsertFromCsv = queryInsertFromCsv;
const _1 = require(".");
const log_1 = require("../../log");
const entities_1 = require("../../models/entities");
const helpers_1 = require("../../helpers");
async function queryInsertFromCsv(service, paramsFile) {
    console.log(log_1.logging.whereIam(new Error().stack).toString());
    const sqlRequest = await (0, _1.columnsNameFromHydrasCsv)(paramsFile);
    if (sqlRequest) {
        const stream = await (0, _1.streamCsvFile)(service, paramsFile, sqlRequest);
        console.log(log_1.logging.message(`COPY TO ${paramsFile.tempTable}`, stream > 0 ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : "\u274C" /* EChar.notOk */).toString());
        if (stream > 0) {
            const fileImport = (0, helpers_1.splitLast)(paramsFile.filename, "/");
            const dateImport = new Date().toLocaleString();
            // stream finshed so COPY
            const scriptSql = [];
            // make import query
            Object.keys(paramsFile.columns).forEach((myColumn, index) => {
                const csvColumn = paramsFile.columns[myColumn];
                scriptSql.push(`INSERT INTO "${entities_1.OBSERVATION.table}" 
          ("${csvColumn.stream.type?.toLowerCase()}_id", "featureofinterest_id", "phenomenonTime", "resultTime", "result", "resultQuality")
            SELECT 
            ${csvColumn.stream.id}, 
            ${csvColumn.stream.FoId},  
            ${sqlRequest.dateSql}, 
            ${sqlRequest.dateSql},
            json_build_object('value', 
            CASE "${paramsFile.tempTable}".value${csvColumn.column}
              WHEN '---' THEN NULL 
              WHEN '#REF!' THEN NULL 
              ELSE CAST(REPLACE(value${csvColumn.column},',','.') AS float) 
            END),
            '{"import": "${fileImport}","date": "${dateImport}"}'  
           FROM "${paramsFile.tempTable}" ON CONFLICT DO NOTHING returning 1`);
            });
            return {
                count: stream,
                query: scriptSql
            };
        }
    }
}
