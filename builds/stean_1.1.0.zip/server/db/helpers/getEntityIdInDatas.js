"use strict";
/**
 * getEntityIdInDatas
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEntityIdInDatas = void 0;
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const getEntityIdInDatas = (dataInput, pg) => {
    const res = {};
    if (pg.entity)
        Object.keys(pg.entity.relations).forEach((elem) => {
            if (dataInput[elem]) {
                res[elem] = dataInput[elem] && dataInput[elem] != null && dataInput[elem][enums_1.EConstant.id]
                    ? BigInt(dataInput[elem][enums_1.EConstant.id])
                    : pg.parentEntity && (pg.parentEntity.singular === elem || pg.parentEntity.name === elem)
                        ? (0, helpers_1.getBigIntFromString)(pg.parentId)
                        : undefined;
            }
            ;
        });
    return res;
};
exports.getEntityIdInDatas = getEntityIdInDatas;
