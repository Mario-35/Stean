"use strict";
/**
 * streamCsvFile
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.streamCsvFile = streamCsvFile;
const fs_1 = require("fs");
const stream_1 = require("stream");
const configuration_1 = require("../../configuration");
const log_1 = require("../../log");
async function streamCsvFile(service, paramsFile, sqlRequest) {
    console.log(log_1.logging.whereIam(new Error().stack).toString());
    const cols = [];
    const controller = new AbortController();
    const readable = (0, fs_1.createReadStream)(paramsFile.filename);
    sqlRequest.columns.forEach((value) => cols.push(`"${value}" varchar(255) NULL`));
    await configuration_1.config.executeSql(service, `CREATE TABLE "${paramsFile.tempTable}" ( id serial4 NOT NULL, ${cols}, CONSTRAINT ${paramsFile.tempTable}_pkey PRIMARY KEY (id));`).catch((error) => {
        console.log(error);
    });
    const writable = configuration_1.config
        .connection(service.name)
        .unsafe(`COPY "${paramsFile.tempTable}" (${sqlRequest.columns.join(",")}) FROM STDIN WITH(FORMAT csv, DELIMITER ';'${paramsFile.header})`)
        .writable();
    return new Promise(async function (resolve, reject) {
        readable
            .pipe((0, stream_1.addAbortSignal)(controller.signal, await writable))
            .on("finish", async (e) => {
            await configuration_1.config
                .executeSqlValues(service, `SELECT count(id) FROM "${paramsFile.tempTable}"`)
                .then((e) => {
                resolve(+e[0]);
            })
                .catch((error) => {
                console.log(error);
                resolve(-1);
            });
        })
            .on("error", (error) => {
            console.log(error);
            resolve(-1);
        });
    });
}
