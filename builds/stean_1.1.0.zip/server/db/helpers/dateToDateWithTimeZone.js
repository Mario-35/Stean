"use strict";
/**
 * dateToDateWithTimeZone.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.dateToDateWithTimeZone = void 0;
const log_1 = require("../../log");
const dateToDateWithTimeZone = (value) => {
    console.log(log_1.logging.whereIam(new Error().stack).toString());
    //Create Date object from ISO string
    const date = new Date(value);
    //Get ms for date
    const time = date.getTime();
    //Check if timezoneOffset is positive or negative
    if (date.getTimezoneOffset() <= 0) {
        //Convert timezoneOffset to hours and add to Date value in milliseconds
        const final = time + Math.abs(date.getTimezoneOffset() * 60000);
        //Convert from milliseconds to date and convert date back to ISO string
        return new Date(final).toISOString();
    }
    else {
        const final = time + -Math.abs(date.getTimezoneOffset() * 60000);
        return new Date(final).toISOString();
    }
};
exports.dateToDateWithTimeZone = dateToDateWithTimeZone;
