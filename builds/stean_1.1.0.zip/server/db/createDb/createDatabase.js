"use strict";
/**
 * createSTDB
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDatabase = void 0;
const helpers_1 = require("../helpers");
const configuration_1 = require("../../configuration");
const helpers_2 = require("../../helpers");
const enums_1 = require("../../enums");
const models_1 = require("../../models");
const log_1 = require("../../log");
const createRole_1 = require("../helpers/createRole");
const queries_1 = require("../queries");
const _1 = require(".");
/**
 *
 * @param configName service name
 * @returns record log report
 */
const createDatabase = async (serviceName) => {
    console.log(log_1.log.debug_head("createDatabase", serviceName));
    // init result
    const servicePg = configuration_1.config.getService(serviceName).pg;
    const returnValue = { "Start create Database": servicePg.database };
    const adminConnection = configuration_1.config.adminConnection();
    // Test Admin connection
    if (!adminConnection) {
        returnValue["DROP Error"] = "No Admin connection";
        return returnValue;
    }
    // create blank DATABASE
    await adminConnection
        .unsafe(`CREATE DATABASE ${servicePg.database}`)
        .then(async () => {
        returnValue[`Create Database`] = `${servicePg.database} ${"\u2714\uFE0F\uFE0F" /* EChar.ok */}`;
        // create default USER if not exist
        await adminConnection.unsafe(`SELECT COUNT(*) FROM pg_user WHERE usename = ${(0, helpers_2.simpleQuotesString)(servicePg.user)};`).then(async (res) => {
            if (res[0].count == 0) {
                returnValue[`CREATE ROLE ${servicePg.user}`] = await adminConnection
                    .unsafe(`CREATE ROLE ${servicePg.user} WITH PASSWORD ${(0, helpers_2.simpleQuotesString)(servicePg.password)} ${enums_1.EConstant.rights}`)
                    .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
                    .catch((err) => err.message);
            }
            else {
                await adminConnection
                    .unsafe(`ALTER ROLE ${servicePg.user} WITH PASSWORD ${(0, helpers_2.simpleQuotesString)(servicePg.password)}  ${enums_1.EConstant.rights}`)
                    .then(() => {
                    returnValue[`Create/Alter ROLE`] = `${servicePg.user} ${"\u2714\uFE0F\uFE0F" /* EChar.ok */}`;
                })
                    .catch((error) => {
                    console.log(error);
                });
            }
        });
    })
        .catch((error) => {
        console.log(error);
    });
    // test user connection
    const dbConnection = configuration_1.config.connection(serviceName);
    if (!dbConnection) {
        returnValue["DROP Error"] = `No DB connection ${"\u274C" /* EChar.notOk */}`;
        return returnValue;
    }
    // create postgis
    returnValue[`Create postgis`] = await dbConnection
        .unsafe((0, queries_1.createExtension)("postgis"))
        .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
        .catch((err) => err.message);
    // create tablefunc
    returnValue[`Create tablefunc`] = await dbConnection
        .unsafe((0, queries_1.createExtension)("tablefunc"))
        .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
        .catch((err) => err.message);
    // Get complete model
    const DB = models_1.models.DBFullCreate(serviceName);
    // loop to create each table
    await (0, helpers_2.asyncForEach)(Object.keys(DB).filter((e) => e.trim() !== ""), async (keyName) => {
        const res = await (0, helpers_1.createTable)(serviceName, DB[keyName], undefined);
        Object.keys(res).forEach((e) => log_1.log.create(e, res[e]));
    });
    // create role
    returnValue[`Create Role`] = await (0, createRole_1.createRole)(configuration_1.config.getService(serviceName))
        .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
        .catch((err) => err.message);
    // create user
    returnValue[`Create user`] = await (0, helpers_1.createUser)(configuration_1.config.getService(serviceName))
        .then(() => "\u2714\uFE0F\uFE0F" /* EChar.ok */)
        .catch((err) => err.message);
    // loop to create each services
    await (0, helpers_2.asyncForEach)((0, _1.pgFunctions)(), async (query) => {
        const name = query.split(" */")[0].split("/*")[1].trim();
        await dbConnection
            .unsafe(query)
            .then(() => {
            log_1.log.create(name, "\u2714\uFE0F\uFE0F" /* EChar.ok */);
        })
            .catch((error) => {
            console.log(error);
            process.exit(111);
        });
    });
    // loop to create each triggers
    await (0, helpers_2.asyncForEach)(Object.keys(DB).filter((e) => e.trim() !== ""), async (keyName) => {
        if (DB[keyName].trigger) {
            await (0, helpers_2.asyncForEach)(DB[keyName].trigger, async (query) => {
                await dbConnection
                    .unsafe(query)
                    .then((e) => {
                    // to preserve size
                    DB[keyName].trigger = [];
                })
                    .catch((error) => {
                    console.log(error);
                    return error;
                });
            });
        }
    });
    // If only numeric extension
    if (configuration_1.config.getService(serviceName).extensions.includes(enums_1.EExtensions.highPrecision)) {
        await dbConnection.unsafe(`ALTER TABLE ${(0, helpers_2.doubleQuotes)(DB.Observations.table)} ALTER COLUMN 'result' TYPE float4 USING null;`).catch((error) => {
            console.log(error);
            return error;
        });
        await dbConnection.unsafe(`ALTER TABLE ${(0, helpers_2.doubleQuotes)(DB.HistoricalLocations.table)} ALTER COLUMN '_result' TYPE float4 USING null;`).catch((error) => {
            console.log(error);
            return error;
        });
    }
    // final test
    await dbConnection
        .unsafe(`SELECT COUNT(*) FROM pg_user WHERE usename = ${(0, helpers_2.simpleQuotesString)(servicePg.user)};`)
        .then(() => {
        returnValue["ALL finished ..."] = "\u2714\uFE0F\uFE0F" /* EChar.ok */;
    })
        .catch((err) => err.message);
    return returnValue;
};
exports.createDatabase = createDatabase;
