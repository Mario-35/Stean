"use strict";
/**
 * Index triggers
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.pgFunctions = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
/**
 *
 * @returns all sql files in directory
 */
const pgFunctions = () => {
    const result = [];
    fs_1.default.readdirSync(path_1.default.join(__dirname))
        .filter((e) => e.endsWith(".sql"))
        .forEach((file) => {
        const content = fs_1.default.readFileSync(path_1.default.join(__dirname, "/", file), "utf8");
        result.push(content);
    });
    return result;
};
exports.pgFunctions = pgFunctions;
