"use strict";
/**
 * asDataArray.
 *
 * @copyright 2020-present Inrae
 * @review 27-01-2024
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.asGeoJSON = void 0;
const _1 = require(".");
const asGeoJSON = (input) => `SELECT JSONB_BUILD_OBJECT(
    'type', 
    'FeatureCollection', 
    'features', 
    (${(0, _1.asJson)({
    query: input.toString(),
    singular: false,
    strip: false,
    count: false
})})) AS value;`;
exports.asGeoJSON = asGeoJSON;
