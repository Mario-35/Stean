"use strict";
/**
 * asDataArray.
 *
 * @copyright 2020-present Inrae
 * @review 27-01-2024
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.asDataArray = void 0;
const _1 = require(".");
const constants_1 = require("../../constants");
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const asDataArray = (input) => {
    // create names
    const names = input.onlyRef === true ? ["@iot.selfLink"] : input.toPgQuery()?.keys.map((e) => (0, helpers_1.formatPgString)(e)) || [];
    // loop subQuery
    if (input.includes)
        input.includes.forEach((include) => {
            if (include.entity)
                names.push(include.entity.singular);
        });
    // Return SQL query
    return (0, _1.asJson)({
        query: `SELECT (ARRAY[${enums_1.EConstant.newline}\t${names
            .map((e) => (0, helpers_1.simpleQuotesString)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(e)))
            .join(`,${enums_1.EConstant.newline}\t`)}]) AS "components", JSONB_AGG(allkeys) AS "dataArray" FROM (SELECT JSON_BUILD_ARRAY(${enums_1.EConstant.newline}\t${names
            .map((e) => (0, helpers_1.doubleQuotes)(e))
            .join(`,${enums_1.EConstant.newline}\t`)}) AS allkeys ${enums_1.EConstant.return}${enums_1.EConstant.tab}FROM (${input.toString()}) AS p) AS l`,
        singular: false,
        strip: false,
        count: true
    });
};
exports.asDataArray = asDataArray;
