"use strict";
/**
 * Constants for DataBase
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.FORMAT_JSONB = void 0;
const constants_1 = require("../constants");
const FORMAT_JSONB = (content) => `E'${content ? (0, constants_1.ESCAPE_SIMPLE_QUOTE)(JSON.stringify(content)) : "{}"}'::text::jsonb`;
exports.FORMAT_JSONB = FORMAT_JSONB;
