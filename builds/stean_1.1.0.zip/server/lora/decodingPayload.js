"use strict";
/**
 * decodingPayload for odata
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.decodingPayload = void 0;
const log_1 = require("../log");
const messages_1 = require("../messages");
const decodingPayload = (decoder, payload) => {
    console.log(log_1.log.debug_head("decodingPayload"));
    try {
        const F = new Function("input", "nomenclature", `${String(decoder.code)}; return decode(input, nomenclature);`);
        let nomenclature = "";
        if (decoder.nomenclature.trim() != "")
            try {
                nomenclature = JSON.parse(decoder.nomenclature);
            }
            catch (error) {
                nomenclature = JSON.parse(decoder.nomenclature);
            }
        const result = F(payload, decoder.nomenclature === "{}" || decoder.nomenclature === "" ? null : nomenclature);
        return { decoder: decoder.name, result: result };
    }
    catch (error) {
        console.log(error);
        return {
            decoder: decoder.name,
            result: undefined,
            error: messages_1.errors.DecodingPayloadError
        };
    }
};
exports.decodingPayload = decodingPayload;
