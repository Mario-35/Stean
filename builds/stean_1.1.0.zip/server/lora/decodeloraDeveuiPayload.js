"use strict";
/**
 * decodeloraDeveuiPayload for odata
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.decodeloraDeveuiPayload = void 0;
const _1 = require(".");
const configuration_1 = require("../configuration");
const log_1 = require("../log");
const messages_1 = require("../messages");
const entities_1 = require("../models/entities");
const decodeloraDeveuiPayload = async (service, loraDeveui, payload) => {
    console.log(log_1.logging.message(`decodeLoraPayload deveui : [${loraDeveui}]`, payload).toString());
    return await configuration_1.config
        .executeSql(service, `SELECT "name", "code", "nomenclature", "synonym" FROM "${entities_1.DECODER.table}" WHERE id = (SELECT "decoder_id" FROM "${entities_1.LORA.table}" WHERE "deveui" = '${loraDeveui}') LIMIT 1`)
        .then((res) => {
        try {
            return (0, _1.decodingPayload)({ ...res[0] }, payload);
        }
        catch (error) {
            return undefined;
        }
    })
        .catch(() => {
        return {
            decoder: "undefined",
            result: undefined,
            error: messages_1.errors.DecodingPayloadError
        };
    });
};
exports.decodeloraDeveuiPayload = decodeloraDeveuiPayload;
