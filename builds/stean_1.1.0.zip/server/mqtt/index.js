"use strict";
/**
 * MqttServer Routes for API
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MqttServer = void 0;
const aedes_1 = __importDefault(require("aedes"));
const configuration_1 = require("../configuration");
const log_1 = require("../log");
const enums_1 = require("../enums");
const messages_1 = require("../messages");
const authentication_1 = require("../authentication");
const aedes_server_factory_1 = require("aedes-server-factory");
const constants_1 = require("../constants");
class MqttServer {
    broker;
    constructor(ports) {
        this.broker = new aedes_1.default();
        const mqttServer = (0, aedes_server_factory_1.createServer)(this.broker, { ws: true });
        mqttServer.listen(ports.wsPort, () => {
            configuration_1.config.messageListen("MQTT Broker on WS", String(ports.wsPort));
        });
        const mqttTcpServer = (0, aedes_server_factory_1.createServer)(this.broker);
        mqttTcpServer.listen(ports.tcpPort, () => {
            configuration_1.config.messageListen("MQTT Broker on TCP", String(ports.tcpPort));
        });
    }
    sendMessage(client, topic, message) {
        const packet = {
            cmd: "publish",
            dup: true,
            qos: 1,
            retain: true,
            topic: topic,
            payload: message
        };
        client.publish(packet, (e) => {
            console.log(e);
        });
    }
    apiCaller(packet, client) {
        console.log(log_1.logging.whereIam(new Error().stack).toString());
        return new Promise(async (resolve, reject) => {
            try {
                const api = await fetch(`http://localhost:8029${packet.topic}`, {
                    method: "POST",
                    headers: {
                        "Authorization": this.broker.id,
                        "Host": "mqtt",
                        "Content-Type": enums_1.EEncodingType.json
                    },
                    body: packet.payload.toString()
                });
                if (api) {
                    log_1.logging.message(`[MESSAGE_PUBLISHED] Client ${client ? client.id : "BROKER_" + this.broker.id} has published message on ${packet.topic} to broker`, this.broker.id).write(constants_1._DEBUG);
                    api.json().then((e) => {
                        client.emit("message", e);
                        resolve(e);
                    });
                }
            }
            catch (error) {
                reject(error);
            }
        });
    }
    init() {
        // authenticate the connecting client
        this.broker.authenticate = async (client, username, password, callback) => {
            console.log(log_1.logging.whereIam(new Error().stack).toString());
            if (client && client.req && client.req.url) {
                const url = client.req.url
                    .trim()
                    .split("/")
                    .filter((e) => e !== "");
                if (url[url.length - 1] === "login") {
                    return await (0, authentication_1.loginUser)(undefined, { configName: url[0], username: String(username), password: Buffer.from(password, "base64").toString() })
                        .then((user) => {
                        log_1.logging
                            .message(`${(0, enums_1.color)(user ? 32 /* EColor.Green */ : 31 /* EColor.Red */)}${(0, enums_1.color)(36 /* EColor.Cyan */)}${user ? (0, messages_1.infos)(["auth", "success"]) : messages_1.errors.authFailed} to broker`, this.broker.id)
                            .write(constants_1._DEBUG);
                        return callback(user ? null : new Error(messages_1.errors.authFailed), user ? true : false);
                    })
                        .catch((error) => {
                        log_1.logging.error(messages_1.errors.authFailed, error);
                        return callback(error, false);
                    });
                }
            }
            else {
                if (client && client["_parser"]) {
                    const paket = client["_parser"]["settings"];
                    if (paket["cmd"] === "connect") {
                        return await (0, authentication_1.loginUser)(undefined, {
                            configName: String(paket["clientId"]).split("_")[0],
                            username: String(paket["username"]),
                            password: Buffer.from(paket["password"], "base64").toString()
                        })
                            .then((user) => {
                            log_1.logging
                                .message(`${(0, enums_1.color)(user ? 32 /* EColor.Green */ : 31 /* EColor.Red */)}${(0, enums_1.color)(36 /* EColor.Cyan */)}${user ? (0, messages_1.infos)(["auth", "success"]) : messages_1.errors.authFailed} to broker`, this.broker.id)
                                .write(constants_1._DEBUG);
                            return callback(user ? null : new Error(messages_1.errors.authFailed), user ? true : false);
                        })
                            .catch((error) => {
                            log_1.logging.error(messages_1.errors.authFailed, error);
                            return callback(error, false);
                        });
                    }
                }
            }
            return callback(null, false);
        };
        // authorizing client to publish on a message topic
        this.broker.authorizePublish = (client, packet, callback) => {
            console.log(log_1.logging.whereIam("authorizePublish").toString());
            return callback(client && packet.topic.trim() !== "" ? null : new Error("You are not authorized to publish on this message topic."));
        };
        this.broker.published = (packet, client, callback) => {
            if (client) {
                console.log(log_1.logging.whereIam("published").toString());
                if (client)
                    log_1.logging.message(`${(0, enums_1.color)(32 /* EColor.Green */)}[PUBLISHED] ${(0, enums_1.color)(36 /* EColor.Cyan */)}${client ? client.id : client}`, packet.payload.toString()).write(constants_1._DEBUG);
            }
        };
        // emitted when a client connects to the broker
        this.broker.on("client", (client) => {
            if (client) {
                console.log(log_1.logging.whereIam(`client : ${client ? client.id : client}`).toString());
                log_1.logging.message(`${(0, enums_1.color)(32 /* EColor.Green */)}[CLIENT_CONNECTED] ${(0, enums_1.color)(36 /* EColor.Cyan */)}${client ? client.id : client} connected to broker`, this.broker.id).write(constants_1._DEBUG);
            }
        });
        // emitted when a client disconnects from the broker
        this.broker.on("clientDisconnect", (client) => {
            if (client) {
                console.log(log_1.logging.whereIam(new Error().stack, "clientDisconnect").toString());
                log_1.logging.message(`${(0, enums_1.color)(31 /* EColor.Red */)}[CLIENT_DISCONNECTED] ${(0, enums_1.color)(36 /* EColor.Cyan */)}${client ? client.id : client} disconnected from the broker`, this.broker.id).write(constants_1._DEBUG);
            }
        });
        // emitted when a client subscribes to a message topic
        this.broker.on("subscribe", (subscriptions, client) => {
            if (client) {
                console.log(log_1.logging.whereIam(new Error().stack, "subscribe").toString());
                log_1.logging
                    .message(`${(0, enums_1.color)(33 /* EColor.Yellow */)}[TOPIC_SUBSCRIBED] ${(0, enums_1.color)(32 /* EColor.Green */)}${client ? client.id : client} subscribed to topics: ${subscriptions
                    .map((s) => s.topic)
                    .join(",")} on broker`, this.broker.id)
                    .write(constants_1._DEBUG);
            }
        });
        // emitted when a client unsubscribes from a message topic
        this.broker.on("unsubscribe", (subscriptions, client) => {
            if (client) {
                console.log(log_1.logging.whereIam("unsubscribe"));
                log_1.logging
                    .message(`${(0, enums_1.color)(33 /* EColor.Yellow */)}[TOPIC_UNSUBSCRIBED] ${(0, enums_1.color)(31 /* EColor.Red */)}${client ? client.id : client} unsubscribed to topics: ${subscriptions
                    .map((s) => s.topic)
                    .join(",")} from broker`, this.broker.id)
                    .write(constants_1._DEBUG);
            }
        });
        // emitted when a client publishes a message packet on the topic
        this.broker.on("publish", (packet, client) => {
            if (client && !packet.topic.includes("$SYS")) {
                console.log(log_1.logging.whereIam("publish"));
                this.apiCaller(packet, client)
                    .then((res) => {
                    res = { mqtt: res };
                    client.publish({
                        cmd: "publish",
                        dup: true,
                        qos: 1,
                        retain: true,
                        topic: packet.topic,
                        payload: JSON.stringify(res),
                        properties: {
                            contentType: "steanResult"
                        }
                    }, (e) => {
                        console.log(e);
                    });
                })
                    .catch((err) => {
                    console.log(err);
                });
            }
        });
    }
}
exports.MqttServer = MqttServer;
