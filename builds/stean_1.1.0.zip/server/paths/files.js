"use strict";
/**
 * File
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.File = void 0;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
/**
 * File Class
 */
class File {
    // path of the file
    pathName;
    // path and name of the file
    fileName;
    extension;
    stream = undefined;
    constructor(pathName, fileName, options) {
        this.pathName = pathName;
        this.extension = fileName.split(".").reverse()[0];
        this.fileName = path_1.default.join(pathName, fileName);
        // if folder no exist create it
        if (!fs_1.default.existsSync(pathName))
            fs_1.default.mkdirSync(pathName);
        // if file is empty delete it
        if (fs_1.default.existsSync(this.fileName) && fs_1.default.readFileSync(this.fileName, "utf8").trim() === "")
            fs_1.default.unlinkSync(this.fileName);
        if (options.includes("backup"))
            if (fs_1.default.existsSync(this.fileName))
                fs_1.default.renameSync(this.fileName, this.fileName.split(".").join(`-${new Date().toISOString().slice(0, 16).replace(/:/g, "H")}.`));
        if (options.includes("stream"))
            this.stream = fs_1.default.createWriteStream(this.fileName, { flags: "w" });
    }
    writeStream(input) {
        if (this.stream)
            this.stream.write(input);
    }
    list() {
        const result = [];
        fs_1.default.readdirSync(this.pathName)
            .filter((e) => e.endsWith(this.extension))
            .forEach((file) => {
            result.push(file);
        });
        return result;
    }
}
exports.File = File;
