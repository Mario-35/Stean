"use strict";
/**
 * EOptions Enum
 *
 * @copyright 2020-present Inrae
 * @review 29-10-2024
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EOptions = void 0;
var EOptions;
(function (EOptions) {
    EOptions["forceHttps"] = "forceHttps";
    EOptions["stripNull"] = "stripNull";
    EOptions["canDrop"] = "canDrop";
    EOptions["unique"] = "unique";
    EOptions["speedCount"] = "speedCount";
})(EOptions || (exports.EOptions = EOptions = {}));
