"use strict";
/**
 * formats Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EReturnFormats = void 0;
var EReturnFormats;
(function (EReturnFormats) {
    EReturnFormats["json"] = "json";
    EReturnFormats["csv"] = "csv";
    EReturnFormats["txt"] = "txt";
    EReturnFormats["sql"] = "sql";
    EReturnFormats["html"] = "html";
    EReturnFormats["icon"] = "icon";
    EReturnFormats["graph"] = "graph";
    EReturnFormats["graphDatas"] = "graphDatas";
    EReturnFormats["dataArray"] = "dataArray";
    EReturnFormats["GeoJSON"] = "GeoJSON";
    EReturnFormats["css"] = "css";
    EReturnFormats["js"] = "js";
    EReturnFormats["png"] = "png";
    EReturnFormats["jpg"] = "jpg";
    EReturnFormats["jpeg"] = "jpeg";
    EReturnFormats["ico"] = "ico";
    EReturnFormats["xlsx"] = "xlsx";
    EReturnFormats["xml"] = "xml";
})(EReturnFormats || (exports.EReturnFormats = EReturnFormats = {}));
