"use strict";
/**
 * datesType Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EDatesType = void 0;
var EDatesType;
(function (EDatesType) {
    EDatesType["date"] = "YYYY-MM-DD HH24:MI:SS";
    EDatesType["dateTz"] = "YYYY-MM-DD\"T\"HH24:MI:SSZ";
    // dateTz = "YYYY-MM-DD HH:MI:SSTZH:TZM",
    EDatesType["dateImport"] = "YYYY-MM-DDXHH24:MI:SS";
    EDatesType["time"] = "HH24:MI:SSZ";
    EDatesType["timeTz"] = "HH:MI:SSTZH:TZM";
    EDatesType["timeImport"] = "HH24:MI:SS";
})(EDatesType || (exports.EDatesType = EDatesType = {}));
