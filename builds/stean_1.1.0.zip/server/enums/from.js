"use strict";
/**
 * from Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EFrom = void 0;
var EFrom;
(function (EFrom) {
    EFrom["unknown"] = "unknown";
    EFrom["mqtt"] = "mqtt";
    EFrom["query"] = "query";
    EFrom["test"] = "test";
})(EFrom || (exports.EFrom = EFrom = {}));
