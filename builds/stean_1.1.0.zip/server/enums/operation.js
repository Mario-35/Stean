"use strict";
/**
 * operation Enum
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EOperation = void 0;
var EOperation;
(function (EOperation) {
    EOperation[EOperation["Table"] = 0] = "Table";
    EOperation[EOperation["Relation"] = 1] = "Relation";
    EOperation[EOperation["Association"] = 2] = "Association";
})(EOperation || (exports.EOperation = EOperation = {}));
