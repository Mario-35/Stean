"use strict";
/**
 * table entityType
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EentityType = void 0;
var EentityType;
(function (EentityType) {
    EentityType[EentityType["blank"] = 0] = "blank";
    EentityType[EentityType["table"] = 1] = "table";
    EentityType[EentityType["link"] = 2] = "link";
})(EentityType || (exports.EentityType = EentityType = {}));
