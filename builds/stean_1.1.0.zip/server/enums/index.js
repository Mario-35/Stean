"use strict";
/**
 * Index Enums
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.typeOptions = exports.enumKeys = exports.color = exports.EUserRights = exports.EQuery = exports.EOptions = exports.ERelations = exports.EEncodingType = exports.EOperation = exports.EObservationType = exports.EReturnFormats = exports.EHttpCode = exports.EExtensions = exports.filterEntities = exports.allEntities = exports.EFrom = exports.EDataType = exports.EDatesType = exports.EColumnType = exports.EConstant = exports.EColor = exports.EentityType = exports.EChar = void 0;
const options_1 = require("./options");
var chars_1 = require("./chars");
Object.defineProperty(exports, "EChar", { enumerable: true, get: function () { return chars_1.EChar; } });
var entityType_1 = require("./entityType");
Object.defineProperty(exports, "EentityType", { enumerable: true, get: function () { return entityType_1.EentityType; } });
var colors_1 = require("./colors");
Object.defineProperty(exports, "EColor", { enumerable: true, get: function () { return colors_1.EColor; } });
var constant_1 = require("./constant");
Object.defineProperty(exports, "EConstant", { enumerable: true, get: function () { return constant_1.EConstant; } });
var colType_1 = require("./colType");
Object.defineProperty(exports, "EColumnType", { enumerable: true, get: function () { return colType_1.EColumnType; } });
var datesType_1 = require("./datesType");
Object.defineProperty(exports, "EDatesType", { enumerable: true, get: function () { return datesType_1.EDatesType; } });
var dataType_1 = require("./dataType");
Object.defineProperty(exports, "EDataType", { enumerable: true, get: function () { return dataType_1.EDataType; } });
var from_1 = require("./from");
Object.defineProperty(exports, "EFrom", { enumerable: true, get: function () { return from_1.EFrom; } });
var entities_1 = require("./entities");
Object.defineProperty(exports, "allEntities", { enumerable: true, get: function () { return entities_1.allEntities; } });
Object.defineProperty(exports, "filterEntities", { enumerable: true, get: function () { return entities_1.filterEntities; } });
var extensions_1 = require("./extensions");
Object.defineProperty(exports, "EExtensions", { enumerable: true, get: function () { return extensions_1.EExtensions; } });
var httpCode_1 = require("./httpCode");
Object.defineProperty(exports, "EHttpCode", { enumerable: true, get: function () { return httpCode_1.EHttpCode; } });
var resultFormats_1 = require("./resultFormats");
Object.defineProperty(exports, "EReturnFormats", { enumerable: true, get: function () { return resultFormats_1.EReturnFormats; } });
var observationType_1 = require("./observationType");
Object.defineProperty(exports, "EObservationType", { enumerable: true, get: function () { return observationType_1.EObservationType; } });
var operation_1 = require("./operation");
Object.defineProperty(exports, "EOperation", { enumerable: true, get: function () { return operation_1.EOperation; } });
var encodingType_1 = require("./encodingType");
Object.defineProperty(exports, "EEncodingType", { enumerable: true, get: function () { return encodingType_1.EEncodingType; } });
var relations_1 = require("./relations");
Object.defineProperty(exports, "ERelations", { enumerable: true, get: function () { return relations_1.ERelations; } });
var options_2 = require("./options");
Object.defineProperty(exports, "EOptions", { enumerable: true, get: function () { return options_2.EOptions; } });
var query_1 = require("./query");
Object.defineProperty(exports, "EQuery", { enumerable: true, get: function () { return query_1.EQuery; } });
var userRights_1 = require("./userRights");
Object.defineProperty(exports, "EUserRights", { enumerable: true, get: function () { return userRights_1.EUserRights; } });
const color = (col) => `\x1b[${col}m`;
exports.color = color;
const enumKeys = (input) => Object.keys(input).filter((prop) => isNaN(parseInt(prop)));
exports.enumKeys = enumKeys;
exports.typeOptions = Object.keys(options_1.EOptions);
