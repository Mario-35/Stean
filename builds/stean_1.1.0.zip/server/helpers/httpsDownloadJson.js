"use strict";
/**
 * httpsDownloadJSON
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.httpsDownloadJSON = httpsDownloadJSON;
const https_1 = __importDefault(require("https"));
function httpsDownloadJSON(url, filename) {
    return new Promise((resolve, reject) => {
        let data = "";
        try {
            https_1.default.get(url, { headers: { "User-Agent": "javascript" } }, (response) => {
                response
                    .on("data", (append) => (data += append))
                    .on("error", (e) => {
                    reject(e);
                })
                    .on("end", () => resolve(JSON.parse(data)));
            });
        }
        catch (error) {
            reject(undefined);
        }
    });
}
