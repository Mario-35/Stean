"use strict";
/**
 * AutoUpdate
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.readRemoteVersion = readRemoteVersion;
const _1 = require(".");
const enums_1 = require("../enums");
/**
 * Reads the applications version from the git repository.
 */
async function readRemoteVersion() {
    return (0, _1.connectWeb)().then(async () => {
        try {
            const file = enums_1.EConstant.repository.replace("github.com", "raw.githubusercontent.com") + `/refs/heads/${enums_1.EConstant.branch}/builds/stean_latest.info`;
            const version = await (0, _1.httpsDownloadJSON)(file, "stean_latest.info");
            return version ? { version: version["version"], date: version["date"] } : undefined;
        }
        catch (error) {
            console.log(error);
            return;
        }
    });
}
