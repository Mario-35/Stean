"use strict";
/**
 * returnFormats
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.returnFormats = void 0;
const queries_1 = require("../db/queries");
const css_1 = require("../views/css");
const js_1 = require("../views/js");
const util_1 = __importDefault(require("util"));
const enums_1 = require("../enums");
const _1 = require(".");
const messages_1 = require("../messages");
const entities_1 = require("../models/entities");
// Default "blank" function
const defaultFunction = (input) => input;
// Default "blank" format function
const defaultForwat = (input) => input.toString();
const generateFields = (input) => {
    if ((0, _1.isReturnGraph)(input)) {
        const entity = input.parentEntity || input.entity;
        return entity ? [`(SELECT ${entity.table}."description" FROM ${entity.table} WHERE ${entity.table}."id" = ${input.parentId ? input.parentId : input.id}) AS title, `] : undefined;
    }
};
/**
 *
 * @param input PgVisitor
 * @returns sSQL Query for graph
 */
const generateGraphSql = (input) => {
    input.intervalColumns = ["id", "step as date", "result"];
    if ((0, _1.isReturnGraph)(input))
        input.intervalColumns.push("concat");
    const entity = input.parentEntity || input.entity;
    if (entity) {
        const id = input.parentId ? input.parentId : input.id;
        const query = entity.table === entities_1.DATASTREAM.table ? (0, queries_1.graphDatastream)(entity.table, id, input) : (0, queries_1.graphMultiDatastream)(entity.table, id, input);
        return (0, queries_1.asJson)({
            query: query,
            singular: false,
            strip: false,
            count: false
        });
    }
};
// all returns format functions
const _returnFormats = {
    xlsx: {
        name: "xlsx",
        type: enums_1.EEncodingType.xlsx,
        format: defaultFunction,
        generateSql: defaultForwat
    },
    // IMPORTANT TO HAVE THIS BEFORE GRAPHDATAS
    json: {
        name: "json",
        type: enums_1.EEncodingType.json,
        format: defaultFunction,
        generateSql(input) {
            return input.interval
                ? (0, queries_1.asJson)({ query: (0, queries_1.interval)(input), singular: false, strip: false, count: true })
                : (0, queries_1.asJson)({
                    query: input.toString(),
                    singular: false,
                    count: true,
                    strip: input.ctx.service.options.includes(enums_1.EOptions.stripNull),
                    fullCount: input.count === true ? input.toPgQuery()?.count : undefined,
                    fields: generateFields(input)
                });
        }
    },
    // IMPORTANT TO HAVE THIS BEFORE GRAPH
    graphDatas: {
        name: "graphDatas",
        type: enums_1.EEncodingType.json,
        format: defaultFunction,
        generateSql(input) {
            return generateGraphSql(input);
        }
    },
    graph: {
        name: "graph",
        type: enums_1.EEncodingType.html + ";" + enums_1.EEncodingType.utf8,
        format(input, ctx) {
            const graphNames = [];
            const formatedDatas = [];
            const height = String(100 / Object.entries(input).length).split(".")[0];
            if (typeof input === "object") {
                // input = input["value" as keyof object];git
                if (input[0]["infos"] === null)
                    return messages_1.errors.noDatas;
                Object.entries(input).forEach((element, index) => {
                    // if (input["infos" as keyof object] == null && input["datas" as keyof object] == null) return "";
                    graphNames.push(`<button type="button" id="btngraph${index}" onclick="graph${index}.remove(); btngraph${index}.remove();">X</button>
           <div id="graph${index}" style="width:95%; height:${height}%;"></div>`);
                    const infos = element[1]["description"]
                        ? `${[element[1]["description"], element[1]["name"], element[1]["symbol"]].join('","')}`
                        : `${element[1]["infos"].split("|").join(enums_1.EConstant.doubleQuotedComa)}`;
                    const formatedData = `const value${index} = [${element[1]["datas"]}]; 
          const infos${index} = ["${infos}"];`;
                    formatedDatas.push(` ${formatedData} showGraph("graph${index}", infos${index}, value${index})`);
                });
            }
            return `<html lang="fr"> <head>
      <style>${(0, css_1.addCssFile)("dygraph.css")}</style> <!-- htmlmin:ignore --><script>${(0, js_1.addJsFile)("dygraph.js")}</script><!-- htmlmin:ignore -->
      ${graphNames.join("")}
        <script>
        ${(0, js_1.addJsFile)("graph.js")}
          const linkBase = "${ctx.decodedUrl.root}";
          ${formatedDatas.join(";")}                             
        </script>`;
        },
        generateSql(input) {
            return generateGraphSql(input);
        }
    },
    dataArray: {
        name: "dataArray",
        type: enums_1.EEncodingType.json,
        format: defaultFunction,
        generateSql(input) {
            return (0, queries_1.asDataArray)(input);
        }
    },
    GeoJSON: {
        name: "GeoJSON",
        type: enums_1.EEncodingType.json,
        format: defaultFunction,
        generateSql(input) {
            return (0, queries_1.asGeoJSON)(input);
        }
    },
    csv: {
        name: "csv",
        type: enums_1.EEncodingType.csv,
        format: defaultFunction,
        generateSql(input) {
            return input.toString();
        }
    },
    txt: {
        name: "txt",
        type: enums_1.EEncodingType.txt,
        format: (input) => (Object.entries(input).length > 0 ? util_1.default.inspect(input, { showHidden: true, depth: 4 }) : JSON.stringify(input)),
        generateSql(input) {
            return (0, queries_1.asJson)({ query: input.toString(), singular: false, strip: false, count: false });
        }
    },
    sql: {
        name: "sql",
        type: enums_1.EEncodingType.txt,
        format: defaultFunction,
        generateSql: defaultForwat
    },
    html: {
        name: "html",
        type: enums_1.EEncodingType.html + ";" + enums_1.EEncodingType.utf8,
        format: defaultFunction,
        generateSql: defaultForwat
    },
    css: {
        name: "css",
        type: enums_1.EEncodingType.css + ";" + enums_1.EEncodingType.utf8,
        format: defaultFunction,
        generateSql: defaultForwat
    },
    js: {
        name: "js",
        type: enums_1.EEncodingType.js + ";" + enums_1.EEncodingType.utf8,
        format: defaultFunction,
        generateSql: defaultForwat
    },
    png: {
        name: "png",
        type: "image/png",
        format: defaultFunction,
        generateSql: defaultForwat
    },
    jpeg: {
        name: "jpeg",
        type: "image/jpeg",
        format: defaultFunction,
        generateSql: defaultForwat
    },
    jpg: {
        name: "jpg",
        type: "image/jpeg",
        format: defaultFunction,
        generateSql: defaultForwat
    },
    icon: {
        name: "icon",
        type: "image/x-icon",
        format: defaultFunction,
        generateSql: defaultForwat
    },
    ico: {
        name: "ico",
        type: "image/x-icon",
        format: defaultFunction,
        generateSql: defaultForwat
    },
    xml: {
        name: "xml",
        type: enums_1.EEncodingType.xml,
        format: defaultFunction,
        generateSql: defaultForwat
    }
};
exports.returnFormats = Object.freeze(_returnFormats);
