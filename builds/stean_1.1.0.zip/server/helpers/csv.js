"use strict";
/**
 * Csv
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Csv = void 0;
const enums_1 = require("../enums");
const messages_1 = require("../messages");
class Csv {
    flattenArray(array, ancestors) {
        ancestors || (ancestors = []);
        function combineKeys(a, b) {
            const result = a.slice(0);
            if (!Array.isArray(b))
                return result;
            for (let i = 0; i < b.length; i++)
                if (result.indexOf(b[i]) === -1)
                    result.push(b[i]);
            return result;
        }
        function extend(target, source) {
            target = target || {};
            for (const prop in source) {
                if (typeof source[prop] === "object") {
                    target[prop] = extend(target[prop], source[prop]);
                }
                else {
                    target[prop] = source[prop];
                }
            }
            return target;
        }
        const rows = [];
        for (let i = 0; i < array.length; i++) {
            let o = array[i], row = {}, orows = {}, count = 1;
            if (o !== undefined && o !== null && (!this.isObject(o) || Array.isArray(o)))
                throw messages_1.errors.errorItemNotAnObject.replace("{0}", JSON.stringify(o));
            const keys = this.getKeys(o);
            for (let k = 0; k < keys.length; k++) {
                const value = o[keys[k]], keyChain = combineKeys(ancestors, [keys[k]]), key = keyChain.join(".");
                if (Array.isArray(value)) {
                    orows[key] = this.flattenArray(value, keyChain);
                    count += orows[key].length;
                }
                else {
                    row[key] = value;
                }
            }
            if (count == 1) {
                rows.push(row);
            }
            else {
                const keys = this.getKeys(orows);
                for (let k = 0; k < keys.length; k++) {
                    const key = keys[k];
                    for (let r = 0; r < orows[key].length; r++) {
                        rows.push(extend(extend({}, row), orows[key][r]));
                    }
                }
            }
        }
        return rows;
    }
    isObject(o) {
        return o && typeof o == "object";
    }
    getKeys(o) {
        if (!this.isObject(o))
            return [];
        return Object.keys(o);
    }
    convert(data, options) {
        options || (options = {});
        if (!this.isObject(data))
            throw messages_1.errors.errorNotAnArray;
        if (!Array.isArray(data))
            data = [data];
        const separator = options.separator || ",";
        if (!separator)
            throw messages_1.errors.errorMissingSeparator;
        const flatten = options.flatten || false;
        if (flatten)
            data = this.flattenArray(data);
        const allKeys = [];
        const allRows = [];
        data.forEach((d) => {
            const o = d[0] || d;
            const row = {};
            if (o !== undefined && o !== null && (!this.isObject(o) || Array.isArray(o)))
                throw messages_1.errors.errorItemNotAnObject.replace("{0}", JSON.stringify(o));
            const keys = this.getKeys(o);
            for (let k = 0; k < keys.length; k++) {
                const key = keys[k];
                if (allKeys.indexOf(key) === -1)
                    allKeys.push(key);
                const value = o[key];
                if (value === undefined && value === null)
                    continue;
                if (typeof value == "string") {
                    row[key] = '"' + value.replace(/"/g, options.output_csvjson_variant ? '\\"' : '""') + '"';
                    if (options.output_csvjson_variant)
                        row[key] = row[key].replace(/\n/g, "\\n");
                }
                else {
                    row[key] = JSON.stringify(value);
                    if (!options.output_csvjson_variant && (this.isObject(value) || Array.isArray(value)))
                        row[key] = '"' + row[key].replace(/"/g, '\\"').replace(/\n/g, "\\n") + '"';
                }
            }
            allRows.push(row);
        });
        const keyValues = [];
        for (let i = 0; i < allKeys.length; i++) {
            keyValues.push('"' + allKeys[i].replace(/"/g, options.output_csvjson_variant ? '\\"' : '""') + '"');
        }
        let csv = keyValues.join(separator) + enums_1.EConstant.return;
        for (let r = 0; r < allRows.length; r++) {
            const row = allRows[r], rowArray = [];
            for (let k = 0; k < allKeys.length; k++) {
                const key = allKeys[k];
                rowArray.push(row[key] || (options.output_csvjson_variant ? "null" : ""));
            }
            csv += rowArray.join(separator) + (r < allRows.length - 1 ? enums_1.EConstant.return : "");
        }
        return csv;
    }
}
exports.Csv = Csv;
