"use strict";
/**
 * removeFromUrl
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeFromUrl = void 0;
/**
 *
 * @param input: string
 * @param remove: string or string[] to remove
 * @returns clean url
 */
const removeFromUrl = (input, remove) => {
    if (typeof remove == "string")
        remove = [remove];
    remove.forEach((e) => {
        input = input.replace(`&$${e}`, "").replace(`$${e}`, "");
    });
    return input;
};
exports.removeFromUrl = removeFromUrl;
