"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isLog = exports.isAllowedTo = exports.isAdmin = exports.isObservation = exports.isReturnGeoJson = exports.isReturnGraph = exports.isReturnDataArray = exports.isReturnCsv = exports.isProduction = exports.isTest = exports.isTestEntity = void 0;
exports.isString = isString;
exports.isBoolean = isBoolean;
exports.isNumber = isNumber;
exports.isIntegerNumber = isIntegerNumber;
exports.isObject = isObject;
exports.isArray = isArray;
/**
 * tests Is
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
const enums_1 = require("../enums");
const returnFormats_1 = require("./returnFormats");
const isTestEntity = (input, test) => (typeof input === "string" ? input === test : input.name === test);
exports.isTestEntity = isTestEntity;
const isTest = () => process.env.NODE_ENV?.trim() === enums_1.EConstant.test || false;
exports.isTest = isTest;
const isProduction = () => process.env.NODE_ENV?.trim() === "production" || false;
exports.isProduction = isProduction;
const isReturnCsv = (input) => (input.returnFormat === returnFormats_1.returnFormats.csv ? true : undefined);
exports.isReturnCsv = isReturnCsv;
const isReturnDataArray = (input) => (input.returnFormat === returnFormats_1.returnFormats.dataArray ? true : undefined);
exports.isReturnDataArray = isReturnDataArray;
const isReturnGraph = (input) => ([returnFormats_1.returnFormats.graph, returnFormats_1.returnFormats.graphDatas].includes(input.returnFormat) ? true : undefined);
exports.isReturnGraph = isReturnGraph;
const isReturnGeoJson = (inputE, input) => (typeof inputE === "string" ? ["Locations", "FeaturesOfInterest"].includes(inputE) : ["Locations", "FeaturesOfInterest"].includes(inputE.name)) && input.returnFormat === returnFormats_1.returnFormats.GeoJSON
    ? true
    : undefined;
exports.isReturnGeoJson = isReturnGeoJson;
const isObservation = (input) => (input.entity && (0, exports.isTestEntity)(input.entity, "Observations")) || (input.parentEntity && (0, exports.isTestEntity)(input.parentEntity, "Observations")) ? true : false;
exports.isObservation = isObservation;
const isAdmin = (service) => service && service.name === enums_1.EConstant.admin;
exports.isAdmin = isAdmin;
const isAllowedTo = (ctx, what) => (ctx.service.extensions.includes(enums_1.EExtensions.users) ? ctx.user && ctx.user.PDCUAS[what] === true : true);
exports.isAllowedTo = isAllowedTo;
const isLog = (input) => (input.entity && (0, exports.isTestEntity)(input.entity, "Logs") ? true : false);
exports.isLog = isLog;
function isString(obj) {
    return typeof obj === "string";
}
function isBoolean(obj) {
    return typeof obj === "boolean";
}
function isNumber(obj) {
    return typeof obj === "number";
}
function isIntegerNumber(obj) {
    return typeof obj === "number" && Number.isInteger(obj);
}
function isObject(obj) {
    return obj != null && typeof obj === "object" && !(obj instanceof Array);
}
function isArray(obj) {
    return obj instanceof Array;
}
