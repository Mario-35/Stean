"use strict";
/**
 * promiseBlindExecute
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.promiseHttpsRequest = promiseHttpsRequest;
const https_1 = __importDefault(require("https"));
const log_1 = require("../log");
const enums_1 = require("../enums");
/**
 * A promise wrapper for sending a get https requests.
 * @param {String} url - The Https address to request.
 * @param {String} options - The request options.
 */
function promiseHttpsRequest(url, options) {
    return new Promise(function (resolve, reject) {
        let req = https_1.default.request(url, options, (res) => {
            //Construct response
            let body = "";
            res.on("data", (data) => {
                body += data;
            });
            res.on("end", function () {
                if (res && res.statusCode && res.statusCode === 200)
                    return resolve(body);
                log_1.logging.message("update", "Bad Response " + res.statusCode + enums_1.EConstant.return).write(true);
                reject(res.statusCode);
            });
        });
        log_1.logging.message("update", "Sending request to " + url + enums_1.EConstant.return).write(true);
        log_1.logging.message("update", "Options: " + JSON.stringify(options) + enums_1.EConstant.return).write(true);
        req.on("error", reject);
        req.end();
    });
}
