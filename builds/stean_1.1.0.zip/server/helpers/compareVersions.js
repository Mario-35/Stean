"use strict";
/**
 * AutoUpdate
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.compareVersions = compareVersions;
const _1 = require(".");
const constants_1 = require("../constants");
const enums_1 = require("../enums");
const log_1 = require("../log");
/**
 * Checks the local version of the application against the remote repository.
 *
 * @param UpToDate - If the local version is the same as the remote version.
 * @param appVersion - The version of the local application.
 * @param remoteVersion - The version of the application in the git repository.
 * @returns An object with the results of the version comparison.
 */
async function compareVersions() {
    try {
        const remoteVersion = await (0, _1.readRemoteVersion)();
        return remoteVersion ? { upToDate: constants_1.appVersion.version == remoteVersion.version && constants_1.appVersion.date == remoteVersion.date, appVersion: constants_1.appVersion, remoteVersion: remoteVersion } : undefined;
    }
    catch (err) {
        process.stdout.write(log_1.log.update(err + enums_1.EConstant.return));
        return undefined;
    }
}
