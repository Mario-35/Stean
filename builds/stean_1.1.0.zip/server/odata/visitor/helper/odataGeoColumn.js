"use strict";
/**
 * OdataGeoColumn
 *
 * @copyright 2022-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OdataGeoColumn = void 0;
const enums_1 = require("../../../enums");
const helpers_1 = require("../../../helpers");
const log_1 = require("../../../log");
const models_1 = require("../../../models");
const helpers_2 = require("../../../models/helpers");
class OdataGeoColumn {
    src;
    test;
    column;
    method;
    key;
    constructor(src, method, column) {
        this.src = src;
        this.column = column;
        this.method = method === "geo.length" ? "ST_Length" : method.toUpperCase().replace("GEO.", "ST_");
        this.test = this.init();
    }
    init() {
        console.log(log_1.log.whereIam());
        this.column = (0, helpers_1.removeAllQuotes)(this.column);
        let test = undefined;
        const tempEntity = this.src.entity;
        if (tempEntity) {
            if (this.column.includes(".")) {
                const temp = this.column.split(".");
                const tm = models_1.models.getEntity(this.src.ctx.service, temp[0]);
                if (tm && tm.columns.hasOwnProperty(temp[1])) {
                    this.src.subQuery.select = `"featureofinterest"."id"`;
                    this.src.subQuery.where = `CASE WHEN "${enums_1.EConstant.encoding}" LIKE '%geo+json' THEN ST_GeomFromEWKT(ST_GeomFromGeoJSON(coalesce(${(0, helpers_1.doubleQuotes)(temp[1])}->'geometry',${(0, helpers_1.doubleQuotes)(temp[1])}))) ELSE ST_GeomFromEWKT(${(0, helpers_1.doubleQuotes)(temp[1])}::text) END`;
                    this.key = `"${temp[1]}"->>'type'`;
                    return undefined;
                }
            }
            else if (this.column.includes("/")) {
                const temp = this.column.split("/");
                if (tempEntity.relations.hasOwnProperty(temp[0])) {
                    const relation = (0, helpers_2.relationInfos)(this.src.ctx.service, tempEntity.name, temp[0]);
                    if (relation.entity) {
                        this.column = `(SELECT ${(0, helpers_1.doubleQuotes)(temp[1])} FROM ${(0, helpers_1.doubleQuotes)(relation.entity.table)} WHERE ${(0, helpers_2.expand)(this.src.ctx.service, tempEntity.name, temp[0])} AND length(${(0, helpers_1.doubleQuotes)(temp[1])}::text) > 2)`;
                        if (tempEntity.columns.hasOwnProperty(enums_1.EConstant.encoding))
                            test = `(SELECT ${(0, helpers_1.doubleQuotes)(enums_1.EConstant.encoding)} FROM ${(0, helpers_1.doubleQuotes)(relation.entity.table)} WHERE ${(0, helpers_2.expand)(this.src.ctx.service, tempEntity.name, temp[0])})`;
                    }
                    else
                        throw new Error(`Invalid this.column ${this.column}`);
                }
            }
            else if (!tempEntity.columns.hasOwnProperty(this.column)) {
                if (tempEntity.relations.hasOwnProperty(this.column)) {
                    const relation = (0, helpers_2.relationInfos)(this.src.ctx.service, tempEntity.name, this.column);
                    if (relation.entity) {
                        this.column = `(SELECT ${(0, helpers_1.doubleQuotes)(relation.column)} FROM ${(0, helpers_1.doubleQuotes)(relation.entity.table)} WHERE ${(0, helpers_2.expand)(this.src.ctx.service, tempEntity.name, this.column)} AND length(${(0, helpers_1.doubleQuotes)(relation.column)}::text) > 2)`;
                        if (tempEntity.columns.hasOwnProperty(enums_1.EConstant.encoding))
                            test = enums_1.EConstant.encoding;
                    }
                    else
                        throw new Error(`Invalid this.column ${this.column}`);
                }
                else if (this.src.ctx.model[this.src.parentEntity].columns.hasOwnProperty(this.column)) {
                    const relation = (0, helpers_2.relationInfos)(this.src.ctx.service, tempEntity.name, this.column);
                    if (relation.entity) {
                        this.column = `(SELECT ${(0, helpers_1.doubleQuotes)(relation.column)} FROM ${(0, helpers_1.doubleQuotes)(relation.entity.table)} WHERE ${(0, helpers_2.expand)(this.src.ctx.service, tempEntity.name, this.column)} AND length(${(0, helpers_1.doubleQuotes)(relation.column)}::text) > 2)`;
                        if (tempEntity.columns.hasOwnProperty(enums_1.EConstant.encoding))
                            test = enums_1.EConstant.encoding;
                    }
                    else
                        throw new Error(`Invalid this.column ${this.column}`);
                }
                else
                    throw new Error(`Invalid this.column ${this.column}`);
            }
            else {
                // TODO ADD doubleQuotes
                const temp = tempEntity.columns.hasOwnProperty(enums_1.EConstant.encoding);
                if (temp)
                    test = (0, helpers_1.doubleQuotes)(enums_1.EConstant.encoding);
                this.column = (0, helpers_1.doubleQuotes)(this.column);
            }
        }
        if (test)
            return `CASE WHEN "${enums_1.EConstant.encoding}" LIKE '%geo+json' THEN ST_GeomFromEWKT(ST_GeomFromGeoJSON(coalesce(${this.column}->'geometry',${this.column}))) ELSE ST_GeomFromEWKT(${this.column}::text) END`;
    }
    toString() {
        return this.test ? this.test : this.src.subQuery.where ? this.src.subQuery.where : "";
    }
    createFunc(datas) {
        switch (this.method) {
            case "ST_Length":
                return `${this.method}(ST_MakeLine(ST_AsText(${this.toString()}), ${datas}))`;
            default:
                return `${this.method}(ST_AsText(${this.toString()}), ${datas})`;
        }
    }
    createColumn(datas, context) {
        if (this.test) {
            this.src.addToWhere(this.createFunc(datas), context);
        }
        else {
            this.src.subQuery.where = `${this.key} = 'Point' AND ${this.createFunc(datas)}`;
            context.target = enums_1.EQuery.Geo;
        }
        return context;
    }
}
exports.OdataGeoColumn = OdataGeoColumn;
