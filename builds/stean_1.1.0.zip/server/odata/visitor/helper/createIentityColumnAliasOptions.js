"use strict";
/**
 * createIentityColumnAliasOptions
 *
 * @copyright 2022-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createIentityColumnAliasOptions = createIentityColumnAliasOptions;
function createIentityColumnAliasOptions(entity, columnName, context, operation, forceString, pgVisitor) {
    return {
        entity: entity,
        columnName: columnName,
        operation: operation,
        alias: false,
        forceString: forceString || false,
        valueskeys: pgVisitor.valueskeys,
        numeric: pgVisitor.numeric,
        context: context
    };
}
