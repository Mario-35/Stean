"use strict";
/**
 * postSqlFromPgVisitor
 *
 * @copyright 2022-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.postSqlFromPgVisitor = postSqlFromPgVisitor;
const helpers_1 = require("../../../helpers");
const enums_1 = require("../../../enums");
const queries_1 = require("../../../db/queries");
const models_1 = require("../../../models");
const log_1 = require("../../../log");
const helpers_2 = require("../../../models/helpers");
const dataAccess_1 = require("../../../db/dataAccess");
const entities = __importStar(require("../../../db/entities"));
const entities_1 = require("../../../models/entities");
function postSqlFromPgVisitor(datas, src) {
    const formatInsertEntityData = (entity, datas, main) => {
        const goodEntity = models_1.models.getEntityName(main.ctx.service, entity);
        if (goodEntity && goodEntity in entities) {
            try {
                const objectEntity = new dataAccess_1.apiAccess(main.ctx, entity);
                const tempDatas = objectEntity.formatDataInput(datas);
                if (tempDatas)
                    return tempDatas;
            }
            catch (error) {
                console.log(error);
            }
        }
        return datas;
    };
    console.log(log_1.log.whereIam());
    let sqlResult = "";
    const queryMaker = {};
    const tempEntity = src.entity;
    const postEntity = tempEntity && tempEntity.name == "CreateFile" ? entities_1.DATASTREAM : tempEntity;
    if (!postEntity)
        return;
    const postParentEntity = src.parentEntity ? src.parentEntity : undefined;
    const names = {
        [postEntity.table]: postEntity.table
    };
    let level = 0;
    const allFields = "*";
    const getRelationNameFromEntity = (source, from) => {
        return Object.keys(source.relations).includes(from.name) ? from.name : Object.keys(source.relations).includes(from.singular) ? from.singular : undefined;
    };
    /**
     *
     * @param query query for the query not in as
     * @returns
     */
    const onConflict = (element) => {
        let conflictNames = Object.keys(queryMaker[element].datas).filter((e) => queryMaker[element].entity.columns[e].create.includes("UNIQUE"));
        if (conflictNames.length <= 0 && src.id)
            conflictNames = Object.keys(queryMaker[element].datas);
        return conflictNames.length <= 0 ? "" : ` ON CONFLICT ("${conflictNames.join('","')}") do update set ${(0, helpers_2.createUpdateValues)(queryMaker[element].entity, queryMaker[element].datas)}`;
    };
    const queryMakerToString = (query) => {
        const returnValue = [query];
        const links = {};
        const sorting = [];
        Object.keys(queryMaker).forEach((element) => {
            Object.keys(queryMaker).forEach((elem) => {
                if (JSON.stringify(queryMaker[elem].datas).includes(`select ${element}`)) {
                    if (links[elem])
                        links[elem].push(element);
                    else
                        links[elem] = [element];
                }
            });
        });
        //  pre sorting for some case like multidatastreams
        Object.keys(links).forEach((elem) => {
            Object.keys(links).forEach((subElem) => {
                if (links[elem].includes(subElem) && !sorting.includes(subElem))
                    sorting.push(subElem);
            });
        });
        // sorting
        Object.keys(queryMaker).forEach((elem) => {
            if (Object.keys(links).includes(elem)) {
                if (!sorting.includes(elem))
                    sorting.push(elem);
            }
            else {
                sorting.unshift(elem);
            }
        });
        // LOOP on sorting
        sorting.forEach((element) => {
            if (queryMaker[element].datas.hasOwnProperty(enums_1.EConstant.id)) {
                const searchId = queryMaker[element].datas[enums_1.EConstant.id];
                returnValue.push(`, ${element} AS (select verifyId('${queryMaker[element].entity.table}', ${searchId}) as id)`);
            }
            else if (queryMaker[element].datas.hasOwnProperty(enums_1.EConstant.name)) {
                const searchByName = queryMaker[element].datas[enums_1.EConstant.name];
                returnValue.push(`, ${element} AS (select "id" from "${queryMaker[element].entity.table}" where "name" = '${searchByName}')`);
            }
            else {
                returnValue.push(`, ${element} AS (`);
                if (src.id) {
                    if (queryMaker[element].type == enums_1.EOperation.Association) {
                        returnValue.push(`INSERT INTO "${queryMaker[element].entity.table}" ${(0, helpers_2.createInsertValues)(src.ctx.service, formatInsertEntityData(queryMaker[element].entity.table, queryMaker[element].datas, src))}${onConflict(element)} WHERE "${queryMaker[element].entity.table}"."${queryMaker[element].keyId}" = ${BigInt(src.id).toString()}`);
                    }
                    else
                        returnValue.push(`UPDATE "${queryMaker[element].entity.table}" SET ${(0, helpers_2.createUpdateValues)(queryMaker[element].entity, queryMaker[element].datas)} WHERE "${queryMaker[element].entity.table}"."${queryMaker[element].keyId}" = (select verifyId('${queryMaker[element].entity.table}', ${src.id}) as id)`);
                }
                else
                    returnValue.push(`INSERT INTO "${queryMaker[element].entity.table}" ${(0, helpers_2.createInsertValues)(src.ctx.service, formatInsertEntityData(queryMaker[element].entity.table, queryMaker[element].datas, src))}${queryMaker[element].entity.type === enums_1.EentityType.link ? onConflict(element) : ""}`);
                returnValue.push(`RETURNING ${postEntity.table == queryMaker[element].entity.table ? allFields : queryMaker[element].keyId})`);
            }
        });
        return returnValue.join(enums_1.EConstant.return).replace(/\'@/g, "").replace(/\@'/g, "");
    };
    /**
     *
     * @param datas datas
     * @param entity entity for the datas if not root entity
     * @param parentEntity parent entity for the datas if not root entity
     * @returns result
     */
    const start = (datas, entity, parentEntity) => {
        console.log(log_1.log.debug_head(`start level ${level++}`));
        const returnValue = {};
        entity = entity ? entity : postEntity;
        parentEntity = parentEntity ? parentEntity : postParentEntity ? postParentEntity : postEntity;
        for (const key in datas) {
            if (entity && !Object.keys(entity.relations).includes(key)) {
                returnValue[key] = typeof datas[key] === "object" ? JSON.stringify(datas[key]) : datas[key];
                delete datas[key];
            }
        }
        /**
         *
         * @param inputNameEntity {string} name of the entity
         * @returns name of th next entity {inputNameEntity1}
         */
        const createName = (inputNameEntity) => {
            let number = 0;
            if (names[inputNameEntity]) {
                const numbers = names[inputNameEntity].match(/[0-9]/g);
                number = numbers !== null ? Number(numbers.join("")) : 0;
            }
            return `${inputNameEntity}${(number + 1).toString()}`;
        };
        /**
         *  add or make query entry
         * @param name name
         * @param tableName table nae for insert
         * @param datas datas to insert string if key is send or object
         * @param key key of the value
         */
        const addToQueryMaker = (type, name, entity, datas, keyId, key) => {
            const isTypeString = typeof datas === "string";
            if (queryMaker.hasOwnProperty(name)) {
                if (key && isTypeString) {
                    // @ts-ignore
                    queryMaker[name].datas[key] = datas;
                    queryMaker[name].keyId = keyId;
                }
                else if (!isTypeString) {
                    if (queryMaker[name].type == enums_1.EOperation.Table || queryMaker[name].type == enums_1.EOperation.Relation)
                        queryMaker[name].datas = Object.assign(queryMaker[name].datas, datas);
                    queryMaker[name].keyId = keyId;
                    if (queryMaker[name].type == enums_1.EOperation.Association)
                        queryMaker[createName(name)] = {
                            type: queryMaker[name].type,
                            entity: queryMaker[name].entity,
                            datas: datas,
                            keyId: queryMaker[name].keyId
                        };
                }
            }
            else {
                if (key && isTypeString)
                    queryMaker[name] = {
                        type: type,
                        entity: entity,
                        datas: { [key]: datas },
                        keyId: keyId
                    };
                else if (!isTypeString)
                    queryMaker[name] = {
                        type: type,
                        entity: entity,
                        datas: datas,
                        keyId: keyId
                    };
            }
        };
        /**
         *
         * @param subEntity {Ientity} entity to use
         * @param subParentEntity {Ientity} entity parent
         */
        const addAssociation = (subEntity, subParentEntity) => {
            console.log(log_1.log.debug_infos(`addAssociation in ${subEntity.name} for parent`, subParentEntity.name));
            const relationName = getRelationNameFromEntity(subEntity, subParentEntity);
            const parentRelationName = getRelationNameFromEntity(subParentEntity, subEntity);
            if (parentRelationName && relationName) {
                const relCardinality = (0, helpers_2.relationInfos)(src.ctx.service, subEntity.name, relationName);
                const parentCardinality = (0, helpers_2.relationInfos)(src.ctx.service, subParentEntity.name, subEntity.name);
                console.log(log_1.log.debug_infos(`Found a parent relation in ${subEntity.name}`, subParentEntity.name));
                if (relCardinality.entity && parentCardinality.entity && relCardinality.entity.table == parentCardinality.entity.table && relCardinality.entity.table == subEntity.table) {
                    console.log(log_1.log.debug_infos("Found a relation to do in sub query", subParentEntity.name));
                    const tableName = names[subEntity.table];
                    const parentTableName = names[subParentEntity.table];
                    addToQueryMaker(enums_1.EOperation.Relation, tableName, subEntity, `@(select ${parentTableName}.id from ${parentTableName})@`, parentCardinality.leftKey, parentCardinality.rightKey);
                }
                else if (relCardinality.entity && parentCardinality.entity && relCardinality.entity.table == parentCardinality.entity.table) {
                    if (relCardinality.entity.table == subParentEntity.table) {
                        const tableName = names[subEntity.table];
                        const parentTableName = names[subParentEntity.table];
                        console.log(log_1.log.debug_infos(`Add parent relation ${tableName} in`, parentTableName));
                        addToQueryMaker(enums_1.EOperation.Relation, parentTableName, subParentEntity, `@(select ${tableName}.id from ${tableName})@`, parentCardinality.leftKey, relCardinality.rightKey);
                    }
                    else if (relCardinality.entity && relCardinality.entity.table != subParentEntity.table && relCardinality.entity.table != subEntity.table) {
                        const tableName = names[subEntity.table];
                        const parentTableName = names[subParentEntity.table];
                        console.log(log_1.log.debug_infos(`Add Table association ${tableName} in`, parentTableName));
                        addToQueryMaker(enums_1.EOperation.Association, relCardinality.entity.table, relCardinality.entity, {
                            [`${subEntity.table}_id`]: `@(select ${tableName}.id from ${tableName})@`,
                            [`${subParentEntity.table}_id`]: `@(select ${parentTableName}.id from ${parentTableName})@`
                        }, relCardinality.entity.columns[relCardinality.rightKey].create.includes("UNIQUE") ? relCardinality.rightKey : relCardinality.leftKey, undefined);
                    }
                }
                else {
                    const tableName = names[subEntity.table];
                    const parentTableName = names[subParentEntity.table];
                    console.log(log_1.log.debug_infos(`Add Relation ${tableName} in`, parentTableName));
                    addToQueryMaker(enums_1.EOperation.Table, parentTableName, subParentEntity, {
                        [relCardinality.rightKey]: `@(select ${tableName}.id from ${tableName})@`
                    }, relCardinality.leftKey, undefined);
                }
            }
        };
        /**
         *
         * @param key key Name
         * @param value Datas to process
         */
        const subBlock = (key, value) => {
            const entityNameSearch = models_1.models.getEntityName(src.ctx.service, key);
            if (entityNameSearch) {
                const newEntity = src.ctx.model[entityNameSearch];
                const name = createName(newEntity.table);
                names[newEntity.table] = name;
                const test = start(value, newEntity, entity);
                if (test) {
                    addToQueryMaker(enums_1.EOperation.Table, name, newEntity, test, "id", undefined);
                    level--;
                }
                if (entity)
                    addAssociation(newEntity, entity);
            }
        };
        // Main loop
        if (entity && parentEntity) {
            for (const key in datas) {
                if (Array.isArray(datas[key])) {
                    // eslint-disable-next-line @typescript-eslint/no-unused-vars
                    Object.entries(datas[key]).forEach(([_key, value]) => {
                        if (entity && parentEntity && Object.keys(entity.relations).includes(key)) {
                            console.log(log_1.log.debug_infos(`Found a relation for ${entity.name}`, key));
                            subBlock(key, value);
                        }
                        else {
                            console.log(log_1.log.debug_infos(`data ${key}`, datas[key]));
                            returnValue[key] = datas[key];
                        }
                    });
                }
                else if (typeof datas[key] === "object") {
                    if (Object.keys(entity.relations).includes(key)) {
                        console.log(log_1.log.debug_infos(`Found a object relation for ${entity.name}`, key));
                        subBlock(key, datas[key]);
                    }
                }
                else
                    returnValue[key] = datas[key];
            }
        }
        return returnValue;
    };
    if (src.parentEntity) {
        const entityName = src.parentEntity.name;
        console.log(log_1.log.debug_infos("Found entity : ", entityName));
        const callEntity = entityName ? src.ctx.model[entityName] : undefined;
        const id = typeof src.parentId == "string" ? (0, helpers_1.getBigIntFromString)(src.parentId) : src.parentId;
        if (entityName && callEntity && id && id > 0) {
            const relationName = getRelationNameFromEntity(postEntity, callEntity);
            if (relationName)
                datas[relationName] = { "@iot.id": id.toString() };
        }
    }
    const root = start(datas);
    if ((names[postEntity.table] && queryMaker[postEntity.table] && queryMaker[postEntity.table].datas) || root === undefined) {
        queryMaker[postEntity.table].datas = Object.assign(root, queryMaker[postEntity.table].datas);
        queryMaker[postEntity.table].keyId = src.id ? "id" : "*";
        sqlResult = queryMakerToString(`WITH "log_request" AS (${enums_1.EConstant.return}${enums_1.EConstant.tab}SELECT srid FROM ${(0, helpers_1.doubleQuotes)(enums_1.EConstant.voidtable)} LIMIT 1${enums_1.EConstant.return})`);
    }
    else {
        sqlResult = queryMakerToString(src.id
            ? root && Object.entries(root).length > 0
                ? `WITH ${postEntity.table} AS (${enums_1.EConstant.return}${enums_1.EConstant.tab}UPDATE ${(0, helpers_1.doubleQuotes)(postEntity.table)}${enums_1.EConstant.return}${enums_1.EConstant.tab}SET ${(0, helpers_2.createUpdateValues)(postEntity, root)} WHERE "id" = (${enums_1.EConstant.return}${enums_1.EConstant.tab}select verifyId('${postEntity.table}', ${src.id}) as id) RETURNING ${allFields})`
                : `WITH ${postEntity.table} AS (${enums_1.EConstant.return}${enums_1.EConstant.tab}SELECT * FROM ${(0, helpers_1.doubleQuotes)(postEntity.table)}${enums_1.EConstant.return}${enums_1.EConstant.tab}WHERE "id" = ${src.id.toString()})`
            : `WITH ${postEntity.table} AS (${enums_1.EConstant.return}${enums_1.EConstant.tab}INSERT INTO ${(0, helpers_1.doubleQuotes)(postEntity.table)} ${(0, helpers_2.createInsertValues)(src.ctx.service, formatInsertEntityData(postEntity.name, root, src))} RETURNING ${allFields})`);
    }
    const temp = src.toPgQuery();
    if (temp)
        sqlResult += (0, queries_1.asJson)({
            query: `SELECT ${temp && temp.select ? temp.select : "*"} FROM ${names[postEntity.table]} ${temp && temp.groupBy ? `GROUP BY ${temp.groupBy}` : ""}`,
            singular: false,
            strip: src.ctx.service.options.includes(enums_1.EOptions.stripNull),
            count: false
        });
    return sqlResult;
}
