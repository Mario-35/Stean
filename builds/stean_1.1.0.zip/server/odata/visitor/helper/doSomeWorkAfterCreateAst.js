"use strict";
/**
 * doSomeWorkAfterCreateAst
 *
 * @copyright 2022-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.doSomeWorkAfterCreateAst = void 0;
const configuration_1 = require("../../../configuration");
const queries_1 = require("../../../db/queries");
const log_1 = require("../../../log");
const doSomeWorkAfterCreateAst = async (input, ctx) => {
    console.log(log_1.log.whereIam());
    if (input.entity && input.splitResult && input.splitResult[0].toUpperCase() == "ALL" && input.parentId && input.parentId > 0) {
        const temp = await configuration_1.config.connection(ctx.service.name).unsafe(`${(0, queries_1.multiDatastreamKeys)(input.parentId)}`);
        input.splitResult = temp[0]["keys"];
    }
};
exports.doSomeWorkAfterCreateAst = doSomeWorkAfterCreateAst;
