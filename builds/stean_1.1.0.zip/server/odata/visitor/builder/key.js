"use strict";
/**
 * GroupBy builder
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Key = void 0;
const _1 = require(".");
class Key extends _1.Core {
    constructor(input) {
        super(input);
    }
    add(input) {
        super.addKey(input);
    }
}
exports.Key = Key;
