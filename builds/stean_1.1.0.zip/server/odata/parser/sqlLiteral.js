"use strict";
/**
 * oData SQLLiteral
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SQLLiteral = void 0;
const literal_1 = require("./literal");
class SQLLiteral extends literal_1.Literal {
    static convert(type, value) {
        return new SQLLiteral(type, value).valueOf();
    }
    "Edm.String"(value) {
        return "'" + decodeURIComponent(value).slice(1, -1).replace(/''/g, "'") + "'";
    }
    "Edm.Guid"(value) {
        return "'" + decodeURIComponent(value) + "'";
    }
    "Edm.Date"(value) {
        return "'" + value + "'";
    }
    "Edm.DateTimePeriod"(value) {
        return "'" + value.trim() + "'";
    }
    "Edm.DateTimeOffset"(value) {
        return "'" + value.replace("T", " ").replace("Z", " ").trim() + "'";
    }
    "Edm.Boolean"(value) {
        value = value || "";
        switch (value.toLowerCase()) {
            case "true":
                return 1;
            case "false":
                return 0;
            default:
                return "NULL";
        }
    }
    "null"(value) {
        return null;
    }
}
exports.SQLLiteral = SQLLiteral;
