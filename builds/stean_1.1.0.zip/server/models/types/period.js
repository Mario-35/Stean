"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Period = void 0;
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const helpers_2 = require("../helpers");
const core_1 = require("./core");
class Period extends core_1.Core {
    constructor(tz) {
        super(tz ? enums_1.EDataType.tstzrange : enums_1.EDataType.tsrange);
        this._.alias = function (options) {
            if (options.context && (options.context.target === enums_1.EQuery.Where || options.context.target === enums_1.EQuery.Select)) {
                return `NULLIF (CONCAT_WS('/', to_char(lower(${(0, helpers_1.doubleQuotes)(options.columnName)}), '${tz ? enums_1.EDatesType.dateTz : enums_1.EDatesType.date}'), to_char(upper(${(0, helpers_1.doubleQuotes)(options.columnName)}), '${tz ? enums_1.EDatesType.dateTz : enums_1.EDatesType.date}')), '')${(0, helpers_2.as)(options)}`;
            }
            else
                return (0, helpers_1.doubleQuotes)(options.columnName);
        };
    }
}
exports.Period = Period;
