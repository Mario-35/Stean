"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Timestamp = void 0;
const enums_1 = require("../../enums");
const core_1 = require("./core");
class Timestamp extends core_1.Core {
    constructor(tz) {
        super(tz ? enums_1.EDataType.timestamptz : enums_1.EDataType.timestamp);
    }
    defaultCurrent() {
        this._.create = this._.create.replace("@DEFAULT@", " DEFAULT CURRENT_TIMESTAMP");
        return this;
    }
}
exports.Timestamp = Timestamp;
