"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Relation = void 0;
const enums_1 = require("../../enums");
const core_1 = require("./core");
class Relation extends core_1.Core {
    constructor(input) {
        super(enums_1.EDataType.bigint);
        this._.dataType = enums_1.EDataType.link;
        this.relation(input.trim());
    }
}
exports.Relation = Relation;
