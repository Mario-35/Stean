"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Time = void 0;
const enums_1 = require("../../enums");
const core_1 = require("./core");
class Time extends core_1.Core {
    constructor(tz) {
        super(tz ? enums_1.EDataType.timetz : enums_1.EDataType.time);
    }
    defaultCurrent() {
        this._.create = this._.create.replace("@DEFAULT@", " DEFAULT CURRENT_TIME");
        return this;
    }
}
exports.Time = Time;
