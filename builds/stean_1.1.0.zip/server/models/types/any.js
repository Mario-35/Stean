"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Any = void 0;
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const helpers_2 = require("../helpers");
const core_1 = require("./core");
class Any extends core_1.Core {
    constructor() {
        super(enums_1.EDataType.any);
        this._.create = "JSONB NULL";
        this._.alias = function alias(options) {
            if (options.context && options.context.target === enums_1.EQuery.Where) {
                const nbs = [1, 2, 3, 4, 5];
                const translate = `TRANSLATE (SUBSTRING (${(0, helpers_1.doubleQuotes)(options.columnName)}->>'value' FROM '(([0-9]+.*)*[0-9]+)'), '[]','')`;
                const isOperation = options.operation && options.operation.trim() != "";
                // json path = had to be ==
                // if (options && !options.context.onEachResult && options.context.sign === "=") options.context.sign = "==";
                if (options.forceString === false && !options.context.onEachResult && options.context.sign && options.context.sign === "=")
                    options.context.sign = "==";
                return options.forceString === true
                    ? // operation on string
                        options.context.onEachResult
                            ? `@EXPRESSIONSTRING@ ALL (ARRAY_REMOVE( ARRAY[${enums_1.EConstant.return}${nbs
                                .map((e) => `${isOperation ? `${options.operation} (` : ""} SPLIT_PART ( ${translate}, ',', ${e}))`)
                                .join(`,${enums_1.EConstant.return}`)}], null))`
                            : `${(0, helpers_1.doubleQuotes)(options.columnName)}->>'value'`
                    : options.context.onEachResult
                        ? // OPERATION ROUND FLOOR CEILING (jsonpath can't process it)
                            `@EXPRESSION@ ALL (ARRAY_REMOVE( ARRAY[${enums_1.EConstant.return}${nbs
                                .map((e) => `${isOperation ? `${options.operation} (` : ""}NULLIF (SPLIT_PART ( ${translate}, ',', ${e}),'')::numeric${isOperation ? `)` : ""}`)
                                .join(`,${enums_1.EConstant.return}`)}], null))`
                        : // jsonpath postgres operation
                            `result @? '$.value ? (@EXPRESSION@ @)'`;
            }
            else {
                return options.valueskeys || options.numeric
                    ? `CASE
                            WHEN JSONB_TYPEOF( ${(0, helpers_1.doubleQuotes)(options.columnName)}->'value') = 'number' THEN (${(0, helpers_1.doubleQuotes)(options.columnName)}->${options.numeric == true ? "" : ">"}'value')::jsonb
                            WHEN JSONB_TYPEOF( ${(0, helpers_1.doubleQuotes)(options.columnName)}->'value') = 'array'  THEN (${(0, helpers_1.doubleQuotes)(options.columnName)}->'${options.valueskeys == true ? "valueskeys" : "value"}')::jsonb
                            ELSE (${(0, helpers_1.doubleQuotes)(options.columnName)}->'${options.valueskeys == true ? "valueskeys" : "value"}')::jsonb
                        END${(0, helpers_2.as)(options)}`
                    : `CASE
                            WHEN JSONB_TYPEOF( ${(0, helpers_1.doubleQuotes)(options.columnName)}->'value') = 'number' THEN (${(0, helpers_1.doubleQuotes)(options.columnName)}->>'value')::jsonb
                            WHEN JSONB_TYPEOF( ${(0, helpers_1.doubleQuotes)(options.columnName)}->'value') = 'array'  THEN (${(0, helpers_1.doubleQuotes)(options.columnName)}->'value')::jsonb
                            ELSE (${(0, helpers_1.doubleQuotes)(options.columnName)}->'value')::jsonb
                        END${(0, helpers_2.as)(options)}`;
            }
        };
    }
    lines() {
        this._.alias = function alias(options) {
            return `${(0, helpers_1.doubleQuotes)(options.columnName)}->'line'`;
        };
        return this;
    }
}
exports.Any = Any;
