"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Texts = void 0;
const enums_1 = require("../../enums");
const core_1 = require("./core");
class Texts extends core_1.Core {
    constructor() {
        super(enums_1.EDataType._text);
    }
    verify(input) {
        this._.verify = {
            list: input,
            default: ""
        };
        return this;
    }
}
exports.Texts = Texts;
