"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Bigint = void 0;
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const core_1 = require("./core");
class Bigint extends core_1.Core {
    constructor() {
        super(enums_1.EDataType.bigint);
    }
    generated() {
        this._.create = "BIGINT GENERATED ALWAYS AS IDENTITY";
        this._.alias = function alias(options) {
            return `${(0, helpers_1.doubleQuotes)(options.entity.table)}.${(0, helpers_1.doubleQuotes)(options.columnName)}${options.context?.target === enums_1.EQuery.Select ? ` AS ${(0, helpers_1.doubleQuotes)(`@iot.${options.columnName}`)}` : ""}`;
        };
        return this;
    }
}
exports.Bigint = Bigint;
