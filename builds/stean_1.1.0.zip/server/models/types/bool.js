"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Bool = void 0;
const enums_1 = require("../../enums");
const core_1 = require("./core");
class Bool extends core_1.Core {
    constructor() {
        super(enums_1.EDataType.bool);
    }
}
exports.Bool = Bool;
