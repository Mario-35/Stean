"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Entity = void 0;
const enums_1 = require("../../enums");
const messages_1 = require("../../messages");
const helpers_1 = require("../helpers");
class EntityPass {
    // global trigger
    static trigger = {};
    // global constraints and indexes
    static pass = {};
}
class Entity extends EntityPass {
    name; // Entity Name
    singular;
    table;
    createOrder;
    type;
    order;
    orderBy;
    columns;
    relations;
    constraints;
    indexes;
    after;
    trigger;
    clean;
    constructor(name, datas) {
        super();
        const entity = enums_1.allEntities[name];
        if (entity) {
            (this.createOrder = datas.createOrder), (this.type = datas.type), (this.order = datas.order), (this.columns = datas.columns), (this.orderBy = Object.keys(datas.columns)[0]);
            (this.relations = datas.relations), (this.constraints = {}), (this.indexes = {}), (this.after = datas.after), (this.name = name);
            if (datas.trigger)
                this.trigger = datas.trigger;
            this.singular = (0, helpers_1.singular)(entity);
            this.table = this.singular.toLowerCase();
        }
        else
            throw new Error((0, messages_1.msg)(messages_1.errors.noValidEntity, name));
        this.prepareColums();
        this.createConstraints();
        this.createTriggers();
    }
    addTrigger(action, table, relTable) {
        return `do $$ BEGIN
    CREATE TRIGGER ${table}s_actualization_${action}
        after ${action}
        on "${relTable}"
        for each row
        execute procedure ${table}s_update_${action}();
  exception
    when others then null;
  end $$;`;
    }
    dataStr(table, column, tim, coalesce) {
        return `IF (NEW."${column}" IS NOT NULL) THEN
       MIN := NULL;
       MAX := NULL; 
      IF (NEW."${column}" < lower(SOURCE."${column}") OR lower(SOURCE."${column}") IS NULL )
        THEN MIN := NEW."${column}"::${tim};
        ELSE MIN := lower(SOURCE."${column}")::${tim};
        MAX := upper(SOURCE."${column}")::${tim};
      END IF;

      IF (NEW."${column}" > upper(SOURCE."${column}") OR upper(SOURCE."${column}") IS NULL )
        THEN MAX := NEW."${column}"::${tim};
        ELSE MAX := upper(SOURCE."${column}")::${tim};
        IF (MIN IS NULL) THEN 
          MIN := lower(SOURCE."${column}")::${tim};
        END IF;
      END IF;

      IF (MIN IS NOT NULL AND MAX IS NOT NULL) THEN 
		    EXECUTE 'UPDATE "${table}" SET "${column}" = ''[' || MIN || ',' || MAX || ']'' WHERE "${table}"."id"=' || NEW."${table}_id" using NEW;
      END IF;
  	END IF;
`;
    }
    insertStr(table, column, relTable, timeType, coalesce) {
        // Ajoute une fonction en vue d'un trigger
        const datas = this.dataStr(table, column, timeType);
        Entity.trigger[table].insert = Entity.trigger[table].hasOwnProperty("insert")
            ? Entity.trigger[table].insert.replace("@DATAS@", `${enums_1.EConstant.return}${datas}@DATAS@`).replace("@COLUMN@", `,"${column}"@COLUMN@`)
            : `CREATE OR REPLACE FUNCTION ${table}s_update_insert()  RETURNS TRIGGER LANGUAGE PLPGSQL AS $$ DECLARE SOURCE RECORD; MIN ${timeType} := NULL; MAX ${timeType} := NULL; BEGIN IF (NEW."${table}_id" is not null) THEN SELECT "id","${column}"@COLUMN@ INTO SOURCE FROM "${table}" WHERE "${table}"."id" = NEW."${table}_id"; ${datas}@DATAS@ END IF; RETURN NEW; END; $$`;
        // Ajoute la fonction precedement créer
        Entity.trigger[table].doInsert = this.addTrigger("insert", table, relTable);
    }
    updateStr(table, column, relTable, timeType, coalesce) {
        // Ajoute une fonction en vue d'un trigger
        const datas = this.dataStr(table, column, timeType);
        Entity.trigger[table].update = Entity.trigger[table].hasOwnProperty("update")
            ? Entity.trigger[table].update.replace("@DATAS@", `${enums_1.EConstant.return}${datas}@DATAS@`).replace("@COLUMN@", `,"${column}"@COLUMN@`)
            : `CREATE OR REPLACE FUNCTION ${table}s_update_update()  RETURNS TRIGGER LANGUAGE PLPGSQL AS $$ DECLARE SOURCE RECORD; MIN ${timeType} := NULL; MAX ${timeType} := NULL; BEGIN IF (NEW."${table}_id" is not null) THEN SELECT "id","${column}"@COLUMN@ INTO SOURCE FROM "${table}" WHERE "${table}"."id" = NEW."${table}_id"; ${datas}@DATAS@ END IF; RETURN NEW; END; $$`;
        Entity.trigger[table].doUpdate = this.addTrigger("update", table, relTable);
    }
    deleteStr(table, column, relTable, timeType, coalesce) {
        const datas = `IF (OLD."${column}" IS NOT NULL) THEN
      IF (OLD."${column}" = lower(SOURCE."${column}") OR OLD."${column}" = upper(SOURCE."${column}")) THEN 
		    EXECUTE 'UPDATE "${table}" SET "${column}" = tstzrange((SELECT MIN("${column}") FROM "${relTable}" WHERE "${relTable}"."${this.table}_id" = ${this.table}.id), (SELECT MAX("${column}") FROM "${relTable}" WHERE "${relTable}"."${this.table}_id" = ${this.table}.id)) WHERE "${table}"."id"=' || OLD."${table}_id" using OLD;

      END IF;
  	END IF;
`;
        Entity.trigger[table].delete = Entity.trigger[table].hasOwnProperty("delete")
            ? Entity.trigger[table].delete.replace("@DATAS@", `${enums_1.EConstant.return}${datas}@DATAS@`).replace("@COLUMN@", `,"${column}"@COLUMN@`)
            : `CREATE OR REPLACE FUNCTION ${table}s_update_delete()  RETURNS TRIGGER LANGUAGE PLPGSQL AS $$ DECLARE SOURCE RECORD; BEGIN IF (OLD."${table}_id" is not null) THEN SELECT "id","${column}"@COLUMN@ INTO SOURCE FROM "${table}" WHERE "${table}"."id" = OLD."${table}_id"; ${datas}@DATAS@ END IF; RETURN OLD; END; $$`;
        Entity.trigger[table].doDelete = this.addTrigger("delete", table, relTable);
    }
    addToClean(input) {
        if (this.clean)
            this.clean.push(input);
        else
            this.clean = [input];
    }
    prepareColums() {
        Object.keys(this.columns).forEach((e) => {
            if (this.columns[e].dataType === enums_1.EDataType.tstzrange || this.columns[e].dataType === enums_1.EDataType.tsrange) {
                const entityRelation = this.columns[e].entityRelation;
                const coalesce = this.columns[e].coalesce;
                const cast = enums_1.EDataType.tstzrange ? "TIMESTAMPTZ" : "TIMESTAMP";
                if (entityRelation) {
                    if (!Entity.trigger[this.table])
                        Entity.trigger[this.table] = {};
                    this.insertStr(this.table, e, (0, helpers_1.singular)(enums_1.allEntities[entityRelation]).toLowerCase(), cast, coalesce);
                    this.updateStr(this.table, e, (0, helpers_1.singular)(enums_1.allEntities[entityRelation]).toLowerCase(), cast, coalesce);
                    this.deleteStr(this.table, e, (0, helpers_1.singular)(enums_1.allEntities[entityRelation]).toLowerCase(), cast, coalesce);
                    this.addToClean(`@DROPCOLUMN@ "_${e}Start";`);
                    this.addToClean(`@DROPCOLUMN@ "_${e}End";`);
                    this.addToClean(`@UPDATE@ "${e}" = tstzrange((SELECT MIN("${e}") FROM "${entityRelation}" WHERE "${entityRelation}"."${this.table}_id" = ${this.table}.id), (SELECT MAX("${e}") FROM "${entityRelation}" WHERE "${entityRelation}"."${this.table}_id" = ${this.table}.id)) WHERE lower("${e}") IS NULL`);
                }
                else
                    this.addToClean(`@DROPCOLUMN@ "${e}"`);
                this.addToClean(`@ADDCOLUMN@ "${e}" tstzrange NULL;`);
            }
        });
    }
    createTriggers() {
        if (Entity.trigger[this.table]) {
            this.trigger = Object.keys(Entity.trigger[this.table]).map((elem) => Entity.trigger[this.table][elem].replace("@DATAS@", "").replace("@COLUMN@", ""));
        }
    }
    is(elem) {
        return Object.keys(this.columns).includes(`${elem.toLowerCase()}_id`);
    }
    addToPass(key, value) {
        value = value || `FOREIGN KEY ("${this.table}_id") REFERENCES "${this.table}"("id") ON UPDATE CASCADE ON DELETE CASCADE`;
        if (!Entity.pass[key])
            Entity.pass[key] = { constraints: {}, indexes: {} };
        Entity.pass[key].constraints[`${(0, helpers_1.singular)(key).toLowerCase()}_${this.table}_id_fkey`] = value;
    }
    addToConstraints(key, value) {
        this.constraints[key] = value;
    }
    addToIndexes(key, value) {
        this.indexes[key] = value;
    }
    createConstraints() {
        Object.keys(this.columns).forEach((elem) => {
            if (this.columns[elem].orderBy)
                this.orderBy = `"${elem}" ${this.columns[elem].orderBy.toUpperCase()}`;
            if (this.columns[elem].create.startsWith("BIGINT GENERATED ALWAYS AS IDENTITY")) {
                this.addToConstraints(`${this.table}_pkey`, `PRIMARY KEY ("${elem}")`);
                this.addToIndexes(`${this.table}_${elem}`, `ON public."${this.table}" USING btree ("${elem}")`);
            }
            else if (this.columns[elem].create.includes(" UNIQUE")) {
                this.addToConstraints(`${this.table}_unik_${elem}`, `UNIQUE ("${elem}")`);
                this.addToIndexes(`${this.table}_${elem}_id`, `ON public."${this.table}" USING btree ("${elem}_id")`);
            }
        });
        Object.keys(this.relations).forEach((elem) => {
            if (this.relations[elem].unique)
                this.addToConstraints(`${this.table}_unik_${elem.toLowerCase()}`, `UNIQUE (${this.relations[elem].unique.map((e) => `"${e}"`)})`);
            switch (this.relations[elem].type) {
                case enums_1.ERelations.belongsTo:
                    const value = `FOREIGN KEY ("${elem.toLowerCase()}_id") REFERENCES "${elem.toLowerCase()}"("id") ON UPDATE CASCADE ON DELETE CASCADE`;
                    if (this.relations[elem].entityRelation && this.is(elem))
                        this.addToPass(this.relations[elem].entityRelation, value);
                    else if (this.is(elem))
                        this.addToConstraints(`${this.table}_${elem.toLowerCase()}_id_fkey`, value);
                    this.addToIndexes(`${this.table}_${elem.toLowerCase()}_id`, `ON public."${this.table}" USING btree ("${elem.toLowerCase()}_id")`);
                    break;
                case enums_1.ERelations.defaultUnique:
                    this.addToConstraints(`${this.table}_${elem.toLowerCase()}_id_fkey`, `FOREIGN KEY ("_default_${elem.toLowerCase()}") REFERENCES "${elem.toLowerCase()}"("id") ON UPDATE CASCADE ON DELETE CASCADE`);
                    break;
                case enums_1.ERelations.belongsToMany:
                    if (this.relations[elem].entityRelation)
                        this.addToPass(this.relations[elem].entityRelation);
                    break;
                case enums_1.ERelations.hasMany:
                    if (this.relations[elem].entityRelation)
                        this.addToPass(this.relations[elem].entityRelation);
                    break;
            }
        });
        if (this.type === enums_1.EentityType.link && Object.keys(this.columns).length === 2) {
            this.addToConstraints(`${this.table}_pkey`, `PRIMARY KEY (${Object.keys(this.columns).map((e) => `"${e}"`)})`);
            Object.keys(this.columns).forEach((elem) => {
                this.addToIndexes(`${this.table}_${elem}`, `ON public."${this.table}" USING btree ("${elem}")`);
            });
        }
        if (Entity.pass[this.name]) {
            Object.keys(Entity.pass[this.name].constraints).forEach((elem) => {
                this.constraints[elem] = Entity.pass[this.name].constraints[elem];
            });
        }
    }
}
exports.Entity = Entity;
