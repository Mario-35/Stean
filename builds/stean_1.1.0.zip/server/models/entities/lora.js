"use strict";
/**
 * entity Lora
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LORA = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const messages_1 = require("../../messages");
const types_1 = require("../types");
exports.LORA = new entity_1.Entity("Loras", {
    createOrder: 11,
    type: enums_1.EentityType.table,
    order: 11,
    columns: {
        id: new types_1.Bigint().generated().column(),
        name: new types_1.Text().notNull().default(messages_1.info.noName).unique().column(),
        description: new types_1.Text().notNull().default(messages_1.info.noDescription).column(),
        properties: new types_1.Jsonb().column(),
        deveui: new types_1.Text().unique().column(),
        decoder_id: new types_1.Relation("Decoders").notNull().column(),
        datastream_id: new types_1.Relation("Datastreams").unique().column(),
        multidatastream_id: new types_1.Relation("MultiDatastreams").unique().column()
    },
    relations: {
        Datastream: {
            type: enums_1.ERelations.belongsTo
        },
        MultiDatastream: {
            type: enums_1.ERelations.belongsTo
        },
        Decoder: {
            type: enums_1.ERelations.belongsTo
        }
    }
});
