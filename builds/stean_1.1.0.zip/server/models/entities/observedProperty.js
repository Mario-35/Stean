"use strict";
/**
 * entity ObservedProperty
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OBSERVEDPROPERTY = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.OBSERVEDPROPERTY = new entity_1.Entity("ObservedProperties", {
    createOrder: 5,
    type: enums_1.EentityType.table,
    order: 8,
    columns: {
        id: new types_1.Bigint().generated().column(),
        name: new types_1.Text().notNull().column(),
        description: new types_1.Text().notNull().column(),
        definition: new types_1.Text().notNull().default("no definition").column()
    },
    relations: {
        Datastreams: {
            type: enums_1.ERelations.hasMany
        },
        MultiDatastreams: {
            type: enums_1.ERelations.hasMany,
            entityRelation: "MultiDatastreamObservedProperties"
        }
    }
});
