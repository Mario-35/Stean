"use strict";
/**
 * entity MultiDatastream
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MULTIDATASTREAM = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.MULTIDATASTREAM = new entity_1.Entity("MultiDatastreams", {
    createOrder: 8,
    type: enums_1.EentityType.table,
    order: 2,
    columns: {
        id: new types_1.Bigint().generated().column(),
        name: new types_1.Text().notNull().column(),
        description: new types_1.Text().notNull().column(),
        unitOfMeasurements: new types_1.Jsonb().notNull().column(),
        observationType: new types_1.Text().notNull().default("http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement").verify(Object.keys(enums_1.EObservationType)).column(),
        multiObservationDataTypes: new types_1.Texts().column(),
        observedArea: new types_1.Geometry().column(),
        phenomenonTime: new types_1.Period("tz").relation("Observations").column(),
        resultTime: new types_1.Period("tz").relation("Observations").column(),
        thing_id: new types_1.Relation("Things").column(),
        sensor_id: new types_1.Relation("Sensors").column(),
        _default_featureofinterest: new types_1.Relation("FeaturesOfInterest").default(1).column()
    },
    relations: {
        Thing: {
            type: enums_1.ERelations.belongsTo
        },
        Sensor: {
            type: enums_1.ERelations.belongsTo
        },
        Observations: {
            type: enums_1.ERelations.hasMany
        },
        ObservedProperties: {
            type: enums_1.ERelations.hasMany,
            entityRelation: "MultiDatastreamObservedProperties"
        },
        Lora: {
            type: enums_1.ERelations.hasOne
        },
        FeatureOfInterest: {
            type: enums_1.ERelations.defaultUnique
        }
    }
});
