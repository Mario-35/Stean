"use strict";
/**
 * entity Observation
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OBSERVATION = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.OBSERVATION = new entity_1.Entity("Observations", {
    createOrder: 12,
    type: enums_1.EentityType.table,
    order: 7,
    columns: {
        id: new types_1.Bigint().generated().column(),
        phenomenonTime: new types_1.Timestamp("tz").notNull().defaultOrder("asc").column(),
        result: new types_1.Any().column(),
        resultTime: new types_1.Timestamp("tz").notNull().column(),
        resultQuality: new types_1.Jsonb().column(),
        validTime: new types_1.Period("tz").column(),
        parameters: new types_1.Jsonb().column(),
        datastream_id: new types_1.Relation("Datastreams").column(),
        multidatastream_id: new types_1.Relation("MultiDatastreams").column(),
        featureofinterest_id: new types_1.Relation("FeaturesOfInterest").notNull().default(1).column()
    },
    relations: {
        Datastream: {
            type: enums_1.ERelations.belongsTo,
            unique: ["phenomenonTime", "resultTime", "datastream_id", "featureofinterest_id"]
        },
        MultiDatastream: {
            type: enums_1.ERelations.belongsTo,
            unique: ["phenomenonTime", "resultTime", "multidatastream_id", "featureofinterest_id"]
        },
        FeatureOfInterest: {
            type: enums_1.ERelations.belongsTo
        }
    }
});
