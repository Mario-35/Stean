"use strict";
/**
 * entity Log
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LOG = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.LOG = new entity_1.Entity("Logs", {
    createOrder: 99,
    type: enums_1.EentityType.blank,
    order: 0,
    columns: {
        id: new types_1.Bigint().generated().column(),
        date: new types_1.Timestamp("tz").notNull().defaultCurrent().defaultOrder("desc").column(),
        method: new types_1.Text().column(),
        url: new types_1.Text().column(),
        datas: new types_1.Jsonb().column(),
        error: new types_1.Jsonb().column()
    },
    relations: {}
});
