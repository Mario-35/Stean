"use strict";
/**
 * entity Decoder.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DECODER = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.DECODER = new entity_1.Entity("Decoders", {
    createOrder: 10,
    type: enums_1.EentityType.table,
    order: 12,
    columns: {
        id: new types_1.Bigint().generated().column(),
        name: new types_1.Text().notNull().column(),
        hash: new types_1.Text().column(),
        code: new types_1.Text().notNull().default("const decoded = null; return decoded;").column(),
        nomenclature: new types_1.Text().notNull().default("{}").column(),
        synonym: new types_1.Text().column()
    },
    relations: {
        Loras: {
            type: enums_1.ERelations.hasMany
        }
    }
});
