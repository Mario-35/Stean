"use strict";
/**
 * entity Location
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LOCATION = void 0;
const entity_1 = require("../entity");
const enums_1 = require("../../enums");
const types_1 = require("../types");
exports.LOCATION = new entity_1.Entity("Locations", {
    createOrder: 2,
    type: enums_1.EentityType.table,
    order: 6,
    columns: {
        id: new types_1.Bigint().generated().column(),
        name: new types_1.Text().notNull().column(),
        description: new types_1.Text().notNull().column(),
        encodingType: new types_1.Text().notNull().default("application/vnd.geo+json").column(),
        location: new types_1.Jsonb().notNull().column()
    },
    relations: {
        Things: {
            type: enums_1.ERelations.belongsToMany,
            entityRelation: "ThingsLocations"
        },
        HistoricalLocations: {
            type: enums_1.ERelations.belongsToMany
        }
    }
});
