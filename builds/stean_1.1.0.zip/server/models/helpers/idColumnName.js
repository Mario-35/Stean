"use strict";
/**
 * idColumnName
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.idColumnName = void 0;
/**
 *
 * @param entity Entity
 * @param search string or Entity
 * @returns String or undefined
 */
const idColumnName = (entity, search) => {
    if (typeof search === "string")
        return Object.keys(entity.columns).includes(search) ? search : undefined;
    else {
        return Object.keys(entity.columns).includes(`${search.singular}_id`) ? `${search.table}_id` : Object.keys(entity.columns).includes(`${search.singular.toLocaleLowerCase()}_id`) ? `${search.singular.toLocaleLowerCase()}_id` : Object.keys(entity.columns).includes(`_default_${search.singular.toLocaleLowerCase()}`) ? `_default_${search.singular.toLocaleLowerCase()}` : undefined;
    }
};
exports.idColumnName = idColumnName;
