"use strict";
/**
 * cardinality
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.relationInfos = void 0;
const _1 = require(".");
const __1 = require("..");
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const log_1 = require("../../log");
const messages_1 = require("../../messages");
const _KeyLink = (entity, column) => Object.keys(entity.columns).filter((e) => e !== column)[0];
const _Key = (entity, search) => {
    return Object.keys(entity.columns).includes(`${search.table}_id`)
        ? `${search.table}_id`
        : Object.keys(entity.columns).includes(`${search.singular.toLocaleLowerCase()}_id`)
            ? `${search.singular.toLocaleLowerCase()}_id`
            : Object.keys(entity.columns).includes(`_default_${search.singular.toLocaleLowerCase()}`)
                ? `_default_${search.singular.toLocaleLowerCase()}`
                : "id";
};
const extractEntityNames = (input, search) => {
    if (typeof search === "string")
        search = [search];
    return search.map((e) => input.replace(e, "")).filter((e) => e != input);
};
const relationInfos = (service, entityName, relationName, loop) => {
    console.log(log_1.logging.whereIam(new Error().stack).toDebugString());
    const leftEntity = __1.models.getEntity(service, entityName);
    const rightEntity = __1.models.getEntity(service, relationName);
    if (entityName !== relationName && leftEntity && rightEntity) {
        console.log(log_1.logging.head(`Entity ====> ${leftEntity.name} : ${rightEntity.name}`).toDebugString());
        const leftRelation = __1.models.getRelation(service, leftEntity, rightEntity);
        const rightRelationName = __1.models.getRelationName(rightEntity, [entityName, leftEntity.name, leftEntity.singular, entityName.replace(relationName, ""), relationName.replace(entityName, "")]);
        const rightRelation = rightRelationName ? rightEntity.relations[rightRelationName] : undefined;
        if (leftRelation && leftRelation.type) {
            let leftKey = _Key(leftEntity, rightEntity);
            let rightKey = _Key(rightEntity, leftEntity);
            const fnError = () => {
                return { type: "ERROR", rightKey: "", leftKey: "", entity: undefined, column: "cardinality ERROR", expand: "", link: "" };
            };
            const fnHasMany = () => {
                const complexEntity = __1.models.getEntity(service, `${leftEntity.name}${rightEntity.name}`) ||
                    __1.models.getEntity(service, `${rightEntity.name}${leftEntity.name}`) ||
                    __1.models.getEntity(service, `${leftEntity.singular}${rightEntity.singular}`) ||
                    __1.models.getEntity(service, `${rightEntity.singular}${leftEntity.singular}`);
                if (complexEntity && rightRelation) {
                    leftKey = _Key(complexEntity, leftEntity);
                    rightKey = _Key(complexEntity, rightEntity);
                    const temp = `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, "id")} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(complexEntity.table, rightKey)} FROM ${(0, helpers_1.formatPgTableColumn)(complexEntity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(complexEntity.table, leftKey)} =$ID)`;
                    return {
                        type: `${leftRelation.type}.${rightRelation.type}`,
                        leftKey: leftKey,
                        rightKey: rightKey,
                        entity: complexEntity,
                        column: (0, _1.idColumnName)(leftEntity, rightEntity) || "id",
                        link: temp,
                        expand: temp.replace("$ID", (0, helpers_1.formatPgTableColumn)(leftEntity.table, "id"))
                    };
                }
                return fnError();
            };
            console.log(log_1.logging.message("leftRelation ; rightRelation", `${leftRelation.type} : ${rightRelation ? rightRelation.type : "undefined"}`).toDebugString());
            switch (leftRelation.type) {
                // === : 1
                case enums_1.ERelations.defaultUnique:
                    console.log(log_1.logging.message("leftRelation Type", `====> defaultUnique : ${enums_1.ERelations.defaultUnique}`).toDebugString());
                    if (rightRelation && rightRelation.type) {
                        switch (rightRelation.type) {
                            // ===> 1.4
                            case enums_1.ERelations.hasMany:
                                return {
                                    type: `${leftRelation.type}.${rightRelation.type}`,
                                    leftKey: leftKey,
                                    rightKey: rightKey,
                                    entity: leftEntity,
                                    column: (0, _1.idColumnName)(leftEntity, rightEntity) || "id",
                                    link: `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} FROM ${(0, helpers_1.formatPgTableColumn)(rightEntity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} =(SELECT ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)} FROM ${(0, helpers_1.formatPgTableColumn)(leftEntity.table)} WHERE id = $ID))`,
                                    expand: `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} FROM ${(0, helpers_1.formatPgTableColumn)(rightEntity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} =${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)})`
                                };
                        }
                    }
                    (0, messages_1.errorMessage)("defaultUnique");
                    break;
                // === : 2
                case enums_1.ERelations.belongsTo:
                    if (rightRelation && rightRelation.type) {
                        switch (rightRelation.type) {
                            // ===> 2.2
                            case enums_1.ERelations.belongsTo:
                                return {
                                    type: `${leftRelation.type}.${rightRelation.type}`,
                                    leftKey: leftKey,
                                    rightKey: rightKey,
                                    entity: leftEntity,
                                    column: (0, _1.idColumnName)(leftEntity, rightEntity) || "id",
                                    link: `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} = (SELECT ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)} FROM ${(0, helpers_1.formatPgTableColumn)(leftEntity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, "id")} =$ID)`,
                                    expand: `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} = ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)}`
                                };
                            // ===> 2.3
                            case enums_1.ERelations.belongsToMany:
                                if (leftRelation.entityRelation) {
                                    const tempEntity = __1.models.getEntity(service, leftRelation.entityRelation);
                                    if (leftRelation && tempEntity && tempEntity.type === enums_1.EentityType.link && !loop) {
                                        leftKey = _Key(tempEntity, rightEntity);
                                        rightKey = _KeyLink(tempEntity, leftKey);
                                        const temp = `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, "id")} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(tempEntity.table, leftKey)} FROM ${(0, helpers_1.formatPgTableColumn)(tempEntity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(tempEntity.table, rightKey)} =$ID)`;
                                        return {
                                            type: `${leftRelation.type}.${rightRelation.type}.1`,
                                            leftKey: leftKey,
                                            rightKey: rightKey,
                                            entity: tempEntity,
                                            column: (0, _1.idColumnName)(leftEntity, rightEntity) || "id",
                                            link: temp,
                                            expand: temp.replace("$ID", (0, helpers_1.formatPgTableColumn)(leftEntity.table, "id"))
                                        };
                                    }
                                }
                                else if (rightRelationName && !loop && leftEntity.type !== enums_1.EentityType.link) {
                                    const entityName = (0, exports.relationInfos)(service, rightRelationName, rightEntity.name, true);
                                    const complexEntity = __1.models.getEntity(service, `${rightRelationName}${rightEntity.name}`) || __1.models.getEntity(service, `${rightEntity.name}${rightRelationName}`);
                                    if (complexEntity && entityName.external) {
                                        leftKey = entityName.external.leftKey;
                                        rightKey = entityName.external.rightKey;
                                        return {
                                            type: `${leftRelation.type}.${rightRelation.type}`,
                                            leftKey: leftKey,
                                            rightKey: rightKey,
                                            entity: leftEntity,
                                            column: (0, _1.idColumnName)(leftEntity, rightEntity) || "id",
                                            expand: `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, "id")} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(rightEntity.table, "id")} FROM ${(0, helpers_1.formatPgTableColumn)(rightEntity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(rightEntity.table, "id")} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(complexEntity.table, rightKey)} FROM ${complexEntity.table} WHERE ${(0, helpers_1.formatPgTableColumn)(complexEntity.table, leftKey)} = ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)}))`,
                                            link: `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, "id")} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(rightEntity.table, "id")} FROM ${(0, helpers_1.formatPgTableColumn)(rightEntity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(rightEntity.table, "id")} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(complexEntity.table, rightKey)} FROM ${complexEntity.table} WHERE ${(0, helpers_1.formatPgTableColumn)(complexEntity.table, leftKey)} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)} FROM ${leftEntity.table} WHERE ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, "id")} =$ID)))`
                                        };
                                    }
                                }
                            // ===> 2.4
                            case enums_1.ERelations.hasMany:
                                return {
                                    type: `${leftRelation.type}.${rightRelation.type}`,
                                    leftKey: leftKey,
                                    rightKey: rightKey,
                                    entity: leftEntity,
                                    column: (0, _1.idColumnName)(leftEntity, rightEntity) || "id",
                                    link: `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} = (SELECT ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)} FROM ${(0, helpers_1.formatPgTableColumn)(leftEntity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, rightKey)} =$ID)`,
                                    expand: `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} = ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)}`
                                };
                        }
                    }
                    (0, messages_1.errorMessage)("belongsTo");
                    break;
                // === : 3
                case enums_1.ERelations.belongsToMany:
                    if (rightRelation && rightRelation.type) {
                        switch (rightRelation.type) {
                            // ===> 3.2
                            case enums_1.ERelations.belongsTo:
                                const complexEntity2 = __1.models.getEntity(service, `${leftEntity.name}${rightEntity.name}`) ||
                                    __1.models.getEntity(service, `${rightEntity.name}${leftEntity.name}`) ||
                                    __1.models.getEntity(service, `${leftEntity.singular}${rightEntity.singular}`) ||
                                    __1.models.getEntity(service, `${rightEntity.singular}${leftEntity.singular}`);
                                // ===> 3.2.1
                                if (rightRelation.entityRelation) {
                                    const tmp = extractEntityNames(rightRelation.entityRelation, [leftEntity.name, rightEntity.name]);
                                    const tempEntity = __1.models.getEntity(service, tmp[0]);
                                    if (tempEntity && !loop) {
                                        const tempCardinality = (0, exports.relationInfos)(service, leftEntity.name, tempEntity.name, true);
                                        if (complexEntity2 && tempCardinality.entity && complexEntity2.type !== enums_1.EentityType.link) {
                                            leftKey = _Key(complexEntity2, rightEntity);
                                            rightKey = _Key(complexEntity2, leftEntity);
                                            const temp = `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, "id")} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(rightEntity.table, "id")} FROM ${(0, helpers_1.formatPgTableColumn)(rightEntity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(rightEntity.table, tempCardinality.rightKey)} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(tempCardinality.entity.table, tempCardinality.rightKey)} FROM ${(0, helpers_1.formatPgTableColumn)(tempCardinality.entity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(tempCardinality.entity.table, tempCardinality.leftKey)} =$ID))`;
                                            return {
                                                type: `${leftRelation.type}.${rightRelation.type}.1`,
                                                leftKey: leftKey,
                                                rightKey: rightKey,
                                                external: {
                                                    leftKey: tempCardinality.leftKey,
                                                    rightKey: tempCardinality.rightKey,
                                                    table: tempCardinality.entity.table
                                                },
                                                entity: complexEntity2,
                                                column: (0, _1.idColumnName)(leftEntity, rightEntity) || "id",
                                                link: temp,
                                                expand: temp.replace("$ID", (0, helpers_1.formatPgTableColumn)(leftEntity.table, "id"))
                                            };
                                        }
                                    }
                                }
                                // ===> 3.2.2
                                else if (complexEntity2) {
                                    leftKey = _Key(complexEntity2, rightEntity);
                                    rightKey = _Key(complexEntity2, leftEntity);
                                    const temp = `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(complexEntity2.table, (0, _1.idColumnName)(complexEntity2, rightEntity) || "id")} FROM ${(0, helpers_1.formatPgTableColumn)(complexEntity2.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(complexEntity2.table, (0, _1.idColumnName)(complexEntity2, leftEntity) || "id")} =$ID)`;
                                    return {
                                        type: `${leftRelation.type}.${rightRelation.type}.2`,
                                        leftKey: leftKey,
                                        rightKey: rightKey,
                                        entity: complexEntity2,
                                        column: (0, _1.idColumnName)(leftEntity, rightEntity) || "id",
                                        link: temp,
                                        expand: temp.replace("$ID", (0, helpers_1.formatPgTableColumn)(complexEntity2.table, rightKey))
                                    };
                                }
                            // ===> 3.3
                            case enums_1.ERelations.belongsToMany:
                                return fnHasMany();
                        }
                    }
                    (0, messages_1.errorMessage)("belongsToMany");
                    break;
                // === : 4
                case enums_1.ERelations.hasMany:
                    if (rightRelation && rightRelation.type) {
                        switch (rightRelation.type) {
                            // ===> 4.1
                            case enums_1.ERelations.defaultUnique:
                                const temp1 = `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, leftKey)} IN (SELECT ${(0, helpers_1.formatPgTableColumn)(rightEntity.table, leftKey)} FROM ${(0, helpers_1.formatPgTableColumn)(rightEntity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} =$ID)`;
                                return {
                                    type: `${leftRelation.type}.${rightRelation.type}`,
                                    leftKey: leftKey,
                                    rightKey: rightKey,
                                    entity: leftEntity,
                                    column: (0, _1.idColumnName)(leftEntity, rightEntity) || "id",
                                    link: temp1,
                                    expand: temp1.replace("$ID", (0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey))
                                };
                            // ===> 4.2
                            case enums_1.ERelations.belongsTo:
                                // const temp2 = `${formatPgTableColumn(rightEntity.table, "id")} IN (SELECT ${formatPgTableColumn(rightEntity.table, "id")} FROM ${formatPgTableColumn(rightEntity.table)} WHERE ${formatPgTableColumn(rightEntity.table, rightKey)} =$ID)`;
                                const temp2 = `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} =$ID`;
                                return {
                                    type: `${leftRelation.type}.${rightRelation.type}`,
                                    rightKey: rightKey,
                                    leftKey: leftKey,
                                    entity: rightEntity,
                                    column: (0, _1.idColumnName)(leftEntity, rightEntity) || "id",
                                    link: temp2,
                                    expand: temp2.replace("$ID", (0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey))
                                };
                            // ===> 4.4
                            case enums_1.ERelations.hasMany:
                                return fnHasMany();
                        }
                    }
                    (0, messages_1.errorMessage)("hasMany");
                    break;
                // === : 5
                case enums_1.ERelations.hasOne:
                    if (rightRelation && rightRelation.type) {
                        switch (rightRelation.type) {
                            // ===> 5.2
                            case enums_1.ERelations.belongsTo:
                                return {
                                    type: `${leftRelation.type}.${rightRelation.type}`,
                                    leftKey: leftKey,
                                    rightKey: rightKey,
                                    entity: leftEntity,
                                    column: (0, _1.idColumnName)(leftEntity, rightEntity) || "id",
                                    link: `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} = (SELECT ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)} FROM ${(0, helpers_1.formatPgTableColumn)(leftEntity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)} =$ID)`,
                                    expand: `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} = ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)}`
                                };
                            // ===> 5.5
                            case enums_1.ERelations.hasOne:
                                return {
                                    type: `${leftRelation.type}.${rightRelation.type}`,
                                    leftKey: leftKey,
                                    rightKey: rightKey,
                                    entity: leftEntity,
                                    column: (0, _1.idColumnName)(leftEntity, rightEntity) || "id",
                                    link: `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} = (SELECT ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)} FROM ${(0, helpers_1.formatPgTableColumn)(leftEntity.table)} WHERE ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, rightKey)} =$ID)`,
                                    expand: `${(0, helpers_1.formatPgTableColumn)(rightEntity.table, rightKey)} = ${(0, helpers_1.formatPgTableColumn)(leftEntity.table, leftKey)}`
                                };
                        }
                    }
                    (0, messages_1.errorMessage)("hasOne");
                    break;
            }
        }
        (0, messages_1.errorMessage)(`relationInfos [${leftEntity.name} ${leftRelation?.type}] : [${rightEntity.name} ${rightRelation?.type}]`);
    }
    return { type: "ERROR", rightKey: "", leftKey: "", entity: undefined, column: "cardinality ERROR", expand: "", link: "" };
};
exports.relationInfos = relationInfos;
