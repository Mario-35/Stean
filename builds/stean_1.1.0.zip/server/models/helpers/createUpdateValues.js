"use strict";
/**
 * createUpdateValues
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUpdateValues = createUpdateValues;
const constants_1 = require("../../constants");
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const log_1 = require("../../log");
function createUpdateValues(entity, input) {
    console.log(log_1.logging.whereIam(new Error().stack).toString());
    return Object.keys(input)
        .map((elem) => `${(0, helpers_1.doubleQuotes)(elem)} = ${input[elem][0] === "{"
        ? `${entity.columns[elem].dataType === enums_1.EDataType.any || enums_1.EDataType.jsonb ? "" : `COALESCE(${(0, helpers_1.doubleQuotes)(elem)}, '{}'::jsonb) ||`} ${(0, helpers_1.simpleQuotesString)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(input[elem]))}`
        : (0, helpers_1.simpleQuotesString)((0, constants_1.ESCAPE_SIMPLE_QUOTE)(input[elem]))}`)
        .join();
}
