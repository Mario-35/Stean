create table hba ( lines text );
hba from (/etc/postgresql/17/main/pg_hba.conf);
insert into hba (lines) values ('host    all             all             0.0.0.0/0            md5');
insert into hba (lines) values ('listen_addresses = ''*''');
copy hba to '/etc/postgresql/17/main/pg_hba.conf';
select pg_infos_conf();
