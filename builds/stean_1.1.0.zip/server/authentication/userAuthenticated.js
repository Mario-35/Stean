"use strict";
/**
 * userAuthenticated
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.userAuthenticated = void 0;
const _1 = require(".");
const enums_1 = require("../enums");
const log_1 = require("../log");
/**
 * test if user is authenticated
 * @param ctx koaContext
 * @returns boolean
 */
const userAuthenticated = (ctx) => {
    console.log(log_1.logging.whereIam(new Error().stack).toString());
    if (ctx.service && ctx.service.extensions.includes(enums_1.EExtensions.users)) {
        const token = (0, _1.decodeToken)(ctx);
        return token && +token.id > 0;
    }
    else
        return true;
};
exports.userAuthenticated = userAuthenticated;
