"use strict";
/**
 * blankUser
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.blankUser = blankUser;
const enums_1 = require("../../enums");
function blankUser(service) {
    return {
        id: 0,
        username: "query",
        password: "",
        email: "",
        database: service.pg.database,
        canPost: !service.extensions.includes(enums_1.EExtensions.users),
        canDelete: !service.extensions.includes(enums_1.EExtensions.users),
        canCreateUser: !service.extensions.includes(enums_1.EExtensions.users),
        canCreateDb: !service.extensions.includes(enums_1.EExtensions.users),
        admin: false,
        superAdmin: false
    };
}
