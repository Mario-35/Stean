var __importDefault=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(exports,"__esModule",{value:!0}),exports.Admin=void 0;let configuration_1=require("../../configuration"),enums_1=require("../../enums"),helpers_1=require("../../helpers"),log_1=require("../../log"),models_1=require("../../models"),paths_1=require("../../paths"),css_1=require("../css"),js_1=require("../js"),core_1=require("./core"),fs_1=__importDefault(require("fs")),path_1=__importDefault(require("path"));class Admin extends core_1.CoreHtmlView{constructor(e,s){super(e,s),this.init()}init(){!0===this.adminConnection?this.adminHtml():this.adminLogin("admin")}adminHtml(){let s=configuration_1.config.getInfosForAll(this.ctx);var e=this.ctx.header.referer?.split("/"),e=(e&&(e[e.length-1]="service"),{addUrl:e?.join("/"),services:s,versions:models_1.models.listVersion().reverse().map(e=>e.replace("_",".")),extensions:(0,enums_1.enumKeys)(enums_1.EExtensions).filter(e=>!["file","base"].includes(e)),options:(0,enums_1.enumKeys)(enums_1.EOptions),logsFiles:paths_1.paths.logFile.list()});let i=e=>e.replace(".min",""),t=(this._HTMLResult=fs_1.default.readFileSync(path_1.default.resolve(__dirname,"../html/","admin.html")).toString().replace(/<link /g,enums_1.EConstant.return+"<link ").replace(/<script /g,enums_1.EConstant.return+"<script ").replace(/<\/script>/g,"<\/script>"+enums_1.EConstant.return).replace(/\r\n/g,enums_1.EConstant.return).split(enums_1.EConstant.return).map(e=>e.trim()).filter(e=>""!=e.trim()),(e,s)=>{var i=this._HTMLResult.indexOf(e);(0<i||0<(i=this._HTMLResult.indexOf((0,helpers_1.removeAllQuotes)(e))))&&(this._HTMLResult[i]=s)});(0,css_1.listaddCssFiles)().forEach(e=>{t(`<link rel="stylesheet" href="${i(e)}">`,`<style>${(0,css_1.addCssFile)(e)}</style>`)}),(0,js_1.listaddJsFiles)().forEach(e=>{t(`<script src="${i(e)}"></script>`,`<script>${(0,js_1.addJsFile)(e)}</script>`)});var n=Object.keys(s).filter(e=>e!==enums_1.EConstant.test).map(e=>`<div class="card">
                <div class="title" onclick="selectCard('${e}')">${e}</div>
                <button class="copy-btn" id="copy${e}" onclick="copyService('${e}')"> COPY </button>
                <div class="product">
                    <span class="service-name">${s[e].version}&nbsp;:&nbsp;</span>
                    <span id="root" class="service-root" onclick="location.href = '${s[e].root}';">${s[e].root}</span>
                </div>
                <div class="description">
                    <div id="editList${e}"class="editList">
                        <textarea></textarea>
                    </div>
                    <fieldset id="options${e}">
                        <legend>Options</legend>
                        <ul class="card-list">
                            <li class="card-list-item canPoint icon-${s[e].service.options.includes(enums_1.EOptions.canDrop)?"yes":"no"}" onclick="selectChange('${e}', this)">canDrop</li>
                            <li class="card-list-item canPoint icon-${s[e].service.options.includes(enums_1.EOptions.forceHttps)?"yes":"no"}" onclick="selectChange('${e}', this)">forceHttps</li>
                            <li class="card-list-item canPoint icon-${s[e].service.options.includes(enums_1.EOptions.stripNull)?"yes":"no"}" onclick="selectChange('${e}', this)">stripNull</li>
                            <li class="card-list-item canPoint icon-${s[e].service.options.includes(enums_1.EOptions.speedCount)?"yes":"no"}" onclick="selectChange('${e}', this)">speedCount</li>
                            <li class="card-list-item canPoint icon-${s[e].service.options.includes(enums_1.EOptions.unique)?"yes":"no"}" onclick="selectChange('${e}', this)">unique</li>
                        </ul>
                    </fieldset>
    
                    <select id="infos${e}" size="5">
                        ${s[e].service.extensions.map(e=>`<option value="${e}">${e}</option>`).join(enums_1.EConstant.return)}
                    </select>
    
                </div>
                <div class="description">
                    <span class="page canPoint" onclick="editPage('${e}', this)">${s[e].service.nb_page}</span>
                    <span class="csv canPoint" onclick="editCsv('${e}', this)">${s[e].service.csvDelimiter}</span>
                    <select class="patrom-select tabindex="1" onchange="selectChange('${e}', this)">
                        <option selected="selected">Services</option>
                        <option>Statistiques</option>
                        ${s[e].service.extensions.includes("users")?"<option>Users</option>":""} 
                        ${s[e].service.extensions.includes("lora")?"<option>Loras</option>":""} 
                        ${s[e].service.extensions.includes("lora")?"<option>Synonyms</option>":""} 
                    </select>
                </div>
                </div>`);this.replacers({cards:n.join("")}),this.replacer("_PARAMS={}","_PARAMS="+JSON.stringify(e,this.bigIntReplacer))}}exports.Admin=Admin;