"use strict";
/**
 * HTML Documentation for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Documentation = void 0;
const configuration_1 = require("../../configuration");
const enums_1 = require("../../enums");
const helpers_1 = require("../../helpers");
const log_1 = require("../../log");
const models_1 = require("../../models");
const paths_1 = require("../../paths");
const css_1 = require("../css");
const js_1 = require("../js");
const core_1 = require("./core");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
/**
 * Admin Class for HTML View
 */
class Documentation extends core_1.CoreHtmlView {
    constructor(ctx, datas) {
        console.log(log_1.logging.whereIam(new Error().stack, "View").toString());
        super(ctx, datas);
        this.documentationHtml();
    }
    /**
     * create admin htmlPage for all services.
     */
    documentationHtml() {
        // get all infos for all services
        const services = configuration_1.config.getInfosForAll(this.ctx);
        const dest = this.ctx.header.referer?.split("/");
        if (dest)
            dest[dest.length - 1] = "service";
        // create params object
        const params = {
            addUrl: dest?.join("/"),
            services: services,
            versions: models_1.models
                .listVersion()
                .reverse()
                .map((e) => e.replace("_", ".")),
            extensions: (0, enums_1.enumKeys)(enums_1.EExtensions).filter((e) => !["file", "base"].includes(e)),
            options: (0, enums_1.enumKeys)(enums_1.EOptions),
            logsFiles: paths_1.paths.logFile.list()
        };
        // if js or css .min
        const fileWithOutMin = (input) => input.replace(".min", "");
        // Split files for better search and replace
        this._HTMLResult = fs_1.default
            .readFileSync(path_1.default.resolve(__dirname, "../html/", "documentation.html"))
            .toString()
            .replace(/<link /g, `${enums_1.EConstant.return}<link `)
            .replace(/<script /g, `${enums_1.EConstant.return}<script `)
            .replace(/<\/script>/g, `</script>${enums_1.EConstant.return}`)
            .replace(/\r\n/g, enums_1.EConstant.return)
            .split(enums_1.EConstant.return)
            .map((e) => e.trim())
            .filter((e) => e.trim() != "");
        // replace in result
        const replaceInReturnResult = (searhText, content) => {
            let index = this._HTMLResult.indexOf(searhText);
            if (index > 0)
                this._HTMLResult[index] = content;
            else {
                index = this._HTMLResult.indexOf((0, helpers_1.removeAllQuotes)(searhText));
                if (index > 0)
                    this._HTMLResult[index] = content;
            }
        };
        // process all css files
        (0, css_1.listaddCssFiles)().forEach((item) => {
            replaceInReturnResult(`<link rel="stylesheet" href="${fileWithOutMin(item)}">`, `<style>${(0, css_1.addCssFile)(item)}</style>`);
        });
        // process all js files
        (0, js_1.listaddJsFiles)().forEach((item) => {
            replaceInReturnResult(`<script src="${fileWithOutMin(item)}"></script>`, `<script>${(0, js_1.addJsFile)(item)}</script>`);
        });
        this.replacer("_PARAMS={}", "_PARAMS=" + JSON.stringify(params, this.bigIntReplacer));
    }
}
exports.Documentation = Documentation;
