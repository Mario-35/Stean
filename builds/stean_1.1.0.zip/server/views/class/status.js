"use strict";
/**
 * HTML Views Status for API
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Status = void 0;
const configuration_1 = require("../../configuration");
const enums_1 = require("../../enums");
const log_1 = require("../../log");
const core_1 = require("./core");
/**
 * Status Class for HTML View
 */
class Status extends core_1.CoreHtmlView {
    constructor(ctx, datas) {
        console.log(log_1.logging.whereIam(new Error().stack, "View").toString());
        super(ctx, datas);
        if (datas.user)
            this.status(ctx, datas.user);
    }
    status(ctx, user) {
        const service = configuration_1.config.getConfigNameFromDatabase(user.database);
        const url = `${this.ctx.decodedUrl.linkbase}/${ctx.service.apiVersion}`;
        const sec = ctx.service.extensions.includes(enums_1.EExtensions.users);
        this._HTMLResult = [
            `<!DOCTYPE html>
        <html> 
            ${this.head("Status")}
            <body>
                <div class="login-wrap">
                    <div class="login-html">
                        ${this.title("Status")}
                        <h3>Username : ${user.username}</h3> 
                        <h3>Hosting : ${user.database == "all" ? "all" : service ? configuration_1.config.getService(service).pg.host : "Not Found"}</h3>
                        <h3>Database : ${user.database}</h3>
                        <h3>Status : ${user.id && user.id > 0 ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : !sec ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : "\u274C" /* EChar.notOk */}</h3> 
                        <h3>Post : ${user.canPost === true ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : !sec ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : "\u274C" /* EChar.notOk */}</h3>
                        <h3>Delete : ${user.canDelete === true ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : !sec ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : "\u274C" /* EChar.notOk */}</h3>
                        <h3>Create User: ${user.canCreateUser === true ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : !sec ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : "\u274C" /* EChar.notOk */}</h3>
                        <h3>Create Service : ${user.canCreateDb === true ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : !sec ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : "\u274C" /* EChar.notOk */}</h3>
                        <h3>Admin : ${user.admin === true ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : !sec ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : "\u274C" /* EChar.notOk */}</h3>
                        <h3>Super admin : ${user.superAdmin === true ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : !sec ? "\u2714\uFE0F\uFE0F" /* EChar.ok */ : "\u274C" /* EChar.notOk */}</h3>
                        ${this.foot([
                { href: `${url}/Logout`, class: "button-logout", name: "Logout" },
                { href: `${url}/Query`, class: "button-query", name: "Query" }
            ])}
                    </div>
                </div>
            </body>
        </html>`
        ];
    }
}
exports.Status = Status;
