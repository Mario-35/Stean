"use strict";
/**
 * HTML Views Logs for API
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HtmlLogs = void 0;
const core_1 = require("./core");
const fs_1 = __importDefault(require("fs"));
/**
 * Logs Class for HTML View
 */
class HtmlLogs extends core_1.CoreHtmlView {
    // use data to name ifle
    constructor(ctx, datas) {
        const fileContent = fs_1.default.readFileSync(datas.url, "utf8");
        super(ctx, datas);
        this.logs(fileContent);
    }
    logs(message) {
        this._HTMLResult = [
            `<!DOCTYPE html>
            <html>
                <body style="background-color:#353535;">
                    ${message}
                </body>
            </html>`
        ];
    }
}
exports.HtmlLogs = HtmlLogs;
