"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatConfig = formatConfig;
const enums_1 = require("../../enums");
/**
 *
 * @param input Key values record
 * @param admin is admin configuration
 * @returns Key values formated formated config
 */
function formatConfig(input, admin) {
    const name = admin ? enums_1.EConstant.admin : input.name.toLowerCase();
    return {
        "name": name,
        "ports": admin
            ? {
                "http": 8029,
                "tcp": 9000,
                "ws": 1883
            }
            : 8029,
        "pg": {
            "host": input["host"],
            "port": input["port"],
            "user": admin ? input["adminname"] : name,
            "password": admin ? input["adminpassword"] : input["password"],
            "database": admin ? "postgres" : input["database"].toLowerCase(),
            "retry": 2
        },
        "apiVersion": input["version"],
        "date_format": "DD/MM/YYYY hh:mi:ss",
        "webSite": "no web site",
        "nb_page": 200,
        "alias": [""],
        "extensions": admin ? ["base"] : `base,${input["extensions"] ? String(input["extensions"]) : ""}`.split(","),
        "options": admin ? [] : input["options"] ? String(input["options"]).split(",") : []
    };
}
