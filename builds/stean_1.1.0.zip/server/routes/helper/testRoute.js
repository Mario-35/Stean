"use strict";
/**
 * Test Helpers.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.testRoute = void 0;
const testRoute = async (ctx) => {
    try {
        return { "Test": "No Test" };
    }
    catch (error) {
        console.log(error);
        return { error: error };
    }
};
exports.testRoute = testRoute;
