"use strict";
/**
 * logsRoute connection page.
 *
 * @copyright 2020-present Inrae
 * @review 31-01-2024
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.logsRoute = void 0;
const helpers_1 = require("../../helpers");
const logs_1 = require("../../views/class/logs");
/**
 * Generate logs root page
 *
 * @param ctx koa context
 */
const logsRoute = async (ctx, file) => {
    const bodyLogs = new logs_1.HtmlLogs(ctx, { url: file });
    ctx.type = helpers_1.returnFormats.html.type;
    ctx.body = bodyLogs.toString();
};
exports.logsRoute = logsRoute;
