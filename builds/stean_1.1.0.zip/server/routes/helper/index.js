"use strict";
/**
 * Routes Helpers.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.docRoute = exports.logsRoute = exports.exportRoute = exports.adminRoute = exports.formatConfig = exports.postgresAdmin = exports.testRoute = exports.decodeUrl = exports.checkPassword = exports.emailIsValid = void 0;
const emailIsValid = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
exports.emailIsValid = emailIsValid;
// at least one number, one lowercase and one uppercase letter
// at least six characters that are letters, numbers or the underscore
const checkPassword = (str) => /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])\w{6,}$/.test(str);
exports.checkPassword = checkPassword;
var decodeUrl_1 = require("./decodeUrl");
Object.defineProperty(exports, "decodeUrl", { enumerable: true, get: function () { return decodeUrl_1.decodeUrl; } });
var testRoute_1 = require("./testRoute");
Object.defineProperty(exports, "testRoute", { enumerable: true, get: function () { return testRoute_1.testRoute; } });
var postgresAdmin_1 = require("./postgresAdmin");
Object.defineProperty(exports, "postgresAdmin", { enumerable: true, get: function () { return postgresAdmin_1.postgresAdmin; } });
var formatConfig_1 = require("./formatConfig");
Object.defineProperty(exports, "formatConfig", { enumerable: true, get: function () { return formatConfig_1.formatConfig; } });
var adminRoute_1 = require("./adminRoute");
Object.defineProperty(exports, "adminRoute", { enumerable: true, get: function () { return adminRoute_1.adminRoute; } });
var exportRoute_1 = require("./exportRoute");
Object.defineProperty(exports, "exportRoute", { enumerable: true, get: function () { return exportRoute_1.exportRoute; } });
var logsRoute_1 = require("./logsRoute");
Object.defineProperty(exports, "logsRoute", { enumerable: true, get: function () { return logsRoute_1.logsRoute; } });
var docRoute_1 = require("./docRoute");
Object.defineProperty(exports, "docRoute", { enumerable: true, get: function () { return docRoute_1.docRoute; } });
