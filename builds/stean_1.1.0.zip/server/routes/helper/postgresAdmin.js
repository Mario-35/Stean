"use strict";
/**
 * postgresAdmin connection page.
 *
 * @copyright 2020-present Inrae
 * @review 31-01-2024
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.postgresAdmin = postgresAdmin;
const postgres_1 = __importDefault(require("postgres"));
const _1 = require(".");
const configuration_1 = require("../../configuration");
const helpers_1 = require("../../helpers");
async function postgresAdmin(ctx) {
    // valid connection ?
    if (ctx.request.body && ctx.request.body["_connection"]) {
        // Adding service
        if (ctx.request.body && ctx.request.body["_action"] && ctx.request.body["_action"] === "addService") {
            const src = JSON.parse(JSON.stringify(ctx.request.body["jsonDatas"], null, 2));
            await configuration_1.config.addConfig(JSON.parse(src));
        }
        else
            return ctx.request.body["_connection"];
    }
    // connection not found so ...
    const src = JSON.parse(JSON.stringify(ctx.request.body, null, 2));
    function missingItems(src, search) {
        const mess = {};
        search.forEach((e) => {
            if (!src.hasOwnProperty(e))
                mess[e] = `${e} not define`;
        });
        return Object.keys(mess).length > 0 ? mess : undefined;
    }
    if (!missingItems(src, ["optName", "optVersion", "optPassword", "optRepeat", "jsonDatas"])) {
        if (await configuration_1.config.addConfig(JSON.parse(src["jsonDatas"])))
            ctx.redirect(`${ctx.request.origin}/admin`);
    }
    if (missingItems(src, ["host", "adminname", "port", "adminpassword"]))
        return;
    return await (0, postgres_1.default)(`postgres://${src["adminname"]}:${src["adminpassword"]}@${src["host"]}:${src["port"]}/postgres`, {}) `select 1+1 AS result`
        .then(async () => {
        if (configuration_1.config.configFileExist() === false)
            if (await configuration_1.config.initConfig(JSON.stringify({ "admin": (0, _1.formatConfig)(src, true) }, null, 2)))
                await (0, _1.adminRoute)(ctx);
        return (0, helpers_1.encrypt)(JSON.stringify({ login: true, "host": src["host"], "adminname": src["adminname"], "port": src["port"], "adminpassword": src["adminpassword"] }));
    })
        .catch((error) => {
        return `[error]${error.message}`;
    });
}
