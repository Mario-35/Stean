"use strict";
/**
 * Protected Routes for API
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.protectedRoutes = void 0;
const koa_router_1 = __importDefault(require("koa-router"));
const dataAccess_1 = require("../db/dataAccess");
const helpers_1 = require("../helpers");
const fs_1 = __importDefault(require("fs"));
const odata_1 = require("../odata");
const messages_1 = require("../messages");
const enums_1 = require("../enums");
const authentication_1 = require("../authentication");
const configuration_1 = require("../configuration");
const helper_1 = require("./helper");
const views_1 = require("../views");
const helpers_2 = require("../views/helpers");
const log_1 = require("../log");
const entities_1 = require("../models/entities");
exports.protectedRoutes = new koa_router_1.default();
exports.protectedRoutes.post("/(.*)", async (ctx, next) => {
    switch (ctx.decodedUrl.path.toUpperCase()) {
        // login html page or connection login
        case "LOGIN":
            if (ctx.request["token"])
                ctx.redirect(`${ctx.decodedUrl.root}/status`);
            await (0, authentication_1.loginUser)(ctx).then((user) => {
                if (user) {
                    ctx.status = 200 /* EHttpCode.ok */;
                    if (ctx.request.header.accept && ctx.request.header.accept.includes("text/html"))
                        ctx.redirect(`${ctx.decodedUrl.root}/Status`);
                    else
                        ctx.body = {
                            message: messages_1.info.loginOk,
                            user: user.username,
                            token: user.token
                        };
                }
                else {
                    ctx.throw(401 /* EHttpCode.Unauthorized */);
                }
            });
            return;
        case "REGISTER":
            const why = {};
            // Username
            if (ctx.body["username"].trim() === "") {
                why["username"] = (0, messages_1.msg)(messages_1.errors.empty, "username");
            }
            else {
                const user = await configuration_1.config.executeSqlValues(configuration_1.config.getService(enums_1.EConstant.admin), `SELECT "username" FROM "${entities_1.USER.table}" WHERE username = '${ctx.body["username"]}' LIMIT 1`);
                if (user)
                    why["username"] = messages_1.errors.alreadyPresent;
            }
            // Email
            if (ctx.body["email"].trim() === "") {
                why["email"] = (0, messages_1.msg)(messages_1.errors.empty, "email");
            }
            else {
                if ((0, helper_1.emailIsValid)(ctx.body["email"]) === false)
                    why["email"] = (0, messages_1.msg)(messages_1.errors.invalid, "email");
            }
            // Password
            if (ctx.body["password"].trim() === "") {
                why["password"] = (0, messages_1.msg)(messages_1.errors.empty, "password");
            }
            // Repeat password
            if (ctx.body["repeat"].trim() === "") {
                why["repeat"] = (0, messages_1.msg)(messages_1.errors.empty, "repeat password");
            }
            else {
                if (ctx.body["password"] != ctx.body.repeat) {
                    why["repeat"] = messages_1.errors.passowrdDifferent;
                }
                else {
                    if ((0, helper_1.checkPassword)(ctx.body["password"]) === false)
                        why["password"] = (0, messages_1.msg)(messages_1.errors.invalid, "password");
                }
            }
            if (Object.keys(why).length === 0) {
                try {
                    await dataAccess_1.userAccess.post(ctx.service.name, ctx.body);
                }
                catch (error) {
                    ctx.redirect(`${ctx.decodedUrl.root}/error`);
                }
            }
            else {
                const createHtml = new views_1.Login(ctx, {
                    url: "",
                    login: false,
                    body: ctx.request.body,
                    why: why
                });
                ctx.type = helpers_1.returnFormats.html.type;
                ctx.body = createHtml.toString();
            }
            return;
    }
    // Add new lora observation this is a special route without ahtorisatiaon to post (deveui and correct payload limit risks)
    console.log(ctx.request.headers["authorization"]);
    if ((ctx.user && ctx.user.id > 0) ||
        !ctx.service.extensions.includes(enums_1.EExtensions.users) ||
        ctx.request.url.includes("/Lora") ||
        (ctx.request.headers["authorization"] && ctx.request.headers["authorization"] === configuration_1.config.getBrokerId())) {
        if (ctx.request.type.startsWith("application/json") && Object.keys(ctx.body).length > 0) {
            const odataVisitor = await (0, odata_1.createOdata)(ctx);
            if (odataVisitor)
                ctx.odata = odataVisitor;
            if (ctx.odata) {
                const objectAccess = new dataAccess_1.apiAccess(ctx);
                const returnValue = await objectAccess.post();
                if (returnValue) {
                    helpers_1.returnFormats.json.type;
                    if (returnValue.location)
                        ctx.set("Location", returnValue.location);
                    ctx.status = 201 /* EHttpCode.created */;
                    ctx.body = returnValue.body;
                }
            }
            else
                ctx.throw(400 /* EHttpCode.badRequest */);
        }
        else if (ctx.request.type.startsWith("multipart/")) {
            // If upload datas
            const getDatas = async () => {
                console.log(log_1.logging.head("getDatas ...").toString());
                return new Promise(async (resolve, reject) => {
                    await (0, helpers_1.upload)(ctx)
                        .then((data) => {
                        resolve(data);
                    })
                        .catch((data) => {
                        reject((data["state"] = "ERROR"));
                    });
                });
            };
            ctx.datas = await getDatas();
            const odataVisitor = await (0, odata_1.createOdata)(ctx);
            if (odataVisitor)
                ctx.odata = odataVisitor;
            if (ctx.odata) {
                console.log(log_1.logging.head("POST FORM").toString());
                const objectAccess = new dataAccess_1.apiAccess(ctx);
                const returnValue = await objectAccess.post();
                if (ctx.datas)
                    fs_1.default.unlinkSync(ctx.datas["file"]);
                if (returnValue) {
                    if (ctx.datas["source"] == "query") {
                        const tempContext = await (0, helpers_2.createQueryParams)(ctx);
                        if (tempContext) {
                            const bodyQuery = new views_1.Query(ctx, {
                                url: "",
                                queryOptions: {
                                    ...tempContext,
                                    results: JSON.stringify({
                                        added: returnValue.total,
                                        value: returnValue.body
                                    })
                                }
                            });
                            ctx.set("script-src", "self");
                            ctx.set("Content-Security-Policy", "self");
                            ctx.type = helpers_1.returnFormats.html.type;
                            if (returnValue.location)
                                ctx.set("Location ", returnValue.location);
                            ctx.body = bodyQuery.toString();
                        }
                    }
                    else {
                        helpers_1.returnFormats.json.type;
                        ctx.status = 201 /* EHttpCode.created */;
                        if (returnValue.location)
                            ctx.set("Location ", returnValue.location);
                        ctx.body = returnValue.body;
                    }
                }
                else {
                    ctx.throw(400 /* EHttpCode.badRequest */);
                }
            }
        }
        else {
            // payload is malformed
            ctx.throw(400 /* EHttpCode.badRequest */, { details: messages_1.errors.payloadIsMalformed });
        }
    }
    else
        ctx.throw(401 /* EHttpCode.Unauthorized */);
});
exports.protectedRoutes.patch("/(.*)", async (ctx) => {
    if ((!ctx.service.extensions.includes(enums_1.EExtensions.users) || (0, helpers_1.isAllowedTo)(ctx, enums_1.EUserRights.Post) === true) && Object.keys(ctx.body).length > 0) {
        const odataVisitor = await (0, odata_1.createOdata)(ctx);
        if (odataVisitor)
            ctx.odata = odataVisitor;
        if (ctx.odata) {
            console.log(log_1.logging.head("PATCH").toString());
            const objectAccess = new dataAccess_1.apiAccess(ctx);
            if (ctx.odata.id) {
                const returnValue = await objectAccess.update();
                if (returnValue) {
                    helpers_1.returnFormats.json.type;
                    ctx.status = 201 /* EHttpCode.created */;
                    ctx.body = returnValue.body;
                    if (returnValue.location)
                        ctx.set("Location", returnValue.location);
                }
            }
            else {
                ctx.throw(400 /* EHttpCode.badRequest */, { detail: messages_1.errors.idRequired });
            }
        }
        else {
            ctx.throw(404 /* EHttpCode.notFound */);
        }
    }
    else {
        ctx.throw(401 /* EHttpCode.Unauthorized */);
    }
});
exports.protectedRoutes.delete("/(.*)", async (ctx) => {
    if (!ctx.service.extensions.includes(enums_1.EExtensions.users) || (0, helpers_1.isAllowedTo)(ctx, enums_1.EUserRights.Delete) === true) {
        const odataVisitor = await (0, odata_1.createOdata)(ctx);
        if (odataVisitor)
            ctx.odata = odataVisitor;
        if (ctx.odata) {
            console.log(log_1.logging.head("DELETE").toString());
            const objectAccess = new dataAccess_1.apiAccess(ctx);
            if (!ctx.odata.id)
                ctx.throw(400 /* EHttpCode.badRequest */, { detail: messages_1.errors.idRequired });
            const returnValue = await objectAccess.delete(ctx.odata.id);
            if (returnValue && returnValue.body && +returnValue.body > 0) {
                helpers_1.returnFormats.json.type;
                ctx.status = 204 /* EHttpCode.noContent */;
            }
            else
                ctx.throw(404 /* EHttpCode.notFound */, { code: 404 /* EHttpCode.notFound */, detail: messages_1.errors.noId + ctx.odata.id });
        }
        else {
            ctx.throw(404 /* EHttpCode.notFound */);
        }
    }
    else {
        ctx.throw(401 /* EHttpCode.Unauthorized */);
    }
});
