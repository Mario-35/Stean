"use strict";
/**
 * Index Routes
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.routerHandle = exports.protectedRoutes = exports.unProtectedRoutes = void 0;
const authentication_1 = require("../authentication");
const constants_1 = require("../constants");
const log_1 = require("../log");
const helpers_1 = require("../helpers");
const helper_1 = require("./helper");
const messages_1 = require("../messages");
const configuration_1 = require("../configuration");
const models_1 = require("../models");
var unProtected_1 = require("./unProtected");
Object.defineProperty(exports, "unProtectedRoutes", { enumerable: true, get: function () { return unProtected_1.unProtectedRoutes; } });
var protected_1 = require("./protected");
Object.defineProperty(exports, "protectedRoutes", { enumerable: true, get: function () { return protected_1.protectedRoutes; } });
const querystring_1 = __importDefault(require("querystring"));
const paths_1 = require("../paths");
const routerHandle = async (ctx, next) => {
    // copy body
    ctx.body = ctx.request.body;
    // if configuration exist
    if (configuration_1.config.configFileExist() === true)
        await configuration_1.config.trace.write(ctx); // trace request
    else
        return await (0, helper_1.adminRoute)(ctx); // admin route for first start
    // create token
    (0, helpers_1.createBearerToken)(ctx);
    // decode url
    const decodedUrl = (0, helper_1.decodeUrl)(ctx);
    // if logs show log file
    if (ctx.path.includes("logs-"))
        return (0, helper_1.logsRoute)(ctx, paths_1.paths.root + "logs\\" + `${decodedUrl ? decodedUrl.path : ctx.path}`);
    // Specials routes
    switch ((0, helpers_1.splitLast)(ctx.path, "/").toLocaleUpperCase()) {
        // admin page
        case "ADMIN":
            return await (0, helper_1.adminRoute)(ctx);
        // export page
        case "EXPORT":
            if (!decodedUrl)
                await (0, helper_1.exportRoute)(ctx);
        // logging for all
        case "DOCUMENTATION":
            if (!decodedUrl)
                return await (0, helper_1.docRoute)(ctx);
        case "LOGGING":
            if (!decodedUrl)
                return await (0, helper_1.logsRoute)(ctx, paths_1.paths.logFile.fileName);
    }
    // error decodedUrl
    if (!decodedUrl) {
        ctx.type = helpers_1.returnFormats.json.type;
        ctx.throw(404 /* EHttpCode.notFound */);
    }
    // copy decodedUrl context
    ctx.decodedUrl = decodedUrl;
    if ((0, helpers_1.splitLast)(ctx.path, "/").toLocaleUpperCase().startsWith("REPLAYS(")) {
        await configuration_1.config.trace.rePlay(ctx);
    }
    if (constants_1._DEBUG)
        console.log(log_1.logging.message("decodedUrl", decodedUrl));
    // if service is not identified get out
    if (!decodedUrl.service)
        throw new Error(messages_1.errors.noNameIdentified);
    // get service
    if (decodedUrl.service && decodedUrl.configName)
        ctx.service = configuration_1.config.getService(decodedUrl.configName);
    else
        return;
    // forcing post loras with different version IT'S POSSIBLE BECAUSE COLUMN ARE THE SAME FOR ALL VERSION
    if (decodedUrl.version != ctx.service.apiVersion) {
        if (!(ctx.request.method === "POST" && ctx.originalUrl.includes(`${decodedUrl.version}/Loras`)))
            ctx.redirect(ctx.request.method === "GET" ? ctx.originalUrl.replace(String(decodedUrl.version), ctx.service.apiVersion) : `${ctx.decodedUrl.linkbase}/${ctx.service.apiVersion}/`);
    }
    // Clean query string
    ctx.querystring = ctx.request.method === "POST" && ctx.originalUrl.includes(`${decodedUrl.version}/Loras`) ? "" : decodeURIComponent(querystring_1.default.unescape(ctx.querystring));
    // get model
    ctx.model = models_1.models.filtered(ctx.service);
    try {
        // Init config context
        if (!ctx.service)
            return;
        ctx.user = (0, authentication_1.decodeToken)(ctx);
        await next().then(async () => { });
    }
    catch (error) {
        // In prod console is romoved
        console.log("\x1b[31m▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ route error ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\x1b[0m");
        console.log(error);
        console.log("\x1b[31m▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\x1b[0m");
        const tempError = {
            code: error.statusCode || null,
            message: error.message || null,
            detail: error.detail
        };
        ctx.status = error.statusCode || error.status || 500 /* EHttpCode.internalServerError */;
        ctx.body = error.link ? { ...tempError, link: error.link } : tempError;
        configuration_1.config.trace.error(ctx, tempError);
    }
};
exports.routerHandle = routerHandle;
